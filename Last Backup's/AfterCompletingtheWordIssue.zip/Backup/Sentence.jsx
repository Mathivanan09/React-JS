import React, { useState, useEffect } from 'react';
import parse from "html-react-parser";
import PropTypes from 'prop-types';

/**
 * React functional component which renders Sentences selection based on selection type.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace Sentences
 *
 * @function Sentences - React functional container component for Seneteces selectionType
 * @param {object} item - JSON data that will contain the item information
 * for displaying select text item
 * @param {object} divUUID - Id for the div to be rendered
 * @param {boolean} showCorrectResponse -  display Correct Response checkbox value
 * @param {object} buildDataForHighlight - Build Correct Response for Highlighting
 * @param {object} correctResponseHighlight - Highlighted Correct Response Data
 * @return {component} - container for Sentences selection of passage content
 *
 */
const Sentences = ({
    item,
    divUUID,
    showCorrectResponse,
    buildDataForHighlight,
    correctResponseHighlight
}) => {

    const content = item?.item_json || {};
    const [parsedPassageContent, setParsedPassageContent] = useState(item?.item_json.passageContent);

    useEffect(() => {
        generateContentForCorrectResponse();
        // eslint-disable-next-line
    }, [content, showCorrectResponse]);

    useEffect(() => {
        correctResponseHighlight();
    });

    //This method is to set the content in the correct response section based on type selection
    const generateContentForCorrectResponse = () => {
      // console.log(item)
        let passageContent = " ", updatedPassageContent = parsedPassageContent, divElement = document.createElement("div");

        divElement.innerHTML = item?.item_json?.passageContent;
        passageContent = item?.item_json?.passageContent;

        for (let i = 0; i < content?.optionList?.length; i++) {
            if (content.optionList[i].optionText !== "" && content.optionList[i].optionText !== "-") {
                // This logic will execute for make the correct response with selectable for Sentences
                // eslint-disable-next-line
                let regex = "", optionText = content.optionList[i].optionText, format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
// console.log(passageContent)
                passageContent = passageContent.replace(/&nbsp;/gi, " ");
// console.log(passageContent)
                passageContent = passageContent.replace(/\?/gi, "QEST_MARK");
                optionText = optionText.replace(/\?/gi, "QEST_MARK");
                regex = optionText.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
                if (optionText.slice(-1).match(format) === null && optionText.slice(-1).match(/[a-z0-9]/i) === null) {
                    regex = new RegExp("(<=\\s|\\b)" + regex);
                } else if (optionText.slice(-1).match(format) !== null && optionText.slice(0, 1).match(/[a-z0-9]/i) !== null) {
                    regex = new RegExp("\\b" + regex, "");
                } else if ((optionText.slice(-1).match(format) !== null || optionText.endsWith("QEST_MARK", optionText.length)) && (optionText.slice(0, 1).match(/[a-z0-9]/i) === null) || (optionText.slice(0, 1).match(format) !== null)) {
                    //RegX below is used if the starting letter is any special character.
                    regex = new RegExp("(?=[]\\b|\\W)" + regex + "(?=[]\\b|\\W)");
                } else {
                    regex = new RegExp("\\b" + regex + "\\b", "");
                }
                passageContent = passageContent.replace(regex, buildDataForHighlight(content.optionList[i].id, optionText));
                passageContent = passageContent.replace(/QEST_MARK/gi, "?");
            }
        }
        if (passageContent !== "" && passageContent !== undefined) {
            //Regular expression is used for removing all the 'Cb_High_Light' strings from the correct response content
            passageContent = passageContent.replace(/SPAN_SPACE/gi, " ");
            passageContent = passageContent.replace(/<\s*\/\s*span[^>]*>/gi, "</span>");
            updatedPassageContent = passageContent?.replace(/Cb_High_Light/gi, "");
        }
        // console.log(updatedPassageContent);
        if (updatedPassageContent !== parsedPassageContent) {
            setParsedPassageContent(updatedPassageContent);
        }
    };

    return (
        <div id={divUUID}>
            <div className='row item-content m-1 mt-4 p-4 content_style'>{parse(parsedPassageContent || '<div></div>')}</div>
        </div>
    );
};

Sentences.propTypes = {
    item: PropTypes.object,
    divUUID: PropTypes.string,
    showCorrectResponse: PropTypes.bool,
    buildDataForHighlight: PropTypes.func,
    correctResponseHighlight: PropTypes.func
};

export default Sentences;
