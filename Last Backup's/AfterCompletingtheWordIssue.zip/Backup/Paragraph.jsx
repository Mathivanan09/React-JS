/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react';
import parse from "html-react-parser";
import PropTypes from 'prop-types';
import { CLASS } from "./constants";

/**
 * React functional component which renders Paragraph selection based on selection type.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace Paragraphs
 *
 * @function Paragraphs - React functional container component for Paragraphs selectionType
 * @param {object} item - JSON data that will contain the item information
 * for displaying select text item
 * @param {object} divUUID - Id for the div to be rendered
 * @param {boolean} showCorrectResponse -  display Correct Response checkbox value
 * @param {object} buildCorrectResponse - Build correct response for the passage content written based on selection type choosed
 * @param {function} getClassName - return the class names based on id
 * @return {component} - container for Paragraph selection of passage content
 *
 */
const Paragraphs = ({
  item,
  divUUID,
  showCorrectResponse,
  buildCorrectResponse,
  getClassName
}) => {

  const content = item?.item_json || {};
  const [parsedPassageContent, setParsedPassageContent] = useState(content.passageContent);

  useEffect(() => {
    generateContentForCorrectResponse();
    // eslint-disable-next-line
  }, [content, showCorrectResponse]);

  useEffect(() => {
    const container = document.getElementById(divUUID);
    if (container !== undefined) {
      container.querySelectorAll("p").forEach(para => {
        if (para?.id) {
          para.className = getClassName(para.id) + " st-border-margin";
          para.onclick = buildCorrectResponse;
        }
      });
    }
  });

  //This method is to set the content in the correct response section based on type selection
  const generateContentForCorrectResponse = () => {
    let updatedPassageContent = "";
    for (let i = 0; i < content?.optionList?.length; i++) {
      if (content.optionList[i].optionText !== "" && content.optionList[i].optionText !== "-") {
        const tempElement = document.createElement("div");
        tempElement.innerHTML = content.passageContent || '';
        const paragraphElements = tempElement.getElementsByTagName("p")
        const paragraphElement = paragraphElements?.[i];
        if (paragraphElement !== undefined) {
          const id = content.optionList[i].id;
          paragraphElement.setAttribute('id', id);
          paragraphElement.setAttribute(CLASS, getClassName(id) + " st-border-margin");
          updatedPassageContent = updatedPassageContent + paragraphElement.outerHTML;
        }
      }
    }
    if (updatedPassageContent && updatedPassageContent !== parsedPassageContent) {
      setParsedPassageContent(updatedPassageContent);
    }
  };
  console.log(parsedPassageContent)

  return (
    <div id={divUUID}>
      <div className='row item-content m-1 mt-4 p-4 content_style'>{parse(parsedPassageContent || '<div></div>')}</div>
    </div>
  );
};

Paragraphs.propTypes = {
  item: PropTypes.object,
  divUUID: PropTypes.string,
  showCorrectResponse: PropTypes.bool,
  buildCorrectResponse: PropTypes.func,
  getClassName: PropTypes.func
};

export default Paragraphs;
