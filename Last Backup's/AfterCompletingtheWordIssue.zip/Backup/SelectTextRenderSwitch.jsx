/* eslint-disable react/prop-types */
import React, { useState } from 'react';
import uuid from "react-uuid";
import PropTypes, { element } from 'prop-types';
import parse from "html-react-parser";
import Words from './Words';
import Sentences from './Sentence';
import Paragraphs from './Paragraph';
import Manual_Selection from './Manual_Selection';
import {
  CLASS,
  ST_RED,
  ST_BLACK,
  ST_YELLOW,
  SELECTED_RESPONSE_CLASS,
  WHOLE_WORDS,
  WHOLE_SENTENCES,
  WHOLE_PARAGRAPHS,
  MANUALLY_SELECTED_RESPONSE
} from "./constants";

/**
 * React functional component which switches selection type between item jsons selectionType value.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace SelectTextRenderSwitch
 *
 * @function SelectTextRenderSwitch - React functional component to select
 * the requried selection type component to render
 * @param {object} item - JSON data that will contain the item information
 * for displaying select text item
 * @param {string} selectionType - Selectiontype choosen to highlight/select the passage content
 * @param {object} classNameForCR - Updated ClassName in correct response based on selection type
 * @return {component} - component which need to be rendered for selected selectionType type
 *
 */

const SelectTextRenderSwitch = ({
  item,
  config,
  onUpdate,
  selectionType,
  classNameForCR,
  showCorrectResponse,
  responseOnly
}) => {
  const [divUUID] = useState(item?.item_json?.uuid || uuid());
  const [selections, setSelections] = useState([]);
  const classes = classNameForCR.borderOnStart + classNameForCR.borderOnHover + classNameForCR.highlightHover + classNameForCR.highlightStart;

  //To get selected id from item json correct response
  let responseData = [];
  for (let i = 0; i < item?.item_json?.correctResponse?.length; i++) {
    if (item?.item_json?.correctResponse[i].value === true) {
      responseData.push(item?.item_json?.correctResponse[i].id);
    }
  }

  function getOnSelectClassNames() {
    let classNameForCR = "";
    if (item?.item_json?.highlightOnSelect === ST_YELLOW) {
      classNameForCR = SELECTED_RESPONSE_CLASS;
    } else {
      classNameForCR = " st-selected-response-none";
    }

    if (item?.item_json?.borderOnSelect === ST_RED) {
      if (item?.item_json?.boldedBorderOnSelect === true) {
        classNameForCR = classNameForCR + " st-bold-border-select-red";
        if (item?.item_json?.boldedBorderOnSelect) {
          classNameForCR = classNameForCR + " st-bold-border-select-red border border-3";
        }
      } else {
        classNameForCR = classNameForCR + " st-border-select-red";
      }
    } else if (item?.item_json?.borderOnSelect === ST_BLACK) {
      if (item?.item_json?.boldedBorderOnSelect === true) {
        classNameForCR = classNameForCR + " st-bold-border-select-black";
        if (item?.item_json?.boldedBorderOnSelect) {
          classNameForCR = classNameForCR + " st-bold-border-select-black border border-3";
        }
      } else {
        classNameForCR = classNameForCR + " st-border-select-black";
      }
    }
    return classNameForCR;
  }

  const getClassName = (id, showCorrectResponse) => {
    const responses = (responseOnly || showCorrectResponse) ? responseData : selections;
    let classNames = "st-highlight ";
    if (responses.includes(id)) {
      classNames += getOnSelectClassNames();
    }
    classNames += classes;
    return classNames?.trim() || '';
  }

  //Common method to set the html element for highlighting
  const buildDataForHighlight = (id, optionText, showCorrectResponse) => {
    // console.log(optionText)
    let spanElement = document.createElement("span");
    spanElement.setAttribute("id", id);
    spanElement.setAttribute(CLASS, getClassName(id, showCorrectResponse));
    spanElement.innerHTML = "Cb_High_Light" + optionText;
    // console.log(spanElement.outerHTML)
    return spanElement.outerHTML;
  };

  const correctResponseHighlight = (showCorrectResponse) => {
    if (item?.item_json?.selectionType !== MANUALLY_SELECTED_RESPONSE) {
      const container = document.getElementById(divUUID);
      if (container !== undefined && container !== null) {
        container.querySelectorAll("span.st-highlight").forEach(span => {
          if (span?.id) {
            span.className = getClassName(span?.id, showCorrectResponse)
          }
          span.onclick = (e) => buildCorrectResponse(e, showCorrectResponse);
        });
      }
    }
  };

  // This Handler is used to build the correct response based on user selection
  // added the showCorrectResponse as a parameter to fix the correct response data not updated properly within the click function
  const buildCorrectResponse = (e, showCorrectResponse) => {
    e.preventDefault();
    if (!responseOnly && showCorrectResponse) {
      return;
    }
    const container = e.target.closest(`[id="${divUUID}" ]`);
    if (container) {
      let selectedtext = e.target;
      if (selectionType === WHOLE_PARAGRAPHS) {
        for (let i = 0; i < item?.item_json?.optionList?.length; i++) {
          if (selectedtext.innerText === item?.item_json?.optionList[i].optionText) {
            selectedtext.id = item?.item_json?.optionList[i].id
          }
        }
      }

      let foilsIdValue = item?.item_json?.optionList?.filter(function (foil) {
        return foil.id === selectedtext.id;
      });

      if (foilsIdValue?.length === 0) {
        selectedtext = e.target.parentElement;
        foilsIdValue = item?.item_json?.optionList.filter(function (foil) {
          return foil.id === selectedtext.id;
        });
      }

      if (foilsIdValue.length !== 0) {
        //if the preview is only for showing correct response then restricting user actions
        if (selectedtext.id === undefined || selectedtext.id === "") {
          selectedtext = e.currentTarget;
        }

        const responses = responseOnly ? responseData : selections;
        if (selectedtext !== null && selectedtext.getAttribute(CLASS) !== null
          && selectedtext.getAttribute(CLASS) !== "" && responses.includes(selectedtext.id)) {
          let className = selectedtext.getAttribute(CLASS).replace(/st-border-select-black/gi, "")
            .replace(/st-border-select-red/gi, "").replace(/st-selected-response/gi, "")
            .replace(/st-bold-border-select-red/gi, "").replace(/st-bold-border-select-black/gi, "");
          selectedtext.setAttribute(CLASS, className);
          if (responses.includes(selectedtext.id)) {
            const optIndex = responses.findIndex((element) => element === selectedtext.id);
            responses.splice(optIndex, 1);
          }
        } else {
          let className = selectedtext.getAttribute(CLASS);
          if (item?.item_json?.borderOnSelect === ST_RED) {
            if (item?.item_json?.boldedBorderOnSelect === true) {
              className.replace(/st-border-select-black/gi, "");
              className = className + " st-bold-border-select-red";
            } else {
              className.replace(/st-border-select-black/gi, "");
              className = className + " st-border-select-red";
            }
          } else if (item?.item_json?.borderOnSelect === ST_BLACK) {
            if (item?.item_json?.boldedBorderOnSelect === true) {
              className.replace(/st-border-select-red/gi, "");
              className = className + " st-bold-border-select-black";
            } else {
              className.replace(/st-border-select-red/gi, "");
              className = className + " st-border-select-black";
            }
          } else {
            className = selectedtext.getAttribute(CLASS);
          }

          if (item?.item_json?.highlightOnSelect === ST_YELLOW) {
            className = className + " st-selected-response-yellow";
          } else {
            className = className + " st-selected-response-none";
          }

          if (item?.item_json?.maxResponseSelection === "" || responses.length < item?.item_json?.maxResponseSelection) {
            selectedtext.setAttribute(CLASS, className);
            responses.push(selectedtext.id);
          }
        }
        if (responseOnly) {
          if (onUpdate !== undefined) {
            let correctResponseData = [];
            item?.item_json?.optionList.map((option) => {
              let crData = {};
              if (responses.includes(option.id)) {
                crData.id = option.id;
                crData.value = true;
              } else {
                crData.id = option.id;
                crData.value = false;
              }
              correctResponseData.push(crData);
            })

            const updatedItem = {
              item_json: {
                correctResponse: correctResponseData
              }
            };
            onUpdate(updatedItem);
          }
        } else {
          setSelections(responses);
        }
      }
    }
  };

  switch (selectionType) {

    case WHOLE_PARAGRAPHS:
      return (
        <Paragraphs
          item={item}
          divUUID={divUUID}
          showCorrectResponse={showCorrectResponse}
          buildCorrectResponse={(e) => buildCorrectResponse(e, showCorrectResponse)}
          getClassName={(id) => getClassName(id, showCorrectResponse)}
        />
      );

    case WHOLE_SENTENCES:
      return (
        <Sentences
          item={item}
          divUUID={divUUID}
          showCorrectResponse={showCorrectResponse}
          buildDataForHighlight={(id, optionText) => buildDataForHighlight(id, optionText, showCorrectResponse)}
          correctResponseHighlight={() => correctResponseHighlight(showCorrectResponse)}
        />
      );

    case WHOLE_WORDS:
      return (
        <Words
          item={item}
          divUUID={divUUID}
          showCorrectResponse={showCorrectResponse}
          buildDataForHighlight={(id, optionText) => buildDataForHighlight(id, optionText, showCorrectResponse)}
          correctResponseHighlight={() => correctResponseHighlight(showCorrectResponse)}
        />
      );

    case MANUALLY_SELECTED_RESPONSE:
      return (
        <Manual_Selection
          item={item}
          config={config}
          divUUID={divUUID}
          selections={selections}
          responseOnly={responseOnly}
          classNameForCR={classNameForCR}
          correctResponseData={responseData}
          showCorrectResponse={showCorrectResponse}
          buildCorrectResponse={(e) => buildCorrectResponse(e, showCorrectResponse)}
          getClassName={(id) => getClassName(id, showCorrectResponse)}
          getOnSelectClassNames={getOnSelectClassNames}
        />
      );

    default:
      return (
        <div className='row item-content m-1 mt-4 p-4 content_style' >
          {
            parse(item?.item_json?.passageContent || '<div></div>')
          }
        </div>
      );
  }
};

SelectTextRenderSwitch.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  selectionType: PropTypes.string,
  classNameForCR: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  responseOnly: PropTypes.bool
};

export default SelectTextRenderSwitch;
