/**
 * Messages that are used across the application will be defined in this file
 * 
 * @inner
 * @memberof UtilityMethods 
 * 
 * @function
 * @namespace messages 
 *
 */

export default {
    warning_message: "Warning Message",
    min_selections_exceed: "Min selections can't be more than number of hotspots.",
    max_selections_exceed: "Max Selections can't be more than number of hotspots.",
    min_max_selections_exceed: "Min selections can't be more than Max selections.",
    item_delete_info: "Please confirm, if you want to delete the item(s) ",
    item_delete_success_info: "Please confirm, if you want to delete the item(s) ",
    item_delete_success_info: "Please confirm, if you want to delete the item(s) ",
    mc_maximum_selected: "Maximum number of selections made.",
    
};
