/**
 * @file styleCode - Style code constants that are
 * used across the application will be defined in this file
 *
 * example:
 *
 * styleCodes.ALTERNATE
 */
export const ALTERNATE = 'alternate';
export const GENERAL = 'general';
export const KELPA_GRADE_K_1 = 'kelpa_grade_k_1';
export const KELPA_GRADE_2_3 = 'kelpa_grade_2_3';
export const KELPA_GRADE_4_12 = 'kelpa_grade_4_12';
