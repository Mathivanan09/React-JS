import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";

// import component here
import DisplayInterface from './DisplayInterface';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

/**
 * Test an empty component and verify the element with Missing item data
 */
it("Test default component", () => {
  act(() => {
    render(
      <DisplayInterface />, container);
  });

  expect(container.children).toBeNull;
  const emptyComponent = document.querySelector("[data-testid=missing-item]");
  expect(emptyComponent).toBeNull;
});

/**
 * Test non implemented item
 */
it("Test non implemented item", () => {
  act(() => {
    render(
      <DisplayInterface item={{
        item_json: {
          itemTypeCode: 'XYZ'
        }
      }
      } />, container);
  });

  expect(container.children).toBeNull;
  const notImplemented = document.querySelector("[data-testid=not-implemented]");
  expect(notImplemented).not.toBeNull;
  expect(notImplemented.textContent).toBe('xyz Not implemented');
});

/**
 * Test component by passing skeleton item json and verify the 
 * elements and values when opened from new  item
 */
it("Test skeleton component when opened from new item", () => {
  act(() => {
    render(
      <DisplayInterface item={{
        item_json: {
          itemTypeCode: 'MC'
        }
      }
      } />, container);
  });

  /**
   * Verify that root element and the components root element are rendered
   */
  expect(container.children.length).toBe(1);
  // Make sure that the parent element is rendered
  expect(container.children[0].className).toContain('content_style');
  // Make sure that the children from individual components are rendered
  expect(container.children[0].children.length).toBeGreaterThan(0);
  
});

/**
 * Test component by passing clickHistory object
 */
 it("Test click history", () => {
   let clickHistory = {};
  act(() => {
    render(
      <DisplayInterface item={{
        id: -1,
        itemTypeCategory: 'question',
        item_json: {
          itemTypeCode: 'MC'
        }
      }
      } 
      config={{clickHistoryRequired: true}}
      clickHistory={clickHistory}/>, container);
  });

  /**
   * Verify that clickHistory basic attributes are updated if enabled
   */
  expect(container.children.length).toBe(1);
  // Make sure that the parent element is rendered
  expect(container.children[0].className).toContain('content_style');
  // Make sure that the children from individual components are rendered
  expect(container.children[0].children.length).toBeGreaterThan(0);
  expect(clickHistory.id).toBe(-1);
  expect(clickHistory.itemTypeCategory).toBe('question');
  expect(clickHistory.itemType).toBe('MC');
  
});