/**
 * @file Two Column Click Simulation Item Preview Component Test
 */
import React from 'react';
import { act } from 'react-dom/test-utils';
import { unmountComponentAtNode } from 'react-dom';
import { render, fireEvent, screen } from '@testing-library/react';

// import component here
import TwoColumnClickPreview from './TwoColumnClickPreview';

// Test Data
import TWO_COLUMN_DATA from '../../../../stories/assets/tcc/tcc_two_column.json';
import THREE_COLUMN_DATA from '../../../../stories/assets/tcc/tcc_three_column.json';

let container = null;

beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement('div');
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('Two Column Click Simulation Item Preview Component Test', () => {
    test('Testing Loading of TCC Preview Component with empty item json data', () => {
        // set up test mock data 
        let content;
        const config = {
            clickHistoryRequired: false
        };

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => {
            content = data;
        });

        act(() => {
            render(
                <TwoColumnClickPreview item={content} onUpdate={onUpdate} config={config} />,
                container
            );
        });

        // check the TCC Preview Component exists and loaded or not
        expect(screen.getByTestId('preview-container')).toBeInTheDocument();
        expect(screen.getByTestId('stem-content')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-preivew')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-title')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-container')).toBeInTheDocument();

        expect(onUpdate).toHaveBeenCalledTimes(0);

        expect(document.querySelectorAll('[data-testid=tcc-tab-left]').length).toBe(0);
        expect(document.querySelectorAll('[data-testid=tcc-sub-tab-middle]').length).toBe(0);
        expect(document.querySelectorAll('[data-testid=tcc-sub-tab-right]').length).toBe(0);

    });

    test('Testing Tab with New Two Column Click data with two column type', () => {
        // set up test mock data 
        let clickHistory = {};
        let content = { ...TWO_COLUMN_DATA?.item };
        const config = {
            clickHistoryRequired: true
        };

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => {
            content = data;
        });

        let update;
        act(() => {
            const { rerender } = render(
                <TwoColumnClickPreview item={content} onUpdate={onUpdate} config={config} clickHistory={clickHistory} />,
                container
            );
            update = rerender;
        });

        // check the TCC Preview Component exists and loaded or not
        expect(screen.getByTestId('preview-container')).toBeInTheDocument();
        expect(screen.getByTestId('stem-content')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-preivew')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-title')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-container')).toBeInTheDocument();

        expect(onUpdate).toHaveBeenCalledTimes(0);

        // is item data and column type validation passed, and check the tab(s)/subtab(s) component exists and loaded or not
        expect(screen.getByTestId('tcc-tab-left')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-right')).toBeInTheDocument();

        // two column type should have only two column
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-middle]').length).toBe(0);

        // check the menu in the main tab
        const firstTab = screen.getByTestId('tcc-tab-menu-1');
        const secondTab = screen.getByTestId('tcc-tab-menu-2');
        const description = screen.getByTestId('tcc-sub-tab-description');
        expect(firstTab).toBeInTheDocument();
        expect(secondTab).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tab-menu-]').length).toBe(4);

        // check the tab menu content
        expect(screen.getByTestId('tcc-tab-menu-content-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-menu-content-2')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tab-menu-content]').length).toBe(2);

        // check the default tab is selected or not
        expect(firstTab.attributes['aria-selected'].value).toBe('true');
        expect(secondTab.attributes['aria-selected'].value).toBe('false');
        expect(content.item_json.optionList[0].items[0].right === description?.innerHTML).toBe(true);

        act(() => {
            // trigger the click event to navigate to the second tab with two column column type
            fireEvent.click(secondTab);
        });

        expect(onUpdate).toHaveBeenCalledTimes(0);

        // check the second tab selected or not
        expect(firstTab.attributes['aria-selected'].value).toBe('false');
        expect(secondTab.attributes['aria-selected'].value).toBe('true');
        expect(content.item_json.optionList[1].items[0].right === description?.innerHTML).toBe(true);

        // check the click history
        expect(clickHistory.numberOfColumns).toBe('twocolumn');
        expect(clickHistory?.options).toBeDefined();
        expect(clickHistory.options[0].optionId).toBeDefined();
        expect(content.item_json.optionList[1].id === clickHistory.options[0].optionId).toBe(true);

        // disabled click history
        config.clickHistoryRequired = false;
        clickHistory = {};
        update(
            <TwoColumnClickPreview item={content} onUpdate={onUpdate} config={config} clickHistory={clickHistory} />,
            container
        );

        act(() => {
            // trigger the click event to navigate to the first tab with two column column type
            fireEvent.click(firstTab);
        });

        // check the disabled click history value
        expect(clickHistory?.numberOfColumns).toBeUndefined();
        expect(clickHistory?.options).toBeUndefined();

    });

    test('Testing Add Tab with New Two Column Click data with three columnType', () => {
        // set up test mock data 
        let clickHistory = {};
        let content = { ...THREE_COLUMN_DATA?.item };
        const config = {
            clickHistoryRequired: true
        };

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => {
            content = data;
        });

        let update;
        act(() => {
            const { rerender } = render(
                <TwoColumnClickPreview item={content} onUpdate={onUpdate} config={config} clickHistory={clickHistory} />,
                container
            );
            update = rerender;
        });

        // check the TCC Preview Component exists and loaded or not
        expect(screen.getByTestId('preview-container')).toBeInTheDocument();
        expect(screen.getByTestId('stem-content')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-preivew')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-title')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-container')).toBeInTheDocument();

        expect(onUpdate).toHaveBeenCalledTimes(0);

        // is item data and column type validation passed, and check the tab(s)/subtab(s) component exists and loaded or not
        expect(screen.getByTestId('tcc-tab-left')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-middle')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-right')).toBeInTheDocument();

        // check the menu in the main tab
        const firstMainTab = screen.getByTestId('tcc-tab-menu-1');
        const secondMainTab = screen.getByTestId('tcc-tab-menu-2');
        const thirdMainTab = screen.getByTestId('tcc-tab-menu-3');
        const description = screen.getByTestId('tcc-sub-tab-description');

        expect(firstMainTab).toBeInTheDocument();
        expect(secondMainTab).toBeInTheDocument();
        expect(thirdMainTab).toBeInTheDocument();

        // check the tab menu content
        expect(screen.getByTestId('tcc-tab-menu-content-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-menu-content-2')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-menu-content-3')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tab-menu-]').length).toBe(6);
        expect(document.querySelectorAll('[data-testid^=tcc-tab-menu-content-]').length).toBe(3);

        // check the default tab is selected or not
        expect(firstMainTab.attributes['aria-selected'].value).toBe('true');
        expect(secondMainTab.attributes['aria-selected'].value).toBe('false');
        expect(thirdMainTab.attributes['aria-selected'].value).toBe('false');
        expect(content.item_json.optionList[0].items[0].right === description?.innerHTML).toBe(true);

        // check the sub-tab menu
        let firstSubTab = screen.getByTestId('tcc-sub-tab-menu-1-1');
        let secondSubTab = screen.getByTestId('tcc-sub-tab-menu-1-2');
        expect(firstSubTab).toBeInTheDocument();
        expect(secondSubTab).toBeInTheDocument();

        // check the sub-tab menu content
        expect(screen.getByTestId('tcc-sub-tab-menu-1-content-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-menu-1-content-2')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-menu-1-]').length).toBe(4);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-menu-1-content-]').length).toBe(2);

        act(() => {
            // trigger the click event to navigate to the third tab with three column column type
            fireEvent.click(thirdMainTab);
        });

        firstSubTab = screen.getByTestId('tcc-sub-tab-menu-3-1');

        act(() => {
            // trigger the click event to navigate to the second tab with three column column type
            fireEvent.click(firstSubTab);
        });

        expect(onUpdate).toHaveBeenCalledTimes(0);

        // check the thrid tab selected or not
        expect(firstMainTab.attributes['aria-selected'].value).toBe('false');
        expect(secondMainTab.attributes['aria-selected'].value).toBe('false');
        expect(thirdMainTab.attributes['aria-selected'].value).toBe('true');

        expect(firstSubTab).toBeInTheDocument();

        // check the sub-tab menu content
        expect(screen.getByTestId('tcc-sub-tab-menu-3-content-1')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-menu-3-]').length).toBe(2);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-menu-3-content-]').length).toBe(1);

        expect(content.item_json.optionList[2].items[0].right === description?.innerHTML).toBe(true);

        // check the click history
        expect(clickHistory.numberOfColumns).toBe('threecolumn');
        expect(clickHistory?.options).toBeDefined();
        expect(clickHistory.options[0].optionId).toBeDefined();
        expect(content.item_json.optionList[2].id === clickHistory.options[0].optionId).toBe(true);
        expect(content.item_json.optionList[2].items[0].id === clickHistory.options[1].optionId).toBe(true);

        // disabled click history
        config.clickHistoryRequired = false;
        clickHistory = {};

        act(() => {
            // trigger the click event to navigate to the third tab with three column column type
            fireEvent.click(secondMainTab);
        });

        secondSubTab = screen.getByTestId('tcc-sub-tab-menu-2-2');

        act(() => {
            // trigger the click event to navigate to the second tab with three column column type
            fireEvent.click(secondSubTab);
        });

        update(
            <TwoColumnClickPreview item={content} onUpdate={onUpdate} config={config} clickHistory={clickHistory} />,
            container
        );

        expect(secondSubTab).toBeInTheDocument();

        // check the disabled click history value
        expect(clickHistory?.numberOfColumns).toBeUndefined();
        expect(clickHistory?.options).toBeUndefined();
    });

});