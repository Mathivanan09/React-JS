import React, { useState } from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { setShuffle } from '../../../../utility/shuffleList';
import { itemPreviewProps } from '../../../common/ItemHelper';

import MatrixInteractionResponse from '../../response/matrixinteraction/MatrixInteractionResponse';

import '../../../../styles/item/MatrixInteractionPreview.css';

/**
 * React functional component to display Matrix Interaction click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace MatrixInteractionPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Matrix Interaction click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - MatrixInteractionPreview component for displaying Matrix Interaction click item
 */

const MatrixInteractionPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  let itemJson = item?.item_json;
  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  //method to generated shuffled response option based on user selection
  let shuffleNumber = Math.floor(Math.random() * 100000);
  const getShuffledData = (optionsList) => {
    let data = [];
    if (optionsList?.length > 0) {
      data = JSON.parse(JSON.stringify(optionsList));
      if (itemJson?.shuffle == true) {
        data = setShuffle(data, shuffleNumber);
      }
    } else {
      data = optionsList;
    }
    return data;
  };

  const [shuffledLtOptions, setShuffledLtoptions] = useState(
    getShuffledData(itemJson?.optionList)
  );
  const [shuffledRtOptions, setShuffledRtoptions] = useState(
    getShuffledData(itemJson?.matchList)
  );

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className={'row m-1'}>
            <StemFormatter stemContent={itemJson?.stemContent} />
          </div>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <MatrixInteractionResponse
              item={item}
              onUpdate={onUpdate}
              config={config}
              shuffledLtOptions={shuffledLtOptions}
              shuffledRtOptions={shuffledRtOptions}
              showCorrectResponse={showCorrectResponse}
              clickHistory={clickHistory}
              onClickHistoryUpdate={onClickHistoryUpdate}
              isPreview={true}
            />
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

MatrixInteractionPreview.propTypes = itemPreviewProps;

export default MatrixInteractionPreview;
