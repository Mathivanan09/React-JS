import React from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

import MatchingLinesResponse from '../../response/matchinglines/MatchingLinesResponse';

import '../../../../styles/item/MatchingLinesPreview.css';

/**
 * React functional component to display Matching Lines click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace MatchingLinesPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Matching Lines click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - MatchingLinesPreview component for displaying Matching Lines click item
 */

const MatchingLinesPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div>
            <StemFormatter stemContent={item?.item_json?.stemContent} />
          </div>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <MatchingLinesResponse
              item={item}
              config={config}
              responseOnly={false}
              showCorrectResponse={showCorrectResponse}
              isPreview={true}
            />
          </div>
        </div>
      ) : (<div className='row' data-testid='missing-item'>{label.missing_item_data}</div>)
      }
    </>
  );
};

MatchingLinesPreview.propTypes = itemPreviewProps;

export default MatchingLinesPreview;
