import React, { useState } from 'react';
import PropTypes from 'prop-types';
import MultipleChoiceResponse from '../../response/multiplechoice/MultipleChoiceResponse';
import StemFormatter from '../shared/StemFormatter';
import '../../../../styles/item/MultipleChoicePreview.css';
import MessagePreview from '../../../common/MessagePreview';

/**
 * React functional component to display multiple choice item with stem in it.
 *
 * @memberof PreviewComponents
 * @inner
 * @namespace MultipleChoicePreview
 *
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying multiple choice item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - MultipleChoicePreview component for displaying multiple choice item
 */

const MultipleChoicePreview = ({
  item,
  onUpdate,
  config,
  showCorrectResponse,
  clickHistory,
  onClickHistoryUpdate
}) => {
  const itemJson = item?.item_json || {};
  // determines whether to show error popup or nott
  const [showMessage, setShowMessage] = useState(false);
  // state object of selected responses
  const [selected, setSelected] = useState([]);

  // returns wheter the selections exeeds max selections
  const isSelectionExceeds = (selectdList) => {
    if (item?.item_json?.selectionType === 'multiple') {
      return selectdList.length >= item?.item_json?.maxSelections;
    } else {
      return false;
    }
  };

  const handleResponse = (e) => {
    const id = e.target.id;
    const val = e.target.checked;
    let selectedList = [...selected];
    if (val && !isSelectionExceeds(selectedList)) {
      setSelected(e.target.type === 'radio' ? [id]: [...selectedList, id]);
    } else {
      selectedList = [...selected.filter((el) => el !== id)];
      setSelected(selectedList);
    }

    if (isSelectionExceeds(selectedList)) {
      setShowMessage(true);
    } else {
      onUpdate(id, val);
      // Updating history
      let clickHistoryObj = { ...clickHistory };
      if (config?.clickHistoryRequired) {
        clickHistoryObj.selectionType = itemJson?.selectionType;
        const historyOption = {
          optionId: id
        };
        if (!clickHistoryObj.options) {
          clickHistoryObj.options = [];
        }
        clickHistoryObj.options.push(historyOption);
      }
      onClickHistoryUpdate && onClickHistoryUpdate(clickHistoryObj);
    }
  };

  return (
    <div data-testid='preview-container'>
      <MessagePreview
        code={'mc_maximum_selected'}
        showHideFlag={showMessage}
        onCancel={() => {
          setShowMessage(false);
        }}
        onClose={() => {
          setShowMessage(false);
        }}
      />
      <MultipleChoiceResponse
        item={item}
        stemComponent={
          <StemFormatter
            stemContent={itemJson?.stemContent}
          />
        }
        config={config}
        onUpdate={handleResponse}
        showCorrectResponse={showCorrectResponse}
        selected={selected}
        isPreview={true}
      />
    </div>
  );
};

MultipleChoicePreview.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  clickHistory: PropTypes.object,
  onClickHistoryUpdate: PropTypes.func
};

export default MultipleChoicePreview;
