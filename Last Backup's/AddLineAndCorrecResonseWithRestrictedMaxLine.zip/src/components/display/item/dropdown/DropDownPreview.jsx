import React from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

import '../../../../styles/item/DropDownPreview.css';
import DropDownResponse from '../../response/dropdown/DropDownResponse';

/**
 * React functional component to display DropDown click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace DropDownPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying DropDown click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - DropDownPreview component for displaying DropDown click item
 */

const DropDownPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <DropDownResponse item={item} config={config}
              showCorrectResponse={showCorrectResponse}
              isPreview={true}></DropDownResponse>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

DropDownPreview.propTypes = itemPreviewProps;

export default DropDownPreview;
