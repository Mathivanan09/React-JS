import React, { useState } from 'react';
import PropTypes from 'prop-types';

import label from '../../../../constants/labelCodes';

/**
 * @memberof PreviewInterface
 * @inner
 *
 * @namespace PreviewOptions - React functional component to display the options for preview
 * @param {String} itemType - enable or disable display correct response if it is rubric based item
 * @param {String} itemTypeCategory - to confirm is the item is question type category or not in order to Display the Correct Response 
 * @param {Function} onSelect - callback function of the preview window dropdown
 * @return {component} - Preview display component based on the itemTypeCode in item JSON
 */

const PreviewOptions = ({ itemType, itemTypeCategory, onSelect }) => {

    const chromebookId = 'chromebook';
    const chromebookName = 'Chromebook';
    const chromebookWidth = 1280;
    const chromebookHeight = 800;
    const iPadId = 'ipad';
    const iPadName = 'iPad';
    const iPadWidth = 1024;
    const iPadHeight = 768;
    const pcmacId = 'pc-mac';
    const pcmacName = 'PC/Mac';

    const [selectedView, setSelectedView] = useState("Select");
    let disableCorrectResponse = false;

    // rurbic based item types
    const rubricItemCodes = ['ER', 'SI'];
    if (itemType) {
        // disable the correct response for rubric based item
        disableCorrectResponse = rubricItemCodes.includes(itemType);
    }

    const displayMap = {
        'pc-mac': [window.screen.width, window.screen.height],
        'chromebook': [chromebookWidth, chromebookHeight],
        'ipad': [iPadWidth, iPadHeight]
    };

    const displayChange = (e) => {
        let key = e.target.value;
        let dimensions = displayMap[key];
        setSelectedView(key);
        window.resizeTo(dimensions[0], dimensions[1]);
    };

    return (
        <>
            <div className='row display-correct-response-container'>
                <div className='col col-sm-10'>
                    {(itemTypeCategory === 'question') &&
                        <span className={disableCorrectResponse ? 'disable-correct-response' : ''}>
                            <div className='form-check-inline'>
                                <div className='hstack gap-2'>
                                    <input
                                        type='checkbox'
                                        onClick={onSelect}
                                        className='form-check-input'
                                        id='display-correct-response'
                                        name='display-correct-response'
                                        disabled={disableCorrectResponse}
                                    />
                                    <label
                                        htmlFor='display-correct-response'
                                        className='form-check-label'
                                    >
                                        {label.display_correct_response}
                                    </label>
                                </div>
                            </div>
                        </span>
                    }
                </div>
                <div className='col col-sm-2' sm={2}>
                    <select
                        id='display-options'
                        className='form-select form-select-sm'
                        aria-label='form-select-columns-number'
                        value={selectedView || pcmacId}
                        onChange={displayChange}
                    >
                        <option value={pcmacId}>{pcmacName}</option>
                        <option value={chromebookId}>{chromebookName}</option>
                        <option value={iPadId}>{iPadName}</option>
                    </select>
                </div>
            </div>
        </>
    );
}

PreviewOptions.propTypes = {
    itemType: PropTypes.string,
    itemTypeCategory: PropTypes.string,
    onSelect: PropTypes.func
};

export default PreviewOptions;
