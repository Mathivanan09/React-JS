import React from 'react';

import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';
import '../../../../styles/item/SpeechInteractionPreview.css';
import ResponseAlignment from '../shared/ResponseAlignment';
import SpeechInteractionRecorder from '../../response/speechinteraction/SpeechInteractionRecorder';

/**
 * React functional component to display Speech Interaction click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace SpeechInteractionPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Speech Interaction click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - SpeechInteractionPreview component for displaying Speech Interaction click item
 */

const SpeechInteractionPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse,
  api
}) => {
  const itemJson = item?.item_json || {};
  const assessmentProgramId = item?.assessment_program_id;

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <ResponseAlignment
              stem={itemJson?.stemContent}
              responses={
                <SpeechInteractionRecorder
                  maxNumberofAttempts={itemJson?.maxNumberofAttempts || 1}
                  dataTestId='Speech-interaction-response'
                  maxTimeAllowedForEachAttempt={itemJson?.maxTimeAllowedForEachAttempt || 5}
                  retainAttempts={itemJson?.retainAttempts || false}
                  api={api}
                  assessmentProgramId={assessmentProgramId}
                  config={config}
                />
              }
              alignment={itemJson?.answerAlignment || 'right_vertical_stacked'}
              dataTestId='response-alignment'
            />
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

SpeechInteractionPreview.propTypes = itemPreviewProps;

export default SpeechInteractionPreview;