import React, { useState, useEffect } from 'react';
import parse from "html-react-parser";
import PropTypes from 'prop-types';

/**
 * React functional component which renders Words selection based on selection type.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace Words
 *
 * @function Words - React functional container component for Words selectionType
 * @param {object} item - JSON data that will contain the item information
 * for displaying select text item
 * @param {object} divUUID - Id for the div to be rendered
 * @param {boolean} showCorrectResponse -  display Correct Response checkbox value
 * @param {object} buildDataForHighlight - Build Correct Response for Highlighting
 * @param {object} correctResponseHighlight - Highlighted Correct Response Data
 * @return {component} - container for Words selection of passage content
 *
 */
const Words = ({
    item,
    divUUID,
    showCorrectResponse,
    buildDataForHighlight,
    correctResponseHighlight
}) => {

    const content = item?.item_json || {};
    const [parsedPassageContent, setParsedPassageContent] = useState(item?.item_json.passageContent);

    useEffect(() => {
        generateContentForCorrectResponse();
        // eslint-disable-next-line
    }, [content, showCorrectResponse]);

    useEffect(() => {
        correctResponseHighlight();
    });

    //This method is to set the content in the correct response section based on word selection
    const generateContentForCorrectResponse = () => {
        let passageContent = " ", updatedPassageContent = parsedPassageContent, divElement = document.createElement("div");

        divElement.innerHTML = item?.item_json?.passageContent;
        passageContent = divElement.innerHTML;

        if (passageContent.includes("<span")) {
            let spanTagsArray = passageContent.match(/<\s*span[^>]*>(.*?)<\s*\/\s*span>/g);
            for (let index = 0; index < spanTagsArray.length; index++) {
                let element = spanTagsArray[index].replace(/\s/g, 'SPAN_SPACE');
                passageContent = passageContent.replace(spanTagsArray[index], element)
            }
        }

        for (let i = 0; i < content?.optionList?.length; i++) {
            if (content?.optionList[i].optionText !== "" && content?.optionList[i].optionText !== "-") {
                // This logic will execute for make the correct response with selectable for Word
                let regex = "", optionText = HTMLEncode(content?.optionList[i].optionText);
                optionText = escapeRegExp(optionText);

                passageContent = passageContent.replace(/\?/gi, "@QEST_MARK");
                passageContent = passageContent.replace(/&nbsp; /gi, "NBSP_TAG; ");

                passageContent = passageContent.replace(/ &nbsp;/gi, " NBSP_TAG;");
                passageContent = passageContent.replace(/&nbsp;/gi, "NBSP_TAG;");
                optionText = optionText.replace(/\?/gi, "@QEST_MARK");

                if (optionText.slice(-1) !== "." && optionText.slice(-1).match(/[a-z]/i) === null &&
                    optionText.slice((optionText.length - 1), 1).match(/[a-z0-9]/i) !== null && optionText.slice(0, 1).match(/[a-z0-9]/i) !== null
                ) {
                    regex = new RegExp("(<=\\s|\\b)" + optionText + "(?=[]\\b|\\s|$)");
                } else if (optionText.slice(-1) !== "." && optionText.slice(-1).match(/[a-z]/i) === null &&
                    optionText.slice((optionText.length - 1), 1).match(/[a-z0-9]/i) === null &&
                    optionText.slice(0, 1).match(/[a-z0-9]/i) !== null) {
                    regex = new RegExp("(<=\\s|\\b)" + optionText);
                } else if (optionText.slice(0, 1).match(/[a-z0-9]/i) === null) {
                    regex = new RegExp("(?=[]\\b|\\W)" + optionText + "(?=[]\\b|\\s|$)");
                } else if (optionText.slice(-1) === ".") {
                    regex = new RegExp("\\b" + optionText, "");
                } else {
                    regex = new RegExp("\\b" + optionText + "\\b", "");
                }

                //Parsing the passage content to check the styles added, which will not be with the optionText
                const parser = new DOMParser();
                const doc = parser.parseFromString(content.passageContent, "text/html");
                let pNodelist = doc.querySelectorAll("p,h1,h2,h3,pre");
                let fullOptionText = "";
                let pArray = [];
                for (let i = 0; i < pNodelist.length; i++) {
                    if (fullOptionText.length < 1) {
                        fullOptionText = pNodelist[i].innerHTML;
                        pArray.push(0);
                        pArray.push(fullOptionText.split(" ").length);
                    } else {
                        fullOptionText = fullOptionText + " " + pNodelist[i].innerHTML;
                        pArray.push(fullOptionText.split(" ").length);
                    }
                }

                fullOptionText = fullOptionText.replace(/\?/gi, "@QEST_MARK");
                fullOptionText = fullOptionText.replace(/&nbsp; /gi, " NBSP_TAG;");
                fullOptionText = fullOptionText.replace(/&nbsp;/gi, "NBSP_TAG;");

                fullOptionText = fullOptionText.replace(/NBSP_TAG;/g, ' ');

                if (fullOptionText.includes("<span")) {
                    let spanTagsArray = fullOptionText.match(/<\s*span[^>]*>(.*?)<\s*\/\s*span>/g);
                    for (let index = 0; index < spanTagsArray.length; index++) {
                        let element = spanTagsArray[index].replace(/\s/g, 'SPAN_SPACE');
                        fullOptionText = fullOptionText.replace(spanTagsArray[index], element)
                    }
                }

                let newoptionText = fullOptionText.split(" ").filter(data => data != null && data.trim() !== "").map(data => data.trim());
                let currentIndexText = newoptionText[i];
                // eslint-disable-next-line
                let format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.\/?~]/;
                let symbol = "";
                //Below logic is used to neglect if the last character is punctuation for Word splitting.
                if (currentIndexText !== undefined && currentIndexText.slice(-1).match(format) !== null) {
                    symbol = " ##" + currentIndexText.slice(-1).match(format);
                    passageContent = passageContent.replace(currentIndexText, (currentIndexText.slice(0, currentIndexText.length - 1) + symbol));
                    currentIndexText = currentIndexText.slice(0, currentIndexText.length - 1);
                } if (currentIndexText !== undefined && currentIndexText.endsWith("@QEST_MARK", currentIndexText.length)) {
                    symbol = " @QEST_MARK";
                    passageContent = passageContent.replace(currentIndexText, (currentIndexText.slice(0, currentIndexText.length - 10) + symbol));
                    currentIndexText = currentIndexText.slice(0, currentIndexText.length - 10);
                }

                //Logic below is used to created the regx if the starting letter is any special character
                if (currentIndexText !== undefined && optionText !== escapeRegExp(currentIndexText) &&
                    currentIndexText.slice(0, 1).match(/[a-z0-9]/i) !== null) {
                    regex = new RegExp("(<=\\s|\\b)" + currentIndexText);
                    optionText = currentIndexText;
                } else if (currentIndexText !== undefined && currentIndexText.slice(0, 1).match(/[a-z0-9]/i) === null) {
                    regex = new RegExp("(?=[]\\b|\\W)" + currentIndexText + "(?=[]\\b|\\s|$)");
                    optionText = currentIndexText;
                }

                let hightlightText = buildDataForHighlight(content?.optionList[i].id, content?.optionList[i].optionText);
                if (content?.optionList[i].optionText !== optionText) {
                    hightlightText = optionText.replace(content?.optionList[i].optionText, hightlightText);
                }

                // ignore the replace process for the content that is already converted, to avoid replacing the existing content/html
                const highlights = passageContent.match(/<\s*span[^>]* class=\"st-highlight[^>]*>(.*?)<\s*\/\s*span>/g)
                if (highlights?.length > 0) {
                    const lastHighlight = highlights?.pop();
                    const lastIndex = passageContent.lastIndexOf(lastHighlight)+lastHighlight?.length
                    const highlightedContent = passageContent.substring(0, lastIndex);
                    const normalContent = passageContent.substring(lastIndex);
                    passageContent = highlightedContent + normalContent.replace(regex, hightlightText);
                } else {
                    passageContent = passageContent.replace(regex, hightlightText);
                }

                if (symbol !== "") {
                    if (symbol === " @QEST_MARK") {
                        passageContent = passageContent.replace(" @QEST_MARK", "@QEST_MARK");
                    } else {
                        passageContent = passageContent.replace(symbol, symbol.slice(-1));
                    }
                }
                passageContent = passageContent.replace(/@QEST_MARK/gi, "?");
                passageContent = passageContent.replace(/NBSP_TAG;/gi, "&nbsp;");
                passageContent = passageContent.replace(/<\s*\/\s*span[^>]*>/gi, "</span>");

            }
        }
        if (passageContent !== "" && passageContent !== undefined) {
            //Regular expression is used for removing all the 'Cb_High_Light' strings from the correct response content
            passageContent = passageContent.replace(/SPAN_SPACE/gi, " ");
            passageContent = passageContent.replace(/<\s*\/\s*span[^>]*>/gi, "</span>");
            updatedPassageContent = passageContent?.replace(/Cb_High_Light/gi, "");
        }

        if (updatedPassageContent !== parsedPassageContent) {
            setParsedPassageContent(updatedPassageContent);
        }
    };

    function HTMLEncode(htmlText) {
        let element = document.createElement("div");
        element.innerText = element.textContent = htmlText;
        htmlText = element.innerHTML;
        return htmlText;
    }

    function escapeRegExp(str) {
        if (str !== undefined && str !== "") {
            // eslint-disable-next-line
            return str.replace(/[\-\[\]\/\{\}\(\)\*\+\\\^\$\|]/g, "\\$&");
        }
    }
    return (
        <div id={divUUID}>
            <div className='row item-content m-1 mt-4 p-4 content_style'>{parse(parsedPassageContent || '<div></div>')}</div>
        </div>
    );
};

Words.propTypes = {
    item: PropTypes.object,
    divUUID: PropTypes.string,
    showCorrectResponse: PropTypes.bool,
    buildDataForHighlight: PropTypes.func,
    correctResponseHighlight: PropTypes.func
};

export default Words;