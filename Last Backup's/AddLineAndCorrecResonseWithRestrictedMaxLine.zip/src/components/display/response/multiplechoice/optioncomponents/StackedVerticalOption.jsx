import React from 'react';
import PropTypes from 'prop-types';

import parse from 'html-react-parser';

/**
 * React functional component to render options in Stacked Vertical alignment component.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace StackedVerticalOption
 * 
 * @function StackedVerticalOption - React functional component to display
 * stacked vertically aligned options
 * @param {string} id - component id
 * @param {string} type - input type (either 'radio' or 'checkbox')
 * @param {boolean} checked - value of the input
 * @param {string} className - optional class name to input
 * @param {boolean} inline - flag to display inline input or not
 * @param {string} optionText - text value of the option
 * @param {string} responseLabels - response label types
 * @param {function} onUpdate - dispatcher function to update the store
 * @param {string} styleCode - style code of the UI
 * @return {component} - component which renders stacked vertically aligned options
 *
 */
const StackedVerticalOption = ({
  id,
  type,
  name,
  checked,
  className,
  inline,
  optionText,
  responseLabels,
  onUpdate,
  config,
  disabled
}) => {
  return (
    <>
      {config?.styleCode == 'alternate' ? (
        <div className='row mb-2'>
          <label>
            <input
              data-testid='stackedvertical-input-option'
              id={id}
              type={type}
              name={name}
              checked={checked}
              aria-label={optionText}
              className={className}
              inline={inline}
              onChange={onUpdate}
              disabled={disabled}
            />
            <div className='p-2'>
              <div className='row flex-nowrap align-items-center'>
                {responseLabels != null ? (
                  <div className='col-1 text-center'>
                    {responseLabels}
                  </div>
                ) : null}
                <div className='col'>{parse(optionText || '<div></div>')}</div>
              </div>
            </div>
          </label>
        </div>
      ) : (
        <div className='row align-items-center h-100'>
          <div className='hstack gap-3'>
            <div>
              <input
                id={id}
                type={type}
                name={name}
                checked={checked}
                onChange={onUpdate}
                disabled={disabled}
                aria-label={optionText}
                data-testid='stackedvertical-input-option'
                className={'form-check-input' + (className ? ' ' + className : '')}
              />
            </div>
            <div>{responseLabels}</div>
            <div className='w-100'>{parse(optionText || '<div></div>')}</div>
          </div>
        </div>
      )}
    </>
  );
};

StackedVerticalOption.propTypes = {
  id: PropTypes.string,
  type: PropTypes.string,
  name: PropTypes.string,
  checked: PropTypes.bool,
  label: PropTypes.string,
  className: PropTypes.string,
  inline: PropTypes.bool,
  optionText: PropTypes.string,
  responseLabels: PropTypes.string,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  disabled: PropTypes.bool,
};

export default StackedVerticalOption;
