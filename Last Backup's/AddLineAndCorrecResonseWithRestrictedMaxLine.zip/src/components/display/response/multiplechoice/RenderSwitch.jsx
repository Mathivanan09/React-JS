import React from 'react';
import PropTypes from 'prop-types';
import StackedZ from './StackedZ';
import RightSideZ from './RightSideZ';
import RightSideVertical from './RightSideVertical';
import StackedVertical from './StackedVertical';
import StackedHorizontal from './StackedHorizontal';

/**
 * React functional component which switches alignment between item jsons aligment value.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace RenderSwitch
 * 
 * @function RenderSwitch - React functional component to select
 * the requried alignment component to render
 * @param {string} ItemJson - Item content
 * @param {string} optionObject - option object with alignment type information
 * @param {boolean} stemComponent - stem content to be rendered
 * @param {function} onUpdate - dispatcher function to update the store
 * @return {component} - component which need to be rendered for selected alignment type
 *
 */
const RenderSwitch = ({
  optionsList,
  correctResponses,
  optionObject,
  stemComponent,
  onUpdate,
  config,
  showCorrectResponse,
  selected
}) => {
  switch (optionObject.alignment) {
    case 'stacked_z':
      return (
        <StackedZ
          optionsList={optionsList}
          correctResponses={correctResponses}
          optionObject={optionObject}
          stemComponent={stemComponent}
          onUpdate={onUpdate}
          config={config}
          showCorrectResponse={showCorrectResponse}
          selected={selected}
        />
      );
    case 'right_z':
      return (
        <RightSideZ
          optionsList={optionsList}
          correctResponses={correctResponses}
          optionObject={optionObject}
          stemComponent={stemComponent}
          onUpdate={onUpdate}
          config={config}
          showCorrectResponse={showCorrectResponse}
          selected={selected}
        />
      );
    case 'right_vertical_stacked':
      return (
        <RightSideVertical
          optionsList={optionsList}
          correctResponses={correctResponses}
          optionObject={optionObject}
          stemComponent={stemComponent}
          onUpdate={onUpdate}
          config={config}
          showCorrectResponse={showCorrectResponse}
          selected={selected}
        />
      );
    case 'vertical_stacked':
      return (
        <StackedVertical
          optionsList={optionsList}
          correctResponses={correctResponses}
          optionObject={optionObject}
          stemComponent={stemComponent}
          onUpdate={onUpdate}
          config={config}
          showCorrectResponse={showCorrectResponse}
          selected={selected}
        />
      );
    case 'horizontal':
      return (
        <StackedHorizontal
          optionsList={optionsList}
          correctResponses={correctResponses}
          optionObject={optionObject}
          stemComponent={stemComponent}
          onUpdate={onUpdate}
          config={config}
          showCorrectResponse={showCorrectResponse}
          selected={selected}
        />
      );
    default:
      // TO-DO: get confirmation on which alignment to show default.
      return (
        <StackedVertical
          optionsList={optionsList}
          correctResponses={correctResponses}
          optionObject={optionObject}
          stemComponent={stemComponent}
          onUpdate={onUpdate}
          config={config}
          showCorrectResponse={showCorrectResponse}
          selected={selected}
        />
      );
  }
};

RenderSwitch.propTypes = {
  optionsList: PropTypes.array,
  correctResponses: PropTypes.array,
  optionObject: PropTypes.object,
  stemComponent: PropTypes.element,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  selected: PropTypes.any
};

export default RenderSwitch;
