import React, { useState } from 'react';
import PropTypes from 'prop-types';
import parse from 'html-react-parser';

const MatrixInteractionResponse = ({
  item,
  onUpdate,
  config,
  showCorrectResponse,
  shuffledLtOptions,
  shuffledRtOptions,
  clickHistory,
  onClickHistoryUpdate,
  isPreview,
  onUpdateStudentResponse,
}) => {
  const itemJson = item?.item_json || {};
  const optionList = (shuffledLtOptions||itemJson.optionList) || [];
  const matchList = (shuffledRtOptions||itemJson.matchList) || [];
  const { responseLayout } = itemJson;
  const alignment = itemJson?.alignmentValue;
  const [selected, setSelected] = useState(optionList.map(option => ({
    id: option.id,
    values: [],
  })));

  //This Method will fix the left column width if its set.
  const handleLeftColWidth = () => {
    const leftColWidth = itemJson.leftColWidth || 0;
    if (leftColWidth && leftColWidth > 0) {
      return { width: leftColWidth + '%', minWidth: 'auto',  fontWeight: 'normal'};
    } else {
      return { width: '20%', fontWeight: 'normal'};
    }
  };

  const handleRemainingColWidth = () => {
    const leftColWidth = itemJson.leftColWidth || 0;
    if (leftColWidth && leftColWidth > 0) {
      return { width: (100 - leftColWidth)/itemJson?.optionList?.length + '%', minWidth: 'auto', fontWeight: 'normal'};
    } else {
      return { width: (80 - leftColWidth)/itemJson?.optionList?.length + '%', minWidth: 'auto', fontWeight: 'normal'};
    }
  };

  const handleChange = (optionId, matchId) => {
    if (showCorrectResponse) return; // Lock the correct response options preview

    let newCorrectResponse;
    if (isPreview) {
       newCorrectResponse = [ ...selected ];
    } else {
       newCorrectResponse = [ ...itemJson.correctResponse ];
    }

    const optionResponse = newCorrectResponse.find(response => response.id === optionId);
    if (optionResponse.values.includes(matchId)) { // Uncheck
      optionResponse.values = optionResponse.values.filter(id => id !== matchId);
    } else if (itemJson.multipleChoice || optionResponse.values.length === 0) { // Multi-select or no value selected already
      optionResponse.values.push(matchId);
    } else { // Single select and one value already selected; replace with new value
      optionResponse.values.splice(0, 1, matchId);
    }

    if (isPreview) {
      // Handle student portal logic here
      setSelected(newCorrectResponse);
    } else {
      onUpdate({
        item_json: {
          correctResponse: newCorrectResponse,
        }
      });
    }
  };

  const isChecked = (optionId, matchId) => {
    let newCorrectResponse;
    if (isPreview && !showCorrectResponse) {
      newCorrectResponse = selected;
    } else {
      newCorrectResponse = itemJson.correctResponse;
    }

    const matchIds = newCorrectResponse.find(response => response.id === optionId).values;
    return matchIds.includes(matchId);
  };

  // Horizontal Layout:
  // optionList => rows
  // matchList => columns
  //
  // Vertical Layout:
  // optionList => columns
  // matchList => rows

  let tableContents = null;
  if (responseLayout?.toLowerCase() === 'horizontal') {
    tableContents =
      <>
        <tr>
          <th style={{fontWeight: 'normal'}}>{itemJson.header ? parse(itemJson.header) : ''}</th>
          {
            matchList.map(match => (
              <th key={match.id} style={handleRemainingColWidth()}>{parse(match.optionText)}</th>
            ))
          }
        </tr>
        {
          optionList.map((option, index) => (
            <tr key={option.id}>
              <th scope="row" style={handleLeftColWidth()}>
                <div id={index}>{parse(option.optionText)}</div>
              </th>
              {
                matchList.map(match => (
                  <td key={match.id}>
                    <div style={{ textAlign: alignment }}>
                      <input
                        key={`${index}-${match.id}`}
                        type={itemJson.multipleChoice ? 'checkbox' : 'radio'}
                        checked={isChecked(option.id, match.id)}
                        name={option.id}
                        id={match.id}
                        onChange={() => handleChange(option.id, match.id)}
                      />
                    </div>
                  </td>
                ))
              }
            </tr>
          ))
        }
      </>;
  } else {
    tableContents =
      <>
        <tr>
          <th style={{fontWeight: 'normal'}}>{itemJson.header ? parse(itemJson.header) : ''}</th>
          {
            optionList.map(option => (
              <th key={option.id} style={handleRemainingColWidth()}>{parse(option.optionText)}</th>
            ))
          }
        </tr>
        {
          matchList.map(match => (
            <tr key={match.id}>
              <th scope="row" style={handleLeftColWidth()}>
                <div id={match.id}>{parse(match.optionText)}</div>
              </th> 
              {
                optionList.map((option, index) => (
                  <td key={option.id}>
                    <div style={{ textAlign: alignment }}>
                      <input
                        key={`${index}-${option.id}`}
                        type={itemJson.multipleChoice ? 'checkbox' : 'radio'}
                        checked={isChecked(option.id, match.id)}
                        name={option.id}
                        id={option.id}
                        onChange={(e) => handleChange(option.id, match.id)}
                      />
                    </div>
                  </td>
                ))
              }
            </tr>
          ))
        }
      </>;
  }

  return (
    <>
      {itemJson && (
        <div className='mc-item-response-generalui'>
          <table className='table table-bordered'>
            <tbody>
              {tableContents}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
};

MatrixInteractionResponse.propTypes = {
  item: PropTypes.object,
  leftOption: PropTypes.array,
  rightOption: PropTypes.array,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  clickHistory: PropTypes.any,
  onClickHistoryUpdate: PropTypes.func,
  isPreview: PropTypes.bool,
  onUpdateStudentResponse: PropTypes.func,
};

export default MatrixInteractionResponse;
