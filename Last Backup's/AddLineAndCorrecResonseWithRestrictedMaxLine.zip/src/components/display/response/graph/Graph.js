
/**
 * @file Graph component and controls for Chart Item item type
 * @author Feroz, Krishna & Mahalingam
 */
import React, { useRef, useEffect } from "react";
import Chart from 'chart.js/auto';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import ChartDragData from 'chartjs-plugin-dragdata';
import * as cons from "./constants";

/*
 * snapToGridPoint - get the nearest snap to grid point of x/y position from the chart
 * @param {object} - chartData - data of the grid to collect x and y Axis
 * @param {boolean} - isXAxis - is X or Y Axis
 * @param {number} - point value of the x/y
 */
const snapToGridPoint = (chartData, isXAxis, point) => {
  let closest = point;
  if (chartData?.datasets && chartData?.datasets[0]?.data?.length > 0 && chartData?.datasets[1]?.data?.length > 0) {
    const xy = [...chartData?.datasets[0].data, ...chartData?.datasets[1]?.data];
    let data = [];
    if (isXAxis) {
      data = xy.filter(d => d.x !== 0).map(d => d.x);
    } else {
      data = xy.filter(d => d.y !== 0).map(d => d.y);
    }
    if (data?.length > 0) {
      data.push(0);
      const reduced = data.reduce(function (prev, curr) {
        return (Math.abs(curr - point) < Math.abs(prev - point) ? curr : prev);
      });
      if (reduced !== null && Number.isNaN(Number(reduced)) === false) {
        closest = reduced;
      }
    }
  }
  return closest;
}

/*
 * findAxis - based on the mouse event on the chart get the x, and y position
 * @param {object} - event
 * @param {object} - myChart
 * @param {object} - content
 * @param {object} - chartData
 */
const findAxis = (event, myChart, content, chartData) => {
  let newY = null;
  let newX = null;

  try {
    let yTop = myChart.chartArea.top;
    let yBottom = myChart.chartArea.bottom;

    let yMin = myChart.scales['y'].min;
    let yMax = myChart.scales['y'].max;

    if (event.offsetY <= yBottom && event.offsetY >= yTop) {
      newY = Math.abs((event.offsetY - yTop) / (yBottom - yTop));
      newY = (newY - 1) * -1;
      newY = newY * (Math.abs(yMax - yMin)) + yMin;
    };

    let xTop = myChart.chartArea.left;
    let xBottom = myChart.chartArea.right;
    let xMin = myChart.scales['x'].min;
    let xMax = myChart.scales['x'].max;

    if (event.offsetX <= xBottom && event.offsetX >= xTop) {
      newX = Math.abs((event.offsetX - xTop) / (xBottom - xTop));
      newX = newX * (Math.abs(xMax - xMin)) + xMin;
    };

    if (newY) {
      if (content?.snapToGrid === true) {
        newY = snapToGridPoint(chartData, false, newY);
      } else {
        newY = newY.toFixed(1);
      }
    }

    if (newX) {
      if (content?.snapToGrid === true) {
        newX = snapToGridPoint(chartData, true, newX);
      } else {
        newX = newX.toFixed(1);
      }
    }
  } catch (e) {
    //Throws Empty or blank if no axis found.
    //this error occurs in the chart plugin but we can't do anything about it so just catch it and move on
    //when the chart gets created it will re-render
  }
  return {
    x: newX,
    y: newY
  };
}

/*
 * assignChartValues - prepare chart data based on the data/chart template and saved values.
 * @param {boolean} - showLine - determine whether we need to connect the points as a line, or not
 * @param {object} - obj - x, y values
 * @param {number} - ind - index of the chart data
 * @param {boolean} - extendedLines - add extended line for the line
 * @param {boolean} - dummyPoints - return boolean value says the dummy point exists or not
 */
const assignChartValues = (showLine, obj, ind, extendedLines, dummyPoints) => {
  let pointColor = showLine ? ((extendedLines && dummyPoints) ? cons.COLORCODE1 : cons.COLORCODE2) : cons.COLORCODE3;
  if (dummyPoints) {
    pointColor[0] = 'black';
    pointColor[3] = 'black';
  }
  let lastRotation = {};
  let radius = showLine ? ((extendedLines && dummyPoints) ? cons.RADIUS1 : cons.RADIUS2) : cons.RADIUS3;

  const dataTemplate = {
    id: 'Dataset' + (ind + 1),
    name: 'Dataset ' + (ind + 1),
    label: 'Dataset ' + (ind + 1),
    datalabels: {
      display: false
    },
    borderColor: 'black',
    borderWidth: 1,
    pointBackgroundColor: pointColor,
    pointBorderColor: 'black',
    pointRadius: radius,
    pointStyle: (data) => {
      if (showLine && extendedLines && data && data.dataset && data.dataset.data
        && (data.dataset.data.length === 2 || (data.dataset.data.length === 4))
        && data.dataset.data[data.dataIndex].dummyPoint) {
        if (data.dataset.data[0] && data.dataset.data[0].x !== undefined && data.dataset.data[0].y !== undefined
          && isNaN(parseFloat(data.dataset.data[0].x)) === false && isNaN(parseFloat(data.dataset.data[0].y)) === false
          && data.dataset.data[1] && data.dataset.data[1].x !== undefined && data.dataset.data[1].y !== undefined
          && isNaN(parseFloat(data.dataset.data[1].x)) === false && isNaN(parseFloat(data.dataset.data[1].y)) === false) {
          return 'triangle';
        }
      }
      return 'circle';
    },
    pointRotation: (data) => {
      let rotation = 0;
      if (showLine && extendedLines && data && data.dataset && data.dataset.data && data.dataset.data.length > 0
        && ((data.dataset.data[data.dataIndex].dummyPoint) || (!data.dataset.data[data.dataIndex].dummyPoint))) {
        let line = data.dataset.data;
        let index = data.dataIndex;

        line = data.dataset.data.filter((d) => d.dummyPoint);
        index = data.dataIndex === 0 ? 0 : 1;

        if (line && line.length === 2) {
          let firstPoints = Object.assign({}, line[index]);
          let secondPoint = Object.assign({}, line[index === 0 ? 1 : 0]);
          if (firstPoints && Object.keys(firstPoints).length >= 2 && secondPoint && Object.keys(secondPoint).length >= 2) {
            if (firstPoints.x !== undefined && secondPoint.x !== undefined && firstPoints.y !== undefined && secondPoint.y !== undefined) {
              let switched = false;
              if (index === 0 && firstPoints.y >= secondPoint.y) {
                switched = true;
              } else if (index === 1 && firstPoints.y <= secondPoint.y) {
                switched = true;
              }

              if (switched) {
                firstPoints = Object.assign({}, secondPoint);
                secondPoint = Object.assign({}, line[index]);
              }

              let rotation1 = Math.atan2((firstPoints.x - secondPoint.x), (firstPoints.y - secondPoint.y)) * (180 / Math.PI) + 360;
              rotation1 = (rotation1 + 180) % 360;
              rotation = parseInt((switched) ? rotation1 : (rotation1 + 180) % 360);
              if (index === 0) {
                if (lastRotation) {
                  lastRotation.rotation = rotation;
                }
              } else {
                if (lastRotation.rotation === rotation) {
                  rotation = parseInt((parseInt(rotation1) !== rotation) ? rotation1 : ((rotation1 - 180) % 360));
                }
              }
            }
          }
        }
      }
      return rotation;
    },
    pointHoverRadius: radius,
    fill: false,
    tension: 0,
    showLine: showLine,
    data: (obj && obj.length > 0) ? obj : null
  };
  return dataTemplate;
};

/*
 * infiniteLine - Identify the graph boundary and will calculate the dummy points to draw arrowheads.
                  Based on the points given end point will be calculated
 */
const infiniteLine = (pointA, pointB, bottomLeft, upperRight) => {
  alert("Hi")
  let points = null;
  if (pointA && pointB) {
    let finiteA = { dummyPoint: true }, finiteB = { dummyPoint: true };
    let pointAB = Math.sqrt(Math.abs(Math.pow(pointA.x - pointB.x, 2.0) - Math.pow(pointA.y - pointB.y, 2.0)));
    if (isNaN(pointAB) === false) {
      if (pointAB === 0) {
        pointAB = 1;
      }

      //Calculating Extended line points based on end point of graph
      let midPoint = null; //To find mid point of selected two points
      let extendPoint = null; //Actual Mid point which used calculating positive / negative points
      let checkData = null;//line equation calculation

      //Assiging the value to variable if the points not equal
      if (pointB.x !== pointA.x && pointA.y !== pointB.y) {
        extendPoint = (pointB.y - pointA.y) / (pointB.x - pointA.x);
        midPoint = extendPoint;
        checkData = pointA.y - (extendPoint * (pointA.x));
      }
      // calculating angle is 0 to 90 and 180 to 270
      if (midPoint > 0 && pointA.x !== pointB.x && pointA.y !== pointB.y) {
        let y = (extendPoint * (upperRight[0])) + checkData;
        if (y <= upperRight[1]) {
          finiteA.x = upperRight[0];
          finiteA.y = y;
        } else {
          let x = (upperRight[1] - checkData) / extendPoint;
          if (x <= upperRight[0]) {
            finiteA.x = x;
            finiteA.y = upperRight[1];
          }
        }

        let y1 = (extendPoint * (bottomLeft[0])) + checkData;
        console.log(y1);
        if (y1 >= bottomLeft[1]) {
          finiteB.x = bottomLeft[0];
          finiteB.y = y1;
        } else {
          let x1 = (bottomLeft[1] - checkData) / extendPoint;
          if (x1 >= bottomLeft[0]) {
            finiteB.x = x1;
            finiteB.y = bottomLeft[1];
          }
        }
      } else if (midPoint < 0 && pointA.x !== pointB.x && pointA.y !== pointB.y) { // calculating angle is 90 to 180 and  270 to 360
        let y = (extendPoint * (bottomLeft[0])) + checkData;
        if (y <= upperRight[1]) {
          finiteA.x = bottomLeft[0];
          finiteA.y = y;
        } else {
          let x = (upperRight[1] - checkData) / extendPoint;
          if (x >= bottomLeft[0]) {
            finiteA.x = x;
            finiteA.y = upperRight[1];
          }
        }

        let y1 = (extendPoint * (upperRight[0])) + checkData;
        if (y1 >= bottomLeft[1]) {
          finiteB.x = upperRight[0];
          finiteB.y = y1;
        } else {
          let x1 = (bottomLeft[1] - checkData) / extendPoint;
          if (x1 <= upperRight[0]) {
            finiteB.x = x1;
            finiteB.y = bottomLeft[1];
          }
        }
      } else if (pointA.x === pointB.x && pointA.y !== pointB.y) { //if x points are same and y are different this condition will be executed
        finiteA.x = pointA.x;
        finiteA.y = upperRight[1];
        finiteB.x = pointB.x;
        finiteB.y = bottomLeft[1];
      } else if (pointA.y === pointB.y && pointA.x !== pointB.x) { //if y points are same and x are different this condition will be executed
        finiteA.x = upperRight[0];
        finiteA.y = pointA.y;
        finiteB.x = bottomLeft[0];
        finiteB.y = pointB.y;
      } else { // if All the points are same
        finiteA.x = upperRight[0];
        finiteA.y = pointA.y;
        finiteB.x = bottomLeft[0];
        finiteB.y = pointB.y;
      }

      points = Object.assign([], [finiteA, pointA, pointB, finiteB]);
    }
  }
  return points;
}

let updateAvailable = false;
const scaleOffsetLimit = 2;

/*
 * buildChartData - prepare chart with the graph settings, template and saved values.
 * @param {object} - data - saved graph data
 * @param {boolean} - showLine - determine whether we need to connect the points as a line, or not
 * @param {number} - limit - max lines/points
 * @param {object} - content - item related data
 * @param {boolean} - drawLine - manually draw the line with slope and a point
 * @param {boolean} - extendedLines - add extended line for the line
 * @param {boolean} - native - represent original or duplciate graph
 */
const buildChartData = (data, showLine, limit, content, incrementLabel, drawLine, extendedLines, native) => {
  let chartData = [];
  const lineArrow = (content?.lineArrow);
  let bottomLeft = (content?.bottomLeft && content.bottomLeft.replace(/ /g, '').split(',')) || cons.BOTTOM_LEFT;
  let upperRight = (content?.upperRight && content.upperRight.replace(/ /g, '').split(',')) || cons.UPPER_RIGHT;
  for (let scale = 0; scale < scaleOffsetLimit; scale++) {
    chartData[scale] = {};
    chartData[scale].data = [];
    if (content && (content.xAxisScale && content.xAxisScale >= 1) && (content.yAxisScale && content.yAxisScale >= 1)) {
      scaleLabelOptionsChange(scale, bottomLeft, upperRight, content.xAxisScale, content.yAxisScale, chartData, incrementLabel);
    }

    chartData[scale].datalabels = {
      align: (data) => {
        const value = data.dataset.data[data.dataIndex];
        let cursorAt = (value.y && value.y !== 0 ? value.y : null) || (value.x && value.x !== 0 ? value.x : null);
        let position = 130;
        if (cursorAt !== null) {
          position = (scale === 0 ? ((cursorAt > 0) ? 182 : -180) : ((cursorAt > 0) ? 85 : 100));
        }
        return position;
      },
      anchor: 'center',
      font: {
        size: 10
      },
      color: 'black',
      formatter: (value) => {
        //Handle both Zero - text and 0 - Number.
        if (incrementLabel.code === "NONE" || incrementLabel.code === "SELECT") {
          return '';
        } else if (incrementLabel.code === "LEAST_AND_GREAT") {
          return scale === 0 ? (value.y && value.y !== 0 ? value.y : '') : (value.x && value.x !== 0 ? value.x : 0);
        } else {
          if ((parseInt(content?.bottomLeft[0]) === 0) && (content?.bottomLeft[3] === content?.bottomLeft[0])) {
            return scale === 0 ? (value.y && value.y !== 0 ? value.y : '') : (value.x && value.x !== 0 ? value.x : 0);
          } else {
            return scale === 0 ? (value.y && value.y !== 0 ? value.y : '') : (value.x && value.x !== 0 ? value.x : '');
          }
        }
      }
    };

    chartData[scale].showLine = true;

    if (lineArrow) {
      chartData[scale].pointBackgroundColor = '#000';
      chartData[scale].pointBorderColor = '#000';
      const isAxisBorder = (data) => {
        let valid = false;
        const value = data.dataset.data[data.dataIndex];
        let cursorAt = (scale === 0 ? (value.y && value.y !== 0 ? value.y + '' : null) : (value.x && value.x !== 0 ? value.x + '' : null));
        const index = scale === 0 ? 1 : 0;

        if (cursorAt && ((bottomLeft[index]?.trim() == cursorAt && bottomLeft.includes(cursorAt)) ||
          (upperRight[index]?.trim() == cursorAt && upperRight.includes(cursorAt)))) {
          valid = true;
        }
        return valid;
      }
      chartData[scale].pointRadius = (data) => {
        if (isAxisBorder(data)) {
          return 5;
        } else {
          return null;
        }
      }

      chartData[scale].pointHoverRadius = (data) => {
        if (isAxisBorder(data)) {
          return 5;
        } else {
          return null;
        }
      }

      chartData[scale].pointRotation = (data) => {
        let rotation = null;
        if (isAxisBorder(data)) {
          rotation = 0;
          const value = data.dataset.data[data.dataIndex];
          if (scale === 0 && value.y && value.y !== 0) {
            if (value.y < 0) {
              rotation = 180;
            }
          } else if (scale === 1 && value.x && value.x !== 0) {
            if (value.x < 0) {
              rotation = 270;
            } else {
              rotation = 90;
            }
          };
        }
        return rotation;
      }

      chartData[scale].pointStyle = (data) => {
        if (isAxisBorder(data)) {
          return 'triangle';
        } else {
          return null;
        }
      }
    }
  }

  if (Array.isArray(data) && native) {
    if (limit < data.length) {
      data.length = limit;
      updateAvailable = true;
    }

    for (let ind = 0; ind < limit; ind++) {
      let obj = data[ind];
      if (showLine === false && obj === undefined) {
        obj = [[]];
      }
      let dummyPoints = false;
      if (showLine) {
        const ind1 = 0, ind2 = 1;
        let points = null;
        if (obj && obj.line && obj.line.length > 0) {
          points = Object.assign([], obj.line);
          let pointA = null, pointB = null;
          const x1 = parseFloat(points[ind1] && points[ind1].x);
          const y1 = parseFloat(points[ind1] && points[ind1].y);
          const m = parseFloat(obj.slopeValue);

          if (isNaN(x1) === false && isNaN(y1) === false) {
            pointA = { 'x': x1, 'y': y1 };
          }

          const x2 = parseFloat(points[ind2] && points[ind2].x);
          const y2 = parseFloat(points[ind2] && points[ind2].y);
          if (isNaN(x2) === false && isNaN(y2) === false) {
            pointB = { 'x': x2, 'y': y2 };
          }

          if (content?.slope && drawLine) {
            let slopeValue = null;
            if (pointA && pointB) {
              pointB.slopePoint = true;
              slopeValue = (pointB.y - pointA.y) / (pointB.x - pointA.x);
              if (isNaN(slopeValue)) {
                slopeValue = null;
              }

              if (slopeValue !== null && (isNaN(m) || m !== parseFloat(slopeValue))) {
                obj.slopeValue = slopeValue;
              }
            } else if (pointA && m !== null && isNaN(m) === false) {
              if (points[ind2] === undefined) {
                points[ind2] = {};
              }

              points[ind2].slopePoint = true;

              if (x1 === 0 && y1 !== 0) {
                points[ind2].x = - y1 / m;
                points[ind2].y = 0;
              } else {
                points[ind2].x = 0;
                points[ind2].y = -(m * x1) + y1;
              }

              pointB = { ...points[ind2] };
              obj.line[ind2] = pointB;
            }
          } else {
            if (points[ind2] && points[ind2].slopePoint) {
              delete points[ind2].slopePoint;
              delete obj.line[ind2].slopePoint;
              delete obj.slopeValue;
            }
          }
          if (extendedLines) {
            const ePoints = infiniteLine(pointA, pointB, bottomLeft, upperRight);
            points = ePoints ? ePoints : points;
            if (points?.length === 4) {
              dummyPoints = true;
            }
          }
        }
        chartData.push(assignChartValues(showLine, points, ind, extendedLines, dummyPoints));
      } else {
        chartData.push(assignChartValues(showLine, data, ind, extendedLines, dummyPoints));
        break;
      }
    }
  }
  return chartData;
}

const scaleLabelOptionsChange = (scale, bottomLeft, upperRight, xAxisScale, yAxisScale, chartData, incrementLabel) => {
  for (let ind = 0; ind >= (parseFloat(bottomLeft[0]) < parseFloat(bottomLeft[1]) ? parseFloat(bottomLeft[0]) : parseFloat(bottomLeft[1])); ind = parseInt(ind) - (scale === 0 ? yAxisScale : xAxisScale)) {
    if (scale === 0 || scale === 1) {
      if (incrementLabel && ((incrementLabel.code === "ALL" || incrementLabel.code === "NONE" || incrementLabel.code === "SELECT") ||
        (incrementLabel.code === "LEAST_AND_GREAT" && (parseFloat(upperRight[scale]) === ind)))) {
        chartData[scale].data.push({ x: (scale === 0 ? 0 : ind), y: (scale === 0 ? ind : 0) });
      }
    }
  };
  chartData[scale].data.reverse();

  for (let ind = 0; ind <= (parseFloat(upperRight[0]) > parseFloat(upperRight[1]) ? parseFloat(upperRight[0]) : parseFloat(upperRight[1])); ind = parseInt(ind) + (scale === 0 ? parseInt(yAxisScale) : parseInt(xAxisScale))) {
    if (scale === 0 || scale === 1) {
      if (incrementLabel && ((incrementLabel.code === "ALL" || incrementLabel.code === "NONE" || incrementLabel.code === "SELECT") ||
        (incrementLabel.code === "LEAST_AND_GREAT" && (parseFloat(bottomLeft[scale]) === ind)))) {
        chartData[scale].data.push({ x: (scale === 0 ? 0 : ind), y: (scale === 0 ? ind : 0) });
      }
    }
  };
  // Include the axes end points to the list if they are missing while scaling.
  if (scale === 0) {
    // Y Axis scale
    if (undefined === chartData[scale].data.find(point => point.x === 0 && point.y === parseInt(upperRight[1]))) {
      chartData[scale].data.push({ x: 0, y: parseInt(upperRight[1]) });
    }
    if (undefined === chartData[scale].data.find(point => point.x === 0 && point.y === parseInt(bottomLeft[1]))) {
      chartData[scale].data.push({ x: 0, y: parseInt(bottomLeft[1]) });
    }
  } else if (scale === 1) {
    // X Axis scale
    if (undefined === chartData[scale].data.find(point => point.x === parseInt(upperRight[0]) && point.y === 0)) {
      chartData[scale].data.push({ x: parseInt(upperRight[0]), y: 0 });
    }
    if (undefined === chartData[scale].data.find(point => point.x === parseInt(bottomLeft[0]) && point.y === 0)) {
      chartData[scale].data.push({ x: parseInt(bottomLeft[0]), y: 0 });
    }
  }
}

const destroy = (chart) => {
  if (chart && chart instanceof Chart) {
    chart.stop();
    chart.destroy();
    if (chart.options && chart.options.onClick) {
      chart.options.onClick = null;
    }
    if (chart.options) {
      chart.options = null;
    }
  }
}

/*
 * Graph - common Graph component
 * @param {object} - data - saved graph data
 * @param {boolean} - showLine - determine whether we need to connect the points as a line, or not
 * @param {function} - onUpdate - update function
 * @param {object} - content - item related data
 * @param {boolean} - showCorrectResponse - determine whether component is chart need to be interactive or read only
 * @param {boolean} - drawLine - manually draw the line with slope and a point
 * @param {boolean} - native - represent original or duplciate graph
 */
export const Graph = React.memo(({ data, showLine, onUpdate, content, showCorrectResponse, incrementLabel, drawLine, native }) => {
  console.log(data);
  // console.log(data),console.log(showLine),console.log(content),console.log(showCorrectResponse),console.log(incrementLabel),console.log(native)
  let chart = (native === false ? window.duplicateChart : window.myChart);
  destroy(chart);
  let styles = {
    fontFamily: "sans-serif",
    textAlign: "center",
    color: "red",
    width: 0,
    height: 0
  };
  styles.width = content?.width;
  styles.height = content?.height;
  const extendedLines = (content?.extendedLines) || false;

  let limit = (content && ((showLine && content.maxLines) || content.maxPoints)) || 0;
  const chartValues = ((Array.isArray(data) && data.length > 0 && data) || []);
  const bottomLeft = (content?.bottomLeft && content.bottomLeft.replace(/ /g, '').split(',')) || cons.BOTTOM_LEFT;
  const upperRight = (content?.upperRight && content.upperRight.replace(/ /g, '').split(',')) || cons.UPPER_RIGHT;

  let datasetCursorAt = scaleOffsetLimit;
  if (showLine) {
    datasetCursorAt = datasetCursorAt + chartValues.length;
  }
  //Helper Function to handle the data based on the events of graph.
  const graphEventHandler = (e, element, isDragging) => {
    try {
      if (showCorrectResponse === false && scaleOffsetLimit !== undefined) {
        if (element?.length > 0) {
          if (e.type === "mouseup") { // Drag Event
            datasetCursorAt = element[0]._datasetIndex;
            if (datasetCursorAt <= (scaleOffsetLimit - 1)) {
              return false;
            }
            if (datasetCursorAt > 1) {
              let ind = element[0]._index;
              let index = Math.abs(scaleOffsetLimit - datasetCursorAt);
              let removeSlope = false;
              if (content?.slope) {
                if (data[index]?.slopeValue !== undefined && chartData.datasets[datasetCursorAt].data[ind]?.slopePoint) {
                  delete data[index].slopeValue; // when slope point directly removed, then slope (auto calculated) should be removed as well.
                } else {
                  removeSlope = true;
                }
              }

              if (isDragging === false) {
                if (removeSlope && data[index]) {
                  data.splice(index, 1);
                  chartData.datasets[datasetCursorAt].data.length = 0;
                } else {
                  chartData.datasets[datasetCursorAt].data.splice(ind, 1);
                  if (chartData.datasets[datasetCursorAt]?.data?.length === 0) {
                    if (isNaN(index) === false && data && data[index] && data[index].line) {
                      data[index].line.splice(ind, 1);
                    }
                  }
                }
              } else {
                if (showLine === false) {
                  //Placing Point Data
                  if (content?.snapToGrid === true) {
                    data[ind].x = snapToGridPoint(chartData, true, data[ind].x);
                    data[ind].y = snapToGridPoint(chartData, false, data[ind].y);
                  } else {
                    data[ind].x = data[ind].x.toFixed(1);
                    data[ind].y = data[ind].y.toFixed(1);
                  }
                } else {
                  //Single Line & Straight Line Data
                  if (content?.snapToGrid === true) {
                    chartData.datasets[datasetCursorAt].data[ind].x = snapToGridPoint(chartData, true, chartData.datasets[datasetCursorAt].data[ind].x);
                    chartData.datasets[datasetCursorAt].data[ind].y = snapToGridPoint(chartData, false, chartData.datasets[datasetCursorAt].data[ind].y);
                  } else {
                    chartData.datasets[datasetCursorAt].data[ind].x = chartData.datasets[datasetCursorAt].data[ind].x.toFixed(1);
                    chartData.datasets[datasetCursorAt].data[ind].y = chartData.datasets[datasetCursorAt].data[ind].y.toFixed(1);
                  }
                }
              }
            }
          }
        } else if (e.type === "click") { //Onclick Event
          let axis = findAxis(e, chart, content, chartData);

          if (axis?.x === null || axis?.y === null) {
            return false;
          }

          if (showLine) {
            for (let ind = scaleOffsetLimit; ind <= datasetCursorAt; ind++) {
              if (chartData.datasets && chartData.datasets[ind] && chartData.datasets[ind].data
                && (chartData.datasets[ind].data.length < 2 || (Object.keys(chartData.datasets[ind].data[0]).length === 0 || Object.keys(chartData.datasets[ind].data[1]).length === 0))) {
                if (chartData.datasets[ind].data[1] && Object.keys(chartData.datasets[ind].data[1]).length === 0) {
                  chartData.datasets[ind].data.splice(1, 1);
                }
                if (chartData.datasets[ind].data[0] && Object.keys(chartData.datasets[ind].data[0]).length === 0) {
                  chartData.datasets[ind].data.splice(0, 1);
                }
                datasetCursorAt = ind;
                break;
              }
            }

            if (((chartData.datasets && chartData.datasets[datasetCursorAt] && chartData.datasets[datasetCursorAt].data
              && chartData.datasets[datasetCursorAt].data.length) || 0) >= 2) {
              if ((limit + scaleOffsetLimit) > datasetCursorAt + 1) {
                datasetCursorAt = datasetCursorAt + 1;
              } else {
                return false;
              }
            }
          }

          if (showLine && chartData.datasets[datasetCursorAt] && chartData.datasets[datasetCursorAt].data &&
            chartData.datasets[datasetCursorAt].data?.length < 2) {
            if (drawLine && content?.slope) {
              const ind1 = 0, ind2 = 1;
              let lines = chartData.datasets[datasetCursorAt].data;
              let points = lines.filter((d) => !d.dummyPoint);
              if (points?.length === 0) {
                lines.push(axis);
              } else {
                if (points[0]?.slopePoint) {
                  const slopeData = { 'x': points[0].x, 'y': points[0].y, 'slopePoint': true };
                  lines = [];
                  lines.push(axis);
                  lines.push(slopeData);
                } else {
                  lines.push(axis);
                }
              }

              points = lines.filter((d) => !d.dummyPoint);
              let pointA = null, pointB = null;
              const x1 = parseFloat(points[ind1] && points[ind1].x);
              const y1 = parseFloat(points[ind1] && points[ind1].y);

              if (isNaN(x1) === false && isNaN(y1) === false) {
                pointA = { 'x': x1, 'y': y1 };
              }

              if (pointA) {
                const x2 = parseFloat(points[ind2] && points[ind2].x);
                const y2 = parseFloat(points[ind2] && points[ind2].y);

                if (isNaN(x2) === false && isNaN(x2) === false) {
                  pointB = { 'x': x2, 'y': y2, slopePoint: true };
                }

                if (pointB) {
                  let index = Math.abs(scaleOffsetLimit - datasetCursorAt);
                  if (isNaN(index) === false && data[index]) {
                    let slopeValue = (pointB.y - pointA.y) / (pointB.x - pointA.x);
                    if (isNaN(slopeValue) === false) {
                      data[index].slopeValue = slopeValue;

                    }
                  }
                }
              }
            } else {
              chartData.datasets[datasetCursorAt].data.push(axis);
            }
          } else if (showLine === false && chartData.datasets[datasetCursorAt] && chartData.datasets[datasetCursorAt].data) {
            let ppIndex = chartData.datasets[datasetCursorAt].data.length;
            for (let ind = 0; ind <= chartData.datasets[scaleOffsetLimit].data.length; ind++) {
              let point = chartData.datasets[scaleOffsetLimit].data[ind];
              if (point && (Object.keys(point).length === 0 || point.x === undefined)) {
                ppIndex = ind;
                break;
              }
            }
            if ((chartData.datasets[datasetCursorAt].data.length < limit || ppIndex <= limit - 1)) {
              chartData.datasets[scaleOffsetLimit].data[ppIndex] = axis;
            } else {
              return false;
            }
          } else {
            return false;
          }
        }

        chart && chart.update();
        let updatedData = Object.assign([], data);
        if (showLine === false) {
          updatedData = Object.assign([], chartData.datasets[scaleOffsetLimit].data);
        } else {
          let removedLines = null;
          let intersections = [];
          for (let ind = scaleOffsetLimit; ind <= (chartData?.datasets?.length || 0); ind++) {
            if (chartData.datasets && chartData.datasets[ind]
              && chartData.datasets[ind].id
              && chartData.datasets[ind].data
              && chartData.datasets[ind].data.length > 0) {
              let id = 0;
              const line = Math.abs(ind - scaleOffsetLimit);
              chartData.datasets[ind].data.forEach((set, index) => {
                if (set && set.x !== undefined && !set.dummyPoint) {
                  if (updatedData[line] === undefined) {
                    updatedData[line] = {};
                  }
                  if (updatedData[line].line === undefined) {
                    updatedData[line].line = [];
                  }
                  if (updatedData[line].line[id] === undefined) {
                    updatedData[line].line[id] = {};
                  }
                  updatedData[line].line[id].x = parseFloat(set.x);
                  updatedData[line].line[id].y = parseFloat(set.y);
                  id++;
                }
              });

              if (updatedData[line]?.line?.length !== id) {
                if (id === 0) {
                  removedLines = line;
                } else {
                  updatedData[line].line.splice(id, 1);
                  if (!content?.slope) {
                    intersections.push(line);
                  }
                }
              } else if (!content?.slope && updatedData[line]?.line?.length === 1) {
                intersections.push(line);
              }
            }
          }
          if (removedLines != null) {
            updatedData.splice(removedLines, 1);
          }
          if (intersections?.length > 1) {
            const a = intersections[0];
            const b = intersections[1];
            const lineA = updatedData[a];
            const lineB = updatedData[b];
            if (lineA?.line?.length > 0 && lineB?.line?.length > 0) {
              const x = lineB?.line[0]?.x;
              const y = lineB?.line[0]?.y;
              if (x !== undefined && y !== undefined) {
                const point = {
                  x: x,
                  y: y
                };
                lineA.line.push(point);
                updatedData.splice(b, 1);
              }
            }
          }
        }
        onUpdate(updatedData);
      }
    } catch (e) {
      //Handle the exception on Chart onClick if plugin throw some error
      //this error occurs in the chart plugin but we can't do anything about it so just catch it and move on
      //when the chart gets created it will re-render
    }
  }
  let clickPoint = { x: null, y: null };
  let dragging = false;

  // add or remove the cursor style when drag start or end events
  const toggleCursor = (element, toggle) => {
    let cursorStyle = 'chart-drag-area';
    if (element?.className !== undefined) {
      let className = element?.className || '';
      if (toggle && className?.indexOf(cursorStyle) === -1) {
        element.className = className + " " + cursorStyle; // Apply grabbing, While dragging the cursor will turn into hand symbol
      } else if (className?.indexOf(cursorStyle) !== -1) {
        className = className.replace(cursorStyle, '').trim();
        element.className = className; // Apply default, will turn back to normal cursor.
      }
    }
  };

  // apply the cursor style when drag start or end events
  const applyCursor = (chart, toggle) => {
    toggleCursor(document?.body, toggle);
    toggleCursor(chart?.canvas, toggle);
  }

  const scatterOptions = {
    legend: {
      display: false
    },
    animations: {
      duration: 0 // general animation time
    },
    hover: {
      animationDuration: 0 // duration of animations when hovering an item
    },
    responsiveAnimationDuration: 0,

    tooltips: {
      enabled: true,
      displayColors: false,
      callbacks: {
        label: (tooltipItems, data) => {
          return '(' + tooltipItems.xLabel.toFixed(1) + ', ' + tooltipItems.yLabel.toFixed(1) + ')';
        }
      }
    },
    dragData: true,
    dragX: true,
    events: ['click'],
    onClick: (e, element) => {
      graphEventHandler(e, element, false);
    },
    onDragStart: function (e, element) {
      const datasetIndex = element?._datasetIndex;
      if (datasetIndex <= (scaleOffsetLimit - 1)) {
        return false;
      } else {
        // console.log(content.extendedLines)
        if (content?.extendedLines && chartData?.datasets[datasetIndex]?.data?.length === 4) {
          const index = element?._index;
          const axis = findAxis(e, chart, content, chartData);
          if (chartData.datasets[datasetIndex].data[index].dummyPoint || (axis?.x === null || axis?.y === null)) {
            return false;
          }
        }
        dragging = false;
        clickPoint.x = e.clientX;
        clickPoint.y = e.clientY;
      }
    },
    onDrag: function (e, datasetIndex, index, axis) {
      if (dragging === false && (clickPoint.x !== e.clientX || clickPoint.y !== e.clientY)) {
        dragging = true;
        applyCursor(chart, dragging)
      }

      if (dragging) {
        if (content?.extendedLines && chartData?.datasets[datasetIndex]?.data?.length === 4) {
          if (axis?.x !== null && axis?.y !== null) {
            chartData.datasets[datasetIndex].data[index] = axis;
            const ind1 = 1, ind2 = 2;
            let pointA = chartData.datasets[datasetIndex].data[ind1], pointB = chartData.datasets[datasetIndex].data[ind2];
            const ePoints = infiniteLine(pointA, pointB, bottomLeft, upperRight);
            if (ePoints) {
              chartData.datasets[datasetIndex].data = ePoints;
              chart && chart.update();
            }
          }
        }
      }
    },
    onDragEnd: function (e, datasetIndex, index) {

      let element = [
        {
          _datasetIndex: 0,
          _index: 0,
          hidden: false
        }
      ];
      element[0]._datasetIndex = datasetIndex;
      element[0]._index = index;
      graphEventHandler(e, element, dragging);
      if (dragging) {
        dragging = false;
        applyCursor(chart, dragging);
      };
      clickPoint.x = null;
      clickPoint.y = null;
    },

    maintainAspectRatio: false,
    elements: {
      line: {
        borderColor: 'transparent',
        borderWidth: 0,
        fill: false
      },
      point: {
        radius: 0
      }
    },

    scales: {
      x: {
        type: 'linear',
        position: 'bottom',
        display: true,
        ticks: {
          display: false,
          stepSize: 1,
        },

        grid: {
          display: (content?.showGrid),
          borderWidth: (content?.showGrid ? 1 : 0),

        }
      },

      y: {
        ticks: {
          display: false,
          stepSize: 1,
        },
        scaleLabel: {
          display: true,
          fontSize: 8
        },
        grid: {
          display: (content?.showGrid),
          borderWidth: (content?.showGrid ? 1 : 0),
        }
      },
    }
  };

  const chartData = { datasets: buildChartData(chartValues, showLine, limit, content, incrementLabel, drawLine, extendedLines, native) };


  useEffect(() => {
    if (chart === undefined || chart === null || chart.ctx === null) {
      try {
        // eslint-disable-next-line
        chart = new Chart(ctx.current, { type: 'scatter', data: chartData, options: scatterOptions, plugins: [ChartDataLabels, ChartDragData] });
      } catch (e) {
        //Chart becomes blank white screen if plugin throw error.
        //this error occurs in the chart plugin but we can't do anything about it so just catch it and move on
        //when the chart gets created it will re-render
      }
      if (native) {
        window.myChart = chart;
      } else {
        window.duplicateChart = chart;
      };
    }
    if (updateAvailable) {
      onUpdate(data);
      updateAvailable = false;
    }
    applyCursor(chart);
  }, [data, showLine, content, showCorrectResponse, incrementLabel, showLine, native]);

  const ctx = useRef(null); // ctx - Reference object of canvas HTML element will be used with chart.js to draw chart
  return (
    <div style={{ width: parseInt(styles.width) }}>
      <canvas ref={ctx} height={styles.height} />
    </div>
  );
});
