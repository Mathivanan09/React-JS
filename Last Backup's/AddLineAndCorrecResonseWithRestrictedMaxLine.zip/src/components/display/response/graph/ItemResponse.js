/**
 * @file Item Response component for Line items
 * @author Mahalingam
 */

import React, { useEffect, useState } from "react";
import PropTypes from 'prop-types';
import { Graph } from './Graph'

import { PLACING_POINTS } from "./constants";
import "./style.css";

const ItemResponse = (item, onUpdate, config) => {
  console.log(item.item)
  let responseParam = item.item; // Assigned valueProps to the local responseParam object
  const content = item.item?.item_json;

  let clickHistoryData = [], native, showCorrectResponse = true, graphData = [], pictograph = false, previewClassName = "ci-bg-graph ci-draggable-bg-image", yTitleClass = "col-xs-1.5 ci-preview ci-graph-left-ytitle ci-graph-yTitle";
  let showLine = (responseParam?.item_json.itemTypeCode === PLACING_POINTS) ? true : false;
  const incrementLabel = {
    code: responseParam?.item_json.incrementLabel
  };

  const [correctResponseData, setCorrectResponseData] = useState(item?.item?.item_json?.correctResponse);
  const responseObject = setResponseObject(); //Setting response object where user action has to be saved
  // console.log(showCorrectResponse);
  if (showCorrectResponse === undefined || showCorrectResponse === false) {
    if (responseParam.existingResponseObject === undefined) {
      graphData = content?.correctResponse;
    } else {
      graphData = responseParam.existingResponseObject;
      previewClassName = "ci-bg-graph ci-draggable-bg-image-preview";
      yTitleClass = "col-xs-1.5 ci-preview ci-graph-left-ytitle ci-graph-yTitle-preview";
    }
    showCorrectResponse = false;
  } else if (showCorrectResponse === true) {
    graphData = content.correctResponse;
    showCorrectResponse = true;
    previewClassName = "ci-bg-graph ci-draggable-bg-image-preview";
    yTitleClass = "col-xs-1.5 ci-preview ci-graph-left-ytitle ci-graph-yTitle-preview";

  }
  //This method will return the response object based on showCorrectResponse flag
  function setResponseObject() {
    if (showCorrectResponse) {
      return correctResponseData;
    } else {
      return responseParam.existingResponseObject;
    }
  }
  //To set dynamic interaction with graph (read only)
  if (responseParam.graphNative === false) {
    native = false;
  } else {
    native = true;
  }
  //Allow the user to drag the image if the graph is in CP
  if (pictograph === undefined || pictograph === false) {
    pictograph = true;
  } else {
    pictograph = false;
  }


  //To Calculate Slope
  const drawLine = () => {
    let isNeeded = false;
    if (content?.slope && (responseParam.graphNative !== false || responseParam.graphNative === undefined)) {
      const lineType = [content.orderPairOne, content.orderPairTwo, content.xIntercept, content.yIntercept];
      if (lineType) {
        const unchecked = lineType.filter(function (value) {
          return value === false;
        }).length;
        const checked = lineType.filter(function (value) {
          return value === true;
        }).length;
        if (checked === 1 && unchecked === 3) {
          isNeeded = true;
        }
      }
    }
    return isNeeded;
  }



  useEffect(() => {
    generateClickHistory(correctResponseData);

    // eslint-disable-next-line
  }, [responseObject, correctResponseData, content, clickHistoryData]);

  //This method will return the boolen value for point id and graph id pair.
  const isCorrectResponse = (graphPoint) => {
    const response = responseParam.existingResponseObject;
    if (response && response.length > 0) {

    }
    return false;
  };

  // This method will return the readable response for the given point
  const getResponseValue = (pointData, i) => {
    let xAxis = pointData.x;
    let yAxis = pointData.y
    let responseRow = `"Point${++i}:(${xAxis},${yAxis}) "`;
    return responseRow;
  };

  //This method will generate the click history based the graph selection.
  const generateClickHistory = (pointData) => {

    if (clickHistoryData.length > 0) {
      const lastResponseObj = clickHistoryData[clickHistoryData.length - 1];
      let responseIdList = lastResponseObj.responseoption;
      let readableResponseList = lastResponseObj.readableresponse;

      if (responseParam?.item?.item_json.itemTypeCode === PLACING_POINTS) {
        let newResponseIdList = [...responseIdList]
        let newReadableResponseList = [...readableResponseList]

        clickHistoryData.push({
          "isCorrectResponse": isCorrectResponse(pointData),
          "score": null,
          "responseoption": newResponseIdList,
          "readableresponse": newReadableResponseList,
          "ts": Date().toLocaleString()
        })
      } else {
        let newResponseIdList = [...responseIdList]

        clickHistoryData.push({
          "isCorrectResponse": isCorrectResponse(pointData),
          "responseoption": newResponseIdList,
          "score": null,
          "referencescore": null,
          "ts": Date().toLocaleString()
        })
      }
    } else {
      let readableResponseListFromObj = [];
      let responseIdListFromObj = [];
      if (responseParam?.item?.item_json.itemTypeCode === PLACING_POINTS) {

      } else {
        if (responseObject !== undefined) {
          let linePointData = correctResponseData;
          for (let i = 0; i < responseObject.length; i++) {
            responseIdListFromObj.push(linePointData[i]);
          }
        }
        clickHistoryData.push({
          "isCorrectResponse": isCorrectResponse(pointData),
          "responseoption": responseIdListFromObj,
          "score": null,
          "referencescore": null,
          "ts": Date().toLocaleString()
        })
      }
    }

    if (responseParam.updateClickHistory !== undefined) {
      responseParam.updateClickHistory(clickHistoryData);
    }
  };

  // This method will update CorrectResponseData
  const updateCorrectResponseData = (pointData) => {
    let updatedResponseData = {
      ...content?.correctResponse,
      numberOfResponses: pointData.length,
      responses: pointData
    }
    if (responseParam.updateResponseObject !== undefined) {
      responseParam.updateResponseObject({
        ...content,
        correctResponse: updatedResponseData
      });
    }
    if (responseParam.graphNative !== false || responseParam.graphNative === undefined) {
      setCorrectResponseData(pointData);
    }
  };
  let graphCN = "col-xs", graphCenterTitle = "row ci-preview";

  return (
    <>
      {(content.correctResponse) && (
        <div data-testid="graph-pannel ci-graph-container">
          <div className="row ci-graph-opacity">
            <div className="col-xs">
              <div className={graphCenterTitle}>
                {content?.graphTitle && content.graphTitle}
              </div>
              <div className={graphCenterTitle}>
                {content?.yAxisLabel && content.yAxisLabel}
              </div>
              <div className="row ci-preview ci-graph-row">
                <div className={yTitleClass}>
                  {content?.yAxisTitle}
                </div>
                <div className={graphCN} style={{ pointerEvents: showCorrectResponse ? "none" : "auto" }}>
                  <Graph
                    data={graphData}
                    showLine={true}
                    content={content}
                    onUpdate={(data) => { console.log(data); }}
                    showCorrectResponse={showCorrectResponse}
                    incrementLabel={incrementLabel}
                    drawLine={drawLine()}
                    native={native}
                  />
                </div>
                <div className="col-xs">
                  {content?.xAxisLabel && content.xAxisLabel}
                </div>
              </div>
              <div className={graphCenterTitle}>
                {content?.xAxisTitle && content.xAxisTitle}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
};

ItemResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object
};

export default ItemResponse;
