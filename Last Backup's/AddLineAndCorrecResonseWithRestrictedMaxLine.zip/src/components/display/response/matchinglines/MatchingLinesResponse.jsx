import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import '../../../../styles/item/MatchingLines.css'
import LineTo from "react-lineto";
import { set } from 'lodash';
import contentParser from '../../../../utility/contentParser';

const MatchingLinesResponse = ({ item, onUpdate, showCorrectResponse, isPreview, responseOnly }) => {
    const itemJson = item?.item_json;
    const [leftItem, setLeftItem] = useState("");
    const [rightItem, setRightItem] = useState("");
    const [width, setWidth] = useState(window.innerWidth);
    const [height, setHeight] = useState(window.innerHeight);

    const [contentLeft, setContentLeft] = useState([]);
    const [contentRight, setContentRight] = useState([]);
    const [lineTo, setLineTo] = useState(false);
    const [selected, setSelected] = useState([]);
    /**
   * The LineTo library we're using makes drawing the lines easy, but if the browser
   * is resized, the absolute positioning means that the lines will be in the wrong place.
   * This function should fire when the document is resized. This in turn should set state,
   * which will hopefully cause a re-render of the preview component,
   * and then any lines we've rendered will update accordingly.
   */
    const updateWidthAndHeight = () => {
        setWidth(window.innerWidth);
        setHeight(window.innerHeight);
    };

    useEffect(() => {
        if (itemJson?.optionList !== undefined || itemJson?.matchList !== undefined) {
            setContentLeft(itemJson?.optionList);
            setContentRight(itemJson?.matchList);
        }
        setTimeout(() => setLineTo(!lineTo), 100);
    })

    /**
     * On initial load, set the resize event listener. This is what
     * will cause our re-rendering needed to position lines between elements.
     * We're returning a function, which React will run as cleanup,
     * sort of like classes and componentWillUnmount.
     */
    useEffect(() => {
        window.addEventListener("resize", updateWidthAndHeight);
        return () => window.removeEventListener("resize", updateWidthAndHeight);
    }, []);

    /**This method is to set the response option to yellow colour initially when we click (before match)**/
    const highlightResponse = (id) => {
        let isCorrect = "";
        if (leftItem === id || rightItem === id) {
            isCorrect = "matching-selected-match";
        }
        const correctResponse = (responseOnly || showCorrectResponse) ? (itemJson.correctResponse || []) : selected;
        if (correctResponse != undefined) {
            for (let index = 0; index < correctResponse.length; index++) {
                if (
                    (correctResponse[index].id === id && correctResponse[index].value !== "") ||
                    (correctResponse[index].value === id && correctResponse[index].id !== "")
                ) {
                    isCorrect = "matching-border"
                    break;
                }
            }
        }
        return isCorrect;
    };

    /**This method is to set the yellow colour when we click on matched response **/
    const matchedColour = (id) => {
        let isCorrect = "";
        if (leftItem === id || rightItem === id) {
            isCorrect = "matching-colour-match";
        }
        return isCorrect;
    };

    const correctResponseUpdate = (id, value) => {

        if (itemJson?.correctResponse != undefined) {

            const rowList = responseOnly ? (itemJson?.correctResponse?.filter(
                (rowId) => rowId.id !== id && rowId.value !== value
            ) || []) : selected;

            setSelected([...rowList, { id: id, value: value }])
            if (isPreview) {
                const previewRowList = selected.filter(
                    (rowId) => rowId.id !== id && rowId.value !== value
                );
                setSelected([...previewRowList, { id: id, value: value }])
            }
            if (showCorrectResponse == false && responseOnly && onUpdate !== undefined) {
                checkUnMatchOption(id, value, rowList);
            }
        }
    };

    const checkUnMatchOption = (id, value, rowList) => {

        let correctResponse = [...itemJson.correctResponse];
        let isEmpty = correctResponse?.length <= 0;

        if (isEmpty) {
            const optionList = (itemJson.optionList.filter(
                (optionList) => optionList.id !== id
            ) || []);
            const matchList = (itemJson.matchList.filter(
                (matchList) => matchList.id !== value
            ) || []);
            const unMatchLeft = optionList?.filter((option) => option.id !== id)?.map(option => {
                return {
                    id: option.id,
                    value: ""
                }
            });
            const unMatchRight = matchList?.filter((option) => option.id !== value).map(option => {
                return {
                    id: "",
                    value: option.id
                }
            });
            correctResponse = [...unMatchLeft, ...unMatchRight, { id: id, value: value }]
        } else {
            let undoLeftResponse = [];
            let undoRightResponse = [];
            correctResponse.forEach((response) => {
                if (response.id !== "" && response.value !== "") {
                    if (response.id !== id && response.value === value) {
                        undoLeftResponse = [{ id: response.id, value: "" }];
                    }
                    if (response.value !== value && response.id === id) {
                        undoRightResponse = [{ id: "", value: response.value }];
                    }
                }
            })
            correctResponse = Array.from(new set([...rowList, ...undoLeftResponse, ...undoRightResponse, { id: id, value: value }]));
        }
        onUpdate({
            item_json: {
                correctResponse: correctResponse
            }
        })
    }

    /**
   * if the both matches are set, pass back up to parent and then clear state
   *
   * @param {string} left - ID of left selected element
   * @param {string} right - ID of right selected elemetn
   */
    const checkMatch = (left, right) => {
        if (left && right) {
            correctResponseUpdate(left, right);
            setRightItem("");
            setLeftItem("");
        }

    };

    const leftClick = (id) => {
        if (leftItem === id) {
            setLeftItem(id);
        } else {
            setLeftItem(id);
        }
        checkMatch(id, rightItem);
    }

    const rightClick = (id) => {
        if (rightItem === id) {
            setRightItem(id);
        } else {
            setRightItem(id);
        }
        checkMatch(leftItem, id);
    };

    return (
        <div className="row p-2">
            <fieldset className={`${responseOnly && 'bg-light'} p-3 rounded`}>
                {responseOnly && <legend className='pt-1'>Correct Response</legend>}
                <div className='bg-white'>
                    <div className="row">
                        <div className="col-md-6 d-flex justify-content-center">
                            <div className="ml-header-align" style={{
                                width: itemJson?.dimensions?.width,
                            }}>
                                <div className="p-4">
                                    {contentParser(itemJson?.leftTitle || '<div></div>')}
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 d-flex justify-content-center">
                            <div className="ml-header-align" style={{
                                width: itemJson?.dimensions?.width,
                            }}>
                                <div className="p-4">
                                    {contentParser(itemJson?.rightTitle || '<div></div>')}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-6 col-6 d-flex align-items-center flex-column option-column">
                            {contentLeft.map((option, index) => (
                                <div key={index}>
                                    <div
                                        className={`matching-match-item ${option.id} ${highlightResponse(option.id)} ${matchedColour(option.id)}`}
                                        data-testid={option.id}
                                        onClick={() => showCorrectResponse ? null : leftClick(option.id)}
                                        id={option.id && !showCorrectResponse ? "option"
                                            : option.optionText === "" ? null
                                                : ""}
                                        style={{
                                            width: itemJson?.dimensions?.width + 'px',
                                            height: itemJson?.dimensions?.height + 'px',
                                        }}
                                    >
                                        <div
                                            style={{
                                                width: itemJson?.dimensions?.width + 'px',
                                                height: itemJson?.dimensions?.height + 'px',
                                            }}
                                            className="options-content p-4"
                                        >
                                            {contentParser(option.optionText || '<div></div>')}
                                        </div>
                                    </div>
                                </div>
                            ))}{lineTo !== undefined &&
                                <div>
                                    {(showCorrectResponse == false && responseOnly) || showCorrectResponse ? itemJson?.correctResponse !== undefined &&
                                        itemJson?.correctResponse?.map((response, index) => {
                                            return (
                                                <LineTo
                                                    borderColor="#000000"
                                                    borderWidth={3}
                                                    zIndex={98}
                                                    from={response.id}
                                                    fromAnchor="right"
                                                    to={response.value}
                                                    toAnchor="left"
                                                    key={index}
                                                />
                                            );
                                        }) :
                                        selected.map((response, index) => {
                                            return (
                                                <LineTo
                                                    borderColor="#000000"
                                                    borderWidth={3}
                                                    zIndex={98}
                                                    from={response.id}
                                                    fromAnchor="right"
                                                    to={response.value}
                                                    toAnchor="left"
                                                    key={index}
                                                />
                                            );
                                        })
                                    }
                                </div>}
                        </div>
                        <div className="col-md-6 col-6 d-flex align-items-center flex-column option-column">
                            {contentRight.map((option, index) => (
                                <div
                                    key={index}
                                    data-testid={option.id}
                                    id={
                                        option.id && !showCorrectResponse
                                            ? "option"
                                            : option.optionText === ""
                                                ? null
                                                : ""
                                    }
                                    className={`matching-match-item ${option.id} ${highlightResponse(option.id)} ${matchedColour(option.id)}`}
                                    onClick={() =>
                                        showCorrectResponse ? null : rightClick(option.id)
                                    }
                                    style={{
                                        width: itemJson?.dimensions?.width + 'px',
                                        height: itemJson?.dimensions?.height + 'px',
                                    }}
                                >
                                    <div
                                        style={{
                                            width: itemJson?.dimensions?.width + 'px',
                                            height: itemJson?.dimensions?.height + 'px',
                                        }}
                                        className="options-content p-4"
                                    >
                                        {contentParser(option.optionText || '<div></div>')}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </fieldset>
        </div>
    )
}

MatchingLinesResponse.propTypes = {
    item: PropTypes.object,
    onUpdate: PropTypes.func,
    showCorrectResponse: PropTypes.bool,
    isPreview: PropTypes.bool,
    responseOnly: PropTypes.bool
};

export default MatchingLinesResponse;
