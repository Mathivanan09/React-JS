import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import TagAccessibilityCommand from './tagaccessibilitycommand';
const TAGACCESSIBILITY = 'tagAccessibility';
const ID = 'data-access-id';

/**
 * Class component to create Tag Accessibility Editing Plugin (Accessibility Tag creation functionalites)
 *
 * @memberof TagAccessibility
 * @inner
 *
 * @class
 * @namespace TagAccessibilityEditing
 *
 */

export default class TagAccessibilityEditing extends Plugin {
  static get pluginName() {
    return 'TagAccessibilityEditing';
  }

  init() {
    const editor = this.editor;
    const schema = editor.model.schema;

    // Schema defintion to handle Tag Accessibility
    schema.extend('$text', { allowAttributes: TAGACCESSIBILITY });
    schema.setAttributeProperties(TAGACCESSIBILITY, {
      isFormatting: true,
      copyOnEnter: true,
    });

    editor.conversion.for('downcast').attributeToElement({
      model: TAGACCESSIBILITY,
      view: (attributeValue, { writer }) => {
        return writer.createAttributeElement('span', { class: 'tag-accessibility' });
      },
      converterPriority: 5
    });

    editor.conversion.for('upcast').elementToAttribute({
      model: TAGACCESSIBILITY,
      view: {
        name: 'span',
        classes: 'tag-accessibility'
      },
      converterPriority: 5
    });

    editor.commands.add(TAGACCESSIBILITY, new TagAccessibilityCommand(editor, TAGACCESSIBILITY));

    //  new schema definition to handle ID's
    schema.extend('$text', { allowAttributes: ID });
    schema.setAttributeProperties(ID, {
      isFormatting: true,
      copyOnEnter: true,
    });

    editor.conversion.for('downcast').attributeToElement({
      model: ID,
      view: (attributeValue, { writer }) => {
        return writer.createAttributeElement('span', { 'data-access-id': attributeValue });
      },
      converterPriority: 5
    });

    editor.conversion.for('upcast').attributeToAttribute({
      model: ID,
      view: {
        key: 'data-access-id',
        value: /\S+/
      },
      converterPriority: 5
    });

    editor.commands.add(ID, new TagAccessibilityCommand(editor, ID));
  }
}
