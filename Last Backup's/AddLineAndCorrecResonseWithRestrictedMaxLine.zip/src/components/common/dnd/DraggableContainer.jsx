import React, { useState } from 'react';
import {
  DndContext,
  DragOverlay,
  useSensor,
  MouseSensor,
  TouchSensor,
  KeyboardSensor,
  useSensors
} from '@dnd-kit/core';
import DraggableItem from './DraggableItem';

const DraggableContainer = ({
  activationConstraint,
  handle,
  label = '',
  modifiers,
  style,
  removeDropZone,
  createComponent,
  updateDropZonePosition,
  item
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const mouseSensor = useSensor(MouseSensor, {
    activationConstraint
  });
  const touchSensor = useSensor(TouchSensor, {
    activationConstraint
  });
  const keyboardSensor = useSensor(KeyboardSensor, {});
  const sensors = useSensors(mouseSensor, touchSensor, keyboardSensor);

  return (
    <DndContext
      sensors={sensors}
      onDragStart={() => setIsDragging(true)}
      onDragEnd={({ delta, active }) => {
        setIsDragging(false);
        updateDropZonePosition(delta, active);
      }}
      onDragCancel={() => setIsDragging(false)}
      modifiers={modifiers}
    >
      {item.item_json?.matchList?.map((dropZone) => (
        <DraggableItem
          coordinates={dropZone.coordinates}
          id={dropZone.id}
          label={label}
          handle={handle}
          style={{
            ...style,
            top: dropZone.coordinates.y,
            left: dropZone.coordinates.x
          }}
          removeDropZone={removeDropZone}
          createComponent={createComponent}
        />
      ))}
      <DragOverlay dropAnimation={null}>
        {isDragging ? <DraggableItem dragging dragOverlay style={{
          height: style.height,
          width: style.width,
        }}/> : null}
      </DragOverlay>
    </DndContext>
  );
};

export default DraggableContainer;
