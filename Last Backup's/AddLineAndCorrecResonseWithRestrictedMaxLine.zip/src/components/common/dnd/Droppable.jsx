import React from 'react';
import { useDroppable, UniqueIdentifier } from '@dnd-kit/core';

import styles from './Droppable.module.css';

const Droppable = ({
  children,
  id,
  dragging,
  coordinates,
  dropzoneHeight,
  dropzoneWidth,
  invisible
}) => {
  const { isOver, setNodeRef } = useDroppable({
    id,
  });

  return (
    <div
      ref={setNodeRef}
      id={id}
      className={'Droppable over dragging dropped'}
      aria-label='Droppable region'
      style={{
        top: coordinates.y,
        left: coordinates.x,
        height: +dropzoneHeight+2 + 'px',
        width: +dropzoneWidth+2 + 'px',
        position: 'absolute',
        border: !invisible?'1px solid #000':'none',
      }}
    >
      {children}
    </div>
  );
};
export default Droppable;
