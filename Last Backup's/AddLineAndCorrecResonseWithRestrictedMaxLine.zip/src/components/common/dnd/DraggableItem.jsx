import React from 'react';
import { useDraggable } from '@dnd-kit/core';
import Draggable from './Draggable';

const DraggableItem = ({
  id,
  label,
  style,
  handle,
  removeDropZone,
  createComponent,
  disabled,
}) => {
  const { attributes, isDragging, listeners, setNodeRef, transform } =
    useDraggable({
      id,
      disabled,
    });

  return (
    <>
      <Draggable
        ref={setNodeRef}
        dragging={isDragging}
        handle={handle}
        label={label}
        listeners={listeners}
        style={style}
        transform={transform}
        id={id}
        createComponent={createComponent}
        removeDropZone={removeDropZone}
        {...attributes}
      />
      {createComponent&&!isDragging && (
        <button
          className='btn btn-outline-dark btn-sm'
          onClick={(e) => {
            e.preventDefault();
            removeDropZone(id);
          }}
          style={{
            left: style?.left + style?.width + 'px',
            top: style?.top + 'px',
            position: 'absolute',
            width: '25px',
            height: '25px'
          }}
        >
          <span aria-hidden='true'>&times;</span>
        </button>
      )}
    </>
  );
};

export default DraggableItem;
