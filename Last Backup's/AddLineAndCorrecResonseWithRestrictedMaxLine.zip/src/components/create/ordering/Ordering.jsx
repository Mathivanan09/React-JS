import React, { useState, useEffect } from 'react';
import uuid from 'react-uuid';

import AnswerAlignment from '../shared/AnswerAlignment';
import ItemDimensions from '../shared/ItemDimensions';
import ReorderItems from '../shared/ReorderItems';
import StemContent from '../shared/StemContent';

import OrderingResponse from '../../display/response/ordering/OrderingResponse';
import OrderingInitialView from './OrderingInitialView';

import { readableResponseParser } from '../../../utility/readableResponse';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import { itemProps } from '../../common/ItemHelper';
import label from '../../../constants/labelCodes';
import fetch from '../../../utility/default';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/Ordering.css';

const DIR_UP = -1;
const DIR_DOWN = 1;

/**
 * React functional component to create Ordering item
 *
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace Ordering
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Ordering item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {Ordering} Ordering component for creating Ordering item
 * 
 * @example
 * <Ordering item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'ord' },
    user_id: 0,
  }} />
 */
const Ordering = ({ item, onUpdate, config }) => {
  const answerAlignments = {
    vertical: 'Vertical',
    horizontal: 'Horizontal'
  };

  /**
   * Prepares blank data for options and rationale
   *
   * @inner
   * @memberof Ordering
   *
   * @function
   * @namespace getBlankData
   *
   * @param {string} answerAlignment Type for which blank data need to be constructed
   * possible values are 'Vertical' and 'Horizontal'
   * @returns {object} An object with empty options and rationale based
   * on the answer alignment.
   */
  const getBlankData = (answerAlignment) => {
    let blankOptions = [];
    let blankRationale = [];
    let blankCorrectResponse = [];
    for (let i = 0; i < 0; i++) {
      const optionId = uuid();
      blankOptions.push({
        id: optionId,
        optionText: ''
      });
      blankRationale.push({
        id: optionId,
        rationaleText: ''
      });
      blankCorrectResponse.push({
        id: optionId,
        value: i
      });
    }

    if (answerAlignment !== answerAlignments.vertical) {
      return {
        optionList: blankOptions,
        rationale: blankRationale,
        correctResponse: blankCorrectResponse
      };
    } else if (answerAlignment !== answerAlignments.horizontal) {
      return {
        optionList: blankOptions,
        rationale: blankRationale,
        correctResponse: blankCorrectResponse
      };
    }
  };

  // All event methods go here and uses dispatch method
  const [showRationale, setShowRationale] = useState([]);
  const [initialized, setInitialized] = useState(false);

  // TODO Once byron's default JSON skeleton api is available, useEffect can be removed
  useEffect(() => {
    // Initialize the data if coming from new item screen
    if (item && item.id < 0 && !initialized) {
      let answerAlignment =
        item.item_json?.answerAlignment || fetch('answerAlignment');
      const data = getBlankData(answerAlignment);
      const blankOptions = data.optionList;
      const blankRationale = data.rationale;
      const blankCorrectResponse = data.correctResponse;

      let payload = {
        ...item,
        correctResponse: blankCorrectResponse,
        item_json: {
          ...item.item_json,
          answerAlignment: answerAlignment,
          optionList: blankOptions,
          responseOptionHeight: 60,
          responseOptionWidth: 350
        },
        rationale: { optionList: blankRationale }
      };
      onUpdate(payload);
      setInitialized(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Here empty dependency only allowed, do not provide any dependecies here.

  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  // Checks if the option id is present in the list of correct responses
  const isCorrectResponse = (id) => {
    return item.correctResponse && item.correctResponse.indexOf(id) > -1;
  };

  // Adds a new option to the option list
  const addOption = () => {
    const optionId = uuid(); //New UUID will be generated and assigned to each response

    const addedOption = [
      ...(item.item_json?.optionList || []),
      { optionText: '', id: optionId }
    ];

    const newRationaleList = [
      ...(item.rationale?.optionList || []),
      { rationaleText: '', id: optionId }
    ];
    const updatedCorrectResponses = [
      ...(item?.item_json?.correctResponse || []),
      { id: optionId, value: item?.item_json?.correctResponse?.length || 0 }
    ];

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newRationaleList },
      item_json: {
        optionList: addedOption,
        correctResponse: updatedCorrectResponses
      }
    };
    onUpdate(updatedItem);
  };

  // Generates readable response for the option
  const updateReadableResponse = (value) => {
    let correctResponses;
    const readableResponse = generateReadableResponse(correctResponses);
    // prepare the payload
    let updatedItem = {
      readableResponse: readableResponse,
      item_json: {
        correctResponse: correctResponses
      }
    };
    onUpdate(updatedItem);
  };

  // Event handler for adding option data
  /* istanbul ignore next */
  const handleOptionChange = (data, index) => {
    const newOptList = [...item.item_json.optionList];
    newOptList[index] = {
      ...newOptList[index],
      optionText: data
    };

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: newOptList
      }
    };
    onUpdate(updatedItem);
  };

  // Toggles the rationale text box
  const showHideRationale = (id) => {
    const showing = new Set([...showRationale]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowRationale([...showing]);
  };

  // Event handler for adding rationale data
  /* istanbul ignore next */
  const handleRationaleChange = (data, index) => {
    const newList = [...(item.rationale?.optionList || [])];
    newList[index] = { ...newList[index], rationaleText: data };
    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newList }
    };
    onUpdate(updatedItem);
  };

  //Move items up or down using arrow keys.
  const reorderItems = (id, counter) => {
    const itemIndex = item.item_json?.optionList.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === item.item_json?.optionList.length - 1)
    ) {
      return; // canot move outside of array
    }

    //Reorder the optionList
    const optionItem = item.item_json?.optionList[itemIndex];
    let updatedOptionItems = [];
    if (
      item.item_json?.optionList &&
      item.item_json?.optionList.length > 0
    ) {
      updatedOptionItems =
        item.item_json?.optionList?.filter((i) => i.id !== id) || [];
      updatedOptionItems.splice(itemIndex + counter, 0, optionItem);
    }

    //Reorder the rationale list
    const rationaleItem = item.rationale.optionList[itemIndex];
    let updatedRationaleItems = [];
    if (
      item.rationale?.optionList &&
      item.rationale?.optionList.length > 0
    ) {
      updatedRationaleItems =
        item.rationale?.optionList?.filter((i) => i.id !== id) || [];
      updatedRationaleItems.splice(itemIndex + counter, 0, rationaleItem);
    }

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: updatedRationaleItems },
      item_json: {
        optionList: updatedOptionItems
      }
    };
    onUpdate(updatedItem);
  };

  //Remove the item
  const removeOption = (id) => {
    //Updating the correct response object.
    const removedIndex = item.item_json.correctResponse.find(response =>
      response.id === id
    ).value;

    const correctResponse = item.item_json.correctResponse.filter(response =>
      response.id !== id
    ).map(response => ({
      ...response,
      value: response.value > removedIndex ? response.value - 1 : response.value,
    }));

    //Remove from optionList
    let optionList =
      item.item_json?.optionList?.filter((element) => element.id !== id) ||
      [];
    //Remove from rationale
    let updatedRationaleList =
      item.rationale?.optionList?.filter((element) => element.id !== id) ||
      [];

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: updatedRationaleList },
      item_json: {
        optionList: optionList,
        correctResponse,
      }
    };

    onUpdate(updatedItem);
  };

  /**
   * @summary This method is used to Build readable response for Multiple Choice Item.
   *
   * @inner
   * @memberof UtilityMethods
   *
   * @function
   * @namespace generateReadableResponse
   */
  const generateReadableResponse = (updatedCorrectResponses) => {
    let readableResponse = '';
    if (updatedCorrectResponses) {
      updatedCorrectResponses.forEach((updatedCorrectResponse, index) => {
        const optIndex = item.item_json?.optionList.findIndex(
          (element) => element.id === updatedCorrectResponse
        );
        if (optIndex >= 0) {
          let responseText =
            item.item_json?.optionList[optIndex].optionText;
          let parseElement = readableResponseParser({
            responseText: responseText
          });
          if (index === 0) {
            readableResponse = `${parseElement}`;
          } else {
            readableResponse = readableResponse + `\n\n${parseElement}`;
          }
        }
      });
    }
    return readableResponse;
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={(key, value) => {
                onUpdate({
                  item_json: {
                    ...item.item_json,
                    ...{ stemContent: value, [key]: value }
                  }
                });
              }}
              fieldName='stemContent'
            />
          </div>
          <div className='row' data-testid='options-container'>
            <div className='col col-12 col-sm-5'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <legend>{label.ordering_choice_options}</legend>
                <AnswerAlignment
                  data={[
                    { id: 'Vertical', name: 'Vertical' },
                    { id: 'Horizontal', name: 'Horizontal' }
                  ]}
                  labelCode='answer_alignment'
                  onUpdate={updateItemJson}
                  updateKey='answerAlignment'
                  isRequired={true}
                  showSelect={false}
                  value={item.item_json?.answerAlignment || 'Vertical'}
                ></AnswerAlignment>
                {item?.item_json?.answerAlignment === 'Horizontal' ? (
                  <>
                    <div className='row p-2 text-align-center'>
                      <div className='col col-sm-12 col-md-6 text-right'>
                        <label className='form-label p-2'>
                          {label.response_option_width}:
                        </label>
                      </div>
                      <div className='col'>
                        <input
                          id='responseOptionWidth'
                          value={item?.item_json?.responseOptionWidth || 350}
                          onChange={(e) => {
                            updateItemJson(
                              'responseOptionWidth',
                              e.target.value
                            );
                          }}
                          type='number'
                          className='form-control'
                        ></input>
                      </div>
                    </div>
                    <div className='row p-2 text-align-center'>
                      <div className='col col-sm-12 col-md-6 text-right'>
                        <label className='form-label p-2'>
                          {label.response_option_height}:
                        </label>
                      </div>
                      <div className='col'>
                        <input
                          id='responseOptionHeight'
                          value={item?.item_json?.responseOptionHeight || 60}
                          onChange={(e) => {
                            updateItemJson(
                              'responseOptionHeight',
                              e.target.value
                            );
                          }}
                          type='number'
                          className='form-control'
                        ></input>
                      </div>
                    </div>
                  </>
                ) : (
                  <></>
                )}
              </fieldset>
            </div>
            <div className='col col-12 col-sm-7'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className='row'>
                  <div className='col col-sm-6'>
                    <legend>{label.response_options}</legend>
                  </div>
                  <div className='col col-sm-6 text-end text-right'>
                    <button
                      className='btn btn-primary'
                      data-testid='ordering-addoption'
                      icon='add'
                      onClick={(e) => {
                        e.preventDefault();
                        addOption();
                      }}
                    >
                      {label.ordering_add_options}
                    </button>
                  </div>
                </div>

                <div className='optionbox' data-testid='optionbox'>
                  {item.item_json?.optionList?.map(({ id }, i) => (
                    <div
                      key={id}
                      className='p-10'
                      data-testid='ordering-option'
                    >
                      <div className='row option align-items-center p-2'>
                        <div
                          className='col col-6 col-md-4 col-lg-2 text-end text-right ord-select-container'
                        >
                          <ReorderItems
                            listLength={item.item_json.optionList.length}
                            option={i}
                            onDownClick={() => reorderItems(id, DIR_DOWN)}
                            onUpClick={() => reorderItems(id, DIR_UP)}
                          />
                        </div>
                        <div className='col ord-item-box'>
                          <CKEditorBase
                            type='inline'
                            data={item.item_json.optionList[i].optionText}
                            className='content_style'
                            onChange={
                              /* istanbul ignore next */
                              (data) => {
                                handleOptionChange(data, i);
                              }
                            }
                            placeholder={label.enter_response_content}
                          />
                        </div>
                        <div className='col col-1'>
                          <button
                            className='icon'
                            onClick={(e) => {
                              e.preventDefault();
                              removeOption(id);
                            }}
                            data-testid='option-remove-button'
                          >
                            <span className='icon-minus'>-</span>
                          </button>
                        </div>
                      </div>
                      <div className='row rationale align-items-center p-2'>
                        <div
                          className='col col-4 col-sm-3 col-lg-2 text-end text-right'
                        >
                          <button
                            className='btn btn-primary btn-sm'
                            onClick={() => showHideRationale(id)}
                            data-testid='rationale-button'
                          >
                            {label.rationale}
                          </button>
                        </div>
                        {showRationale.indexOf(id) !== -1 && (
                          <div
                            className='col ord-item-box'
                            data-testid='rationale-container'
                          >
                            <CKEditorBase
                              type='inline'
                              data={
                                item.rationale.optionList[i].rationaleText
                              }
                              onChange={
                                /* istanbul ignore next */
                                (data) => {
                                  handleRationaleChange(data, i);
                                }
                              }
                              placeholder={label.enter_rationale_content}
                              config={{ removePlugins: ['TagAccessibility'] }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </fieldset>
            </div>
          </div>

          <div className='row p-3' data-testid='ord-correct-response-container'>
            <fieldset className='bg-light p-3 rounded m-1'>
              <legend>{label.correct_response}</legend>
              {item.item_json?.answerAlignment === 'Vertical' ? (
                <div className='row'>
                  <div className='col'>
                    <OrderingInitialView item={item} config={config} />
                  </div>
                  <div className='col'>
                    <OrderingResponse
                      item={item}
                      config={config}
                      showCorrectResponse={true}
                      isPreview={false}
                      onUpdate={onUpdate}
                    />
                  </div>
                </div>
              ) : (
                <>
                  <div className='row'>
                    <OrderingInitialView item={item} config={config} />
                  </div>
                  <div className='row'>
                    <OrderingResponse
                      item={item}
                      config={config}
                      showCorrectResponse={true}
                      isPreview={false}
                      onUpdate={onUpdate}
                    />
                  </div>
                </>
              )}
            </fieldset>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

Ordering.propTypes = itemProps;

export default Ordering;
