import React from 'react';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';

import CompositeItem from '../../display/item/composite/CompositeItem';
import AddItems from './items/AddItems';
import ItemGrid from './items/ItemGrid';
import getConfig from './items/config';

import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/CompositeItems.css';

/**
 * React functional component - Component to view/edit/create Composite Items
 *
 * 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace CompositeItems
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Composite-Items
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object, if any
 * @param {Object} param.api API information, if available.
 * @return {CompositeItems} component for creating Composite-Items
 * 
 * @example
 * <CompositeItems item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'com' },
    user_id: 0,
  }} />
 */
const CompositeItems = ({ item, onUpdate, config, api }) => {
  const { questionConfig } = getConfig(item, config, api);
  const itemJson = { ...(item?.item_json || {}) };
  const itemsList = [...(itemJson?.itemList || [])];

  // get the list of the item types based on category code (such as 'question', 'stimulus', 'simulation')
  const items = (itemsList?.filter(data => data?.category === 'question') || []); // question category item list

  /**
   * update item json based on key/value pairs
   *
   * @inner
   * @memberof CompositeItems
   *
   * @function
   * @namespace updateItemJson
   * 
   * @param {{key: String, value: String}} param passed in parameters
  */
  const updateItemJson = (key, value) => {
    onUpdate({
      ...item,
      item_json: {
        ...itemJson,
        [key]: value
      }
    });
  };

  const stem = itemJson?.stemContent;

  /**
   * update steam item json based on key/value pairs
   *
   * @inner
   * @memberof CompositeItems
   *
   * @function
   * @namespace updateItemStem
   * 
   * @param {{key: String, value: String}} param passed in parameters
  */
  const updateItemStem = (key, value) => {
    onUpdate({
      ...item,
      item_json: {
        ...itemJson,
        ...{
          stemContent: value,
          [key]: value
        }
      }
    });
  };

  /**
   * update item list based on index, key/value pairs
   *
   * @inner
   * @memberof CompositeItems
   *
   * @function
   * @namespace onUpdateItems
   * 
   * @param {{action: String, index: Number, key: String, value: Any}} param passed in parameters
   * @param {String} param.action update the items based on the action case.
   * @param {Number} param.index edit/sort/delete the item using the index.
   * @param {String} param.key will update the item based on the key.
   * @param {Any} param.value will hold the value to the update item
  */
  const onUpdateItems = (action, index, key, value) => {
    let updatedItems = itemsList || [];
    if (updatedItems?.length > 0 && index > -1 && itemsList?.[index] !== undefined) {
      if (action === 'delete') {
        updatedItems = [...updatedItems.slice(0, index), ...updatedItems.slice(index + 1)];
        updatedItems = [...updatedItems.map((data, index) => { return { ...data, 'order': index } })];
      } else if (action === 'sort') {
        if (key === 'up') {
          const above = itemsList[index - 1];
          const cursor = itemsList[index];
          updatedItems = [
            ...itemsList.slice(0, index - 1),
            { ...above, order: (above.order + 1) },
            { ...cursor, order: (cursor.order - 1) },
            ...itemsList.slice(index + 1)
          ];
        } else {
          const cursor = itemsList[index];
          const below = itemsList[index + 1];
          updatedItems = [
            ...itemsList.slice(0, index),
            { ...below, order: (below.order - 1) },
            { ...cursor, order: (cursor.order + 1) },
            ...itemsList.slice(index + 2)
          ];
        }
      } else { // default for editable item
        updatedItems = [
          ...itemsList.slice(0, index),
          {
            ...itemsList[index],
            [key]: value
          },
          ...itemsList.slice(index + 1)
        ];
      }

      updatedItems.sort((a, b) => a.order - b.order);

      onUpdate({
        ...item,
        item_json: {
          ...itemJson,
          itemList: updatedItems
        }
      });
    }
  };

  return (
    <>
      {item ? (
        <div className='composite-items-container' data-testid='composite-items-container'>
          <ItemDimensions
            minWidth={itemJson?.minItemWidth || 0}
            minHeight={itemJson?.minItemHeight || 0}
            onChange={(dimension) => {
              if (dimension?.minWidth !== itemJson?.minItemWidth) {
                updateItemJson('minItemWidth', dimension.minWidth);
              }
              if (dimension?.minHeight !== itemJson?.minItemHeight) {
                updateItemJson('minItemHeight', dimension.minHeight);
              }
            }}
          />
          <StemContent
            data={stem}
            onUpdate={updateItemStem}
            fieldName='stemContent'
          />
          <div className='row'>
            <AddItems
              key='Additems'
              items={items}
              setItems={(data) => {
                updateItemJson("itemList", data)
              }}
              config={questionConfig}
              categories={['question']}
            />
          </div>
          <div className='row'>
            <ItemGrid
              key='itemGrid'
              items={items}
              onUpdateItems={onUpdateItems}
              config={config}
              isAddItems={false}
            />
          </div>
          <div
            className='row correct-response-container p-2 pe-3'
            data-testid='com-correct-response-container'
          >
            <fieldset className='bg-light p-3 rounded m-1' disabled>
              <legend>{label.correct_response}</legend>
              <div
                className='composite-item-preview-container pb-2'
                data-testid='composite-item-preview-container'
              >
                {
                  itemsList?.map(({ header, ...data }, index) => {
                    const composite = data;
                    if (typeof composite?.item_json === 'object') {
                      composite.item_json = {
                        ...composite.item_json,
                        minItemWidth: 0,
                        minItemHeight: 0
                      };
                    };
                    return (
                      <CompositeItem
                        key={data?.id + '-' + index}
                        item={composite}
                        header={header}
                        showCorrectResponse={true}
                        responseOnly={true}
                      />
                    );
                  })
                }
              </div>
            </fieldset>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

CompositeItems.propTypes = itemProps;

export default CompositeItems;
