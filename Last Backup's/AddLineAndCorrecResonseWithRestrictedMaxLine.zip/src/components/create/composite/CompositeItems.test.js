import React from 'react';
import { act } from "react-dom/test-utils";
import { unmountComponentAtNode } from "react-dom";
import userEvent from '@testing-library/user-event';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';

// Existing Dummy Item Types Category (like questions)
import CompositeItemsJSON from "../../../stories/assets/com/CompositeItems.json";
import DummyItems from "../../../stories/assets/com/DummyItems.json";
import MCMS from "../../../stories/assets/mc/mc_multiple.json";
import TF from "../../../stories/assets/mc/mc_true_false.json";
import MCMZ from "../../../stories/assets/mc/mc_stackedZ.json";
import MCS from "../../../stories/assets/mc/mc_single.json";

// import component here
import CompositeItems from './CompositeItems';

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('Check the composite item functionality', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    test("Test an empty component and verify the element with Missing item data", () => {
        act(() => {
            render(
                <CompositeItems />,
                container
            );
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the 
     * elements and values when opened from new  item
     */
    test("Test skeleton component when opened from new item", () => {
        // set up test mock data as empty
        let config = {};
        let compositeItem = JSON.parse(JSON.stringify(CompositeItemsJSON.item));
        compositeItem.item_json.itemList = [];

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => { compositeItem = data });

        act(() => {
            render(
                <CompositeItems
                    item={compositeItem}
                    config={config}
                    onUpdate={onUpdate}
                />,
                container
            );
        });

        /**
         * Verify that there main containers Item Dimensions, stem content and Item Grid
         */
        const component = document.querySelector("[data-testid=composite-items-container]");
        expect(component).toBeInTheDocument();

        expect(screen.getByTestId("item-dimensions-container")).toBeInTheDocument();
        expect(screen.getByTestId("stem-content-container")).toBeInTheDocument();
        expect(screen.getByTestId("item-grid-container")).toBeInTheDocument();
        expect(screen.getByTestId("com-correct-response-container")).toBeInTheDocument();
        expect(screen.getByTestId("composite-item-preview-container")).toBeInTheDocument();
    });

    test('Check Create/Edit Composite Items', async () => {
        // set up mock function
        const fetchItems = jest.fn(
            async (categoryCodes, excludeIds, callback) => {
                const itemList = JSON.parse(JSON.stringify(DummyItems));
                if (categoryCodes.includes('question')) {
                    const questions = await itemList?.filter((item) =>
                        item.id && item?.category &&
                        excludeIds?.includes(item.id) === false &&
                        categoryCodes.includes(item?.category)
                    ) || [];
                    callback(questions);
                    return questions;
                }
                return [];
            }
        );
        const fetchItemsDetails = jest.fn(
            async (ids = []) => {
                const itemList = JSON.parse(JSON.stringify(DummyItems));
                itemList[0] = { ...MCMZ?.item, ...itemList[0] };
                itemList[1] = { ...MCS?.item, ...itemList[1] };
                itemList[2] = { ...MCMS?.item, ...itemList[2] };
                itemList[3] = { ...TF?.item, ...itemList[3] };
                const questions = await itemList.filter(item => ids.includes(item.id));
                return questions;
            }
        );

        // set up test mock data as empty
        let config = {};
        let compositeItem = JSON.parse(JSON.stringify(CompositeItemsJSON.item));
        compositeItem.item_json.itemList = [];

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => {
            compositeItem = data
        });

        let update;
        act(() => {
            const { rerender } = render(
                <CompositeItems
                    item={compositeItem}
                    config={config}
                    onUpdate={onUpdate}
                />
            );
            update = rerender;
        });

        // Verify that the Add Button, and The User should be able to click on Add item button and can select the items 
        let addItemButton = screen.getByTestId("show-add-item-modal");
        expect(addItemButton).toBeInTheDocument();

        // add item grid data to add items
        config = {
            fetchItems,
            fetchItemsDetails
        };

        act(() => {
            update(
                <CompositeItems
                    item={compositeItem}
                    config={config}
                    onUpdate={onUpdate}
                />
            );
        });

        act(() => {
            fireEvent.click(addItemButton); // load the add item modal
        });

        expect(screen.getByTestId('add-items-container')).toBeInTheDocument();

        await waitFor(() => {
            expect(config.fetchItems).toHaveBeenCalledTimes(1);
        });

        let itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');
        await waitFor(() => {
            itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');
            expect(itemListCheckbox[0]).not.toBeUndefined();
            expect(itemListCheckbox[1]).not.toBeUndefined();
        });

        expect(itemListCheckbox[0]).toBeInTheDocument();
        expect(itemListCheckbox[1]).toBeInTheDocument();

        // select the two item of the list
        act(() => {
            userEvent.click(itemListCheckbox[0]);
            userEvent.click(itemListCheckbox[1]);
        });

        await waitFor(() => {
            expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).toBeChecked();
        });

        // add the item by clicking the add item button
        const addItemsButton = screen.getByTestId('add-item-submit');
        expect(addItemsButton).toBeInTheDocument();

        act(() => {
            fireEvent.click(addItemsButton);
        });

        await waitFor(() => {
            expect(config.fetchItemsDetails).toHaveBeenCalledTimes(1);
            expect(onUpdate).toHaveBeenCalledTimes(1);
        });

        expect(compositeItem?.item_json?.itemList?.length).toBe(2);

        compositeItem.item_json.itemList = [
            ...compositeItem?.item_json?.itemList,
            {
                ...MCMS?.item,
                ...DummyItems[2],
                order: 2,
                category: "question"
            }
        ];

        // The selected items will be populated in the Item Grid below of Add item button
        act(() => {
            update(
                <CompositeItems
                    item={compositeItem}
                    config={config}
                    onUpdate={onUpdate}
                />
            );
        });

        // The User will be able to see the Actions, order id, order, type, name, header.
        await waitFor(() => {
            expect(document.querySelector('.item-grid .item-actions')).toBeInTheDocument();
            expect(screen.getByTestId('item-actions-container-0')).toBeInTheDocument();
        });

        // User will be able to remove the items if not needed by clicking on the removal icon. 
        // The User will be also able to swap the items within box by clicking on swap icons.
        // respective button should be rendered for the respective item based on the order
        const shiftUpButton = screen.getByTestId("item-1-actions-up");

        // click all the action item for the second item
        act(() => {
            fireEvent.click(shiftUpButton);
        });

        await waitFor(() => {
            expect(screen.getByTestId("item-1-actions-down")).toBeInTheDocument();
        });

        act(() => {
            fireEvent.click(screen.getByTestId("item-1-actions-down"));
        });

        await waitFor(() => {
            expect(screen.getByTestId("item-1-actions-delete")).toBeInTheDocument();
        });

        act(() => {
            fireEvent.click(screen.getByTestId("item-1-actions-delete"));
        });

        // all the actions should be call the onUpdate function to make the actions work
        await waitFor(() => {
            expect(onUpdate).toHaveBeenCalledTimes(4);
        });

    }, (10000000));

});