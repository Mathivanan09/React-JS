import React from "react";
import PropTypes from "prop-types";

/**
 * React functional component - Common Row Actions and its functionality (such as delete, shift up and down the item).
 *
 * @memberof ItemGrid
 * @inner
 * 
 * @component
 * @namespace ItemActions
 * 
 * @param {{items: Array, data: Object, onUpdate: Func}} param passed in parameters
 * @param {Array} param.items will hold the list of items information within an array 
 * @param {Object} param.data Respective grid Row data
 * @param {Func} param.onUpdate Callback function to update the Item List of the item_Json 
 * if there is any change in the state of the item (such as sort, delete, add)
 * @return {ItemGrid} Display Component with the Item Actions buttons
 * 
 * @example
 * <ItemActions 
    items={[{}]
    data={{...}}
    onUpdate={()=>{
        ...
    }}
  }} />
 */
const ItemActions = ({ items, data, onUpdate }) => {
    const index = data?.order;
    const arrowUp = index > 0;
    const arrowDown = (index > -1 && (index < (items?.length - 1)));

    return (
        <div className="item-actions" data-testid={'item-actions-container-' + index}>
            <span className="circle-minus">
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-slash-circle"
                    viewBox="0 0 16 16"
                    tabIndex="0"
                    role="button"
                    aria-label={"Delete the Item " + index}
                    color="red"
                    onClick={() => {
                        onUpdate('delete', index);
                    }}
                    onKeyDown={(event) => {
                        if (event.code === 'Enter') {
                            onUpdate('delete', index);
                        }
                    }}
                    data-testid={'item-' + index + '-actions-delete'}
                >
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                    <path d="M11.354 4.646a.5.5 0 0 0-.708 0l-6 6a.5.5 0 0 0 .708.708l6-6a.5.5 0 0 0 0-.708z" />
                </svg>
            </span>
            <span className={(arrowUp ? 'arrow-up' : 'arrow-up first-arrow-up')}>
                {
                    arrowUp &&
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-arrow-up"
                        viewBox="0 0 16 16"
                        tabIndex="0"
                        role="button"
                        aria-label={"Move Up the Item " + index + " Order"}
                        color='royalblue'
                        onClick={() => {
                            onUpdate('sort', index, 'up');
                        }}
                        onKeyDown={(event) => {
                            if (event.code === 'Enter') {
                                onUpdate('sort', index, 'up');
                            }
                        }}
                        data-testid={'item-' + index + '-actions-up'}
                    >
                        <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z" />
                    </svg>
                }
            </span>
            <span className="arrow-down">
                {
                    arrowDown &&
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        className="bi bi-arrow-down"
                        viewBox="0 0 16 16"
                        tabIndex="0"
                        role="button"
                        aria-label={"Move Down the Item " + index + " Order"}
                        color="royalblue"
                        onClick={() => {
                            onUpdate('sort', index, 'down');
                        }}
                        onKeyDown={(event) => {
                            if (event.code === 'Enter') {
                                onUpdate('sort', index, 'down');
                            }
                        }}
                        data-testid={'item-' + index + '-actions-down'}
                    >
                        <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z" />
                    </svg>
                }
            </span>
        </div>
    );
};

ItemActions.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object),
    data: PropTypes.object,
    onUpdate: PropTypes.func
};

export default ItemActions;
