import React from 'react';
import { act } from "react-dom/test-utils";
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { unmountComponentAtNode } from "react-dom";

// import component here
import ItemHeader from './ItemHeader';

let container = null;
beforeEach(() => {
      // setup a DOM element as a render target
      container = document.createElement("div");
      document.body.appendChild(container);
});

afterEach(() => {
      // cleanup on exiting
      unmountComponentAtNode(container);
      container.remove();
      container = null;
});

describe('Item Header Functionality Check', () => {

      /**
      * Item Header Functionality Check on the first time load
      */
      test("Item Header Functionality Check", async () => {
            // set up test mock data as empty
            const item = {
                  order: 0,
                  id: 12345,
                  category: 'question',
                  header: 'Item Header Text'
            };

            // set up test mock onUpdate function
            const headerUpdate = jest.fn((data) => {
                  item.header = data;
            });
            const onUpdate = jest.fn((action, index, key, editor) => {
                  if (action === 'edit' && key === 'header' && index >= 0) {
                        headerUpdate(editor);
                  }
            });

            let update;
            act(() => {
                  const { rerender } = render(
                        <ItemHeader
                              data={item}
                              onUpdate={onUpdate}
                        />,
                        container
                  );
                  update = rerender;
            });

            // header parser should be rendered for the first time
            let headerParser = document.querySelector('[data-testid=item-header-parser-0]');
            expect(headerParser).toBeInTheDocument();
            expect(screen.queryByText(item.header)).toBeInTheDocument();

            // perform click action on the header parser
            act(() => {
                  fireEvent.click(headerParser);
            });

            update(
                  <ItemHeader
                        data={item}
                        onUpdate={onUpdate}
                  />,
                  container
            );

            // editor should be rendered when the parser is clicked
            await waitFor(() => {
                  expect(screen.getByTestId("item-header-editor-0")).toBeInTheDocument();
            });

            // header parser should not be rendered when the parser is focused
            expect(document.querySelector('[data-testid=item-header-parser-0]')).toBeNull();

            expect(onUpdate).toHaveBeenCalledTimes(0);
            expect(headerUpdate).toHaveBeenCalledTimes(0);

      }, 1000000);

});