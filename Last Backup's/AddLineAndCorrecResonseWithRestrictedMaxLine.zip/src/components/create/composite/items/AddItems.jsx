import React, { useState } from "react";
import PropTypes from "prop-types";

import ItemGrid from './ItemGrid';

import label from '../../../../constants/labelCodes';

/**
 * React functional component - Common Pop to Add the Items using ItemGrid
 *
 * @memberof CompositeItems
 * @inner
 * 
 * @component
 * @namespace AddItems
 * 
 * @param {{items: Array, setItems: Func, config: Object, categories: Array}} param passed in parameters
 * @param {Array} param.items will hold the list of items information within an array to add selected items
 * @param {Func} param.setItems Callback function to update the Item List of the item_Json 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object, if any
 * @param {Object} param.categories categories object, if any
 * @return {AddItems} component for the Add Item Pop-Up Screen and its functionality
 * 
 * @example
 * <AddItems 
    item={[{}]
    setItems={()=>{
        ...
    }}
    config={{...}}
    categories={{...}} 
  />
 */
const AddItems = ({ items = [], setItems, config, categories = [] }) => {
    const [show, setShow] = useState(false);
    const [gridData, setGridData] = useState([]);
    const [selectedItem, setSelectedItem] = useState([]);

    /**
     * Handle on selection change event
     *
     * @inner
     * @memberof AddItems
     *
     * @function
     * @namespace handleOnSelectionChange
     *
     * @param {Object} event on change event
    */
    const handleOnSelectionChange = (event) => {
        const selectedData = event.api.getSelectedNodes().map((node) => node.data);
        setSelectedItem(selectedData);
    };

    /**
     * Add the selected items by using setItems Func and clear & close the AddItems Popup
     *
     * @inner
     * @memberof AddItems
     *
     * @function
     * @namespace onAddItem
     *
    */
    const onAddItem = async () => {
        if (selectedItem?.length > 0) {
            let newItems = [...selectedItem];
            const ids = selectedItem?.map(data => data?.id)?.filter(data => data !== undefined) || [];
            if (config?.fetchItemsDetails) {
                const newItemsDetails = await config.fetchItemsDetails(ids);
                if (newItemsDetails?.length > 0) {
                    newItems = newItemsDetails;
                }
            }
            const itemList = [...items, ...newItems].map((item, index) => {
                const data = { ...item, 'order': index };
                if (data.item_type_category_code !== undefined) {
                    data.category = data.item_type_category_code;
                }
                if (data.item_type_code !== undefined) {
                    data.type = data.item_type_name;
                }
                if (data.history == undefined) {
                    data.history = '';
                }
                return data;
            });
            itemList.sort((a, b) => a.order > b.order);
            setShow(false);
            setItems(itemList);
            setGridData([]);
        }
    };

    /**
     * clear & close the AddItems Popup
     *
     * @inner
     * @memberof AddItems
     *
     * @function
     * @namespace cancelAddItem
     *
    */
    const cancelAddItem = () => {
        setShow(false);
        setGridData([]);
    };

    // already added item ids can be excluded from the list of items while fetching from the Backend/DB
    const excludeIds = items?.map(data => data?.id)?.filter(data => data !== undefined) || [];

    /**
     * async function to get the list of the items from the config object for Add Items popup screen
     *
     * @inner
     * @memberof AddItems
     *
     * @function
     * @namespace fetchItems
     *
     * @returns {Func} callback function (setGridData) that will return the list of the existing items based on the selected categories and excludeIds.
    */
    const fetchItems = async () => {
        if (typeof config?.fetchItems === 'function') {
            await config.fetchItems(categories, excludeIds, setGridData);
        }
    };

    return (
        <>
            <div className='col-6'>
                <button
                    className='btn btn-primary'
                    onClick={() => setShow(true)}
                    data-testid='show-add-item-modal'
                >
                    {label.add_items}
                </button>
            </div>
            {show &&
                <>
                    <div className='fade modal-backdrop show'></div>
                    <div
                        className='modal show'
                        tabIndex='-1'
                        aria-modal='true'
                        aria-labelledby='add-item-modal-title'
                        role='dialog'
                        style={{ display: 'block' }}
                    >
                        <div
                            className='modal-dialog add-item-modal modal-xl modal-dialog-centered'
                            data-testid='add-item-modal-container'
                        >
                            <div className='modal-content'>
                                <div className='modal-header'>
                                    <div
                                        id='add-item-modal-title'
                                        className='modal-title h4'
                                        data-testid='add-item-modal-title'
                                    >
                                        {label.available_items}
                                    </div>
                                    <button
                                        type='button'
                                        tabIndex='0'
                                        data-testid='add-item-close'
                                        className='btn btn-danger btn-sm'
                                        onClick={cancelAddItem}
                                    >
                                        X
                                    </button>
                                </div>
                                <div className='modal-body'>
                                    <div data-testid='add-item-body' style={{ overflowX: 'auto' }}>
                                        <ItemGrid
                                            key='AdditemGrid'
                                            items={gridData}
                                            config={config}
                                            fetchItems={fetchItems}
                                            itemSelectionsHandler={handleOnSelectionChange}
                                            isAddItems={true}
                                        />
                                    </div>
                                </div>
                                <div className='modal-footer'>
                                    <button
                                        tabIndex='0'
                                        type='button'
                                        data-testid='add-item-cancel'
                                        className='btn btn-danger btn-sm'
                                        onClick={cancelAddItem}
                                    >
                                        {label.cancel}
                                    </button>
                                    <button
                                        tabIndex='0'
                                        type='button'
                                        data-testid='add-item-submit'
                                        className='btn btn-primary btn-sm'
                                        onClick={onAddItem}
                                        disabled={selectedItem?.length > 0 ? false : true}
                                    >
                                        {label.add}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            }
        </>
    );
}

AddItems.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object),
    setItems: PropTypes.func,
    config: PropTypes.object,
    categories: PropTypes.array,
};

export default AddItems;