import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import { fireEvent } from '@testing-library/react';

// import component here
import ReorderItems from './ReorderItems';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("Test empty component", () => {
  act(() => {
    render(<ReorderItems />, container);
  });

  // test the empty container
  const riContainer = document.querySelector("[data-testid=ri-container]");
  expect(riContainer).not.toBeNull;
  expect(riContainer.children.length).toBe(0);
});

it("Test component with listLength prop", () => {
  act(() => {
    render(<ReorderItems listLength={4}/>, container);
  });

  // test the empty container
  const riContainer = document.querySelector("[data-testid=ri-container]");
  expect(riContainer).not.toBeNull;
  expect(riContainer.children.length).toBe(1);

  // test if there exists 2 buttons
  const buttons = document.querySelectorAll("button");
  expect(buttons).not.toBeNull;
  expect(buttons.length).toBe(2);
  
});

// component with one arrow down button
it("Test component with listLength & option (0) prop", () => {
  act(() => {
    render(<ReorderItems listLength={4} option={0}/>, container);
  });

  // test the empty container
  const riContainer = document.querySelector("[data-testid=ri-container]");
  expect(riContainer).not.toBeNull;
  expect(riContainer.children.length).toBe(1);

  // test if there exists 2 buttons
  const buttons = document.querySelectorAll("button");
  expect(buttons).not.toBeNull;
  expect(buttons.length).toBe(1);
  expect(buttons[0].id).toBe('arrow-down-0');
});

// component with one arrow up button
it("Test component with listLength & option (listLength-1) prop", () => {
  act(() => {
    render(<ReorderItems listLength={4} option={3}/>, container);
  });

  // test the empty container
  const riContainer = document.querySelector("[data-testid=ri-container]");
  expect(riContainer).not.toBeNull;
  expect(riContainer.children.length).toBe(1);

  // test if there exists 2 buttons
  const buttons = document.querySelectorAll("button");
  expect(buttons).not.toBeNull;
  expect(buttons.length).toBe(1);
  expect(buttons[0].id).toBe('arrow-up-3');
});

// component with 2 buttons for option/index 2
it("Test component with listLength & option (listLength-1) prop", () => {
  act(() => {
    render(<ReorderItems listLength={4} option={2}/>, container);
  });

  // test the empty container
  const riContainer = document.querySelector("[data-testid=ri-container]");
  expect(riContainer).not.toBeNull;
  expect(riContainer.children.length).toBe(1);

  // test if there exists 2 buttons
  const buttons = document.querySelectorAll("button");
  expect(buttons).not.toBeNull;
  expect(buttons.length).toBe(2);
  expect(buttons[0].id).toBe('arrow-up-2');
  expect(buttons[1].id).toBe('arrow-down-2');
});