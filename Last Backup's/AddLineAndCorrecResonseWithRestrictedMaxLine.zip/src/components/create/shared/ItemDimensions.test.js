/**
 * @file Item Dimensions tests
 */
import React from 'react';
import { unmountComponentAtNode } from 'react-dom';
import { act } from 'react-dom/test-utils';
import { render, screen, fireEvent } from '@testing-library/react';

// import component here
import ItemDimensions from './ItemDimensions';

let container = null;

beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement('div');
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it('Testing component without props', () => {
  act(() => {
    render(<ItemDimensions />, container);
  });
  // check the ItemDimensions loaded properly or not by checking the container
  expect(screen.getByTestId('item-dimensions-container')).toBeInTheDocument();
  expect(screen.getByTestId('item-dim-min-width')).toBeInTheDocument();
  expect(screen.getByTestId('item-dim-min-height')).toBeInTheDocument();

  // get a hold of the inputs element, and trigger change on it with a value
  const width = document.querySelector('[data-testid=item-dim-min-width]');

  // always mininum value is zero
  expect(width.min).toBe("0");

  // check is that loading default value
  expect(width.value).toBe("0")
});

it('Testing with data width prop', () => {

  // set up test mock data
  const item = {
    item_json: {
      minItemWidth: 400,
      minItemHeight: 400
    }
  };

  // set dummy onUpdate function for ItemJson
  const setOnChangeValue = jest.fn().mockImplementation((dimension) => {
    if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
      item.item_json.minItemWidth = parseInt(dimension.minWidth, 10);
    }
    if (dimension?.minHeight !== item.item_json.minItemHeight) {
      item.item_json.minItemHeight = parseInt(dimension.minHeight, 10);
    }
  });

  let update;
  act(() => {
    let { rerender } = render(
      <ItemDimensions
        minWidth={item?.item_json?.minItemWidth}
        minHeight={item?.item_json?.minItemHeight}
        onChange={(e) => { setOnChangeValue(e) }}
      />,
      container
    );
    update = rerender;
  });

  // check the ItemDimensions loaded properly or not by checking the container
  expect(screen.getByTestId('item-dimensions-container')).toBeInTheDocument();
  expect(screen.getByTestId('item-dim-min-width')).toBeInTheDocument();

  // get a hold of the inputs element, and trigger change on it with a value
  const width = document.querySelector('[data-testid=item-dim-min-width]');

  // check is that the input is loading saved value from props instead of loading default value or not
  expect(width.value).toBe("400");

  expect(setOnChangeValue).toHaveBeenCalledTimes(0);

  // trigger the change for the width
  act(() => {
    fireEvent.change(width, { target: { value: 600 } });
  });
  expect(setOnChangeValue).toHaveBeenCalledTimes(1);

  // check is that the item data value got updated or not
  expect(item?.item_json?.minItemWidth).toBe(600);
  act(() => {
    update(
      <ItemDimensions
        minWidth={item?.item_json?.minItemWidth}
        minHeight={item?.item_json?.minItemHeight}
        onChange={(e) => { setOnChangeValue(e) }}
      />,
      container
    )
  });

  // check is that the input is loading the new value instead of saved value from props instead of loading default value or not
  expect(width.value).toBe('600');

});


it('Testing with data height prop', () => {

  // set up test mock data
  const item = {
    item_json: {
      minItemWidth: 400,
      minItemHeight: 400
    }
  };

  // set dummy onUpdate function for ItemJson
  const setOnChangeValue = jest.fn().mockImplementation((dimension) => {
    if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
      item.item_json.minItemWidth = parseInt(dimension.minWidth, 10);
    }
    if (dimension?.minHeight !== item.item_json.minItemHeight) {
      item.item_json.minItemHeight = parseInt(dimension.minHeight, 10);
    }
  });


  let update;
  act(() => {
    let { rerender } = render(
      <ItemDimensions
        minWidth={item?.item_json?.minItemWidth}
        minHeight={item?.item_json?.minItemHeight}
        onChange={(e) => { setOnChangeValue(e) }}
      />,
      container
    );
    update = rerender;
  });

  // check the ItemDimensions loaded properly or not by checking the container
  expect(screen.getByTestId('item-dimensions-container')).toBeInTheDocument();
  expect(screen.getByTestId('item-dim-min-height')).toBeInTheDocument();

  // get a hold of the inputs element, and trigger change on it with a valu
  const height = document.querySelector('[data-testid=item-dim-min-height]');

  // check is that the input is loading saved value from props instead of loading default value or not
  expect(height.value).toBe("400");

  expect(setOnChangeValue).toHaveBeenCalledTimes(0);

  // trigger the change for the height
  act(() => {
    fireEvent.change(height, { target: { value: 700 } });
  });
  expect(setOnChangeValue).toHaveBeenCalledTimes(1);

  // check is that the item data value got updated or not
  expect(item?.item_json?.minItemHeight).toBe(700);
  act(() => {
    update(
      <ItemDimensions
        minWidth={item?.item_json?.minItemWidth}
        minHeight={item?.item_json?.minItemHeight}
        onChange={(e) => { setOnChangeValue(e) }}
      />,
      container
    )
  });

  // check is that the input is loading the new value instead of saved value from props instead of loading default value or not
  expect(height.value).toBe('700');
});
