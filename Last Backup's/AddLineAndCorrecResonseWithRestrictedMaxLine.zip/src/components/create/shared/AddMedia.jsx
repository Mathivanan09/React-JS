import React, { useState } from 'react';
import PropTypes from 'prop-types';

import { AgGridReact } from 'ag-grid-react';

import label from '../../../constants/labelCodes';

// Return the Add Media Pop-Up Screen with Add Media Grid and its functionality
export default function AddMedia({ media = [], setMedia, cancelMedia }) {
  const [selectedMedia, setSeletedMedia] = useState([]);

  const onAddMedia = () => {
    setMedia([...selectedMedia]);
    cancelAddMedia();
  };

  const cancelAddMedia = () => {
    setSeletedMedia([]);
    cancelMedia();
  };

  const defaultColDef = {
    sortable: true,
    filter: true,
    filterParams: { buttons: ['reset', 'apply'] },
    flex: 1
  };

  // columns definitions
  const columnDefs = [
    {
      headerName: 'ID',
      field: 'id',
      headerCheckboxSelection: false,
      checkboxSelection: true
    },
    { headerName: 'Name', field: 'name' },
    { headerName: 'Content Area', field: 'content_area' },
    { headerName: 'Grade Level', field: 'grade' },
    { headerName: 'Format', field: 'media_format' }
  ];

  const handleOnSelectionChange = (e) => {
    const selectedData = e.api.getSelectedNodes().map((node) => node.data);
    if (selectedData) {
      setSeletedMedia(selectedData);
    }
  };

  return (
    <>
      <div className='fade modal-backdrop show'></div>
      <div
        className='modal show'
        tabIndex='-1'
        aria-modal='true'
        aria-labelledby='contained-modal-title-vcenter'
        role='dialog'
        style={{ display: 'block', paddingLeft: '17px' }}
      >
        <div
          className='modal-dialog add-collection-modal modal-xl modal-dialog-centered'
        >
          <div className='modal-content'>
            <div className='modal-header'>
              <div
                className='modal-title h4'
                id='contained-modal-title-vcenter'
              >
                {label.available_media}
              </div>
              <button
                type='button'
                className='btn btn-primary btn-sm'
                onClick={cancelAddMedia}
              >
                X
              </button>
            </div>
            <div className='modal-body'>
              <div style={{ overflowX: 'auto' }}>
                <div
                  className='ag-theme-alpine'
                  style={{ height: '500px', width: '100%' }}
                >
                  <AgGridReact
                    pagination={true}
                    rowData={media}
                    columnDefs={columnDefs}
                    paginationPageSize={10}
                    rowSelection={'single'}
                    defaultColDef={defaultColDef}
                    onSelectionChanged={handleOnSelectionChange}
                  />
                </div>
              </div>
            </div>
            <div className='modal-footer'>
              <button
                type='button'
                className='btn btn-primary btn-sm'
                onClick={cancelAddMedia}
              >
                {label.cancel}
              </button>
              <button
                type='button'
                className='btn btn-primary btn-sm'
                onClick={onAddMedia}
                disabled={selectedMedia.length > 0 ? false : true}
              >
                {label.add}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

AddMedia.propTypes = {
  media: PropTypes.arrayOf(PropTypes.object),
  setMedia: PropTypes.func,
  cancelMedia: PropTypes.func
};
