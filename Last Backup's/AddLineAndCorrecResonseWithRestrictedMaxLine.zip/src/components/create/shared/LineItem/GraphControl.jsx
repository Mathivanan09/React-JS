import React from 'react';
import PropTypes from 'prop-types';

import DropDown from '../../straightline/DropDown';

const GraphControl = ({ item, onUpdate, config }) => {

  const incrementalLabels = [
    { id: 'ALL', name: 'All' },
    { id: 'LEAST AND GREAT', name: 'Least and Greatest'},
    { id: 'NONE', name: 'None' }
  ];

  // event handler for updating item json content
  const updateItemJson = (key, value) => {

    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  // Event handler for getting Incremental labels
  const getIncrementLabels = () => {
    return (
      ['All','Least and Greatest','None'].map((val, i) => {
        return {
          id: incrementalLabels[i].id,
          name: val
        };
      })
    );
  };

  /**
 * @summary This method is used to return valid Coordinates input for the Graph/Chart.
 * @param {event value} value as string
 */
  const coordinates = (value, fill) => {
    let target = '';
    if (value?.trim() !== '' && value?.split(',')?.length > 0) {
      let x = value?.split(',')[0]?.trim();
      let y = value?.split(',')[1]?.trim();
      x = x !== '-' && Number.isNaN(Number(x)) ? 0 : x;
      if (value?.split(',')?.length === 1) {
        if (fill) {
          y = 0;
          target = (x + ", " + y);
        } else {
          target = x;
        }
      } else {
        y = (y !== '-' && (y === '' || Number.isNaN(Number(y)))) ? null : y;
        if (y === null) {
          if (fill) {
            y = 0;
          } else {
            y = '';
          }
        }
        target = (x + ", " + y);
      }
    }
    return target;
  }

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col col-xs-12 col-sm-12">
            <fieldset className={'bg-light rounded p-3 m-1'}>
              <h5 className="text-primary">Graph Control</h5>
              <div className="row  pt-2">
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Set Max Lines:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className='form-control'
                    value={item.item_json?.maxLines || 2}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'maxLines': e.target.value
                      }
                    })}
                    data-testid={'gc-max-lines'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>X Axis Scale:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className="form-control"
                    value={item.item_json?.xAxisScale || 1}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'xAxisScale': e.target.value
                      }
                    })}
                    data-testid={'gc-max-lines'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Bottom Left:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="text"
                    className="form-control"
                    value={item.item_json?.bottomLeft}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            bottomLeft: coordinates(e?.target?.value, false)
                      }
                    })}
                    onBlur={(e) =>
                      onUpdate({
                        item_json:{
                          bottomLeft: coordinates(e?.target?.value, true)
                        }
                      })
                    }
                    data-testid={'gc-bottom-left'}
                  />
                </div>
              </div>
              <div className="row pt-2">
                <div className='col-4  p-1 '>
                  <DropDown
                    data={getIncrementLabels()}
                    onUpdate={updateItemJson}
                    labelCode="incremental_label"
                    updateKey={'incrementLabel'}
                    className="form-control"
                    showSelect={true}
                    value={item.item_json?.incrementLabel}
                    data-testid={'gc-incremental-label'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Y Axis Scale:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className="form-control"
                    value={item.item_json?.yAxisScale || 1}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'yAxisScale': e.target.value
                      }
                    })}
                    data-testid={'gc_yaxis_scale'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Upper Right:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="text"
                    className="form-control"
                    value={item.item_json?.upperRight}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            upperRight: coordinates(e?.target?.value, false)
                      }
                    })}
                    onBlur={(e) =>
                      onUpdate({
                        item_json:{
                          upperRight: coordinates(e?.target?.value, true)
                        }

                      })
                    }
                    data-testid={'gc-upper-right'}
                  />
                </div>
              </div>
              <div className="row pt-2">
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Width:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className="form-control"
                    value={item.item_json?.width || 500}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'width': e.target.value
                      }
                    })}
                    data-testid={'gc-width'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Axis Line Size:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className="form-control"
                    value={item.item_json?.axisLineSize || 1}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'axisLineSize': e.target.value
                      }
                    })}
                    data-testid={'gc-axis-line-scale'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Show Grid:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type={'checkbox'}
                    className={"form-check-input"}
                    value={item.item_json?.showGrid}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'showGrid': e.target.checked
                      }
                    })}
                    data-testid={'gc-show-grid'}
                    min={1}
                  />
                </div>
              </div>
              <div className="row pt-2">
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Height:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className="form-control"
                    value={item.item_json?.height || 500}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'height': e.target.value
                      }
                    })}
                    data-testid={'gc-height'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Axis Label Size:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type="number"
                    className="form-control"
                    value={item.item_json?.axisLabelSize || 1}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'axisLabelSize': e.target.value
                      }
                    })}
                    data-testid={'gc-axis-label-scale'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Snap to Grid:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type={'checkbox'}
                    className={"form-check-input"}
                    value={item.item_json?.snapToGrid}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'snapToGrid': e.target.checked
                      }
                    })}
                    data-testid={'gc-snap-to-grid'}
                    min={1}
                  />
                </div>
              </div>
              <div className="row pt-2">
                <div className="col"></div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Axes Arrowheads:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type={'checkbox'}
                    className={"form-check-input"}
                    value={item.item_json?.lineArrow}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'lineArrow': e.target.checked
                      }
                    })}
                    data-testid={'gc-axes-arrowheads'}
                    min={1}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Extended Lines:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <input
                    type={'checkbox'}
                    className={"form-check-input"}
                    value={item.item_json?.extendedLines}
                    onChange={(e) => onUpdate({
                      ...item,
                      item_json:{
                        ...item?.item_json,
                            'extendedLines': e.target.checked
                      }
                    })}
                    data-testid={'gc-extended-lines'}
                    min={1}
                  />
                </div>
              </div>
            </fieldset>
          </div>
        </div>
      </div>
    </>
  )
}

export default GraphControl;
