import React, { useEffect, useState } from 'react'
import label from '../../../../constants/labelCodes';
import propTypes from 'prop-types';
import CKEditorBase from '../../../common/editors/ckeditor/CKEditorBase';
const ScoringSelection = ({ item, onUpdate, config }) => {

  //Get the correctResponse from item Data
  const correctResponse = item.item_json?.correctResponse;

  const [addLine, setAddLine] = useState(false);
  const [crtData, setCrtData] = useState([]);
  const [showRationale, setShowRationale] = useState([]);
  const [addLineSeries, setAddLineSeries] = useState(0);


  //Here Updating the fields into item_json
  const updateContent = () => {
    updateItemJson({
      ...item.item_json,
      orderPairOne: item.item_json.orderPairOne || false,
      orderPairTwo: item.item_json.orderPairTwo,
      xIntercept: item.item_json.xIntercept,
      yIntercept: item.item_json.yIntercept,
      slope: item.item_json.slope,
      lineRelationships: item.item_json.lineRelationships,
      correctResponse: crtData
    });
  }

  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  useEffect(() => {
    updateContent();
  }, [item.item_json.orderPairOne, item.item_json.orderPairTwo, item.item_json.xIntercept, item.item_json.yIntercept, item.item_json.slope, item.item_json.lineRelationships]);

  //Show/Hide Rationale
  const showHideRationale = (id) => {
    const showing = new Set([...showRationale]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowRationale([...showing]);
  };

  //Handle Rationale Change
  const handleRationaleChange = (data, index) => {
    const newList = [...(item.rationale?.optionList || [])];
    newList[index] = { ...newList[index], rationaleText: data };
    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newList }
    };
    onUpdate(updatedItem);
  };


  const findIndexCorrectResponse = (code) => {
    let currentIndex = 0;
    // eslint-disable-next-line
    switch (code) {
      case 1: //orderPairOne
        currentIndex = 0;
        break;
      case 2: //orderPairTwo
        if (item.item_json.orderPairOne === true) {
          currentIndex = 1;
        }
        if (item.item_json.orderPairOne === false) {
          currentIndex = 0;
        }
        break;
      case 3: //xIntercept
        if (item.item_json.yIntercept === true) {
          currentIndex = 0;
        }
        if (item.item_json.orderPairOne === true || item.item_json.orderPairTwo === true) {
          currentIndex = 1;
        }
        break;
      case 4: //yIntercept
        if (item.item_json.orderPairOne === false && item.item_json.orderPairTwo === false && item.item_json.xIntercept === false) {
          currentIndex = 0;
        } else {
          currentIndex = 1;
        }
        break;
    }
    return currentIndex;
  }

  const handleAddLine = () => {
    let newData = {
      id: '',
      value: {
        line:[]
      }
    };

    if (item?.item_json?.maxLines > item?.item_json?.correctResponse.length) {
      setAddLine(true);
      let existingCorrectResponse = item?.item_json?.correctResponse;

      if(item?.item_json?.correctResponse.length === 0){
        existingCorrectResponse = item?.item_json?.correctResponse.push(newData);
        const updatedItem={
          ...item,
          item_json: {
            ...item?.item_json,
            'correctResponse': existingCorrectResponse
          }
        };
        onUpdate(updatedItem);
      }
      else {
        const updatedItem={
          ...item,
          item_json: {
            ...item?.item_json,
            'correctResponse': existingCorrectResponse
          }
        };
        onUpdate(updatedItem);
      }
      if(item?.item_json?.correctResponse[item?.item_json?.correctResponse.length] === undefined){
        existingCorrectResponse = item?.item_json?.correctResponse.push(newData);
        const updatedItem={
          ...item,
          item_json: {
            ...item?.item_json,
            'correctResponse': existingCorrectResponse
          }
        };
        onUpdate(updatedItem);
      }
    }
  }

  //Numeric Check
  const numericCheck = (input) => {
    return (input && (input.trim() === '' || input.trim() === '-' || input.trim() === '-0' || input.trim().split(".").length === 2));
  }

  //Handle Textbox Value
  const correctResponseDatahandler = (e, i, code, fill) => {

    let currentIndex = findIndexCorrectResponse(code);
    let val = e?.target?.value;
    if (correctResponse[i].line === undefined) {
      correctResponse[i].value.line[currentIndex] = {
        x: "",
        y: ""
      };
    }
    val = val.split(",");
    if (code === 4) {
      correctResponse[i].value.line[currentIndex].x = 0;
    } else if (numericCheck(val[0])) {
      correctResponse[i].value.line[currentIndex].x = val[0].trim();
    } else {
      correctResponse[i].value.line[currentIndex].x = val && val[0] ? parseFloat(val[0].trim()) : null;
    }
    if (code === 3) {
      correctResponse[i].value.line[currentIndex].y = 0;
    } else if (numericCheck(val[1])) {
      correctResponse[i].value.line[currentIndex].y = val[1].trim();
    } else {
      correctResponse[i].value.line[currentIndex].y = val && val[1] ? parseFloat(val[1].trim()) : null;
    }
    let y = correctResponse[i].value.line[currentIndex].y;
    // eslint-disable-next-line
    if (y == null || y === '' || y === '-') {
      let x = correctResponse[i].value.line[currentIndex].x;
      if (x !== null && x !== '' && x !== '-' && val.length > 1 && y !== '-') {
        if (fill) {
          correctResponse[i].value.line[currentIndex].y = 0;
        } else {
          correctResponse[i].value.line[currentIndex].y = '';
        }
      } else if (y !== '-') {
        correctResponse[i].value.line[currentIndex].y = undefined;
      }
    }

    if (code === 1) {
      correctResponse[i].value.line[currentIndex].scoringselection = "Ordered Pair 1";
    }
    if (code === 2) {
      correctResponse[i].value.line[currentIndex].scoringselection = "Ordered Pair 2";
    }
    if (code === 3) {
      correctResponse[i].value.line[currentIndex].scoringSelection = "X Intercept";
    }
    if (code === 4) {
      correctResponse[i].value.line[currentIndex].scoringSelection = "Y Intercept";
    }
    if (code === 3) {
      let value = e?.target?.value;
      if (value && value !== null && parseFloat(value) && parseFloat(value) !== 0) {
        correctResponse[i].value.line[currentIndex].x = parseInt(value);
        correctResponse[i].value.line[currentIndex].y = 0;
      }
    }
    if (code === 4) {
      let value = e?.target?.value;
      if (value && value !== null && parseFloat(value) && parseFloat(value) !== 0) {
        correctResponse[i].value.line[currentIndex].x = 0;
        correctResponse[i].value.line[currentIndex].y = parseInt(value);
      }
    }
    correctResponse[i].id = "response-id-" + (i + 1);

    setCrtData(correctResponse);
  }

  const handleTolerance = (e, i, code) => {
    let currentIndex = findIndexCorrectResponse(code);
    let value = e.target.value;
    correctResponse[i].value.line[currentIndex].tolerance = parseInt(value);
    setCrtData(correctResponse);

  }

  // Updating the Slope value
  const handleSlopeData = (e, i, isTolerance) => {
    let val = parseInt(e.target.value);
    if (correctResponse && correctResponse[i]) {
      if (!isTolerance) {
        correctResponse[i].value.slopeValue = val;
        if (correctResponse[i]?.line && correctResponse[i]?.value?.line[1] === undefined) {
          correctResponse[i].value.line[1] = {}
        }
      } else {
        correctResponse[i].value.slopeTolerance = val;
      }
    }
  }



  return (
    <>
      <h5 className="text-primary">Line Settings</h5>
      <h5 className="text-primary pt-2">Scoring Selection</h5>
      <div className="container pt-2">
        <div className="row border border-dark border-3 p-3">
          <div className="row pt-2">
            <div className='col pt-1 pb-1 text-end'>
              <label>Ordered Pair 1:&nbsp;</label>
            </div>
            <div className="col pt-1 pb-1 text-start">
              <input
                type="checkbox"
                className={"form-check-input"}
                value={item.item_json?.orderPairOne}
                checked={item.item_json?.orderPairOne}
                onChange={(e) => updateItemJson("orderPairOne", e.target.checked)}
                data-testid={"ss-order-pair-one"}
                disabled={(
                  (item.item_json.orderPairTwo && item.item_json.xIntercept) ||
                  (item.item_json.orderPairTwo && item.item_json.yIntercept) ||
                  (item.item_json.orderPairTwo && item.item_json.slope) ||
                  (item.item_json.xIntercept && item.item_json.yIntercept) ||
                  (item.item_json.xIntercept && item.item_json.slope) ||
                  (item.item_json.slope && item.item_json.yIntercept)
                )}
                min={1}
              />
            </div>
            <div className='col pt-1 pb-1 text-end'>
              <label>Ordered Pair 2:&nbsp;</label>
            </div>
            <div className="col-2 pt-1 pb-1 text-start">
              <input
                type="checkbox"
                className={"form-check-input"}
                value={item.item_json?.orderPairTwo}
                checked={item.item_json?.orderPairTwo}
                onChange={(e) => updateItemJson("orderPairTwo", e.target.checked)}
                data-testid={'ss-order-pair-two'}
                disabled={(
                  (item.item_json.orderPairOne && item.item_json.xIntercept) ||
                  (item.item_json.orderPairOne && item.item_json.yIntercept) ||
                  (item.item_json.orderPairOne && item.item_json.slope) ||
                  (item.item_json.xIntercept && item.item_json.yIntercept) ||
                  (item.item_json.xIntercept && item.item_json.slope) ||
                  (item.item_json.slope && item.item_json.yIntercept)
                )}
              />
            </div>
          </div>

          <div className="row pt-2">
            <div className='col pt-1 pb-1 text-end'>
              <label>X intercept:&nbsp;</label>
            </div>
            <div className="col pt-1 pb-1 text-start">
              <input
                type="checkbox"
                className={"form-check-input"}
                value={item.item_json?.xIntercept}
                onChange={(e) => updateItemJson("xIntercept", e.target.checked)}
                data-testid={'ss-x-intercept'}
                min={1}
                disabled={(
                  (item.item_json.orderPairOne && item.item_json.orderPairTwo) ||
                  (item.item_json.orderPairOne && item.item_json.yIntercept) ||
                  (item.item_json.orderPairOne && item.item_json.slope) ||
                  (item.item_json.orderPairTwo && item.item_json.yIntercept) ||
                  (item.item_json.orderPairTwo && item.item_json.slope) ||
                  (item.item_json.slope && item.item_json.yIntercept)
                )}
              />
            </div>
            <div className='col pt-1 pb-1 text-end'>
              <label>Y Intercept:&nbsp;</label>
            </div>
            <div className="col-2 pt-1 pb-1 text-start">
              <input
                type="checkbox"
                className={"form-check-input"}
                value={item.item_json?.yIntercept}
                onChange={(e) => updateItemJson("yIntercept", e.target.checked)}
                data-testid={"ss-y-intercept"}
                disabled={(
                  (item.item_json.orderPairOne && item.item_json.orderPairTwo) ||
                  (item.item_json.orderPairOne && item.item_json.xIntercept) ||
                  (item.item_json.orderPairOne && item.item_json.slope) ||
                  (item.item_json.orderPairTwo && item.item_json.xIntercept) ||
                  (item.item_json.orderPairTwo && item.item_json.slope) ||
                  (item.item_json.xIntercept && item.item_json.slope)
                )}
              />
            </div>
          </div>


          <div className="row pt-2">
            <div className='col pt-1 pb-1 text-end'>
              <label>Slope:&nbsp;</label>
            </div>
            <div className="col pt-1 pb-1 text-start ">
              <input
                type="checkbox"
                className={"form-check-input"}
                value={item.item_json?.slope}
                onChange={(e) => updateItemJson("slope", e.target.checked)}
                data-testid={"ss-slope"}
                disabled={(
                  (item.item_json.orderPairOne && item.item_json.orderPairTwo) ||
                  (item.item_json.orderPairOne && item.item_json.xIntercept) ||
                  (item.item_json.orderPairOne && item.item_json.yIntercept) ||
                  (item.item_json.orderPairTwo && item.item_json.xIntercept) ||
                  (item.item_json.orderPairTwo && item.item_json.yIntercept) ||
                  (item.item_json.xIntercept && item.item_json.yIntercept)
                )}
                min={1}
              />
            </div>
            <div className='col pt-1 pb-1 text-end'>
              <label>Line Relationships:&nbsp;</label>
            </div>
            <div className="col-2 pt-1 pb-1 text-start">
              <input
                type="checkbox"
                className={"form-check-input"}
                value={item.item_json?.lineRelationships}
                onChange={(e) => updateItemJson("lineRelationships", e.target.checked)}
                data-testid={"ss-line-relationships"}
              />
            </div>
          </div>
        </div>
        <div className="row p-4 ">
          <div className="col text-end ">
            {console.log(addLine)}
            {/* Adding the Lines Based on maxLines count */}
            <button
              type='button'
              className='btn btn-primary btn-sm'
              data-testid={'addLine-button'}
              onClick={() => handleAddLine()}
            >
              {label.addLine}
            </button>
          </div>
        </div>
        {addLine ? (
          <>
            {item.item_json?.correctResponse.map((id, i) => (
              <>
                <div className="row border border-dark border-3 pb-3">
                  <h5 className="text-primary pt-2">Line {i + 1}</h5>
                  {(item.item_json.orderPairOne === true) && <>
                    <div className="col pt-2 text-end pb-3 ">
                      <label>Ordered Pair 1:</label>
                      <input type="text"
                        onChange={(e) => correctResponseDatahandler(e, i, 1, false)}
                        onBlur={(e) =>
                          onUpdate({
                            ...item.item_json,
                            orderPairOneText: correctResponseDatahandler(e, i, 1, true)
                          })
                        }
                      />
                    </div>
                    <div className="col pt-2 pb-3">
                      <label>Tolerance:</label>
                      <input type="number"
                        onChange={(e) => handleTolerance(e, i, 1)}
                      />
                    </div>
                  </>
                  }

                  {(item.item_json.orderPairTwo === true) ?
                    <>
                      <div className="col pt-2 text-end pb-3">
                        <label>Ordered Pair 2: </label>
                        <input type="text"
                          onChange={(e) => correctResponseDatahandler(e, i, 2, false)}
                          onBlur={(e) =>
                            onUpdate({
                              ...item.item_json,
                              orderPairTwoText: correctResponseDatahandler(e, i, 2, true)
                            })
                          }
                        />
                      </div>
                      <div className="col pt-2 pb-3">
                        <label>Tolerance:</label>
                        <input type="number"
                          onChange={(e) => handleTolerance(e, i, 2)}
                        />
                      </div>
                    </>
                    : ""
                  }

                  {(item.item_json.xIntercept === true) ?
                    <>
                      <div className="col text-end pt-2 pb-3 ">
                        <label>X Intercept:</label>
                        <input type="number"
                          onChange={(e) => correctResponseDatahandler(e, i, 3, false)}
                          onBlur={(e) =>
                            onUpdate({
                              ...item.item_json,
                              xInterceptText: correctResponseDatahandler(e, i, 3, true)
                            })
                          }
                        />
                      </div>
                      <div className="col pt-2 pb-3">
                        <label>Tolerance:</label>
                        <input type="number"
                          onChange={(e) => handleTolerance(e, i, 3)}
                        />
                      </div>
                    </>
                    : ""}

                  {(item.item_json.yIntercept === true) ?
                    <>
                      <div className="col pt-2 text-end pb-3">
                        <label>Y Intercept:</label>
                        <input type="number"
                          onChange={(e) => correctResponseDatahandler(e, i, 4, false)}
                          onBlur={(e) =>
                            onUpdate({
                              ...item.item_json,
                              yInterceptText: correctResponseDatahandler(e, i, 4, true)
                            })
                          }
                        />
                      </div>
                      <div className="col pt-2 pb-3">
                        <label>Tolerance:</label>
                        <input type="number"
                          onChange={(e) => handleTolerance(e, i, 4)}
                        />
                      </div>
                    </>
                    : ""}

                  {(item.item_json.slope === true) ?
                    <>
                      <div className="col pt-2 text-end pb-3">
                        <label>Slope:</label>
                        <input
                          type="number"
                          onChange={(e) => handleSlopeData(e, i, false)}
                        />
                      </div>
                      <div className="col pt-2  pb-3 ">
                        <label>Tolerance:</label>
                        <input
                          type="number"
                          onChange={(e) => handleSlopeData(e, i, true)}
                        />
                      </div>
                    </>
                    : ""}

                </div>

                <div>
                  <div className='col p-3' data-testid='rationale'>
                    <button
                      type='button'
                      className='btn btn-primary btn-sm'
                      data-testid={'rationale-button'}
                      onClick={() => showHideRationale(id)}
                    >
                      {label.rationale}
                    </button>
                  </div>
                  {showRationale.indexOf(id) !== -1 && (
                    <div className='mc-item-box' data-testid={'rationale-container'}>
                      <CKEditorBase
                        type='inline'
                        data={item.rationale.optionList[i].rationaleText}
                        onChange={
                          (data) => { handleRationaleChange(data, i); }
                        }
                        placeholder={label.enter_rationale_content}
                      />
                    </div>
                  )}
                </div>
              </>
            ))}
          </>
        ) : ""}
      </div>
    </>
  )
}

ScoringSelection.propTypes = {
  item: propTypes.object,
  onUpdate: propTypes.func,
  config: propTypes.object
}


export default ScoringSelection


