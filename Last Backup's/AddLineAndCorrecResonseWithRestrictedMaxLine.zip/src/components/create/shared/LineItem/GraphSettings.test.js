import React from 'react';
import { screen } from '@testing-library/dom';
import { render } from '@testing-library/react';
import GraphSettings from './GraphSettings';
import thunk from 'redux-thunk';
import { unmountComponentAtNode } from "react-dom";
import createMockStore from 'redux-mock-store';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import WProofreader from '@webspellchecker/wproofreader-ckeditor5/src/wproofreader';
import { act } from "react-dom/test-utils";

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});


describe('GraphSettings item testing', () =>{

  it("Identify the data for Graph Title", () => {
    act(() => {
        render(
            <GraphSettings
                item={{
                    item_json: {
                        itemTypeCode: 'gs-graph-title'
                    }
                }
                }
            />, container);
    });

    const graphTitle = document.querySelector("[dataTestId=gs-graph-title]");
    expect(graphTitle).not.toBeNull;
});    

it("Identify the data for X Axis Title", () => {
  act(() => {
      render(
          <GraphSettings
              item={{
                  item_json: {
                      itemTypeCode: 'gs-xaxis-title'
                  }
              }
              }
          />, container);
  });

  const xAxisTitle = document.querySelector("[dataTestId=gs-xaxis-title]");
  expect(xAxisTitle).not.toBeNull;
});    

it("Identify the data for Y Axis Title", () => {
  act(() => {
      render(
          <GraphSettings
              item={{
                  item_json: {
                      itemTypeCode: 'gs-yaxis-title'
                  }
              }
              }
          />, container);
  });

  const yAxisTitle = document.querySelector("[dataTestId=gs-yaxis-title]");
  expect(yAxisTitle).not.toBeNull;
});    

it("Identify the data for X Axis Label", () => {
  act(() => {
      render(
          <GraphSettings
              item={{
                  item_json: {
                      itemTypeCode: 'gs-xaxis-label'
                  }
              }
              }
          />, container);
  });

  const xAxisLabel = document.querySelector("[dataTestId=gs-xaxis-label]");
  expect(xAxisLabel).not.toBeNull;
});    

it("Identify the data for gs-xaxis-label", () => {
  act(() => {
      render(
          <GraphSettings
              item={{
                  item_json: {
                      itemTypeCode: 'gs-yaxis-label'
                  }
              }
              }
          />, container);
  });

  const yAxisLabel = document.querySelector("[dataTestId=gs-xaxis-label]");
  expect(yAxisLabel).not.toBeNull;
});    
});

it.todo("Based on the value of Graph Title, the User will be able to give Graph Title in correct response area and also in Preview window");

it.todo("Based on the value of X Axis Title, the User will be able to give X Axis Title in correct response area and also in Preview window");

it.todo("Based on the value of Y Axis Title, the User will be able to give Y Axis Title in correct response area and also in Preview window");

it.todo("Based on the value of X Axis Label, the User will be able to give X Axis Label in correct response area and also in Preview window");

it.todo("Based on the value of Y Axis Label, the User will be able to give Y Axis Label in correct response area and also in Preview window");