import React from 'react';
import PropTypes from 'prop-types';
import './GraphSettings.css';
import CKEditorBase from '../../../common/editors/ckeditor/CKEditorBase';

const GraphSettings = ({ item, onUpdate, config }) => {

 // event handler for updating item json content
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col col-xs-12 col-sm-13">
            <fieldset className={'bg-light p-2 rounded m-1'}>
              <h5 className="text-primary">Graph Settings</h5>
              <div className="row pt-2">
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Graph Title:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <CKEditorBase
                    type='inline'
                    dataTestId='gs-graph-title'
                    data={item.item_json?.graphTitle}
                    onChange={
                      /* istanbul ignore next */
                      (data) => {
                        onUpdate({
                          ...item,
                          item_json: {
                            ...item?.item_json,
                            'graphTitle': data
                          }
                        });
                      }
                    }

                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>X Axis Title:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <CKEditorBase
                    type='inline'
                    dataTestId='gs-xaxis-title'
                    data={item.item_json?.xAxisTitle}
                    onChange={
                      /* istanbul ignore next */
                      (data) => {
                        onUpdate({
                          ...item,
                          item_json: {
                            ...item?.item_json,
                            'xAxisTitle': data
                          }
                        });
                      }
                    }
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Y Axis Title:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <CKEditorBase
                    type='inline'
                    dataTestId='gs-yaxis-title'
                    data={item.item_json?.yAxisTitle}
                    onChange={
                      /* istanbul ignore next */
                      (data) => {
                        onUpdate({
                          ...item,
                          item_json: {
                            ...item?.item_json,
                            'yAxisTitle': data
                          }
                        });
                      }
                    }
                  />
                </div>
              </div>

              <div className="row pt-2 ">
                <div className='col-6 pt-1 pb-1 text-right '>
                  <label>X Axis Label:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <CKEditorBase
                    type='inline'
                    dataTestId='gs-xaxis-label'
                    data={item.item_json?.xAxisLabel}
                    onChange={
                      /* istanbul ignore next */
                      (data) => {
                        onUpdate({
                          ...item,
                          item_json: {
                            ...item?.item_json,
                            'xAxisLabel': data
                          }
                        });
                      }
                    }
                  />
                </div>

                <div className='col-2 pt-1 pb-1 text-right'>
                  <label>Y Axis Label:&nbsp;</label>
                </div>
                <div className="col-2 pt-1 pb-1 text-start">
                  <CKEditorBase
                    type='inline'
                    dataTestId='gs-graph-title'
                    data={item.item_json?.yAxisLabel}
                    onChange={
                      /* istanbul ignore next */
                      (data) => {
                        onUpdate({
                          ...item,
                          item_json: {
                            ...item?.item_json,
                            'yAxisLabel': data
                          }
                        });
                      }
                    }
                  />
                </div>
              </div>
            </fieldset>
          </div >
        </div>
      </div>
    </>
  );
};

export default GraphSettings;
