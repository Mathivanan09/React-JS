import React from 'react';
import PropTypes from 'prop-types';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import label from '../../../constants/labelCodes';

import '../../../styles/item/StemContent.css';

/**
 * React functional component to create the stem content for the item
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace StemContent
 *
 * @param {{data: array, onUpdate: function}} param passed in parameters
 * @param {string} param.data Stem content data that will be displayed in the CKEditor
 * @param {function} param.onUpdate The function that need to be called onChange event
 * @return {component} - StemContent component with CKEditor
 */

const StemContent = ({ data, onUpdate, ...props }) => {
  const stemPlaceholder = label.stem_placeholder;
  return (
    <div className='row' data-testid='stem-content-container'>
      <div className='col stem-container m-1 ms-0 me-0'>
        <CKEditorBase
          data={data}
          onChange={onUpdate}
          fieldName='stemContent'
          className='content_style'
          placeholder={stemPlaceholder}
          dataTestId='stem-content-editor'
          {...props}
        />
      </div>
    </div>
  );
};

StemContent.propTypes = {
  data: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.elementType
  ]),
  onUpdate: PropTypes.func
};

export default StemContent;
