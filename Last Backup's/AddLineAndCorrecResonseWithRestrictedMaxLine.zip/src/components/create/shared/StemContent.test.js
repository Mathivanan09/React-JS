/**
 * @file Stem Content tests
 */
import React from 'react';
import { unmountComponentAtNode } from 'react-dom';
import { act } from 'react-dom/test-utils';
import { render, screen } from '@testing-library/react';

// import component here
import StemContent from './StemContent';

let container = null;

beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement('div');
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

it('Testing component without props', () => {
    let stemContent = 'stem';
    act(() => {
        render(<StemContent
            data={stemContent}
            // onUpdate={updateItemJson}
            fieldName={'stemContent'}
        />, container);
    });

    // TODO need to check, if possible to add/find suitable test for editor data validation and events
    // TypeError: Cannot read property 'getAttribute' of null from CKEditor, may related to this https://github.com/ckeditor/ckeditor5/issues/7836
    // check the ItemDimensions loaded properly or not by checking the container
    expect(screen.getByTestId('stem-content-container')).toBeInTheDocument();
    expect(screen.getByTestId('stem-content-editor')).toBeInTheDocument();
});
