import React, { Component } from 'react';
import PropTypes from 'prop-types';

/**
 * React functional component to reorder the option items
 * 
 * @inner
 * @memberof SharedComponents
 * 
 * @component
 * @namespace ReorderItems
 * 
 * @param {{ listLength: number, option: number, 
 * onDownClick: function, onUpClick: function }} param passed in parameters
 * @param {number} param.listLength - JSON data that will contain the item information
 * for creating/updating multiple choice item
 * @param {number} param.option - index in the list of options
 * @param {function} param.onDownClick - the function to move option downward
 * @param {function} param.onUpClick - the function to move option upward
 * @return {Component} - ReorderItems component for reordering options up & down
 * 
 * @example
 * <ReorderItems
    listLength={item.item_json.optionList.length}
    option={i}
    onDownClick={() => reorderItems(id, DIR_DOWN)}
    onUpClick={() => reorderItems(id, DIR_UP)}
  />
 */
const ReorderItems = ({ listLength, option, onDownClick, onUpClick }) => {
  return (
    <div className={'row p-2'} data-testid={'ri-container'}>
      {listLength > 1 ? (
        option === 0 ? (
          <div className='col'>
            <div className="btn-group-vertical">
              <button
                id={`arrow-down-${option}`}
                type='button'
                value=''
                className='btn btn-sm ordering-button'
                onClick={onDownClick}
                aria-label={'arrow-down'}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-down" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
</svg>
              </button>
            </div>
          </div>
        ) : option === listLength - 1 ? (
          <div className='col'>
            <div className="btn-group-vertical">
              <button
                id={`arrow-up-${option}`}
                type='button'
                value=''
                className='btn btn-sm ordering-button'
                onClick={onUpClick}
                aria-label={'arrow-up'}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-up" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z"/>
</svg>
              </button>
            </div>
          </div>
        ) : (
          <div className='col'>
            <div className="btn-group-vertical">
              <button
                id={`arrow-up-${option}`}
                type='button'
                value=''
                className='btn btn-sm ordering-button'
                onClick={onUpClick}
                aria-label={'arrow-up'}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-up" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z"/>
</svg>
              </button>
              <button
                id={`arrow-down-${option}`}
                type='button'
                value=''
                className='btn btn-sm ordering-button'
                onClick={onDownClick}
                aria-label={'arrow-down'}
              >
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-down" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
</svg>
              </button>
            </div>
          </div>
        )
      ) : (
        ''
      )}
    </div>
  );
};

ReorderItems.propTypes = {
  listLength: PropTypes.number,
  option: PropTypes.number,
  onDownClick: PropTypes.func,
  onUpClick: PropTypes.func
};

export default ReorderItems;
