import React from 'react'
import PropTypes from 'prop-types';
import ScoringSelection from '../shared/LineItem/ScoringSelection'
import ItemResponse from '../../display/response/graph/ItemResponse'

const CorrectResponse = ({ item, onUpdate, config }) => {

  return (
    <>
      {item && (
        <div className="col col-xs-12 col-sm-12">
          <fieldset className={'bg-light rounded p-3 m-1'}>
            <h5 className="text-primary">Correct Response</h5>
            <div className="row">
              <div className="col">
                {/* <ItemResponse
                  item={item}
                  onUpdate={onUpdate}
                  config={config}
                /> */}
              </div>
              <div className="col">
                <ScoringSelection
                  item={item}
                  onUpdate={onUpdate}
                  config={config}
                />
              </div>
            </div>
          </fieldset>
        </div>
      )}

    </>
  )
}
CorrectResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object
};
export default CorrectResponse
