import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';
import uuid from 'react-uuid';
import GraphSettings from '../shared/LineItem/GraphSettings';
import GraphControl from '../shared/LineItem/GraphControl';
import CorrectResponse from './CorrectResponse';
import LineRelationships from '../shared/LineItem/LineRelationships';

/**
 * React functional component to create Straight Line item
 *

 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace StraightLine
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Straight Line item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {StraightLine} StraightLine component for creating Straight Line item
 *
 * @example
 * <StraightLine item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'sl' },
    user_id: 0,
  }} />
 */
const StraightLine = ({ item, onUpdate, config }) => {
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  // This useEffect for making the structured correctResponse
  useEffect(() => {
    onUpdate({
      item_json: {
        uuid: uuid(),
        correctResponse: []
      }
    })
  }, []);



  return (
    <>
      {console.log(item)}
      {item ? (
        <div data-testid={'container'}>
          <div data-testid={'id-container'}>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid={'stem-container'}>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName={'stemContent'}
            />

          </div>
          <div>

            <div className="row" data-testid={'design-container'}>
              <GraphSettings
                item={item}
                onUpdate={onUpdate}
                config={config}
              />
            </div>
            <br />
            <div className="row" data-testid={'design-container'}>
              <GraphControl
                item={item}
                onUpdate={onUpdate}
                config={config}
              />
            </div>
            <div className="row" data-testid={'design-container'}>
              <div >
                <CorrectResponse
                  item={item}
                  onUpdate={onUpdate}
                  config={config}
                />
              </div>
            </div>
        {/* It works only when the lineRelationships is checked */}
            {item?.item_json?.lineRelationships &&
              <div className="row">
                <LineRelationships />
              </div>
            }

          </div>

        </div>
      ) : (
        <div data-testid='missing-item'>Missing item data</div>
      )}
    </>
  );
};

StraightLine.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object
};

export default StraightLine;
