import React, { createRef, useEffect } from 'react';
import Chart from 'chart.js/auto';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import ChartDragData from 'chartjs-plugin-dragdata';

const LineChart = ({item}) => {

  const chartRef = createRef();

  useEffect(() => {
    const ctx = chartRef.current.getContext("2d");
    new Chart(ctx, {
      type: "scatter",
      data: {
        datasets: [{
          label: 'Scatter Dataset',
          data: [{
            x: -10,
            y: 0
          }, {
            x: 0,
            y: 10
          }, {
            x: 10,
            y: 5
          }, {
            x: 0.5,
            y: 5.5
          }],
          backgroundColor: 'rgb(255, 99, 132)'
        }],
      },
      options: {
        responsive: true,
        scales: {
          x: {
            ticks: {
              display: true
         },
            type: 'linear',
            position: 'bottom',
            grid:{
              borderColor:"#333"
            }
          },
          y:{
            ticks: {
              display: false
         },
         grid:{
          borderColor:"#333",

        }
          }
        },



      tooltips: {
          callbacks: {
             label: function(tooltipItem) {
                    return tooltipItem.yLabel;
             }
          }
      }
      },
      plugins: [ChartDataLabels, ChartDragData]
    })

  }, [])

  return (
    <div style={{border:"2px solid blue",width:500}}>
      <canvas id="myChart" ref={chartRef} height={300} />
    </div>
  )

}

export default LineChart
