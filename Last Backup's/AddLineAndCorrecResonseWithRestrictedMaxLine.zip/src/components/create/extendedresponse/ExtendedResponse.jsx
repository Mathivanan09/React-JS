import React, { useState } from 'react';

import StemContent from '../shared/StemContent';
import ItemDimensions from '../shared/ItemDimensions';
import AnswerAlignment from '../shared/AnswerAlignment';

import label from '../../../constants/labelCodes';
import defaultValue from '../../../utility/default';

import { itemProps } from '../../common/ItemHelper';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/ExtendedResponse.css';

/**
 * React functional component to create Extended Response item
 *
 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace ExtendedResponse
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Extended Response item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {ExtendedResponse} ExtendedResponse component for creating Extended Response item
 * 
 * @example
 * <ExtendedResponse item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'er' },
    user_id: 0,
  }} />
 */
const ExtendedResponse = ({ item, onUpdate, config }) => {
  const [showRationale, setShowRationale] = useState(false);
  const itemJson = { ...(item?.item_json || {}) };

  // handler for item json update
  const updateItemJson = (key, value) => {
    const updatedData = {
      [key]: value
    };
    if (key === 'expectedLines' && value === 'PAPER_PENCIL') {
      updatedData.spellCheck = false;
    }

    onUpdate({
      ...item,
      item_json: {
        ...itemJson,
        ...updatedData
      }
    });
  };

  // Handle the dropdown data
  let expectedLines = [{ code: null, name: 'Select' }];
  let responseAlignments = [];

  if (Array.isArray(config?.expectedLines)) {
    expectedLines = [...expectedLines, ...config.expectedLines];
  } else {
    expectedLines = [
      ...expectedLines,
      {
        code: '5LINES_EXT',
        name: 'Up to 5 lines'
      },
      {
        code: '10LINES_EXT',
        name: 'Up to 10 lines'
      },
      {
        code: '20LINES_EXT',
        name: 'Up to 20 lines'
      },
      {
        code: 'PAPER_PENCIL',
        name: 'Paper and pencil'
      }
    ];
  };

  if (Array.isArray(config?.responseAlignments)) {
    responseAlignments = [...config.responseAlignments];
  } else {
    responseAlignments = [
      { code: 'right_vertical_stacked', name: 'Right Side Vertical' },
      { code: 'vertical_stacked', name: 'Stacked Vertical' }
    ];
  }
  
  return (
    <>
      {item ? (
        <div className='extended-response-container' data-testid='extended-response-container'>
          <div className='row' data-testid='id-container'>
            <ItemDimensions
              minWidth={itemJson?.minItemWidth || 0}
              minHeight={itemJson?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== itemJson?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== itemJson.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div className='row' data-testid='stem-container'>
            <StemContent
              fieldName='stemContent'
              data={itemJson?.stemContent}
              onUpdate={(fieldName, value) => {
                /* istanbul ignore next */
                updateItemJson(fieldName, value)
              }}
            />
          </div>
          <div className='container-fluid p-0 pe-4'>
            <div className='row'>
              <div className='col-12 col-md-7 col-lg-5'>
                <div className='bg-light rounded p-3 m-0 ps-0 mt-1 mb-2'>
                  <div className='row align-items-center p-1'>
                    <div className='col col-lg-6 text-right'>
                      <label htmlFor='enable_spell_check'>{label.enable_spell_check}:</label>
                    </div>
                    <div className='col'>
                      <span className={itemJson?.expectedLines === 'PAPER_PENCIL' ? 'disabled-checkbox' : ''}>
                        <input
                          type='checkbox'
                          name='spellCheck'
                          id='enable_spell_check'
                          className='form-check-input'
                          data-testid='enable-spell-check'
                          checked={
                            itemJson?.spellCheck != undefined ? itemJson?.spellCheck : defaultValue('enable_spell_check')
                          }
                          disabled={itemJson?.expectedLines === 'PAPER_PENCIL'}
                          onChange={(e) => {
                            updateItemJson('spellCheck', e?.target?.checked);
                          }}
                        />
                      </span>
                    </div>
                  </div>
                  <div className='row align-items-center p-1'>
                    <div
                      className='col col-lg-6 text-right dropdown-label ps-sm-0 ms-sm-0'
                      data-testid='expected-lines-label'
                    >
                      <label htmlFor='expected_lines'>
                        {label.expected_lines}:
                        <i className='required-field text-danger ms-1'>*</i>
                      </label>
                    </div>
                    <div className='col'>
                      <select
                        required={true}
                        id='expected_lines'
                        data-testid='expected-lines'
                        value={itemJson?.expectedLines !== undefined ? itemJson?.expectedLines : defaultValue('expected_lines')}
                        className='form-select form-select-sm mx-0'
                        onChange={(e) => {
                          updateItemJson('expectedLines', e.target.value);
                        }}
                      >
                        {
                          expectedLines.map((line, ind) => (
                            <option
                              key={line?.code || ind}
                              value={line?.code || ''}
                            >
                              {line?.name}
                            </option>
                          ))
                        }
                      </select>
                    </div>
                  </div>
                  <AnswerAlignment
                    showSelect={true}
                    isRequired={true}
                    dataItemKey='code'
                    updateKey='answerAlignment'
                    data={responseAlignments}
                    onUpdate={updateItemJson}
                    labelCode='er_answer_alignment'
                    dataTestId='answer-alignment'
                    value={itemJson?.answerAlignment}
                    firstColumnClass='col col-lg-6 text-right dropdown-label ps-sm-0 ms-sm-0'
                  />
                </div>
              </div>
              <div className='col-12 col-md-5 col-lg-7 rationale-container' data-testid='rationale-container'>
                <div className='bg-light rounded p-3 mt-1'>
                  <div className='row'>
                    <div className='col-12 col-lg-2 text-lg-center pb-1'>
                      <button
                        type='button'
                        className='btn btn-primary btn-sm'
                        data-testid='rationale-toggle-button'
                        onClick={() => setShowRationale(!showRationale)}
                      >
                        {label.rationale}
                      </button>
                    </div>
                    <div className='col rationale' data-testid='rationale'>
                      {showRationale &&
                        <CKEditorBase
                          type='inline'
                          dataTestId='rationale-text'
                          data={item?.rationale?.rationaleText || ''}
                          onChange={
                            /* istanbul ignore next */
                            (data) => {
                              onUpdate({
                                ...item,
                                rationale: {
                                  ...item?.rationale,
                                  'rationaleText': data
                                }
                              });
                            }
                          }
                          placeholder={label.enter_rationale_content}
                          config={{ removePlugins: ['TagAccessibility'] }}
                        />
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )
      }
    </>
  );
};

ExtendedResponse.propTypes = itemProps;

export default ExtendedResponse;
