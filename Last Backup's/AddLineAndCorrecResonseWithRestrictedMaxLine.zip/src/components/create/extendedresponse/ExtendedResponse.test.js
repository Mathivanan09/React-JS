import React from 'react';

import { act } from "react-dom/test-utils";
import { unmountComponentAtNode } from "react-dom";
import { render, fireEvent, waitFor } from '@testing-library/react';

// import component here
import ExtendedResponse from './ExtendedResponse';

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('Extended Response Item', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <ExtendedResponse />,
                container
            );
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull();
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <ExtendedResponse
                    item={{
                        item_json: {
                            itemTypeCode: 'ER'
                        }
                    }}
                />,
                container
            );
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=extended-response-container]");
        expect(component).not.toBeNull();

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=extended-response-container]")).not.toBeNull();
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull();
    });

    it("Check the Enable Spell Check field", () => {
        act(() => {
            render(
                <ExtendedResponse
                    item={{
                        item_json: {
                            itemTypeCode: 'ER'
                        }
                    }
                    }
                />,
                container
            );
        });

        const spellCheck = document.querySelector("[data-testid=enable-spell-check]");
        expect(spellCheck).not.toBeNull();
    });

    it("Check the Expected Lines field", () => {
        act(() => {
            render(
                <ExtendedResponse
                    item={{
                        item_json: {
                            itemTypeCode: 'ER'
                        }
                    }
                    }
                />,
                container
            );
        });

        expect(document.querySelector("[data-testid=expected-lines]")).not.toBeNull();
    });

    /**
     * Identify the data for Response Alignment
     */
    it("check the Response Alignment field", () => {
        act(() => {
            render(
                <ExtendedResponse
                    item={{
                        item_json: {
                            itemTypeCode: 'ER'
                        }
                    }
                    }
                />,
                container
            );
        });

        const responseAlignment = document.querySelector("[data-testid=answer-alignment]");
        expect(responseAlignment).not.toBeNull();
    });

    /**
       * Identify the data for rationale
       */
    it("check the rationale and its functionality", () => {

        let item = {
            id: -1,
            name: 'Extended_Response Demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'ER',
            item_json: {
                itemTypeCode: 'ER'
            },
            user_id: 1
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    ...item.item_json,
                    ...payload.item_json
                }
            };
        });

        const { rerender } = render(
            <ExtendedResponse
                item={item}
                onUpdate={updateItem}
            />,
            container
        );

        expect(document.querySelector("[data-testid=rationale-container]")).not.toBeNull();
        const rationaleButton = document.querySelector("[data-testid=rationale-toggle-button]");
        expect(rationaleButton).not.toBeNull();
        expect(document.querySelector("[data-testid=rationale-text]")).toBeNull();

        // Trigering the fireEvent to enable the checkbox
        fireEvent.click(rationaleButton);

        act(() => {
            rerender(
                <ExtendedResponse
                    item={item}
                    onUpdate={updateItem}
                />,
                container
            )
        });

        expect(document.querySelector("[data-testid=rationale-text]")).not.toBeNull();
    });

    it('The User will be able to set Item dimensions for the item in item dimensions field', () => {
        let item = {
            id: -1,
            name: 'Extended_Response Demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'ER',
            item_json: {
                itemTypeCode: 'ER',
                minItemWidth: 400,
                minItemHeight: 400
            },
            user_id: 1
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    ...item.item_json,
                    ...payload.item_json
                }
            };
        });

        const { rerender } = render(
            <ExtendedResponse
                item={item}
                onUpdate={updateItem}
            />,
            container
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull();
        expect(minItemHeightInput).not.toBeNull();

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(
                <ExtendedResponse
                    item={item}
                    onUpdate={updateItem}
                />,
                container
            );
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(
                <ExtendedResponse
                    item={item}
                    onUpdate={updateItem}
                />,
                container
            );
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

    it("Check the Expected Lines dropdown field", () => {
        let item = {
            id: -1,
            name: 'Extended_Response Demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'ER',
            item_json: {
                itemTypeCode: 'ER',
                expectedLines: "5LINES_EXT"
            },
            user_id: 1
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    ...item.item_json,
                    ...payload.item_json
                }
            };
        });

        const { rerender } = render(
            <ExtendedResponse
                item={item}
                onUpdate={updateItem}
            />,
            container
        );

        expect(item.item_json.expectedLines).toBe("5LINES_EXT");

        let expectedLinesInput = document.querySelector('[data-testid=expected-lines]');

        expect(expectedLinesInput).not.toBeNull();

        fireEvent.change(expectedLinesInput, { target: { value: "10LINES_EXT" } });

        act(() => {
            rerender(
                <ExtendedResponse
                    item={item}
                    onUpdate={updateItem}
                />,
                container
            );
        });

        expect(item.item_json.expectedLines).toBe("10LINES_EXT");

    });

    it("Check the Response Alignment Drop down field", () => {
        act(() => {
            render(
                <ExtendedResponse
                    config={{
                        responseAlignment: [
                            { id: 'Right Side Vertical', name: 'Right Side Vertical' },
                            { id: 'Stacked Vertical', name: 'Stacked Vertical' }
                        ]
                    }}
                    item={{
                        item_json: {
                            itemTypeCode: 'ER'
                        }
                    }}
                />,
                container
            );
        });

        const responseAlignment = document.querySelector("[data-testid=answer-alignment]");
        expect(responseAlignment).not.toBeNull();
    });

    it("Check Enable/ Disable spell check behaviour", () => {
        let item = {
            id: -1,
            name: 'Extended_Response Demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'ER',
            item_json: {
                itemTypeCode: 'ER',
                spellCheck: false
            },
            user_id: 1
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    ...item.item_json,
                    ...payload.item_json
                }
            };
        });

        const { rerender } = render(
            <ExtendedResponse
                item={item}
                onUpdate={updateItem}
            />,
            container
        );

        let enableSpellCheckInput = document.querySelector('[data-testid=enable-spell-check]');

        expect(enableSpellCheckInput).not.toBeNull();
        expect(enableSpellCheckInput.checked).toBeFalsy();

        // Trigering the fireEvent to enable the checkbox
        fireEvent.click(enableSpellCheckInput);

        act(() => {
            rerender(
                <ExtendedResponse
                    item={item}
                    onUpdate={updateItem} />,
                container
            )
        });

        enableSpellCheckInput = document.querySelector('[data-testid=enable-spell-check]');
        expect(enableSpellCheckInput).not.toBeNull();
        expect(enableSpellCheckInput.checked).toBeTruthy();

    });

    it("Check the Paper and Pencil as Expected Lines dropdown field and Spell Check behaviour", async () => {
        let item = {
            id: -1,
            name: 'Extended_Response Demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'ER',
            item_json: {
                itemTypeCode: 'ER',
                expectedLines: "20LINES_EXT",
                spellCheck: true
            },
            user_id: 1
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    ...item.item_json,
                    ...payload.item_json
                }
            };
        });

        const { rerender } = render(
            <ExtendedResponse
                item={item}
                onUpdate={updateItem} />,
            container
        );

        expect(document.querySelector('[data-testid=enable-spell-check]').checked).toBeTruthy();
        expect(item.item_json.expectedLines).toBe("20LINES_EXT");
        expect(item.item_json.spellCheck).toBeTruthy();
        let expectedLinesInput = document.querySelector('[data-testid=expected-lines]');
        fireEvent.change(expectedLinesInput, { target: { value: "PAPER_PENCIL" } });

        act(() => {
            rerender(
                <ExtendedResponse
                    item={item}
                    onUpdate={updateItem}
                />,
                container
            );
        });

        expect(item.item_json.expectedLines).toBe("PAPER_PENCIL");

        // wait till the spell check is disabled and unchecked that, when the expected lines as paper pencil
        await waitFor(() => {
            expect(document.querySelector('[data-testid=enable-spell-check]').checked).toBeFalsy();
            expect(item.item_json.spellCheck).toBeFalsy();
        });

    }, (10000000));

    it("Check the config dropdown data", () => {
        let item = {
            id: -1,
            name: 'Extended_Response Demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'ER',
            item_json: {
                itemTypeCode: 'ER',
            },
            user_id: 1
        };

        const config = {
            expectedLines: [
                {
                    code: '5LINES_EXT',
                    name: '5 Lines'
                }
            ],
            responseAlignments: [
                { code: 'vertical_stacked', name: 'Vertical Stacked' }
            ]
        }

        render(
            <ExtendedResponse
                item={item}
                config={config}
            />,
            container
        );

        let expectedLinesInput = document.querySelector('[data-testid=expected-lines]');
        expect(expectedLinesInput.children.length).toBe(2);

        const responseAlignment = document.querySelector("[data-testid=answer-alignment]");
        expect(responseAlignment.children.length).toBe(2);
        
    });

});
