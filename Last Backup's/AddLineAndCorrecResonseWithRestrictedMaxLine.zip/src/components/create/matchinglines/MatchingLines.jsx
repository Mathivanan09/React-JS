import React, { useState, useEffect } from 'react';
import uuid from 'react-uuid';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';
import ReorderItems from '../shared/ReorderItems';

import MatchingLinesResponse from '../../display/response/matchinglines/MatchingLinesResponse';

import { readableResponseParser } from '../../../utility/readableResponse';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import { itemProps } from '../../common/ItemHelper';
import label from '../../../constants/labelCodes';
import fetch from '../../../utility/default';
import ColumnOptions from './ColumnOptions';
// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/MatchingLines.css';

/**
 * React functional component to create Matching Lines item
 *

 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace MatchingLines
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Matching Lines item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {MatchingLines} MatchingLines component for creating Matching Lines item
 *
 * @example
 * <MatchingLines item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'ml' },
    user_id: 0,
  }} />
 */
const MatchingLines = ({ item, onUpdate, config }) => {

  const itemJson = item?.item_json;
  const DIR_UP = -1;
  const DIR_DOWN = 1;
  const leftColumnHeader = label.ml_left_column_header;
  const rightColumnHeader = label.ml_right_column_header;
  const leftColumnOptions = label.ml_left_column_options;
  const rightColumnOptions = label.ml_right_column_options;
  const rationaleContent = label.enter_rationale_content;
  
  const defaultOptionWidth = fetch('default-width');
  const defaultOptionHeight = fetch('default-height');
  const minOptionWidth = fetch('min-option-width');
  const maxOptionWidth = fetch('max-option-width');
  const minOptionHeight = fetch('min-option-height');
  const maxOptionHeight = fetch('max-option-height');

  const [visibleRationale, setVisibleRationale] = useState([]);
  const [autoFocus, setAutoFocus] = useState(false);

  let defaultLeftClassName = [];
  let defaultRightClassName = [];

  const loadLeftClassName = () => {
    for (let i = 0; i < itemJson.optionList.length; i++) {
      defaultLeftClassName.push('foils');
    }
    return defaultLeftClassName;
  }
  const loadRightClassName = () => {
    for (let i = 0; i < itemJson.matchList.length; i++) {
      defaultRightClassName.push('foils');
    }
    return defaultRightClassName;
  }

  const [leftClassName, setLeftClassName] = useState(loadLeftClassName);
  const [rightClassName, setRightClassName] = useState(loadRightClassName);

  useEffect(() => {
    const readableResponse = generateReadableResponse(itemJson);
    if (onUpdate !== undefined) {
      onUpdate({
        readableResponse: readableResponse
      })
    }
  }, [])

  /**
  * @summary This method is used to Build readable response for Matching Lines Item.
  * @param {item.item_json} itemJson
  */
  const generateReadableResponse = (itemJson) => {
    let readableResponse = '';
    if (itemJson?.optionList !== undefined && itemJson?.matchList !== undefined) {
      for (let i = 0; i < itemJson?.optionList.length; i++) {
        for (let j = 0; j < itemJson?.matchList.length; j++) {
          let leftOption = itemJson?.optionList[i].optionText;
          let rightOption = itemJson?.matchList[j].optionText;
          let parseElementLeft = readableResponseParser({ responseText: leftOption });
          let parseElementRight = readableResponseParser({ responseText: rightOption });
          let responseRow = `"${parseElementLeft}"LeftOption:"${parseElementRight}"RightOption"`;
          if (i === 0) {
            readableResponse = responseRow;
          } else {
            readableResponse = readableResponse + '\n\n' + responseRow;
          }
        }
      }
    }
    return readableResponse;
  }

  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  // Event handler for set option dimensions width
  const widthChangeHandler = (e) => {
    if (e.target.value === "") {
      onUpdate({
        ...item.item_json,
        item_json: {
          dimensions: {
            width: minOptionWidth,
            height: item.item_json.dimensions.height
          },
        }
      });
    }
    else if (e.target.valueAsNumber > maxOptionWidth) {
      onUpdate({
        ...item.item_json,
        item_json: {
          dimensions: {
            width: maxOptionWidth,
            height: item.item_json.dimensions.height
          },
        }
      });
    }
    else {
      onUpdate({
        ...item.item_json,
        item_json: {
          dimensions: {
            width: e.target.valueAsNumber,
            height: item.item_json.dimensions.height
          },
        }
      })
    }
  };

  // Event handler for set option dimensions height
  const heightChangeHandler = (e) => {

    const leftIndex = leftClassName.findIndex(
      (opt) => opt === ''
    );
    leftClassName[leftIndex] = 'foils';

    const rightIndex = rightClassName.findIndex(
      (opt) => opt === ''
    );
    rightClassName[rightIndex] = 'foils';

    if (e.target.value === "") {
      onUpdate({
        ...item.item_json,
        item_json: {
          dimensions: {
            height: minOptionHeight,
            width: item.item_json.dimensions.width
          },
        }
      });
    }
    else if (e.target.valueAsNumber > maxOptionHeight) {
      onUpdate({
        ...item.item_json,
        item_json: {
          dimensions: {
            height: maxOptionHeight,
            width: item.item_json.dimensions.width
          },
        }
      });
    }
    else {
      onUpdate({
        ...item.item_json,
        item_json: {
          dimensions: {
            height: e.target.valueAsNumber,
            width: item.item_json.dimensions.width
          },
        }
      })
    }
  };




  //Event handler for Adding Left Column Options
  const addLeftOption = () => {
    setAutoFocus(true)
    const optionId = uuid();
    const addedOption = [
      ...itemJson.optionList,
      { optionText: "", id: optionId },
    ];

    // Add new correctResponse entry
    const correctResponse = [
      ...itemJson.correctResponse,
      { id: optionId, value: "" },
    ];

    onUpdate({
      ...item,
      item_json: {
        optionList: addedOption,
        correctResponse,
      }
    })
    leftClassName.push('foils');
  };

  //Event handler for Adding Right Column Options
  const addRightOption = () => {
    setAutoFocus(true)
    const optionId = uuid();
    const addedOption = [
      ...itemJson.matchList,
      { optionText: "", id: optionId },
    ];
    const optionRationales = [
      ...item.rationale.optionRationales,
      { rationaleText: "", id: optionId },
    ];
    onUpdate({
      item_json: {
        matchList: addedOption,
      },
      rationale: {
        id: uuid(),
        optionRationales: optionRationales,
      },
    })
    rightClassName.push('foils')
  };

  //Event handler for Removing Left Column Options
  const removeLeftOption = (id) => {
    const optionList = itemJson?.optionList?.filter(
      (opt) => opt.id !== id
    ) || [];

    // Remove from correctResponse
    const correctResponse = itemJson?.correctResponse?.filter(response =>
      response.id !== id
    ) || [];

    if (optionList !== undefined) {
      onUpdate({
        item_json: {
          optionList,
          correctResponse,
        }
      });
    }
  };

  //Event handler for Removing Right Column Options
  const removeRightOption = (id) => {
    const matchList = itemJson.matchList.filter(
      (opt) => opt.id !== id
    );

    // Remove any correctResponse association
    const correctResponse = [...itemJson.correctResponse];
    if (correctResponse.map(response => response.value).includes(id)) {
      correctResponse.find(response => response.value === id).value = "";
    }

    if (matchList !== undefined) {
      onUpdate({
        item_json: {
          matchList,
          correctResponse,
        }
      });
    }
  };

  //Event handler for Reordering Left Column Options
  const reorderLeftOptions = (id, counter) => {
    const itemIndex = itemJson?.optionList.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === itemJson.optionList.length - 1)
    ) {
      return;
    }
    const optionItem = itemJson?.optionList[itemIndex];
    const updatedList = itemJson?.optionList.filter((i) => i.id !== id);
    updatedList.splice(itemIndex + counter, 0, optionItem);
    onUpdate({
      ...item.item_json,
      item_json: {
        optionList: updatedList,
      }
    })
  }

  //Event handler for Reordering Right Column Options
  const reorderRightOptions = (id, counter) => {
    const itemIndex = itemJson?.matchList.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === itemJson.matchList.length - 1)
    ) {
      return;
    }
    const optionItem = itemJson?.matchList[itemIndex];
    const updatedList = itemJson?.matchList.filter((i) => i.id !== id);
    updatedList.splice(itemIndex + counter, 0, optionItem);
    onUpdate({
      ...item.item_json,
      item_json: {
        matchList: updatedList,
      }
    })
  }

  // Toggles the rationale
  const showHideRationale = (id) => {
    let newVisibleRationale = visibleRationale.slice();

    if (newVisibleRationale.includes(id)) {
      newVisibleRationale = newVisibleRationale.filter(
        (rationaleId) => rationaleId !== id
      );
    } else {
      newVisibleRationale.push(id);
    }
    setVisibleRationale(newVisibleRationale);
  };

  const getRationaleData = (id) => {
    const optionRationale = item?.rationale?.optionRationales.find(
      (optionRationale) => optionRationale.id === id
    );
    return optionRationale ? optionRationale.rationaleText : "";
  }

  // Event handler for Rationale change
  const updateRationale = (text, id) => {

    const rationale = item?.rationale;
    const optionRationales = rationale?.optionRationales;
    const index = optionRationales.findIndex(optionRationale => optionRationale.id === id);
    if (index > -1) {
      optionRationales[index].rationaleText = text;
    } else {
      optionRationales.push({ id: id, rationaleText: text });
    }
  }

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className='row'>
            <div className='col-md-8'>
              <fieldset className='bg-light p-3 rounded mt-1'>
                <div className='row'>
                  <div className='col-md-3 text-right'>
                    <legend className=''>Set Option Dimensions</legend>
                  </div>
                  <div className='col-md-4'>
                    <div className='row'>
                      <div className='pt-1 col-md-4 text-right'>
                        {label.ml_width}:&nbsp;
                      </div>
                      <div className='col-md-8'>
                        <input type="number"
                          data-testid='ml-options-width'
                          className='form-control'
                          min={minOptionWidth}
                          max={maxOptionWidth}
                          onChange={widthChangeHandler}
                          onBlur={() => {
                            if (itemJson.dimensions.width < minOptionWidth) {
                              onUpdate({
                                ...item.item_json,
                                item_json: {
                                  dimensions: {
                                    width: minOptionWidth,
                                    height: item.item_json.dimensions.height
                                  },
                                }
                              });
                            }
                          }}
                          value={itemJson?.dimensions?.width ? itemJson.dimensions.width : defaultOptionWidth}
                        />
                      </div>
                    </div>
                  </div>
                  <div className='col-md-4'>
                    <div className='row'>
                      <div className='pt-1 col-md-4 text-right'>
                        {label.ml_height}:&nbsp;
                      </div>
                      <div className='col-md-8'>
                        <input type="number"
                          data-testid='ml-options-height'
                          className='form-control'
                          min={minOptionHeight}
                          max={maxOptionHeight}
                          onChange={heightChangeHandler}
                          onBlur={() => {
                            if (itemJson.dimensions.height < minOptionHeight) {
                              onUpdate({
                                ...item.item_json,
                                item_json: {
                                  dimensions: {
                                    width: item.item_json.dimensions.width,
                                    height: minOptionHeight
                                  },
                                }
                              });
                            }
                          }}
                          value={itemJson?.dimensions?.height ? itemJson?.dimensions?.height : defaultOptionHeight}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </fieldset>
            </div>
          </div>
          <div className='row'>
            <div className='ml-options col-md-6 left-options' style={{ padding: '0px 0px 0px 6px' }}>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className="row">
                  <div className="col-12" data-testid='ml-left-title'>
                    <legend className='pt-1'>Left Column Header</legend>
                    <CKEditorBase
                      type='inline'
                      data={itemJson?.leftTitle}
                      fieldName='leftTitle'
                      placeholder={leftColumnHeader}
                      onChange={(value) => updateItemJson('leftTitle', value)}
                    />
                  </div>
                </div>
                <hr className='ml-hr'></hr>
                <div className='row'>
                  <div className='col-md-10'>
                    <legend className='pt-1'>Left Column Options:</legend>
                  </div>
                  <div className='col-md-2'>
                    <button type="button" className="btn btn-primary btn-sm" onClick={(e) => {
                      e.preventDefault();
                      addLeftOption();
                    }}>+ Add</button>
                  </div>
                  {itemJson?.optionList !== undefined &&
                    itemJson?.optionList.map((option, index) => (
                      <div key={option.id} className='row p-2 align-items-center'>
                        <div className='col-lg-1 col-md-1 col-6 text-right pt-2'>
                          <ReorderItems
                            listLength={itemJson?.optionList.length}
                            option={index}
                            onDownClick={() => reorderLeftOptions(option.id, DIR_DOWN)}
                            onUpClick={() => reorderLeftOptions(option.id, DIR_UP)}
                          />
                        </div>
                        <ColumnOptions
                          index={index}
                          item={item}
                          leftClassName={leftClassName}
                          setLeftClassName={setLeftClassName}
                          option={option}
                          placeholder={leftColumnOptions}
                          onUpdate={onUpdate}
                          fieldName='optionList'
                          columnOption={true}
                          autoFocus={autoFocus}
                        />
                        <div className='col-lg-1 col-md-1 col-1' style={{ paddingLeft: '39px' }}>
                          <button type="button" key={index} className="icon"
                            onClick={(e) => {
                              e.preventDefault();
                              removeLeftOption(option.id);
                            }}
                          ><span className='icon-minus'>-</span></button>
                        </div>
                      </div>
                    ))}
                </div>
              </fieldset>
            </div>
            <div className='ml-options col-md-6' style={{ padding: '0px 2px 0px 4px' }}>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className="row">
                  <div className="col-12" data-testid='ml-right-title'>
                    <legend className='pt-1'>Right Column Header</legend>
                    <CKEditorBase
                      type='inline'
                      data={itemJson?.rightTitle}
                      fieldName='rightTitle'
                      placeholder={rightColumnHeader}
                      onChange={(value) => updateItemJson('rightTitle', value)}
                    />
                  </div>
                </div>
                <hr className='ml-hr'></hr>
                <div className='row'>
                  <div className='col-md-10'>
                    <legend className='pt-1'>Right Column Options:</legend>
                  </div>
                  <div className='col-md-2'>
                    <button type="button" className="btn btn-primary btn-sm" onClick={(e) => {
                      e.preventDefault();
                      addRightOption();
                    }}>+ Add</button>
                  </div>
                  {itemJson?.matchList !== undefined &&
                    itemJson?.matchList.map((option, index) => (
                      <div key={option.id} className='row p-2 align-items-center'>
                        <div className='col-lg-1 col-md-1 col-6 text-right pt-2'>
                          <ReorderItems
                            listLength={itemJson?.matchList.length}
                            option={index}
                            onDownClick={() => reorderRightOptions(option.id, DIR_DOWN)}
                            onUpClick={() => reorderRightOptions(option.id, DIR_UP)}
                          />
                        </div>
                        <ColumnOptions
                          index={index}
                          item={item}
                          leftClassName={rightClassName}
                          setLeftClassName={setRightClassName}
                          option={option}
                          placeholder={rightColumnOptions}
                          onUpdate={onUpdate}
                          fieldName='matchList'
                          columnOption={false}
                          autoFocus={autoFocus}
                        />
                        <div className='col-lg-1 col-md-1 col-1' style={{ paddingLeft: '39px' }}>
                          <button type="button" className="icon" key={index}
                            onClick={(e) => {
                              e.preventDefault();
                              removeRightOption(option.id);
                            }}
                          ><span className='icon-minus'>-</span></button>
                        </div>
                        <div className="row rationale pt-2 mt-4">
                          <div className='col-md-3'>
                            <button type="button"
                              className="btn btn-primary btn-sm"
                              onClick={() => showHideRationale(option.id)}>{label.ml_rationale}</button>
                          </div>
                          <div className='col-md-9' data-testid='ml-rationale'>
                            {visibleRationale.includes(option.id) && (
                              <CKEditorBase
                                type='inline'
                                data={getRationaleData(option.id)}
                                onChange={(value) => { updateRationale(value, option.id) }}
                                placeholder={rationaleContent}
                                config={{ removePlugins: ['TagAccessibility'] }}
                              />
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </fieldset>
            </div>
          </div>
          <MatchingLinesResponse item={item} onUpdate={onUpdate} showCorrectResponse={false} responseOnly={true} />
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

MatchingLines.propTypes = itemProps;

export default MatchingLines;
