import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import MatchingLines from './MatchingLines';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <MatchingLines />, container);
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <MatchingLines item={{
                    item_json: {
                        itemTypeCode: 'ML'
                    }
                }
                } />, container);
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=container]");
        expect(component).not.toBeNull;
        // expect(component.children.length).toBe(4);

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=container]")).not.toBeNull;
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
    });

    it('The User will be able to set Item dimensions for the item in item dimensions field', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull;
        expect(minItemHeightInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(<Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(<Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

    it("The User will be able enter content in stem", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
                stemContent: "<p>stem content</p>"
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.stemContent).toBe("<p>stem content</p>");

        let stemContent = screen.getByTestId("stem-container");
        expect(stemContent).not.toBeNull;

    });

    it("The User will be able to enter desired headers in Left column header and right column header", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
                leftTitle: "<p>Left Title</p>",
                rightTitle: "<p>Right Title</p>"
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.leftTitle).toBe("<p>Left Title</p>");
        expect(item.item_json.rightTitle).toBe("<p>Right Title</p>");

        let leftTitle = screen.getByTestId("ml-left-title");
        let rightTitle = screen.getByTestId("ml-right-title");

        expect(leftTitle).not.toBeNull;
        expect(rightTitle).not.toBeNull;

    });

    it("User can set the dimensions of the column options boxes by providing necessary values in width and height field. In response also it reflects the same", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
                dimensions: {
                    width: 250,
                    height: 55
                }
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.dimensions.width).toBe(250);
        expect(item.item_json.dimensions.height).toBe(55);

        let width = screen.getByTestId("ml-options-width");
        let height = screen.getByTestId("ml-options-height");

        expect(width).not.toBeNull;
        expect(height).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(width, { target: { value: 300 } });
        act(() => {
            rerender(<Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(height, { target: { value: 300 } });
        act(() => {
            rerender(<Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>);
        });

        expect(item.item_json.dimensions.width).toBe(300);
        expect(item.item_json.dimensions.height).toBe(300);
    });

    it("User will be able to add the left options and right options as many required by clicking on add icon on top right of the box", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
                dimensions: {
                    width: 250,
                    height: 55
                },
                matchList: [
                    {
                        id: "e6bcc3-0dcd-825-c652-60ffeecb10d1",
                        optionText: "<p>Right Option List</p>"
                    },
                ],
                optionList: [
                    {
                        id: "df7bcc8-fe7d-ed1-fd72-a63a4af22d63",
                        optionText: "<p>Left Option List</p>"
                    },
                ]
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });
        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.matchList[0].optionText).toBe("<p>Right Option List</p>");
        expect(item.item_json.optionList[0].optionText).toBe("<p>Left Option List</p>");
        let optionList = document.querySelector("[data-testid=ml-left-column-options]");
        let matchList = document.querySelector("[data-testid=ml-right-column-options]");
        expect(optionList).not.toBeNull;
        expect(matchList).not.toBeNull;

    });

    it("The rationale boxes will be added for each right column options. User can enter content in rationale box", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
            },
            rationale: {
                id: "2abdeb0-cff-a5-e2be-df10f51a808",
                optionRationales: [
                    {
                        id: "e2c8ab2-a430-3211-67f1-a6c3cf35be8",
                        rationaleText: "<p>rationale</p>"
                    },
                ]
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );

        expect(item.rationale.optionRationales[0].rationaleText).toBe("<p>rationale</p>");
        let rationale = document.querySelector("[data-testid=ml-rationale]");
        expect(rationale).not.toBeNull;
    });




    it("User can also able to remove the right options and left options as required by clicking on removal icon", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'ML',
                dimensions: {
                    width: 250,
                    height: 55
                },
                matchList: [
                    {
                        id: "e6bcc3-0dcd-825-c652-60ffeecb10d1",
                        optionText: "<p>Right Option List</p>"
                    },
                ],
                optionList: [
                    {
                        id: "df7bcc8-fe7d-ed1-fd72-a63a4af22d63",
                        optionText: "<p>Left Option List</p>"
                    },
                ]
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatchingLines item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.optionList[0].optionText).toBe("<p>Left Option List</p>");
        expect(item.item_json.matchList[0].optionText).toBe("<p>Right Option List</p>");

        let optionList = document.querySelector("[data-testid=ml-remove-left-option]");
        let matchList = document.querySelector("[data-testid=ml-remove-right-option]");

        expect(optionList).toBeNull;
        expect(matchList).toBeNull;

    });

})