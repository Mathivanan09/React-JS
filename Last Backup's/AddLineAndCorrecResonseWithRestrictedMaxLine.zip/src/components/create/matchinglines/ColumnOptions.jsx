import React, { useRef, useState } from 'react';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import fetch from '../../../utility/default';

const ColumnOptions = ({
    index,
    item,
    leftClassName,
    setLeftClassName,
    option,
    placeholder,
    onUpdate,
    columnOption,
    autoFocus,
    fieldName
}) => {

    const itemJson = item?.item_json;
    const elementRef = useRef(null);
    const maxOptionHeight = fetch('max-option-height');

    const optionChange = (value, id) => {

        if (columnOption) {
            // Event handler for Left Column Options Change
            const foils = itemJson.optionList.map((opt) => opt.id === id ? '' : 'foils');
            setLeftClassName(foils);
            const maxHeights = [elementRef.current?.lastChild?.childNodes[1]?.clientHeight, itemJson?.dimensions?.height];
            let optionListHeight = Math.max(...maxHeights)

            if (optionListHeight > maxOptionHeight) {
                optionListHeight = maxOptionHeight;
            }
            onUpdate({
                ...item,
                item_json: {
                    ...item.item_json,
                    dimensions: {
                        height: optionListHeight,
                        width: itemJson?.dimensions?.width
                    },
                    optionList: itemJson.optionList.map((opt) =>
                        opt.id === id ? { ...opt, optionText: value } : opt
                    )
                }
            });
        }
        else {
            // Event handler for Right Column Options Change
            const foils = itemJson.matchList.map((opt) => opt.id === id ? '' : 'foils');
            setLeftClassName(foils);
            const maxHeights = [elementRef.current?.lastChild?.childNodes[1]?.clientHeight, itemJson?.dimensions?.height];
            let matchListHeight = Math.max(...maxHeights)
            if (matchListHeight > maxOptionHeight) {
                matchListHeight = maxOptionHeight;
            }
            onUpdate({
                ...item,
                item_json: {
                    ...item.item_json,
                    dimensions: {
                        height: matchListHeight,
                        width: itemJson?.dimensions?.width
                    },
                    matchList: itemJson.matchList.map((opt) =>
                        opt.id === id ? { ...opt, optionText: value } : opt
                    )
                }
            });
        }
    };

    const optionBlur = () => {
        if (columnOption) {
            // OnBlur for Left Column Options Change
            const foils = itemJson.optionList.map(() => 'foils');
            setLeftClassName(foils);
        }
        else {
            // OnBlur for Right Column Options Change
            const foils = itemJson.matchList.map(() => 'foils');
            setLeftClassName(foils);
        }
    }
    return (
        <div className="col-lg-10 col-md-10 col my-2">
            <div className={index > 0 ? leftClassName[index] : leftClassName[0]}
                ref={elementRef} data-testid='ml-left-column-options' style={{
                    width: itemJson.dimensions.width + 'px',
                    height: itemJson.dimensions.height + 'px',
                }}>
                <CKEditorBase
                    type='inline'
                    data={option.optionText}
                    fieldName={fieldName}
                    placeholder={placeholder}
                    onReady={(editor) => {
                        if (autoFocus) {
                            editor.focus();
                        }
                    }}
                    onChange={(value) => { optionChange(value, option.id) }}
                    onBlur={optionBlur}
                    className='ml-column-options'
                />
            </div>
        </div>
    )
}

export default ColumnOptions;