import React, { useEffect } from 'react';
import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';
import uuid from 'react-uuid';
import { itemProps } from '../../common/ItemHelper';
import SimulationData from './SimulationData'

// load common styles first and then load any specific item type or overrides
// import common from '../../../styles/item/Common.css';
// import styles from '../../../styles/item/BiologySimulation.css';

/**
 * React functional component to create Biology Simulation item
 *

 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace BiologySimulation
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Biology Simulation item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {BiologySimulation} BiologySimulation component for creating Biology Simulation item
 *
 * @example
 * <BiologySimulation item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'bs' },
    user_id: 0,
  }} />
 */
const BiologySimulation = ({ item, onUpdate, config }) => {
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  console.log(item);

  useEffect(()=>{
    onUpdate({
        item_json: {
          optionList: [],
          stemContent:"",
          uuid: uuid()
        }
      })
    },[]);

  return (
    <>
      {item ? (
        <div data-testid={'container'}>
          <div className="row" data-testid={'id-container'}>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div className="row" data-testid={'stem-container'}>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName={'stemContent'}
            />
          </div>
          <div>
          <div className="row" data-testid={'design-container'}>
              <SimulationData
                item={item}
                onUpdate={onUpdate}
                config={config}
              />

            </div>
          </div>
        </div>
      ) : (
        <div data-testid='missing-item'>Missing item data</div>
      )}
    </>
  );
};

BiologySimulation.propTypes = itemProps;

export default BiologySimulation;
