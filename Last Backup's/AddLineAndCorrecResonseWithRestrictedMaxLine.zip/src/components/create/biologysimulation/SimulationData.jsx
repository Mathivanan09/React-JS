import React, { useState } from 'react'
import uuid from 'react-uuid';
import beetle from '../../../assets/images/beetle.png'
import butterfly from '../../../assets/images/butterfly.png'
import coyote from '../../../assets/images/coyote.png'
import deer from '../../../assets/images/deer.png'
import flower from '../../../assets/images/flower.png'
import frog from '../../../assets/images/frog.png'
import grass from '../../../assets/images/grass.png'
import hawk from '../../../assets/images/hawk.png'
import mouse from '../../../assets/images/mouse.png'
import mushroom from '../../../assets/images/mushroom.png'


const SimulationData = ({ item, onUpdate, config }) => {


  const [data, setData] = useState();
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  //Species JSON Data
  const species = [
    {
      type: "Species beetle",
      labelKey: "Beetle",
      label: ['Beetle', 'Herbivore', 'Insect', 'Unknown'],
      headerImageUrl: beetle,
      selectedValue: ''
    },
    {
      type: "Species butterfly",
      labelKey: "Butterfly",
      label: ['Butterfly', 'Herbivore', 'Insect', 'Unknown'],
      headerImageUrl: butterfly,
      selectedValue: ""
    },
    {
      type: "Species coyote",
      labelKey: "Coyote",
      label: ['Coyote', 'Carnivore', 'Mammal', 'Unknown'],
      headerImageUrl: coyote,
      selectedValue: ""
    },
    {
      type: "Species deer",
      labelKey: "Deer",
      label: ['Deer', 'Herbivore', 'Mammal', 'Unknown'],
      headerImageUrl: deer,
      selectedValue: ""
    },
    {
      type: "Plant Flower",
      labelKey: "Flower",
      label: ['Flower', 'Producer', 'Plant', 'Unknown'],
      headerImageUrl: flower,
      selectedValue: ""
    },
    {
      type: "Species frog",
      labelKey: "Frog",
      label: ['Frog', 'Carnivore', 'Amphibian', 'Unknown'],
      headerImageUrl: frog,
      selectedValue: ""
    },
    {
      type: "Plant grass",
      labelKey: "Grass",
      label: ['Grass', 'Producer', 'Plant', 'Unknown'],
      headerImageUrl: grass,
      selectedValue: ""
    },
    {
      type: "Species hawk",
      labelKey: "Hawk",
      label: ['Hawk', 'Carnivore', 'Bird', 'Unknown'],
      headerImageUrl: hawk,
      selectedValue: ""
    },
    {
      type: "Species mouse",
      labelKey: "Mouse",
      label: ['Mouse', 'Omnivore', 'Mammal', 'Unknown'],
      headerImageUrl: mouse,
      selectedValue: ""
    },
    {
      type: "Fungi mushroom",
      labelKey: "Mushroom",
      label: ['Mushroom', 'Decomposer', 'Fungi', 'Unknown'],
      headerImageUrl: mushroom,
      selectedValue: ""
    }
  ];

  //Handle Radio Button
  const handleRadioChange = (e) => {
    let val = e.target.value;
    let key = e.target.id;
    let isChecked = e.target.checked;
    let length = item.item_json.optionList.length;
    item.item_json.optionList[length] = {
      value: val,
      id: uuid()
    }
    console.log(item.item_json.optionList)
  }



  return (
    <div className="container">
      <div className="row pt-2">
        <h5 className="text-primary">Select Organisms</h5>
        {species.map((data, i) => (
          <>
            {/* {console.log(species[i].label)} */}
            <div className="col-2 pt-2 " style={{ width: 280 }}>
              <fieldset className={'bg-light p-3 m-1'}>
                <div className="card ">
                  <div className="text-center">
                    <img className="card-img-top" src={data.headerImageUrl} alt={data.labelKey} style={{ width: 80, height: 80 }} />
                  </div>
                  <div className="card-body">
                    <h5 className="card-title text-center"><b>{data.labelKey}</b></h5>
                    <p className="card-text">Display Value: {data.labelKey}</p>
                    <div className="radio-group">
                      {species[i].label.map((opt, j) => (
                        <div className="row  ">
                          <div className="col-2 pt-1 text-center">
                            <input
                              type="radio"
                              value={opt}
                              id={i}
                              name={"radio-group"}
                              onChange={(e) => handleRadioChange(e)}
                            />
                          </div>
                          <div className="col col-lg-6">
                            <label key={j}>{opt}</label>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </fieldset>
            </div>
          </>
        ))}

      </div>
    </div>
  )
}

export default SimulationData
