import React from 'react';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';

import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/LineGraph.css';

/**
 * React functional component to create Line Graph item
 *
 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace LineGraph
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Line Graph item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {LineGraph} LineGraph component for creating Line Graph item
 * 
 * @example
 * <LineGraph item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'lg' },
    user_id: 0,
  }} />
 */
const LineGraph = ({ item, onUpdate, config }) => {
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

LineGraph.propTypes = itemProps;

export default LineGraph;
