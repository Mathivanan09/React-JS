import React, { useState } from 'react';
import uuid from 'react-uuid';
import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';

import DraggableContainer from '../../common/dnd/DraggableContainer';
import BgGraphicResponse from '../../display/response/backgroundgraphic/BgGraphicResponse';
import ReorderItems from '../shared/ReorderItems';
import AddMedia from '../shared/AddMedia';

import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import { itemProps } from '../../common/ItemHelper';
import label from '../../../constants/labelCodes';
import fetch from '../../../utility/default';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/BackgroundGraphic.css';

const DIR_UP = -1;
const DIR_DOWN = 1;

/**
 * React functional component to create Background Graphic item
 *
 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace BackgroundGraphic
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Background Graphic item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {BackgroundGraphic} BackgroundGraphic component for creating Background Graphic item
 * 
 * @example
 * <BackgroundGraphic item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'bg' },
    user_id: 0,
  }} />
 */
const BackgroundGraphic = ({ item, onUpdate, config }) => {
  const dummyMedia = [
    {
      id: 4000254,
      name: 'Birds_blue_flying_animation',
      tags: [],
      status: 3000381,
      version: 3,
      grade_id: [[null]],
      file_name: 'Birds_blue_flying_animation',
      file_type: 'gif',
      media_type: 'Media',
      created_date: '2022-03-23T11:37:04.075387+00:00',
      created_user: 'User One',
      media_format: 'Image/Graphic',
      attachment_id: 4000609,
      content_area_id: [[null]],
      created_user_id: 1,
      created_user_name: 'User One',
      assessment_program: 'KAP',
      attachment_version: 1,
      assessment_program_id: 15009,
      content_area: '',
      grade: ''
    }
  ];

  const mediaList = item?.media_library || dummyMedia;
  const defaultOptionHeight = fetch('bg-default-option-height');
  const defaultOptionWidth = fetch('bg-default-option-width');

  const filteredMedia = mediaList.filter(
    (obj) => obj.media_format === 'Image/Graphic'
  ) || [];
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };
  const [showRationale, setShowRationale] = useState([]);
  const [imgUrl, setImgUrl] = useState([]);
  const [selectMedia, setSelectMedia] = useState({
    show: false,
    index: 0
  });

  const imageAlignment = () => {
    const values = ['Left', 'Right', 'Center'].map((val) => {
      return {
        id: val,
        name: val
      };
    });

    return [{ id: null, name: 'Select' }, ...values];
  };


  const handleInvisibleDropzones = (value) => {
    updateItemJson('invisibleDropzones', value);
  };

  const handleReusableAnswers = (value) => {
    updateItemJson('reusableAnswers', value);
  };

  const handleDropzoneWidth = (value) => {
    updateItemJson('dropzoneWidth', value);
  };

  const handleDropzoneHeight = (value) => {
    updateItemJson('dropzoneHeight', value);
  };

  // Adds a new option to the option list
  const appOption = () => {
    const optionId = uuid(); //New UUID will be generated and assigned to each response

    const addedOption = [
      ...(item.item_json?.optionList || []),
      { optionText: '', id: optionId }
    ];

    const newOptionList = [
      ...(item.rationale?.optionList || []),
      { rationaleText: '', id: optionId }
    ];

    // Update correctResponse data with new option
    const correctResponse = [
      ...(item.item_json.correctResponse || []),
      { id: optionId, values: [] },
    ];

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newOptionList },
      item_json: {
        optionList: addedOption,
        correctResponse,
      }
    };
    onUpdate(updatedItem);
  };

  // Event handler for adding option data
  /* istanbul ignore next */
  const handleOptionChange = (data, index) => {
    const newOptList = [...item.item_json.optionList];
    newOptList[index] = {
      ...newOptList[index],
      optionText: data
    };

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: newOptList
      }
    };
    onUpdate(updatedItem);
  };

  // Toggles the rationale text box
  const showHideRationale = (id) => {
    const showing = new Set([...showRationale]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowRationale([...showing]);
  };

  // Event handler for adding rationale data
  /* istanbul ignore next */
  const handleRationaleChange = (data, index) => {
    const newList = [...(item.rationale?.optionList || [])];
    newList[index] = { ...newList[index], rationaleText: data };
    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newList }
    };
    onUpdate(updatedItem);
  };

  //Move items up or down using arrow keys.
  const reorderItems = (id, counter) => {
    const itemIndex = item.item_json?.optionList.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === item.item_json?.optionList.length - 1)
    ) {
      return; // canot move outside of array
    }

    //Reorder the optionList
    const optionItem = item.item_json?.optionList[itemIndex];
    const updatedoptionList =
      item.item_json?.optionList?.filter((i) => i.id !== id) || [];
    updatedoptionList.splice(itemIndex + counter, 0, optionItem);

    //Reorder the rationale list
    const rationaleItem = item.rationale.optionList[itemIndex];
    let updatedRationaleItems = [];
    if (item.rationale?.optionList && item.rationale?.optionList.length > 0) {
      updatedRationaleItems =
        item.rationale?.optionList?.filter((i) => i.id !== id) || [];
      updatedRationaleItems.splice(itemIndex + counter, 0, rationaleItem);
    }

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: updatedRationaleItems },
      item_json: {
        optionList: updatedoptionList
      }
    };
    onUpdate(updatedItem);
  };

  //Remove the item
  const removeOption = (id) => {
    //Remove from optionList
    let optionList =
      item.item_json?.optionList?.filter((element) => element.id !== id) || [];
    //Remove from rationale
    let updatedRationaleList =
      item.rationale?.optionList?.filter((element) => element.id !== id) || [];

    //Update correctResponse information with removed option
    const correctResponse =
      item.item_json.correctResponse.filter(response => response.id !== id);

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: updatedRationaleList },
      item_json: {
        optionList: optionList,
        correctResponse,
      }
    };

    onUpdate(updatedItem);
  };

  const onAddImage = (data) => {
    const selectedMediaItem = data[0];
    const newImage = `/media/${selectedMediaItem.assessment_program_id}/${selectedMediaItem?.id}/${selectedMediaItem.attachment_id}/${selectedMediaItem?.file_name}.${selectedMediaItem.file_type}`;
    // const newImage = 'https://dummyimage.com/500x400/FF0000/000'; // this dummy image is to be uncommented and replaced in place of actual newImage to test the image upload in storybook.
    updateItemJson('imagePanel', newImage);
    setSelectMedia({
      show: false
    });
  };

  const addDropZone = (e) => {
    const newmatchList = [...(item.item_json?.matchList || [])];
    const newDropZone = {
      id: uuid(),
      coordinates: {
        x: e.clientX - e.target.getBoundingClientRect().left,
        y: e.clientY - e.target.getBoundingClientRect().top
      }
    };
    newmatchList.push(newDropZone);
    const updatedItem = {
      item_json: {
        matchList: newmatchList
      }
    };
    onUpdate(updatedItem);
  };

  const updateDropZonePosition = (delta, id) => {
    const newmatchList = [...(item.item_json?.matchList || [])];
    const newX =
      newmatchList.find((drop) => drop.id === id.id).coordinates.x + delta.x;
    const newY =
      newmatchList.find((drop) => drop.id === id.id).coordinates.y + delta.y;
    const newDropZone = {
      id: id.id,
      coordinates: {
        x: newX,
        y: newY
      }
    };
    const dropIndex = newmatchList.findIndex((element) => element.id === id.id);
    newmatchList[dropIndex] = newDropZone;
    const updatedItem = {
      item_json: {
        matchList: newmatchList
      }
    };
    onUpdate(updatedItem);
  };

  const removeDropZone = (id) => {
    const newmatchList = [...(item.item_json?.matchList || [])];
    const updatedmatchList = newmatchList.filter(
      (element) => element.id !== id
    );

    // Remove this match from values field for every option
    const correctResponse = item.item_json.correctResponse.map(response => ({
      ...response,
      values: response.values.filter(matchId => id !== matchId),
    }));

    const updatedItem = {
      item_json: {
        matchList: updatedmatchList,
        correctResponse,
      }
    };
    onUpdate(updatedItem);
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className='row' data-testid='design-container'>
            <div className='col col-12 col-sm-7'>
              <fieldset className='bg-light p-3 rounded m-1 ms-0'>
                <div className='row p-2'>
                  <div className='col col-sm-6'>
                    <legend>{label.background_image}</legend>
                  </div>
                  <div sm={6} className='col col-sm-6 text-end text-right'>
                    <button
                      className='btn btn-sm btn-primary'
                      data-testid='bggraphic-addoption'
                      icon='add'
                      onClick={(e) => {
                        e.preventDefault();
                        setSelectMedia({ show: true });
                      }}
                    >
                      {label.select_image}
                    </button>
                    {selectMedia.show && (
                      <AddMedia
                        setMedia={onAddImage}
                        media={filteredMedia}
                        cancelMedia={() =>
                          setSelectMedia({
                            show: false,
                            index: 0
                          })
                        }
                      />
                    )}
                  </div>
                </div>

                <div className='bg-image-zone' style={{ overflow: 'auto' }}>
                  <div id='imagePanel' style={{ position: 'relative' }}>
                    <img
                      id='imgDiv'
                      className='bg-image-size'
                      src={item?.item_json?.imagePanel || ''}
                      onClick={(e) => addDropZone(e)}
                      alt=''
                    />
                    <div id='planetmap' className='image-drop-box'>
                      <DraggableContainer
                        item={item}
                        removeDropZone={removeDropZone}
                        dropzoneHeight={item.item_json?.dropzoneHeight || defaultOptionHeight}
                        dropzoneWidth={item.item_json?.dropzoneWidth || defaultOptionWidth}
                        style={{
                          position: 'absolute',
                          height: item.item_json?.dropzoneHeight || defaultOptionHeight,
                          width: item.item_json?.dropzoneWidth || defaultOptionWidth
                        }}
                        createComponent={true}
                        updateDropZonePosition={updateDropZonePosition}
                      />
                    </div>
                  </div>
                </div>
              </fieldset>
            </div>
            <div className='col col-12 col-sm-5'>
              <fieldset className='bg-light p-3 rounded m-1 me-0'>
                <div className='row'>
                  <div className='col col-sm-6'>
                    <legend>{label.response_options}</legend>
                  </div>
                  <div className='col col-sm-6 text-end text-right'>
                    <button
                      className='btn btn-sm btn-primary'
                      data-testid='bggraphic-addoption'
                      icon='add'
                      onClick={(e) => {
                        e.preventDefault();
                        appOption();
                      }}
                    >
                      {label.multiple_choice_add_options}
                    </button>
                  </div>
                </div>

                <div className='optionbox' data-testid='optionbox'>
                  {item.item_json?.optionList?.map(({ id }, i) => (
                    <div
                      key={id}
                      className='p-10'
                      data-testid='bggraphic-option'
                    >
                      <div className='row option align-items-center p-2'>
                        <div
                          className='col col-6 col-md-4 col-lg-2 text-end text-right bg-select-container'
                        >
                          <ReorderItems
                            listLength={item.item_json.optionList.length}
                            option={i}
                            onDownClick={() => reorderItems(id, DIR_DOWN)}
                            onUpClick={() => reorderItems(id, DIR_UP)}
                          />
                        </div>
                        <div className='col bg-item-box'>
                          <CKEditorBase
                            type='inline'
                            data={item.item_json.optionList[i].optionText}
                            className='content_style'
                            onChange={
                              /* istanbul ignore next */
                              (data) => {
                                handleOptionChange(data, i);
                              }
                            }
                            placeholder={label.enter_response_content}
                          />
                        </div>
                        <div className='col col-1'>
                          <button
                            className='btn icon'
                            onClick={(e) => {
                              e.preventDefault();
                              removeOption(id);
                            }}
                            data-testid='option-remove-button'
                          >
                            <span className='icon-minus'>-</span>
                          </button>
                        </div>
                      </div>
                      <div className='row rationale align-items-center p-2'>
                        <div
                          className='col col-4 col-sm-3 col-lg-2 text-end text-right'
                        >
                          <button
                            className='btn btn-sm btn-primary'
                            onClick={() => showHideRationale(id)}
                            data-testid='rationale-button'
                          >
                            {label.rationale}
                          </button>
                        </div>
                        {showRationale.indexOf(id) !== -1 && (
                          <div
                            className='col bg-item-box'
                            data-testid='rationale-container'
                          >
                            <CKEditorBase
                              type='inline'
                              data={item.rationale.optionList[i].rationaleText}
                              onChange={
                                /* istanbul ignore next */
                                (data) => {
                                  handleRationaleChange(data, i);
                                }
                              }
                              placeholder={label.enter_rationale_content}
                              config={{ removePlugins: ['TagAccessibility'] }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </fieldset>
            </div>

            <div className='row p-3 ps-2 ms-1' data-testid='bg-configure-container'>
              <fieldset className='bg-light p-3 rounded m-1 mx-0'>
                <div className='row'>
                  <div className='col col-sm-4 col-lg-4'>
                    <div className='row align-items-center p-1'>
                      <div
                        className='col col-6 col-lg-6 text-right'
                        align='end'
                        data-testid='dd-required'
                      >
                        {label.drop_zone_width}:&nbsp;
                      </div>
                      <div className='col col-sm-6 col-lg-6'>
                        <input
                          min={0}
                          type='number'
                          className='form-control'
                          value={item.item_json.dropzoneWidth || defaultOptionWidth}
                          id='dropzoneWidth'
                          data-testid='dropzoneWidth'
                          onChange={(e) => {
                            let val = e.target.value;
                            if (val < 0) {
                              val = 0;
                            } else if (val === null || val === '' || val === undefined) {
                              val = defaultOptionWidth;
                            }
                            handleDropzoneWidth(parseInt(val));
                          }}
                        ></input>
                      </div>
                    </div>
                    <div className='row align-items-center p-1'>
                      <div
                        className='col col-6 col-lg-6 text-right'
                        align='end'
                        data-testid='dd-required'
                      >
                        {label.drop_zone_height}:&nbsp;
                      </div>
                      <div className='col col-6 col-sm-6'>
                        <input
                          min={0}
                          type='number'
                          className='form-control'
                          value={item.item_json.dropzoneHeight || defaultOptionHeight}
                          id='dropzoneHeight'
                          data-testid='dropzoneHeight'
                          onChange={(e) => {
                            let val = e.target.value;
                            if (val < 0) {
                              val = 0;
                            } else if (val === null || val === '' || val === undefined) {
                              val = defaultOptionHeight;
                            }
                            handleDropzoneHeight(parseInt(val));
                          }}
                        ></input>
                      </div>
                    </div>
                  </div>

                  <div className='col col-sm-4 col-lg-4'>
                    <div className='row align-items-center p-1'>
                      <div
                        className='col col-6 col-lg-6 text-right'
                        align='end'
                        data-testid='dd-required'
                      >
                        {label.reusable_response}:&nbsp;
                      </div>
                      <div className='col col-6 col-sm-6'>
                        <input
                          type='checkbox'
                          checked={item.item_json.reusableAnswers}
                          className='form-check-input'
                          id='reusableAnswers'
                          data-testid='reusableAnswers'
                          onChange={(e) => {
                            let val = e.target.checked;
                            handleReusableAnswers(val);
                          }}
                        ></input>
                      </div>
                    </div>
                    <div className='row align-items-center p-1'>
                      <div className='col col-6 col-lg-6 text-right' align='end'>
                        {label.invisible_dropzones}:&nbsp;
                      </div>
                      <div className='col col-6 col-sm-6'>
                        <input
                          type='checkbox'
                          checked={item.item_json.invisibleDropzones}
                          className='form-check-input'
                          id='invisibleDropzones'
                          data-testid='invisibleDropzones'
                          onChange={(e) => {
                            let val = e.target.checked;
                            handleInvisibleDropzones(val);
                          }}
                        ></input>
                      </div>
                    </div>
                  </div>

                  <div className='col col-sm-4 col-lg-4'>
                    <div className='row align-items-center p-1'>
                      <div
                        className='col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end'
                      >
                        <label
                          htmlFor='background_alignment'
                        >
                          {label.background_alignment}:
                        </label>
                      </div>
                      <div className='col'>
                        <select
                          id='background_alignment'
                          className='form-select form-select-sm mx-0'
                          data-testid='imageAlignment'
                          onChange={(e) => {
                            let val = e.target.value;
                            updateItemJson('imageAlignment', val);
                          }}
                          value={item.item_json.imageAlignment}
                        >
                          {imageAlignment().map((alignment, ind) => (
                            <option
                              key={alignment?.id || ind}
                              value={alignment?.id || ''}
                            >
                              {alignment?.name || ''}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </fieldset>
            </div>

            <div
              className='row p-3 pt-0 ps-2 ms-1'
              data-testid='bg-correct-response-container'
            >
              <fieldset className='bg-light p-3 rounded m-1 mx-0'>
                <legend>{label.correct_response}</legend>
                <BgGraphicResponse
                  item={item}
                  stemComponent={null}
                  config={config}
                  showCorrectResponse={true}
                  isPreview={false}
                  onUpdate={onUpdate}
                />
              </fieldset>
            </div>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

BackgroundGraphic.propTypes = itemProps;

export default BackgroundGraphic;
