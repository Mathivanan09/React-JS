import React, { useState } from 'react';

import StemContent from '../shared/StemContent';
import ItemDimensions from '../shared/ItemDimensions';
import AnswerAlignment from '../shared/AnswerAlignment';

import fetch from '../../../utility/default';
import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';

/**
 * React functional component to create Speech Interaction item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace SpeechInteraction
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Speech Interaction item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {SpeechInteraction} SpeechInteraction component for creating Speech Interaction item
 *
 * @example
 * <SpeechInteraction item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'si' },
    user_id: 0,
  }} />
 */
const SpeechInteraction = ({ item, onUpdate, config }) => {

  // All event methods go here and uses dispatch method
  const [showRationale, toggleRationale] = useState(false);

  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  // Event handler for Maximum Attempts Allowed
  const handleMaxAttemptAllowed = (e) => {
    let updatedItem;
    //To handle key in value for the field
    if (e.target.value > fetch('maxNoOfAttempt')) {
      updatedItem = {
        item_json: { maxNumberofAttempts: fetch('maxNoOfAttempt') }
      };
    } else if (e.target.value < fetch('noOfAttempt') || e.target.value === '') {
      updatedItem = {
        item_json: { maxNumberofAttempts: fetch('noOfAttempt') }
      };
    } else {
      updatedItem = {
        item_json: { maxNumberofAttempts: e.target.value }
      };
    }
    onUpdate(updatedItem);
  }

  // Event handler for Maximum Seconds Allowed
  const handleMaxSecondsAllowed = (e) => {
    let updatedItem;
    //To handle key in value for the field
    if (e.target.value > fetch('maxTimeAllowed')) {
      updatedItem = {
        item_json: { maxTimeAllowedForEachAttempt: fetch('maxTimeAllowed') }
      };
    } else if (e.target.value < fetch('minTimeAllowed') || e.target.value === '') {
      updatedItem = {
        item_json: { maxTimeAllowedForEachAttempt: fetch('minTimeAllowed') }
      };
    } else {
      updatedItem = {
        item_json: { maxTimeAllowedForEachAttempt: e.target.value }
      };
    }
    onUpdate(updatedItem);
  }

  const answerAlignments = [
    { id: 'right_vertical_stacked', name: 'Right Side Vertical' },
    { id: 'vertical_stacked', name: 'Stacked Vertical' }
  ];

  // Event handler for getting Response Alignments
  const getResponseAlignment = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Right Side Vertical', 'Stacked Vertical'].map((val, i) => {
        return {
          id: answerAlignments[i].id,
          name: val
        };
      })
    );
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div className='row' data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div className='row' data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className='container-fluid p-0 pe-4'>
            <div className='row'>
              <div className='col-12 col-md-7 col-lg-5'>
                <div className='bg-light rounded p-3 m-0 ps-0 mt-1 mb-2'>
                  <div className='row align-items-center p-1'>
                    <div className='col col-lg-6 text-right'>
                      <label htmlFor='max_number_of_attempts'>{label.attempts_allowed}:</label>
                    </div>
                    <div className='col'>
                      <input type="number"
                        className='form-control'
                        id='max_number_of_attempts'
                        value={item.item_json?.maxNumberofAttempts}
                        onChange={(e) => handleMaxAttemptAllowed(e)}
                        data-testid='si_attemptsAllowed_number'
                        defaultValue={fetch('noOfAttempt')}
                        min={fetch('noOfAttempt')}
                        max={fetch('maxNoOfAttempt')}
                      />
                    </div>
                  </div>
                  <div className='row align-items-center p-1'>
                    <div className='col col-lg-6 text-right'>
                      <label htmlFor='max_time_allowed_for_each_attempt'>{label.seconds_allowed_per_attempt}:</label>
                    </div>
                    <div className='col'>
                      <input type="number"
                        className='form-control'
                        id='max_time_allowed_for_each_attempt'
                        value={item.item_json?.maxTimeAllowedForEachAttempt}
                        onChange={(e) => handleMaxSecondsAllowed(e)}
                        data-testid='si_secondsAllowed_number'
                        defaultValue={fetch('defaultTimeAllowed')}
                        min={fetch('minTimeAllowed')}
                        max={fetch('maxTimeAllowed')}
                      />
                    </div>
                  </div>
                  <AnswerAlignment
                    data={getResponseAlignment()}
                    labelCode='answer_alignment'
                    onUpdate={updateItemJson}
                    updateKey='answerAlignment'
                    isRequired={true}
                    showSelect={true}
                    value={item.item_json?.answerAlignment}
                    dataTestId='response_alignment'
                    firstColumnClass='col col-lg-6 text-right dropdown-label ps-sm-0 ms-sm-0 pe-0'
                  />
                  <div className='row align-items-center p-1'>
                    <div className='col col-lg-6 text-right'>
                      <label htmlFor='enable_retain_all_attempts'>{label.retain_all_attempts}:</label>
                    </div>
                    <div className='col'>
                      <input
                        type='checkbox'
                        name='retainAttempt'
                        id='enable_retain_all_attempts'
                        className='form-check-input'
                        data-testid='st_checkbox'
                        value={item.item_json?.retainAttempts}
                        checked={item?.item_json?.retainAttempts || false}
                        onChange={(e) => {
                          updateItemJson('retainAttempts', e?.target?.checked);
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className='col-12 col-md-5 col-lg-7 rationale-container' data-testid='rationale-container'>
                <div className='bg-light rounded p-3 mt-1'>
                  <div className='row'>
                    <div className='col-12 col-lg-2 text-lg-center pb-1'>
                      <button
                        type='button'
                        className='btn btn-primary btn-sm'
                        data-testid='rationale-button'
                        onClick={() => toggleRationale(!showRationale)}
                      >
                        {label.rationale}
                      </button>
                    </div>
                    <div className='col rationale' data-testid='rationale'>
                      {showRationale &&
                        <CKEditorBase
                          type='inline'
                          dataTestId='rationale-text'
                          data={item?.rationale?.rationaleText || ''}
                          onChange={
                            /* istanbul ignore next */
                            (data) => {
                              onUpdate({
                                ...item,
                                rationale: {
                                  ...item?.rationale,
                                  'rationaleText': data
                                }
                              });
                            }
                          }
                          placeholder={label.enter_rationale_content}
                          config={{ removePlugins: ['TagAccessibility'] }}
                        />
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

SpeechInteraction.propTypes = itemProps;

export default SpeechInteraction;