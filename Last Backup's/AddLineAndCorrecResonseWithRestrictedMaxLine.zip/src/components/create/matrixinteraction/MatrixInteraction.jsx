import React, { useState } from 'react';
import uuid from 'react-uuid';

import StemContent from '../shared/StemContent';
import ItemDimensions from '../shared/ItemDimensions';

import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';

import ReorderItems from '../shared/ReorderItems';
import AnswerAlignment from '../shared/AnswerAlignment';
import MatrixInteractionResponse from '../../display/response/matrixinteraction/MatrixInteractionResponse';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/MatrixInteraction.css';

const DIR_UP = -1;
const DIR_DOWN = 1;

/**
 * React functional component to create Matrix Interaction item
 *
 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace MatrixInteraction
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Matrix Interaction item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {MatrixInteraction} MatrixInteraction component for creating Matrix Interaction item
 * 
 * @example
 * <MatrixInteraction item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'mcrb' },
    user_id: 0,
  }} />
 */
const MatrixInteraction = ({ item, onUpdate, config }) => {

  const [showRationale, setShowRationale] = useState(false);
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  const responseAlignment = () => {
    const values = ["Left", "Right", "Center"].map((val) => {
      return {
        id: val,
        name: val
      };
    });
    return values;
  };

  const responseLayout = () => {
    const values = ["vertical", "horizontal"].map((val) => {
      return {
        id: val,
        name: val[0].toUpperCase() + val.slice(1)
      };
    });
    return [{ id: null, name: 'Select' }, ...values];
  };

  // Adds a new option to the option list
  const addLeftOption = () => {
    const optionId = uuid(); //New UUID will be generated and assigned to each response

    const addedOption = [
      ...(item.item_json?.optionList || []),
      { optionText: '', index: item.item_json?.optionList?.length - 1 || 0, id: optionId }
    ];

    const updatedCorrectResponses = [
      ...(item.item_json?.correctResponse || []),
      { id: optionId, values: [] },
    ];

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: addedOption,
        correctResponse: updatedCorrectResponses,
      }
    };
    onUpdate(updatedItem);
  };

  // Adds a new option to the option list
  const addRightOption = () => {
    const optionId = uuid(); //New UUID will be generated and assigned to each response

    const addedOption = [
      ...(item.item_json?.matchList || []),
      { optionText: '', index: item.item_json?.matchList?.length - 1 || 0, id: optionId }
    ];

    // prepare the payload
    const updatedItem = {
      item_json: {
        matchList: addedOption,
      }
    };
    onUpdate(updatedItem);
  };

  // Event handler for adding left option data
  /* istanbul ignore next */
  const handleLeftOptionChange = (data, index, id) => {
    const newOptList = [...(item.item_json?.optionList || [])];
    newOptList[index] = { ...newOptList[index], id: id, index: index, optionText: data };

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: newOptList
      }
    };
    onUpdate(updatedItem);
  };

  // Event handler for adding left option data
  /* istanbul ignore next */
  const handleRighttOptionChange = (data, index, id) => {
    const newOptList = [...item.item_json.matchList];
    newOptList[index] = { ...newOptList[index], id: id, index: index, optionText: data };

    // prepare the payload
    const updatedItem = {
      item_json: {
        matchList: newOptList
      }
    };
    onUpdate(updatedItem);
  };



  //Move items up or down using arrow keys.
  const reorderLeftItems = (id, counter) => {
    const itemIndex = item.item_json?.optionList?.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === item.item_json?.optionList?.length - 1)
    ) {
      return; // canot move outside of array
    }

    //Reorder the optionList
    const optionItem = item.item_json?.optionList?.[itemIndex];
    const updatedLeftOptionItems = item.item_json?.optionList?.filter(
      (i) => i.id !== id
    ) || [];
    updatedLeftOptionItems.splice(itemIndex + counter, 0, optionItem);

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: updatedLeftOptionItems
      }
    };
    onUpdate(updatedItem);
  };

  //Move items up or down using arrow keys.
  const reorderRightItems = (id, counter) => {
    const itemIndex = item.item_json?.matchList.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === item.item_json?.matchList.length - 1)
    ) {
      return; // canot move outside of array
    }
    //Reorder the matchList
    const optionItem = item.item_json?.matchList[itemIndex];
    const updatedRightOptionItems = item.item_json?.matchList?.filter(
      (i) => i.id !== id
    ) || [];
    updatedRightOptionItems.splice(itemIndex + counter, 0, optionItem);
    // prepare the payload
    const updatedItem = {
      item_json: {
        matchList: updatedRightOptionItems
      }
    };
    onUpdate(updatedItem);
  };

  //Remove the Left item
  const removeLeftOption = (id) => {
    //Remove from optionList
    let optionList = item.item_json?.optionList?.filter(
      (element) => element.id !== id
    ) || [];

    // Remove from correctResponse
    const correctResponse = item.item_json?.correctResponse?.filter(response =>
      response.id !== id
    );

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: optionList,
        correctResponse,
      }
    };
    onUpdate(updatedItem);
  };

  //Remove the Left item
  const removeRightOption = (id) => {
    //Remove from matchList
    let optionList = item.item_json?.matchList?.filter(
      (element) => element.id !== id
    ) || [];

    //Remove from correctResponse
    const correctResponse = [...(item.item_json?.correctResponse || [])];
    correctResponse.forEach(response => {
      response.values = response.values.filter(matchId => matchId !== id);
    });

    // prepare the payload
    const updatedItem = {
      item_json: {
        matchList: optionList,
        correctResponse,
      }
    };

    onUpdate(updatedItem);
  };


  const handleLeftColWidthChange = (value) => {
    updateItemJson("leftColWidth", value);
  };

  const handleMaintainLeftColWidth = (value) => {
    updateItemJson("maintainLeftColWidth", value);
  };

  const isMultipleChoiceEnable = (value) => {
    let newItemJson = JSON.parse(JSON.stringify(item.item_json));
    newItemJson.multipleChoice = value;
    if (!value) { // Clear responses for each option in optionList when switching to single
      newItemJson.correctResponse.forEach(response => {
        response.values = [];
      });
    }
    onUpdate({ item_json: newItemJson });
  };

  const handleRationaleChange = (value) => {
    updateItemJson("rationale", value);
  };

  const handleHeaderChange = (value) => {
    updateItemJson("header", value);
  };

  // Toggles the rationale text box
  const showHideRationale = () => {
    setShowRationale(!showRationale);
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className='row' data-testid='label-container'>
            <div className='col col-12 col-sm-7'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className='row'>
                  <div className='col-sm-6'>
                    <legend>{label.response_options}</legend>
                  </div>
                </div>
                <div className='row'>
                  <div className='col border border-dark rounded m-10'>
                    <div className='row'>
                      <div className='col mcrb-select-container'>Row</div>
                      <div className='col text-end text-right mcrb-select-container'>
                        <button
                          data-testid='matrix-addleftoption'
                          className='btn btn-primary btn-sm m-2'
                          icon='add'
                          onClick={(e) => {
                            e.preventDefault();
                            addLeftOption();
                          }}
                        >
                          + Add
                        </button>
                      </div>
                    </div>
                    <div className='row'>
                      <div
              
                        className='col col-6 col-md-4 col-lg-2 text-end text-right mcrb-select-container'
                      >
                        {label.enter_table_header}
                      </div>
                      <div
                        className='col mcrb-item-box m-2'
                        data-testid='matrix-head'
                      >
                        <CKEditorBase
                          type='inline'
                          data={item.item_json?.header}
                          className='content_style'
                          onChange={
                            /* istanbul ignore next */
                            (data) => {
                              handleHeaderChange(data);
                            }
                          }
                          placeholder={label.enter_table_header}
                        />
                      </div>
                    </div>
                    {item.item_json?.optionList?.map((option, index) => (
                      <div className='row option align-items-center p-2'>
                        <div
                          className='col col-6 col-md-4 col-lg-2 text-end text-right mcrb-select-container'
                        >
                          <ReorderItems
                            listLength={item.item_json?.optionList?.length}
                            option={index}
                            onDownClick={() =>
                              reorderLeftItems(option.id, DIR_DOWN)
                            }
                            onUpClick={() =>
                              reorderLeftItems(option.id, DIR_UP)
                            }
                          />
                        </div>
                        <div className='col mcrb-item-box'>
                          <CKEditorBase
                            type='inline'
                            data={item.item_json?.optionList?.[index]?.optionText}
                            className='content_style'
                            onChange={
                              /* istanbul ignore next */
                              (data) => {
                                handleLeftOptionChange(data, index, option.id);
                              }
                            }
                            placeholder={label.enter_response_content}
                          />
                        </div>
                        <div className='col col-1'>
                          <button
                            key={index}
                            className='icon'
                            onClick={(e) => {
                              e.preventDefault();
                              removeLeftOption(option.id);
                            }}
                            data-testid='leftoption-remove-button'
                          >
                            <span className='icon-minus'>-</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className='col border border-dark rounded m-10'>
                    <div className='row'>
                      <div className='col mcrb-select-container'>Column</div>
                      <div className='col text-end text-right mcrb-select-container'>
                        <button
                          data-testid='matrix-addrightoption'
                          className='btn btn-primary btn-sm m-2'
                          icon='add'
                          onClick={(e) => {
                            e.preventDefault();
                            addRightOption();
                          }}
                        >
                          + Add
                        </button>
                      </div>
                    </div>
                    {item.item_json?.matchList?.map((option, index) => (
                      <div className='row option align-items-center p-2'>
                        <div
                          className='col col-6 col-md-4 col-lg-2 text-end text-right mc-select-container'
                        >
                          <ReorderItems
                            listLength={item.item_json?.matchList?.length}
                            option={index}
                            onDownClick={() =>
                              reorderRightItems(option.id, DIR_DOWN)
                            }
                            onUpClick={() =>
                              reorderRightItems(option.id, DIR_UP)
                            }
                          />
                        </div>
                        <div className='col mcrb-item-box'>
                          <CKEditorBase
                            type='inline'
                            data={item.item_json?.matchList[index]?.optionText}
                            className='content_style'
                            onChange={
                              /* istanbul ignore next */
                              (data) => {
                                handleRighttOptionChange(
                                  data,
                                  index,
                                  option.id
                                );
                              }
                            }
                            placeholder={label.enter_response_content}
                          />
                        </div>
                        <div className='col col-1'>
                          <button
                            key={index}
                            className='btn icon'
                            onClick={(e) => {
                              e.preventDefault();
                              removeRightOption(option.id);
                            }}
                            data-testid='leftoption-remove-button'
                          >
                            <span className='icon-minus'>-</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </fieldset>
            </div>
            <div className='col col-12 col-sm-5'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <button
                  className='btn btn-primary btn-sm m-2'
                  onClick={() => showHideRationale()}
                  data-testid='rationale-button'
                >
                  {label.rationale}
                </button>
                {showRationale && (
                  <div className='mt-2'>
                    <CKEditorBase
                      type='inline'
                      data={item.item_json?.rationale}
                      className='content_style'
                      onChange={
                        /* istanbul ignore next */
                        (data) => {
                          handleRationaleChange(data);
                        }
                      }
                      placeholder={label.enter_rationale_content}
                      config={{ removePlugins: ['TagAccessibility'] }}
                    />
                  </div>
                )}
              </fieldset>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div data-testid='shuffle_selection'>
                  <legend className='pt-1'>
                    {label.multiple_choice_shuffle_option}
                  </legend>
                  <div className='form-check-inline'>
                    <div className='hstack gap-2'>
                      <input
                        type='radio'
                        className='form-check-input'
                        name='multiple_choice_shuffle'
                        id='multiple_choice_yes_shuffle'
                        checked={item?.item_json?.shuffle || false}
                        data-testid='multiple_choice_yes_shuffle'
                        onChange={() => {
                          updateItemJson('shuffle', true);
                        }}
                      />
                      <label
                        htmlFor='multiple_choice_yes_shuffle'
                        className='form-check-label'
                      >
                        {label.yes}
                      </label>
                    </div>
                  </div>
                  <div className='form-check-inline'>
                    <div className='hstack gap-2'>
                      <input
                        type='radio'
                        className='form-check-input'
                        name='multiple_choice_shuffle'
                        id='multiple_choice_no_shuffle'
                        checked={!item?.item_json?.shuffle || false}
                        data-testid='multiple_choice_no_shuffle'
                        onChange={() => {
                          updateItemJson('shuffle', false);
                        }}
                      />
                      <label
                        htmlFor='multiple_choice_no_shuffle'
                        className='form-check-label'
                      >
                        {label.no}
                      </label>
                    </div>
                  </div>
                </div>
              </fieldset>
              <fieldset className='bg-light p-3 rounded m-1'>
                <legend>{label.configuration}</legend>
                <div className='row align-items-center p-1'>
                  <div
                    className='col col-12 col-lg-6 text-right'
                    align='end'
                    data-testid='dd-required'
                  >
                    Multiple Select&nbsp;:&nbsp;
                  </div>
                  <div className='col col-12 col-sm-6'>
                    <input
                      type='checkbox'
                      checked={item.item_json.multipleChoice}
                      className='form-check-input'
                      id='matrix-multiple-choice'
                      data-testid='matrix-multiple-choice'
                      onChange={(e) => {
                        let val = e.target.checked;

                        isMultipleChoiceEnable(val);
                      }}
                    ></input>
                  </div>
                </div>
                <div className='row align-items-center p-1'>
                  <div
                    className='col col-12 col-lg-6 text-right'
                    align='end'
                    data-testid='dd-required'
                  >
                    Left Column Width (in %)&nbsp;:&nbsp;
                  </div>
                  <div className='col col-12 col-sm-6'>
                    <input
                      min={0}
                      max={80}
                      onBlur={(e) => {
                        let val = e.target.value;
                        if (val > 80) {
                          val = 80;
                        }
                        if (val < 0) {
                          val = 0;
                        }
                        handleLeftColWidthChange(val);
                      }}
                      type='number'
                      className='form-control'
                      value={item.item_json.leftColWidth}
                      id='left-col-width'
                      data-testid='left-col-width'
                      onChange={(e) => {
                        let val = e.target.value;
                        handleLeftColWidthChange(val);
                      }}
                    ></input>
                  </div>
                </div>
                <div className='row align-items-center p-1'>
                  <div
                    className='col col-12 col-lg-6 text-right'
                    align='end'
                    data-testid='dd-required'
                  >
                    Maintain Left column Width in Split Screen View
                    Mode&nbsp;:&nbsp;
                  </div>
                  <div className='col col-12 col-sm-6'>
                    <input
                      type='checkbox'
                      checked={item.item_json.maintainLeftColWidth}
                      className='form-check-input'
                      id='maintainLeftColWidth'
                      data-testid='maintainLeftColWidth'
                      onChange={(e) => {
                        let val = e.target.checked;
                        handleMaintainLeftColWidth(val);
                        // onUpdate('maintainLeftColWidth', val);
                      }}
                    ></input>
                  </div>
                </div>
                <AnswerAlignment
                  data={responseAlignment()}
                  labelCode='answer_alignment'
                  onUpdate={updateItemJson}
                  updateKey='alignmentValue'
                  isRequired={false}
                  showSelect={true}
                  value={item.item_json.alignmentValue}
                />
                <div className='row align-items-center p-1'>
                  <div
                    className='col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end'
                    data-testid='dd-required'
                  >
                    <label htmlFor='response_layout'>{label.response_layout}:</label>
                  </div>
                  <div className='col'>
                    <select
                      id='response_layout'
                      value={item.item_json.responseLayout}
                      className='form-select form-select-sm mx-0'
                      onChange={(e) => {
                        updateItemJson('responseLayout', e.target.value);
                      }}
                    >
                      {
                        responseLayout().map((layout, ind) => (
                          <option
                            key={layout?.id || ind}
                            value={layout?.id || ''}
                          >
                            {layout?.name}
                          </option>
                        ))
                      }
                    </select>
                  </div>
                </div>
              </fieldset>
            </div>
          </div>

          <div className='row p-3' data-testid='mc-correct-response-container'>
            <fieldset className='bg-light p-3 rounded m-1'>
              <legend>{label.correct_response}</legend>
              <MatrixInteractionResponse
                item={item}
                config={config}
                isPreview={false}
                onUpdate={onUpdate}
              />
            </fieldset>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

MatrixInteraction.propTypes = itemProps;

export default MatrixInteraction;
