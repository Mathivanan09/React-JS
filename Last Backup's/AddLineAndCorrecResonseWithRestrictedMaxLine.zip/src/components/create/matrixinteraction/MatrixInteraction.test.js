import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import MatrixInteraction from './MatrixInteraction';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <MatrixInteraction />, container);
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the 
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <MatrixInteraction item={{
                    item_json: {
                        itemTypeCode: 'MCRB'
                    }
                }
                } />, container);
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=container]");
        expect(component).not.toBeNull;
        // expect(component.children.length).toBe(4);

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=container]")).not.toBeNull;
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
    });

    it('The User will be able to set Item dimensions for the item in item dimensions field', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'MCRB',
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <MatrixInteraction item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull;
        expect(minItemHeightInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(<Provider store={store}>
                <MatrixInteraction item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(<Provider store={store}>
                <MatrixInteraction item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

    it("The User will be able enter content in stem", () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'MCRB',
                stemContent: "stem content",
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };
        act(() => {
            render(
                <MatrixInteraction item={item} />, container);
        });

        expect(document.querySelector('[dataTestId=stem-content-editor]')).not.toBeNull;

    });

    it("The User will be able enter content in stem", () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'MCRB',
                stemContent: "stem content",
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };
        act(() => {
            render(
                <MatrixInteraction item={item} />, container);
        });

        expect(document.querySelector("[data-testid=matrix-head]")).not.toBeNull;

    });


    it('Test add Left option event handle', () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'MCRB',
                stemContent: "stem content",
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
          item = {
            ...item,
            ...payload,
            item_json: { ...item.item_json, ...payload.item_json }
          };
        });
    
        const store = mockStore({});
        const { rerender } = render(
          <Provider store={store}>
            <MatrixInteraction item={item} onUpdate={updateItem} />
          </Provider>
        );
      
        // Verify add option button exists
        const addLeftOption = screen.getByTestId('matrix-addleftoption');
        expect(addLeftOption).not.toBeNull;
    
        // Fire event 'add option' then update the component
        fireEvent.click(addLeftOption);
        act(() => {
          rerender(<Provider store={store}>
            <MatrixInteraction item={item} onUpdate={updateItem} />
          </Provider>);
        });
    
        // Expected new option in list of left options
        expect(updateItem).toHaveBeenCalledTimes(1);
      });

      it('Test add Right option event handle', () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'MCRB',
                stemContent: "stem content",
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
          item = {
            ...item,
            ...payload,
            item_json: { ...item.item_json, ...payload.item_json }
          };
        });
    
        const store = mockStore({});
        const { rerender } = render(
          <Provider store={store}>
            <MatrixInteraction item={item} onUpdate={updateItem} />
          </Provider>
        );
      
        // Verify add option button exists
        const addRightOption = screen.getByTestId('matrix-addrightoption');
        expect(addRightOption).not.toBeNull;
    
        // Fire event 'add option' then update the component
        fireEvent.click(addRightOption);
        act(() => {
          rerender(<Provider store={store}>
            <MatrixInteraction item={item} onUpdate={updateItem} />
          </Provider>);
        });
    
        // Expected new option in list of left options
        expect(updateItem).toHaveBeenCalledTimes(1);
      });



    //it.todo("The User will be able enter content in stem")

    it.todo("User can add see the Row header ckeditor box always in the Row area of Response Option");

    it.todo("User can add the Row by clicking on plus icon in the row area, when the click on the icon ckeditor will be added for the new row");

    it.todo("The number of rows created the same number will be populated in correct response");

    it.todo("The User can swap the positions of row boxes by clicking on up and down arrows near the boxes. Also, can be able to remove the row if User wants to, by clicking on remove icon");

    it.todo("User can add the Column by clicking on plus icon in the column area, when the click on the icon ckeditor will be added for the new column");

    it.todo("The number of column created the same number will be populated in correct response");

    it.todo("The User can swap the positions of column boxes by clicking on up and down arrows near the boxes. Also, can be able to remove the column if User wants to, by clicking on remove icon");

    it.todo("The User can change alignment of correct response boxes by selection of Response Alignmentin Left / Right/Center");

    it.todo("The User also can change the response selection as multiple for each row by clicking on the Multiple Select checkbox in the configuration");

    it.todo("When the Multiple Select is checked user can see the response selection as a checkbox in the correct response area instead of radio button");

    it.todo("User should be able to select more than one option when the checkbox are enabled in the correct response area");

    it.todo("User can add the Rationale content by clicking on the Rationale button, while clicking on this ckeditor box will be open for entering the content");

    it.todo("User can also choose the Shuffle option by selecting the radio button Yes / No under the shuffle option, these same changes will reflect in preview window also");

    it.todo("User also can enable the Maintain Left Column Width in Split screen View Mode option by clicking the checkbox under the configuration");

    it.todo("User can provide the Left Colum Width in the numeric text box under the configuration");

    it.todo("User can view the row and column as the table format in the correct response area with radio / checkbox based on the configuration, these same changes can also view in preview window");

    it.todo("The User can change align of response group and question layout correct response boxes by providing selection of response group layout ");

    it.todo("The User will be able to check and uncheck the radio / checkbox in the correct response");

})