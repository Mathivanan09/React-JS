import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import { fireEvent } from '@testing-library/react';
import DropDown from './DropDown';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("Testing the component without props", () => {
  act(() => {
    render(<DropDown />, container);
  });

  // get a hold of the select element, and trigger change on it with a value
  const select = document.querySelector("[data-testid=dd-select]");
  expect(select.children.length).not.toBeNull;
});

it("Testing the component with data prop", () => {
  act(() => {
    render(<DropDown data={[
      { id: 'YES', name: 'Yes' },
      { id: 'NO', name: 'No' }
    ]} />, container);
  });

  // get a hold of the select element, and trigger change on it with a value
  const select = document.querySelector("[data-testid=dd-select]");
  expect(select.children.length).toBe(2);
});

it("Testing with showSelect prop as true", () => {
  act(() => {
    render(<DropDown data={[
      { id: 'YES', name: 'Yes' }
    ]} showSelect={true} />, container);
  });

  // get a hold of the select element, and trigger change on it with a value
  const select = document.querySelector("[data-testid=dd-select]");
  expect(select.children.length).toBe(2);
});

it("Testing with showSelect prop as false", () => {
  act(() => {
    render(<DropDown data={[
      { id: 'YES', name: 'Yes' }
    ]} showSelect={false} />, container);
  });

  // get a hold of the select element, and trigger change on it with a value
  const select = document.querySelector("[data-testid=dd-select]");
  expect(select.children.length).toBe(1);
});

it("Testing with isRequired prop as true", () => {
  act(() => {
    render(<DropDown data={[
      { id: 'YES', name: 'Yes' },
      { id: 'NO', name: 'No' }
    ]}
      showSelect={true}
      isRequired={true}
      updateKey={'keyToUpdate'}
      onUpdate={() => {
        setSelectedAlignment()
      }}
    />, container);

    // get a hold of the select element, and trigger change on it with a value
    const select = document.querySelector("[data-testid=dd-select]");
    expect(select.children.length).toBe(3);
    expect(select.value).toBe('Select');
    expect(select.required).toBeTruthy;

    const required = document.querySelector("[data-testid=dd-required]");
    expect(required.classList.contains('label-mandatory-field')).toBeTruthy;
  });
});


it("Testing onChange event", () => {
  let selectedAlignment = '';
  let keyToUpdate = '';
  const setSelectedAlignment = jest.fn().mockImplementation((updateKey, value) => {
    keyToUpdate = updateKey;
    selectedAlignment = value;
  });

  act(() => {
    render(
      <DropDown data={[
        { id: 'YES', name: 'Yes' },
        { id: 'NO', name: 'No' }
      ]}
        showSelect={true}
        isRequired={true}
        updateKey={'keyToUpdate'}
        onUpdate={setSelectedAlignment}
      />, container);
  });

  expect(keyToUpdate).toBe('');

  // get a hold of the select element, and trigger change on it with a value
  const select = document.querySelector("[data-testid=dd-select]");
  expect(select.children.length).toBe(3);
  expect(select.value).toBe('Select');

  // Updating value
  fireEvent.change(select, { target: { value: 'YES' } })
  expect(select.value).toBe('YES');
  expect(keyToUpdate).toBe('keyToUpdate');
  expect(selectedAlignment).toBe('YES');
  expect(setSelectedAlignment).toBeCalledTimes(1);

  // Updating value again 
  fireEvent.change(select, { target: { value: 'NO' } })
  expect(select.value).toBe('NO');
  expect(keyToUpdate).toBe('keyToUpdate');
  expect(selectedAlignment).toBe('NO');
  expect(setSelectedAlignment).toBeCalledTimes(2);
});


it("Testing value prop", () => {

  act(() => {
    render(
      <DropDown data={[
        { id: 'YES', name: 'Yes' },
        { id: 'NO', name: 'No' }
      ]}
        showSelect={true}
        isRequired={true}
        updateKey={'keyToUpdate'}
        value={'YES'}
      />, container);
  });

  // get a hold of the select element, and trigger change on it with a value
  const select = document.querySelector("[data-testid=dd-select]");
  expect(select.children.length).toBe(3);
  expect(select.value).toBe('YES');
});