import uuid from 'react-uuid';

/**
 * Main tab, and sub tab template for the two column click item
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @function
 * @namespace template
 *
 * @param {boolean} main - to generate template for the main tab or sub tab
 * @return {object} - generate template for the main tab or sub tab for TwoColumnClick
 */
const template = (main, ind) => {
    let obj;
    if (main) {
        const tab = {
            header: '',
            id: uuid(),
            index: ind,
            items: []
        };
        obj = tab;
    } else {
        const subTab = {
            id: uuid(),
            left: '',
            right: ''
        };
        obj = subTab;
    }
    return obj;
};

/**
 * add main tab/sub tab to the item
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @function
 * @namespace addTab
 *
 * @param {array} items - sub tab data
 * @param {number} columnNumber - column type value
 * @return {array} - added data of the main tab/sub tab
 */
export const addTab = (items = [], columnNumber) => {
    if (columnNumber !== undefined) {
        const tab = template(true, items.length);
        if (tab.items.length === 0) {
            addSubTab(tab.items);
        }
        items.push(tab);
        return [...items];
    }
};

/**
 * add sub tab to the item
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @function
 * @namespace addSubTab
 *
 * @param {array} main - sub tab data
 * @return {array} - added data of the sub tab
 */
const addSubTab = (items = []) => {
    const subTab = template(false, items.length);
    items.push(subTab);
    return [...items];
};

/**
 * remove main tab/sub tab based on the index of the item
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @function
 * @namespace removeItem
 *
 * @param {array} items - main tab/sub tab data
 * @param {number} index - index of the data that need to be removed
 * @param {boolean} correct - data index correction required when removed
 * @return {array} - removed data of the main tab/sub tab
 */
const removeItem = (items = [], index, correct) => {
    let data = items;
    if (items.length > 0 && index !== -1) {
        data = [...items.slice(0, index), ...items.slice(index + 1)];
    }
    if (correct) {
        data = [...data.map((data, index) => { return { ...data, 'index': index } })];
    }
    return [...data];
};

/**
 * update the items (tab/sub-tab) based on the index of the item, and/or key/value
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @function
 * @namespace updateItems
 *
 * @param {array} items - main tab/sub tab data
 * @param {number} idx - index of the data that need to be removed
 * @param {string} key - key of the object that needs to be updated in the data
 * @param {string} value - value of the object that needs to be updated in the data
 * @return {array} - updated item data
 */
const updateItems = (items, idx, key, value) => {
    let newItems = [];
    if (key) {
        const start = items.slice(0, idx);
        let end = items.slice(idx + 1);
        const newObj = { ...items[idx] };
        newItems = [...start, { ...newObj, [key]: value }, ...end];
    } else {
        newItems = [...items, ...addSubTab([])]
    }

    return [...newItems];
};

/**
* update the main-tab data modification and/or removal of tab data with onUpdate
*
* @inner
* @memberof TwoColumnClick
*
* @function
* @namespace onUpdateTab
*
* @param {array} tabs - main tab data
* @param {number} idx - index of the main tab that need to be updated
* @param {string} key - key of the object that needs to be updated in the data
* @param {string} value - value of the object that needs to be updated in the data
* @param {boolean} isRemove - is tab removed
* @return {array} - updated item data for store
*/
const onUpdateTab = (tabs, idx, key, value, isRemove) => {
    let newItems = [...(tabs || [])];

    if (key) {
        newItems = updateItems(newItems, idx, key, value);
    } else if (isRemove) {
        newItems = removeItem(newItems, idx, true);
    }

    return newItems;
};

/**
* update the sub-tab data modification and/or add/removal of tab data with onUpdate
*
* @inner
* @memberof TwoColumnClick
*
* @function
* @namespace onUpdateSubTab
*
* @param {array} tabs - sub tab data
* @param {number} idx - index of the main tab that currently focused on
* @param {string} key - key of the object that needs to be updated in the data
* @param {string} value - value of the object that needs to be updated in the data
* @param {number} subIdx - index of the sub-tab that need to be updated
* @param {boolean} isRemove - is tab removed
* @return {array} - updated item data for store
*/
const onUpdateSubTab = (tabs, idx, key, value, subIdx, isRemove) => {
    let newItems = [...(tabs || {})];
    let subTabs = newItems[idx]?.items || [];
    let newSubItems = [...subTabs];

    if (isRemove) {
        newSubItems = removeItem(subTabs, subIdx, false);
    } else {
        newSubItems = updateItems(subTabs, subIdx, key, value);
    }

    newItems = [
        ...tabs.slice(0, idx),
        {
            ...tabs[idx],
            items: [...newSubItems]
        },
        ...tabs.slice(idx + 1)
    ];

    return newItems;
};

/**
* Tab Component data change handler
*
* @inner
* @memberof TwoColumnClick
*
* @function
* @namespace onUpdateSubTab
*
* @param {array} tabs - sub tab data
* @param {number} idx - index of the main tab that currently focused on
* @param {string} key - key of the object that needs to be updated in the data
* @param {string} value - value of the object that needs to be updated in the data
* @param {number} subIdx - index of the sub-tab that confirms the sub-tab needs to be updated, instead of main tab
* @param {boolean} isRemove - is tab removed
* @return {array} - updated item data of the Tab Component
*/
export const tabHandler = (tabs, idx, key, value, subIdx, isRemove) => {
    if (typeof subIdx === 'number') {
        return onUpdateSubTab(tabs, idx, key, value, subIdx, isRemove);
    } else if (typeof idx === 'number') {
        return onUpdateTab(tabs, idx, key, value, isRemove);
    }
}