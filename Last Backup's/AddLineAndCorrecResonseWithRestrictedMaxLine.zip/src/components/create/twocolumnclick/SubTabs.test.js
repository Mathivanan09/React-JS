/**
 * @file SubTabs - Two Column Click Simulation Item Creation Component Test
 */
import React from 'react';
import { act } from 'react-dom/test-utils';
import { unmountComponentAtNode } from 'react-dom';
import { render, screen } from '@testing-library/react';

// import component here
import SubTabs from './SubTabs';

let container = null;

// set up dummy test mock onUpdate function
let content = {};
let item = {};
const onUpdate = jest.fn((key, value) => {
    if (item[key] !== undefined) {
        item[key] = value;
    }
});

beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement('div');
    document.body.appendChild(container);
    item = {};
    content = {
        id: '2307b70-a8ca-35c6-c5e6-14c13b3ba',
        left: '<p>Menu 1</p>',
        right: '<p>option 1</p>'
    };
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
    content = {}
    item = {};
});

describe('SubTabs - Two Column Click Simulation Item Creation Component Test', () => {

    test('Testing SubTabs with empty/invalid item data', () => {
        // set up test mock data 
        item = null;
        let id = null;
        const index = null;
        const subIndex = null;
        const columnNumber = null;

        act(() => {
            render(
                <SubTabs
                    id={id}
                    index={index}
                    item={item}
                    onUpdate={onUpdate}
                    subIndex={subIndex}
                    columnNumber={columnNumber}
                />,
                container
            )
        });

        // check the component how it is handling the invalid data
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-]')?.length).toBe(0);
        expect(document.querySelectorAll('[data-testid^=tcc-tab-editor-col-]')?.length).toBe(0);

    });

    test('Testing SubTabs For Two Column Type with Valid Item Data', () => {
        // set up test mock data 
        let id;
        const index = 0;
        const subIndex = 0;
        const columnNumber = 2;
        ({ id, ...item } = { ...content });

        // loading the sub-tab with appropriate data for two column
        act(() => {
            render(
                <SubTabs
                    id={id}
                    index={index}
                    item={item}
                    onUpdate={onUpdate}
                    subIndex={subIndex}
                    columnNumber={columnNumber}
                />
            );
        });

        // check the tab container exists with appropriate structure for two column type or not
        expect(screen.getByTestId('tcc-sub-tab-row-1-col-1-0')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-row-1-col-1-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-editor-col-a')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-editor-col-b')).toBeInTheDocument();

    });

    test('Testing SubTabs For Three Column Type with Valid Item Data', () => {
        // set up test mock data 
        let id;
        const index = 1;
        const subIndex = 1;
        const columnNumber = 3;
        ({ id, ...item } = { ...content });

        // loading the sub-tab with appropriate data for three column
        act(() => {
            render(
                <SubTabs
                    id={id}
                    index={index}
                    item={item}
                    onUpdate={onUpdate}
                    subIndex={subIndex}
                    columnNumber={columnNumber}
                />
            )
        });

        // check the tab container exists with appropriate structure or not for three column type
        expect(screen.getByTestId('tcc-sub-tab-row-2-col-2-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-row-2-col-2-2')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-editor-col-b')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-editor-col-c')).toBeInTheDocument();

    });

});