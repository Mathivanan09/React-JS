import React from 'react';
import PropTypes from 'prop-types';
import label from '../../../constants/labelCodes';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';

const placeholder = label.two_column_click_tab_placeholder + ' ';

// get placeholder that represent each column/tab name
const columnName = (index) => {
  const charCode = index + 1 + 64;
  return `${placeholder}${String.fromCharCode(charCode)}`;
};

/**
 * React functional component is to customized Editor
 * for each main tab and sub tab
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @namespace Editor
 *
 * @param {string} id - unique id of the respective tab
 * @param {html} data - html/text data of the respective tab
 * @param {number} index - index of the respective tab
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the items/data
 * @return {component} - Editor for each Tab with the appropriate placeholder
 */
const Editor = ({ id, data, index, onUpdate }) => {
  let placeholderName = null;
  let testName = '';
  if (index != undefined) {
    const column = index + 1;
    placeholderName = columnName(column);
    testName = '-' + placeholderName?.replace(placeholder, '')?.toLowerCase();
  }

  return (
    <CKEditorBase
      data={data}
      type='inline'
      fieldName={id}
      id={id + '-' + index}
      key={id + '-' + index}
      className='content_style'
      placeholder={placeholderName}
      dataTestId={'tcc-tab-editor-col' + testName}
      onChange={(value) => {
        onUpdate(value);
      }}
    />
  );
};

Editor.propTypes = {
  id: PropTypes.string,
  data: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.elementType
  ]),
  index: PropTypes.number,
  onUpdate: PropTypes.func
};

export default Editor;
