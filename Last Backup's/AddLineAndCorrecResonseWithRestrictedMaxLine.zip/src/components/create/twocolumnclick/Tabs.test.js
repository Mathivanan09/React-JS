/**
 * @file Tabs - Two Column Click Simulation Item Creation Component Test
 */
import React from 'react';
import { act } from 'react-dom/test-utils';
import { unmountComponentAtNode } from 'react-dom';
import { render, screen, fireEvent } from '@testing-library/react';

import { tabHandler } from './template.js';
import TWO_COLUMN_DATA from '../../../stories/assets/tcc/tcc_two_column.json';
import THREE_COLUMN_DATA from '../../../stories/assets/tcc/tcc_three_column.json';

// import component here
import Tabs from './Tabs';

let container = null;

beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement('div');
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('Tabs - Two Column Click Simulation Item Creation Component Test', () => {

    test('Testing Tabs with empty/invalid item data', () => {
        // set up test mock data 
        let content = undefined;
        const columnNumber = null;

        // set up test mock onUpdate function
        const onUpdate = jest.fn((...data) => {
            if (data !== undefined) {
                content = tabHandler(content, ...data);
            }
        });

        act(() => {
            render(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            )
        });

        // check the component how it is handling the invalid data
        expect(screen.getByTestId('tcc-all-tabs-container')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tabs-container-]')?.length).toBe(0);
        expect(document.querySelectorAll('[data-testid^=tcc-tab-remove-]')?.length).toBe(0);

        // there is no update change in the data
        expect(onUpdate).toHaveBeenCalledTimes(0);
    });

    test('Testing Tabs With Two Column Type Item Data', () => {
        // set up test mock data
        const columnNumber = 2;
        let content = TWO_COLUMN_DATA?.item?.item_json?.optionList;

        // set up test mock onUpdate function
        const onUpdate = jest.fn((...data) => {
            if (data !== undefined) {
                content = tabHandler(content, ...data);
            }
        });

        act(() => {
            render(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            );
        });

        // check the tab container exists with appropriate structure for two column type or not
        expect(screen.getByTestId('tcc-all-tabs-container')).toBeInTheDocument();

        // check tabs exists or not, and it contains only two containers
        expect(screen.getByTestId('tcc-tabs-container-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tabs-container-2')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tabs-container-]')?.length).toBe(2);

        expect(document.querySelectorAll('[data-testid^=tcc-tab-head-]')?.length).toBe(0);

        // do the basic test for the sub item based on the data, since we have separate test for that. i.e. is it exists or not
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-]')?.length).toBe(4);

        // there is no update change in the data
        expect(onUpdate).toHaveBeenCalledTimes(0);
    });

    test('Testing Tabs With Three Column Type Item Data', () => {

        // set up test mock data 
        const columnNumber = 3;
        let content = THREE_COLUMN_DATA?.item?.item_json?.optionList;

        // set up test mock onUpdate function
        const onUpdate = jest.fn((...data) => {
            if (data !== undefined) {
                content = tabHandler(content, ...data);
            }
        });

        act(() => {
            render(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            )
        });

        // check the tab container exists with appropriate structure for three column type or not
        expect(screen.getByTestId('tcc-all-tabs-container')).toBeInTheDocument();

        // check tabs exists or not, and it contains only three containers
        expect(screen.getByTestId('tcc-tabs-container-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tabs-container-2')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tabs-container-3')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tabs-container-]')?.length).toBe(3);

        expect(screen.getByTestId('tcc-tab-head-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-head-2')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-head-3')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tab-head-]')?.length).toBe(3);

        // do the basic test for the sub item based on the data, since we have separate test for that. i.e. is it exists or not
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-]')?.length).toBe(10);
        expect(document.querySelectorAll('[data-testid^=tcc-tab-head-] [data-testid=tcc-tab-editor-col-a]')?.length).toBe(3);

        expect(screen.getByTestId('tcc-tab-remove-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-remove-2')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-tab-remove-2')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tab-remove-]')?.length).toBe(3);

        // there is no update change in the data
        expect(onUpdate).toHaveBeenCalledTimes(0);
    });

    test('Testing Tabs Remove Buttons With Two Column Type Item Data', () => {
        // set up test mock data
        const columnNumber = 2;
        let content = TWO_COLUMN_DATA?.item?.item_json?.optionList;

        // set up test mock onUpdate function
        const onUpdate = jest.fn((...data) => {
            if (data !== undefined) {
                content = tabHandler(content, ...data);
            }
        });

        let update;
        act(() => {
            const { rerender } = render(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            );
            update = rerender;
        });

        // check the remove buttons for tabs
        const removeFirstTab = screen.getByTestId('tcc-tab-remove-1');
        const removeSecondTab = screen.getByTestId('tcc-tab-remove-1');
        expect(removeFirstTab).toBeInTheDocument();
        expect(removeSecondTab).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-tab-remove-]')?.length).toBe(2);

        // there is no update change in the data
        expect(onUpdate).toHaveBeenCalledTimes(0);

        act(() => {
            // remove a tabs by trigger the click event
            fireEvent.click(removeFirstTab);
        });

        // data should be updated two times, since tried to add two tabs in the new item
        expect(onUpdate).toHaveBeenCalledTimes(1);

        // re-render to check the component structure is match with the updated item data or not

        act(() => {
            update(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            )
        });

        expect(screen.getByTestId('tcc-tabs-container-1')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid=tcc-tabs-container-2]')?.length).toBe(0);
        expect(document.querySelectorAll('[data-testid^=tcc-tabs-container-]')?.length).toBe(1);

    });

    test('Testing Add & Remove Sub Tabs With Three Column Type Item Data', () => {

        // set up test mock data 
        const columnNumber = 3;
        let content = THREE_COLUMN_DATA?.item?.item_json?.optionList;

        // set up test mock onUpdate function
        const onUpdate = jest.fn((...data) => {
            if (data !== undefined) {
                content = tabHandler(content, ...data);
            }
        });

        let update;
        act(() => {
            const { rerender } = render(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            );
            update = rerender;
        });

        // check the add buttons for subtabs
        const addFirstSubTab = screen.getByTestId('tcc-add-sub-tab-1');
        const addSecondSubTab = screen.getByTestId('tcc-add-sub-tab-2');
        const addThirdSubTab = screen.getByTestId('tcc-add-sub-tab-3');
        expect(addFirstSubTab).toBeInTheDocument();
        expect(addSecondSubTab).toBeInTheDocument();
        expect(addThirdSubTab).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-add-sub-tab-]')?.length).toBe(3);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-1-col-]')?.length).toBe(4);

        // check the remove buttons for subtabs, for subtab there won't a remove button
        const removeFirstSubTab = screen.getByTestId('tcc-remove-sub-tab-1-2');
        const removeSecondSubTab = screen.getByTestId('tcc-remove-sub-tab-2-2');
        expect(removeFirstSubTab).toBeInTheDocument();
        expect(removeSecondSubTab).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-remove-sub-tab-]')?.length).toBe(2);

        // there is no update change in the data
        expect(onUpdate).toHaveBeenCalledTimes(0);

        act(() => {
            // add a third sub-tab by trigger the click event
            fireEvent.click(addThirdSubTab);
            // remove first sub-tab by trigger the click event
            fireEvent.click(removeFirstSubTab);
        });

        // data should be updated two times, since tried to add two tabs in the new item
        expect(onUpdate).toHaveBeenCalledTimes(2);

        // re-render to check the component structure is match with the updated item data or not
        act(() => {
            update(
                <Tabs
                    data={content}
                    onUpdate={onUpdate}
                    columnNumber={columnNumber}
                />,
                container
            )
        });

        // check the re-render component structure, do the basic test for the sub item based on the data, since we have separate test for that.
        expect(document.querySelectorAll('[data-testid^=tcc-add-sub-tab-]')?.length).toBe(3);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-]')?.length).toBe(10);

        // check the added sub-tab
        expect(screen.getByTestId('tcc-sub-tab-row-3-col-2-1')).toBeInTheDocument();
        expect(screen.getByTestId('tcc-sub-tab-row-3-col-2-2')).toBeInTheDocument();
        expect(document.querySelectorAll('[data-testid^=tcc-remove-sub-tab-3-2]')?.length).toBe(1);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-3-col-] [data-testid^=tcc-tab-editor-col-]')?.length).toBe(4);

        // check the removed sub-tab
        expect(document.querySelectorAll('[data-testid^=tcc-add-sub-tab-]')?.length).toBe(3);
        expect(document.querySelectorAll('[data-testid^=tcc-remove-sub-tab-]')?.length).toBe(2);
        expect(document.querySelectorAll('[data-testid^=tcc-remove-sub-tab-1-2]')?.length).toBe(0);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-1-col-2-]')?.length).toBe(0);
        expect(document.querySelectorAll('[data-testid^=tcc-sub-tab-row-1-col-] [data-testid^=tcc-tab-editor-col-]')?.length).toBe(2);

    });

});