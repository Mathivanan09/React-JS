import React from 'react';

import CKEditorBase from '../../../common/editors/ckeditor/CKEditorBase';
import label from '../../../../constants/labelCodes';
import { itemProps } from '../../../common/ItemHelper';

/**
 * React functional component to create Table Video item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace TableVideoOutputOptions
 *
 * @param {{item: Object, onUpdate: func }} param passed in parameters
 * @param {Object} param.inputObject JSON data that will contain the input information
 * for creating/updating inputnoptions of Table Video item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @return {TableVideoOutputOptions} TableVideoOutputOptions component for creating Table Video item
 *
 * @example
 * <TableVideoOutputOptions inputObject={{}} />
 */
const TableVideoOutputOptions = ({ data, onUpdate, onDelete }) => {

  const titlePlacholder = label.tvs_output_title_placeholder;

  /**
   *  Event handler to update output data
   *
   * @param {String} key
   * @param {String} value
   */
  const handleUpdate = (key, value) => {
    onUpdate({ ...data, ...{ [key]: value } });
  };

  return (
    <>
      <div className='bg-light p-3 rounded m-1'>
        <div className='row'>
          <div className='col-sm-11'>
            <label className='mb-1'>Output Title {data?.index + 1}: </label>
          </div>
          <div className='col-sm-1 text-right'>
            <button
              className='icon'
              onClick={(e) => {
                e.preventDefault();
                onDelete(data?.id);
              }}
              data-testid='option-item-remove-button'
            >
              <span className='icon-minus'>-</span>
            </button>
          </div>
          <div className='col-sm-12'>
            <CKEditorBase
              type='inline'
              data={data?.textHtml}
              className='content_style'
              onChange={(value) => {
                handleUpdate('textHtml', value);
              }}
              placeholder={titlePlacholder}
            />
          </div>
        </div>
      </div>
    </>
  );
};

TableVideoOutputOptions.propTypes = itemProps;

export default TableVideoOutputOptions;
