import React from 'react';
import PropTypes from 'prop-types';
import parse from 'html-react-parser';

import CKEditorBase from '../../../common/editors/ckeditor/CKEditorBase';
import label from '../../../../constants/labelCodes';

/**
 * React functional component to create Table Video item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace TableVideoSimulationOption
 *
 * @param {{data: Object, onUpdate: func, selectMedia: func, removeMedia: func }} param passed in parameters
 * @param {Object} param.data JSON data that will contain the input information
 * for creating/updating inputnoptions of Table Video item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.selectMedia Callback function to Select Media
 * @param {Object} param.removeMedia Callback function to Remove Media
 * @return {TableVideoSimulationOption} TableVideoSimulationOption component for creating Table Video item
 *s
 * @example
 * <TableVideoSimulationOption inputObject={{}} />
 */
const TableVideoSimulationOption = ({
  data,
  onUpdate,
  selectMedia,
  removeMedia
}) => {
  const outputValuePlaceholder = label.tvs_output_value_placholder;

  /**
   * Event handler to update output for simulations
   *
   * @param {String} value
   * @param {String} index
   */
  const handleOuputValue = (value, index) => {
    const updatedOutputs = [...data.outputs];
    updatedOutputs[index] = {
      ...updatedOutputs[index],
      ...{
        value
      }
    };
    onUpdate({ ...data, ...{ outputs: updatedOutputs } });
  };

  const outputTitle = (labelName, index) => {
    return labelName === 'data' || labelName === '' ? 'Output Title ' + (index + 1) : parse(labelName);
  }

  return (
    <section className='simulation-options'>
      <div className='row align-items-center'>
        <div className='col-sm-6'>
          <div className='row align-items-center'>
            <div className='col-sm-4'>
              {
                <div
                  className='combinations'
                  dangerouslySetInnerHTML={{
                    __html: data?.combination
                      ?.map((each) => {
                        return each.textHtml;
                      })
                      .join(' x ')
                  }}
                ></div>
              }
            </div>
            <div className='col-sm-4'>
              <input
                type='text'
                disabled={true}
                value={data.id ? `${data?.id} / ${data?.fileName}` : ''}
                className='form-control form-select-sm'
              />
            </div>
            <div className='col-sm-1 p-0'>
              {data.id ? (
                <button
                  className='icon'
                  onClick={(e) => {
                    e.preventDefault();
                    removeMedia();
                  }}
                  data-testid={'default-media-remove'}
                >
                  <span className='icon-minus'>-</span>
                </button>
              ) : (
                <></>
              )}
            </div>
            <div className='col-sm-3'>
              <button
                className='btn btn-primary btn-sm'
                onClick={(e) => {
                  e.preventDefault();
                  selectMedia();
                }}
              >
                Select Media
              </button>
            </div>
          </div>
        </div>
        <div className='col-sm-6'>
          <div className='row'>
            {data.outputs &&
              data?.outputs.map((output, index) => (
                <div className='col-sm-4' key={index}>
                  <div className='row align-items-center'>
                    <legend>{outputTitle(output.label, index)}</legend>
                  </div>
                  <div className='row align-items-center'>
                    <CKEditorBase
                      type='inline'
                      data={output.value}
                      className='content_style'
                      onChange={(value) => {
                        handleOuputValue(value, index);
                      }}
                      placeholder={outputValuePlaceholder}
                    />
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </section>
  );
};

TableVideoSimulationOption.propTypes = {
  data: PropTypes.object,
  onUpdate: PropTypes.func,
  selectMedia: PropTypes.func,
  removeMedia: PropTypes.func
}

export default TableVideoSimulationOption;
