import React from 'react';
import PropTypes from 'prop-types';
import label from '../../../constants/labelCodes';

export const typeSelections = {
  single: 'single',
  multiple: 'multiple',
  true_false: 'true/false'
};

/**
 * React functional component for switching Multiple Choice type selections
 * between single, multiple and true/false types
 * 
 * @inner
 * @memberof SharedComponents
 * 
 * @component
 * @namespace TypeSelection
 * 
 * @param {{ selectionType: string, onChange: func }} param Passed in parameters
 * @param {string} param.selectionType type of Multiple Choice selection type (multiple, single or true/false)
 * @param {function} param.onChange Callback function to update item_son attributes
 * @return {TypeSelection} TypeSelection component for selecting Multiple Choice type among
 * (multiple, single or true/false)
 * 
 * @example
 * <TypeSelection selectionType={item?.item_json?.selectionType} onChange={handleAnswerTypeChange} />
 */

const TypeSelection = ({ selectionType = 'single', onChange }) =>
(
  <div className='typeselection' data-testid='multiselect-typeselection'>
    <legend>{label.multiple_choice_selection}</legend>
    <div className='form-check-inline'>
      <div className='hstack gap-2'>
        <input
          type='radio'
          className='form-check-input'
          name='multiselect-typeselection'
          id='multiple_choice_single_select'
          data-testid='ts-single-radio-input'
          checked={selectionType === typeSelections.single}
          onChange={() => {
            onChange(typeSelections.single);
          }}
        />
        <label
          htmlFor='multiple_choice_single_select'
          className='form-check-label'
        >
          {label.multiple_choice_single_select}
        </label>
      </div>
    </div>
    <div className='form-check-inline'>
      <div className='hstack gap-2'>
        <input
          type='radio'
          className='form-check-input'
          name='multiselect-typeselection'
          id='multiple_choice_multi_select'
          data-testid='ts-multiple-radio-input'
          checked={selectionType === typeSelections.multiple}
          onChange={() => {
            onChange(typeSelections.multiple);
          }}
        />
        <label
          htmlFor='multiple_choice_multi_select'
          className='form-check-label'
        >
          {label.multiple_choice_multi_select}
        </label>
      </div>
    </div>
    <div className='form-check-inline'>
      <div className='hstack gap-2'>
        <input
          type='radio'
          className='form-check-input'
          name='multiselect-typeselection'
          id='multiple_choice_true_false_select'
          data-testid='ts-boolean-radio-input'
          checked={selectionType === typeSelections.true_false}
          onChange={() => {
            onChange(typeSelections.true_false);
          }}
        />
        <label
          htmlFor='multiple_choice_true_false_select'
          className='form-check-label'
        >
          {label.multiple_choice_true_false_select}
        </label>
      </div>
    </div>
  </div>
);

TypeSelection.propTypes = {
  selectionType: PropTypes.string,
  onChange: PropTypes.func
};

export default TypeSelection;
