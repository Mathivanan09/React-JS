import React, { useState, useEffect } from 'react';
import uuid from 'react-uuid';

import StemContent from '../shared/StemContent';
import ReorderItems from '../shared/ReorderItems';
import ItemDimensions from '../shared/ItemDimensions';
import AnswerAlignment from '../shared/AnswerAlignment';

import TypeSelection, { typeSelections } from './TypeSelection';

import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';

import fetch from '../../../utility/default';
import label from '../../../constants/labelCodes';

import MultipleChoiceResponse from '../../display/response/multiplechoice/MultipleChoiceResponse';
import { readableResponseParser } from '../../../utility/readableResponse';
import { itemProps } from '../../common/ItemHelper';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/MultipleChoice.css';

const DIR_UP = -1;
const DIR_DOWN = 1;
const SELECT = { id: null, name: 'Select' };

/**
 * React functional component to create multiple choice item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace MultipleChoice
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating multiple choice item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {MultipleChoice} MultipleChoice component for creating multiple choice item
 *
 * @example
 * <MultipleChoice item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'mc' },
    user_id: 0,
  }} />
 */
const MultipleChoice = ({ item, onUpdate, config }) => {
  /**
   * Prepares blank data for options, feedback and rationale
   * for single, multiple & boolean selection types
   *
   * @inner
   * @memberof MultipleChoice
   *
   * @function
   * @namespace getBlankData
   *
   * @param {string} selectionType Type for which blank data need to be constructed
   * possible values are 'single', 'multiple' and 'true/false'
   * @returns {object} An object with empty options, rationale and feedback based
   * on the selection type.
   */
  const getBlankData = (selectionType) => {
    let blankOptions = [];
    let blankRationale = [];
    let blankFeedback = [];

    if (selectionType !== typeSelections.true_false) {
      for (let i = 0; i < 4; i++) {
        const optionId = uuid();
        blankOptions.push({
          id: optionId,
          optionText: ''
        });
        blankRationale.push({
          id: optionId,
          rationaleText: ''
        });
        blankFeedback.push({
          id: optionId,
          feedbackText: ''
        });
      }
      return {
        optionList: blankOptions,
        rationale: blankRationale,
        feedbackList: blankFeedback
      };
    } else if (selectionType === typeSelections.true_false) {
      const optionIdTrue = uuid();
      const optionIdFalse = uuid();
      const trueFalseOptions = [
        { optionText: 'True', id: optionIdTrue },
        { optionText: 'False', id: optionIdFalse }
      ];

      const trueFalseRationale = [
        { rationaleText: '', id: optionIdTrue },
        { rationaleText: '', id: optionIdFalse }
      ];

      const addedFeedback = [];
      if (item.item_json?.feedback) {
        addedFeedback.push({
          feedbackText: '',
          id: optionIdTrue
        });
        addedFeedback.push({
          feedbackText: '',
          id: optionIdFalse
        });
      }
      return {
        optionList: trueFalseOptions,
        rationale: trueFalseRationale,
        feedbackList: addedFeedback
      };
    }
  };

  // All event methods go here and uses dispatch method
  const [showRationale, setShowRationale] = useState([]);
  const [showFeedback, setShowFeedback] = useState([]);
  const [initialized, setInitialized] = useState(false);

  // TODO Once byron's default JSON skeleton api is available, useEffect can be removed
  useEffect(() => {
    // Initialize the data if coming from new item screen
    if (item && item.id < 0 && !initialized) {
      let selectionType =
        item.item_json?.selectionType || fetch('selection_type');
      const data = getBlankData(selectionType);
      const blankOptions = data.optionList;
      const blankRationale = data.rationale;
      const blankFeedback = data.feedbackList;

      let shuffle = !fetch('multiple_choice_no_shuffle');
      let feedback = !fetch('multiple_choice_no_feedback');

      let payload = {
        ...item,
        item_json: {
          ...item.item_json,
          selectionType: selectionType,
          optionList: blankOptions,
          feedbackList: blankFeedback,
          correctResponse: [],
          shuffle: shuffle,
          feedback: feedback
        },
        rationale: { optionList: blankRationale }
      };
      onUpdate(payload);
      setInitialized(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Here empty dependency only allowed, do not provide any dependecies here.

  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  // Checks if the option id is present in the list of correct responses
  const isCorrectResponse = (id) => {
    return (
      item.item_json?.correctResponse &&
      item.item_json?.correctResponse.findIndex(response => response.id === id && response.value === true) > -1
    );
  };

  // Event handler for answer type change
  const handleAnswerTypeChange = (value) => {
    let updatedItem = {};
    const prevSelectionType = item.item_json?.selectionType;
    // Prepare blanks
    let blankOptions = [];
    let blankRationale = [];
    let blankFeedback = [];

    // type check for single selection type
    if (value === typeSelections.single) {
      if (
        prevSelectionType === typeSelections.true_false ||
        !item.item_json?.optionList
      ) {
        const data = getBlankData(value);
        blankOptions = data.optionList;
        blankRationale = data.rationale;
        blankFeedback = data.feedbackList;
      }

      // set minSelections to 0 and maxSelections to 1 as well as changing the selection type
      let optionList =
        prevSelectionType === typeSelections.true_false ||
          !item?.item_json?.optionList
          ? blankOptions
          : item.item_json.optionList;
      let rationale =
        prevSelectionType === typeSelections.true_false ||
          !item?.rationale
          ? { optionList: blankRationale }
          : item.rationale;
      let feedbackList = item.item_json?.feedback
        ? prevSelectionType === typeSelections.true_false ||
          !item.item_json?.feedbackList
          ? blankFeedback
          : item.item_json.feedbackList
        : [];

      let updatedCorrectResponses = (optionList?.map(option => {
        return { id: option.id, value: false }
      }) || []);
      let readableResponse = generateReadableResponse(updatedCorrectResponses);

      // prepare the payload
      updatedItem = {
        rationale: rationale,
        readableResponse: readableResponse,
        scoring_method_id: null,
        scoring_method_code: null,
        item_json: {
          minSelections: 0,
          maxSelections: 1,
          selectionType: value,
          optionList: optionList,
          feedbackList: feedbackList,
          correctResponse: updatedCorrectResponses
        }
      };
    } else if (value === typeSelections.multiple) {
      if (
        prevSelectionType === typeSelections.true_false ||
        !item.item_json?.optionList
      ) {
        const data = getBlankData(value);
        blankOptions = data.optionList;
        blankRationale = data.rationale;
        blankFeedback = data.feedbackList;
      }

      let optionList =
        prevSelectionType === typeSelections.true_false ||
          !item?.item_json?.optionList
          ? blankOptions
          : item.item_json.optionList;
      let rationale =
        prevSelectionType === typeSelections.true_false ||
          !item?.rationale
          ? { optionList: blankRationale }
          : item.rationale;
      let feedbackList = item.item_json?.feedback
        ? prevSelectionType === typeSelections.true_false ||
          !item?.item_json?.feedbackList
          ? blankFeedback
          : item.item_json.feedbackList
        : [];

      let updatedCorrectResponses = (optionList?.map(option => {
        return { id: option.id, value: false }
      }) || []);
      let readableResponse = generateReadableResponse(updatedCorrectResponses);

      // prepare the payload
      updatedItem = {
        rationale: rationale,
        readableResponse: readableResponse,
        item_json: {
          minSelections: 0,
          maxSelections: 0,
          selectionType: value,
          optionList: optionList,
          feedbackList: feedbackList,
          correctResponse: updatedCorrectResponses
        }
      };
    } else if (value === typeSelections.true_false) {
      const data = getBlankData(value);
      const trueFalseOptions = data.optionList;
      const trueFalseRationale = data.rationale;
      const addedFeedback = data.feedbackList;

      // set minSelections to 0 and maxSelections to 1 as well as changing the selection type
      let updatedCorrectResponses = (trueFalseOptions?.map(option => {
        return { id: option.id, value: false }
      }) || []);
      let readableResponse = generateReadableResponse(updatedCorrectResponses);

      // prepare the payload
      updatedItem = {
        rationale: { optionList: trueFalseRationale },
        readableResponse: readableResponse,
        scoring_method_id: null,
        scoring_method_code: null,
        item_json: {
          minSelections: 0,
          maxSelections: 1,
          selectionType: value,
          optionList: trueFalseOptions,
          correctResponse: updatedCorrectResponses,
          feedbackList: addedFeedback
        }
      };
    }
    onUpdate(updatedItem);
  };

  // Adds a new option to the option list
  const appOption = () => {
    const optionId = uuid(); //New UUID will be generated and assigned to each response

    const addedOption = [
      ...(item?.item_json?.optionList || []),
      { optionText: '', id: optionId }
    ];

    const addRationale = [
      ...(item.rationale?.optionList || []),
      { rationaleText: '', id: optionId }
    ];

    const addedFeedback = [...(item.item_json?.feedbackList || [])];
    if (item.item_json?.feedback) {
      addedFeedback.push({
        feedbackText: '',
        id: optionId
      });
    }

    const updatedCorrectResponses = [
      ...(item.item_json?.correctResponse || []),
      { value: false, id: optionId }
    ];

    const readableResponse = generateReadableResponse(updatedCorrectResponses);

    // prepare the payload
    const updatedItem = {
      rationale: {
        optionList: addRationale
      },
      readableResponse: readableResponse,
      item_json: {
        optionList: addedOption,
        feedbackList: addedFeedback,
        correctResponse: updatedCorrectResponses
      }
    };
    onUpdate(updatedItem);
  };

  // Checks/unchecks the option radio button/checkbox
  const setOptionCheck = (id) => {
    let correctResponses;
    if (item.item_json?.selectionType === typeSelections.multiple) {
      correctResponses = (item?.item_json?.correctResponse?.map(option => {
        return {
          id: option.id,
          value: option.id === id ? !option?.value : (option.value || false)
        }
      }) || []);
    } else {
      correctResponses = (item?.item_json?.correctResponse?.map(option => {
        return {
          id: option.id,
          value: option.id === id ? !option?.value : false
        }
      }) || []);
    }

    const readableResponse = generateReadableResponse(correctResponses);

    // prepare the payload
    let updatedItem = {
      readableResponse: readableResponse,
      item_json: {
        correctResponse: correctResponses
      }
    };
    onUpdate(updatedItem);
  };

  // Event handler for adding option data
  /* istanbul ignore next */
  const handleOptionChange = (data, index) => {
    const newOptList = [...item.item_json.optionList];
    newOptList[index] = {
      ...newOptList[index],
      optionText: data
    };

    // prepare the payload
    const updatedItem = {
      item_json: {
        optionList: newOptList
      }
    };
    onUpdate(updatedItem);
  };

  // Toggles the rationale text box
  const showHideRationale = (id) => {
    const showing = new Set([...showRationale]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowRationale([...showing]);
  };

  //Toggles the feedback text box
  const showHideFeedback = (id) => {
    const showing = new Set([...showFeedback]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowFeedback([...showing]);
  };

  // Event handler for adding rationale data
  /* istanbul ignore next */
  const handleRationaleChange = (data, index) => {
    const newList = [...(item.rationale?.optionList || [])];
    newList[index] = { ...newList[index], rationaleText: data };
    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newList }
    };
    onUpdate(updatedItem);
  };

  const getInputType = () => {
    if (
      item.item_json.selectionType === typeSelections.single ||
      item.item_json.selectionType === typeSelections.true_false
    ) {
      return 'radio';
    } else {
      return 'checkbox';
    }
  };

  //Move items up or down using arrow keys.
  const reorderItems = (id, counter) => {
    const itemIndex = item.item_json?.optionList.findIndex(
      (element) => element.id === id
    );
    if (
      (counter === DIR_UP && itemIndex === 0) ||
      (counter === DIR_DOWN &&
        itemIndex === item.item_json?.optionList.length - 1)
    ) {
      return; // canot move outside of array
    }

    //Reorder the optionList
    const optionItem = item.item_json?.optionList[itemIndex];
    let updatedOptionItems = [];
    if (item.item_json?.optionList && item.item_json?.optionList.length > 0) {
      updatedOptionItems =
        item.item_json?.optionList?.filter((i) => i.id !== id) || [];
      updatedOptionItems.splice(itemIndex + counter, 0, optionItem);
    }

    //Reorder the rationale list
    const rationaleItem = item.rationale.optionList[itemIndex];
    let updatedRationaleItems = [];
    if (item.rationale?.optionList && item.rationale?.optionList.length > 0) {
      updatedRationaleItems =
        item.rationale?.optionList?.filter((i) => i.id !== id) || [];
      updatedRationaleItems.splice(itemIndex + counter, 0, rationaleItem);
    }

    //Reorder the feedack list
    let feedbackItem = [];
    let updatedFeedbackItems = [];
    if (
      item.item_json?.feedbackList &&
      item.item_json?.feedbackList.length > 0
    ) {
      feedbackItem = item.item_json?.feedbackList[itemIndex];
      updatedFeedbackItems =
        item.item_json?.feedbackList?.filter((i) => i.id !== id) || [];
      updatedFeedbackItems.splice(itemIndex + counter, 0, feedbackItem);
    }

    // prepare the payload
    const updatedItem = {
      rationale: { optionList: updatedRationaleItems },
      item_json: {
        optionList: updatedOptionItems,
        feedbackList: updatedFeedbackItems
      }
    };
    onUpdate(updatedItem);
  };

  //Event handler for adding feedback data
  /* istanbul ignore next */
  const handleFeedbackChange = (data, index) => {
    const newList = [...(item.item_json?.feedbackList || [])];
    newList[index].feedbackText = data;
    // prepare the payload
    const updatedItem = {
      item_json: {
        feedbackList: newList
      }
    };
    onUpdate(updatedItem);
  };

  //Remove the item
  const removeOption = (id) => {
    //Updating the correct response object.
    let updatedCorrectResponses =
      item.item_json?.correctResponse?.filter((element) => element.id !== id) || [];
    //Remove from optionList
    let optionList =
      item.item_json?.optionList?.filter((element) => element.id !== id) || [];
    //Remove from rationale
    let updatedRationaleList =
      item.rationale?.optionList?.filter((element) => element.id !== id) || [];
    //Remove from feedback
    const updatedFeedbackList =
      item.item_json?.feedbackList?.filter((element) => element.id !== id) || [];

    const readableResponse = generateReadableResponse(updatedCorrectResponses);

    // prepare the payload
    const updatedItem = {
      readableResponse: readableResponse,
      rationale: { optionList: updatedRationaleList },
      item_json: {
        optionList: optionList,
        correctResponse: updatedCorrectResponses,
        feedbackList: updatedFeedbackList
      }
    };

    onUpdate(updatedItem);
  };
  
  // Drop down values for Responses Required
  // Calculated based on the options length
  const getResponsesRequiredData = () => {
    const values = [...[-1], ...(item.item_json.optionList || []).keys()].map((val) => {
      return {
        id: val + 1,
        name: val + 1
      };
    });
    return [SELECT, ...values];
  };

  // Drop down values for Responses allowed
  // Calculated based on the options length and need to allow 0 responses as well
  const getResponsesAllowedData = () => {
    const values = [...[-1], ...(item.item_json.optionList || []).keys()].map((val) => {
      return {
        id: val + 1,
        name: val + 1
      };
    });
    return [SELECT, ...values];
  };

  // Drop down values for Response labels data
  // Uses if config object has the labels else uses the default values
  const getResponseLabelsData = () => {
    // TODO Need to re-factor at later to use proper values
    const values = (
      (config && config.responseLabels) ||
      ['Letters', 'No Response Label', 'Numbers'].map((val) => {
        return {
          id: val,
          name: val
        };
      })
    );
    return [SELECT, ...values];
  };

  //Event handler for feedback option change
  const feedbackOptionChange = (value) => {
    const addedFeedback = [];
    if (value === true) {
      for (let i = 0; i < item.item_json?.optionList?.length; i++) {
        addedFeedback.push({
          feedbackText: '',
          id: item.item_json?.optionList[i].id
        });
      }
    }

    // prepare the payload
    const updatedItem = {
      item_json: {
        feedbackList: addedFeedback
      }
    };

    onUpdate(updatedItem);
  };

  /**
   * @summary This method is used to Build readable response for Multiple Choice Item.
   *
   * @inner
   * @memberof UtilityMethods
   *
   * @function
   * @namespace generateReadableResponse
   */
  const generateReadableResponse = (updatedCorrectResponses) => {
    let readableResponse = '';
    if (updatedCorrectResponses) {
      updatedCorrectResponses.forEach((updatedCorrectResponse, index) => {
        if (updatedCorrectResponse?.id && updatedCorrectResponse?.value) {
          const optIndex = item.item_json?.optionList.findIndex(
            (element) => element.id === updatedCorrectResponse?.id
          );
          if (optIndex >= 0) {
            let responseText = item.item_json?.optionList[optIndex].optionText;
            let parseElement = readableResponseParser({
              responseText: responseText
            });
            if (index === 0) {
              readableResponse = `${parseElement}`;
            } else {
              readableResponse = readableResponse + `\n\n${parseElement}`;
            }
          }
        }
      });
    }
    return readableResponse;
  };

  const isBooleanTypeSelected = () => {
    return item.item_json?.selectionType === typeSelections.true_false;
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={(key, value) => {
                onUpdate({
                  item_json: {
                    ...item.item_json,
                    ...{ stemContent: value, [key]: value }
                  }
                });
              }}
              fieldName='stemContent'
            />
          </div>
          <div className='row' data-testid='options-container'>
            <div className='col col-12 col-sm-5'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <TypeSelection
                  selectionType={item?.item_json?.selectionType}
                  onChange={handleAnswerTypeChange}
                />
              </fieldset>
              <fieldset className='bg-light p-3 rounded m-1'>
                <legend>{label.multiple_choice_choice_options}</legend>
                {item.item_json?.selectionType === typeSelections.multiple && (
                  <>
                    <div className='row align-items-center p-1'>
                      <div
                        className='col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end'
                      >
                        <label htmlFor='multiple_choice_selection_required'>
                          {label.multiple_choice_selection_required}:
                          <i className='required-field text-danger ms-1'>*</i>
                        </label>
                      </div>
                      <div className='col'>
                        <select
                          required={true}
                          id='multiple_choice_selection_required'
                          className='form-select form-select-sm mx-0'
                          value={item.item_json.minSelections}
                          onChange={(e) => {
                            updateItemJson('minSelections', e.target.value);
                          }}
                        >
                          {
                            getResponsesRequiredData().map((value, ind) => (
                              <option
                                key={value?.id || ind}
                                value={value?.id !== null ? value?.id : ''}
                              >
                                {value?.name}
                              </option>
                            ))
                          }
                        </select>
                      </div>
                    </div>
                    <div className='row align-items-center p-1'>
                      <div
                        className='col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end'
                      >
                        <label htmlFor='multiple_choice_selection_allowed'>
                          {label.multiple_choice_selection_allowed}:
                          <i className='required-field text-danger ms-1'>*</i>
                        </label>
                      </div>
                      <div className='col'>
                        <select
                          required={true}
                          id='multiple_choice_selection_allowed'
                          className='form-select form-select-sm mx-0'
                          value={item.item_json.maxSelections}
                          onChange={(e) => {
                            updateItemJson('maxSelections', e.target.value);
                          }}
                        >
                          {
                            getResponsesAllowedData().map((value, ind) => (
                              <option
                                key={value?.id || ind}
                                value={value?.id !== null ? value?.id : ''}
                              >
                                {value?.name}
                              </option>
                            ))
                          }
                        </select>
                      </div>
                    </div>
                  </>
                )}
                <AnswerAlignment
                  labelCode='answer_alignment'
                  onUpdate={updateItemJson}
                  updateKey='answerAlignment'
                  isRequired={true}
                  showSelect={false}
                  value={item.item_json?.answerAlignment}
                />
                <div className='row align-items-center p-1'>
                  <div
                    className='col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end'
                  >
                    <label htmlFor='response_labels'>
                      {label.response_labels}:
                      <i className='required-field text-danger ms-1'>*</i>
                    </label>
                  </div>
                  <div className='col'>
                    <select
                      required={true}
                      id='response_labels'
                      data-testid='mc-response-labels'
                      value={item.item_json?.responseLabels !== undefined ? item.item_json?.responseLabels: fetch('response_labels')}
                      className='form-select form-select-sm mx-0'
                      onChange={(e) => {
                        updateItemJson('responseLabels', e.target.value);
                      }}
                    >
                      {
                        getResponseLabelsData()?.map((value, ind) => (
                          <option
                            key={value?.id || ind}
                            value={value?.id || ''}
                          >
                            {value?.name}
                          </option>
                        ))
                      }
                    </select>
                  </div>
                </div>
              </fieldset>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div data-testid='shuffle_selection'>
                  <legend className='pt-1'>
                    {label.multiple_choice_shuffle_option}
                  </legend>
                  <div className="form-check-inline">
                    <div className="hstack gap-2">
                      <input
                        type="radio"
                        className="form-check-input"
                        name="multiple_choice_shuffle"
                        id="multiple_choice_yes_shuffle"
                        checked={item?.item_json?.shuffle || false}
                        data-testid="multiple_choice_yes_shuffle"
                        onChange={() => {
                          updateItemJson('shuffle', true);
                        }}
                      />
                      <label
                        htmlFor="multiple_choice_yes_shuffle"
                        className="form-check-label"
                      >
                        {label.yes}
                      </label>
                    </div>
                  </div>
                  <div className="form-check-inline">
                    <div className="hstack gap-2">
                      <input
                        type="radio"
                        className="form-check-input"
                        name="multiple_choice_shuffle"
                        id="multiple_choice_no_shuffle"
                        checked={!item?.item_json?.shuffle || false}
                        data-testid="multiple_choice_no_shuffle"
                        onChange={() => {
                          updateItemJson('shuffle', false);
                        }}
                      />
                      <label
                        htmlFor="multiple_choice_no_shuffle"
                        className="form-check-label"
                      >
                        {label.no}
                      </label>
                    </div>
                  </div>
                </div>
              </fieldset>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div data-testid='feedback_selection'>
                  <legend className='pt-1'>
                    {label.multiple_choice_feedback_option}
                  </legend>
                  <div className='form-check-inline'>
                    <div className='hstack gap-2'>
                      <input
                        type='radio'
                        className='form-check-input'
                        name='multiple_choice_feedback'
                        id='multiple_choice_yes_feedback'
                        data-testid='multiple_choice_yes_feedback'
                        checked={item?.item_json?.feedback || false}
                        onChange={() => {
                          updateItemJson('feedback', true);
                          feedbackOptionChange(true);
                        }}
                      />
                      <label
                        htmlFor='multiple_choice_yes_feedback'
                        className='form-check-label'
                      >
                        {label.yes}
                      </label>
                    </div>
                  </div>
                  <div className='form-check-inline'>
                    <div className='hstack gap-2'>
                      <input
                        type='radio'
                        className='form-check-input'
                        name='multiple_choice_feedback'
                        id='multiple_choice_no_feedback'
                        data-testid='multiple_choice_no_feedback'
                        checked={!item?.item_json?.feedback || false}
                        onChange={() => {
                          updateItemJson('feedback', false);
                          feedbackOptionChange(false);
                        }}
                      />
                      <label
                        htmlFor='multiple_choice_no_feedback'
                        className='form-check-label'
                      >
                        {label.no}
                      </label>
                    </div>
                  </div>
                </div>
              </fieldset>
            </div>
            <div className='col col-12 col-sm-7'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className='row'>
                  <div className='col col-sm-6'>
                    <legend>{label.response_options}</legend>
                  </div>
                  <div className='col col-sm-6 text-end text-right'>
                    <button
                      className='btn btn-primary'
                      data-testid='multiplechoice-addoption'
                      icon='add'
                      disabled={
                        item.item_json?.selectionType ===
                        typeSelections.true_false
                      }
                      onClick={(e) => {
                        e.preventDefault();
                        appOption();
                      }}
                    >
                      {label.multiple_choice_add_options}
                    </button>
                  </div>
                </div>
                <div className='optionbox' data-testid='optionbox'>
                  {item.item_json?.optionList?.map(({ id }, i) => (
                    <div
                      key={id}
                      className='p-10'
                      data-testid='multiplechoice-option'
                    >
                      <div className='row option align-items-center p-2'>
                        <div
                          className='col col-6 col-md-4 col-lg-2 text-end text-right mc-select-container'
                        >
                          <div className='row'>
                            <div className='col col-12'>
                              <div className="form-check-inline">
                                <div className="hstack gap-2">
                                  <label
                                    htmlFor={'mc_correct' + i}
                                    className="form-check-label"
                                  >
                                    {label.mc_correct}
                                  </label>
                                  <input
                                    name="optionlist"
                                    type={getInputType()}
                                    id={'mc_correct' + i}
                                    className="form-check-input"
                                    data-testid="mc-correct"
                                    checked={isCorrectResponse(id) || false}
                                    onChange={() => setOptionCheck(id)}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                          <ReorderItems
                            listLength={item.item_json.optionList.length}
                            option={i}
                            onDownClick={() => reorderItems(id, DIR_DOWN)}
                            onUpClick={() => reorderItems(id, DIR_UP)}
                          />
                        </div>
                        <div className='col mc-item-box'>
                          <CKEditorBase
                            type='inline'
                            data={item.item_json.optionList[i].optionText}
                            className='content_style'
                            disabled={isBooleanTypeSelected()}
                            onChange={
                              /* istanbul ignore next */
                              (data) => {
                                handleOptionChange(data, i);
                              }
                            }
                            placeholder={label.enter_response_content}
                          />
                        </div>
                        <div className='col col-1'>
                          <button
                            className='icon'
                            disabled={
                              item.item_json.selectionType ===
                              typeSelections.true_false
                            }
                            onClick={(e) => {
                              e.preventDefault();
                              removeOption(id);
                            }}
                            data-testid='option-remove-button'
                          >
                            <span className='icon-minus'>-</span>
                          </button>
                        </div>
                      </div>
                      <div className='row rationale align-items-center p-2'>
                        <div
                          className='col col-4 col-sm-3 col-lg-2 text-end text-right'
                        >
                          <button
                            className='btn btn-sm btn-primary'
                            onClick={() => showHideRationale(id)}
                            data-testid='rationale-button'
                          >
                            {label.rationale}
                          </button>
                        </div>
                        {showRationale.indexOf(id) !== -1 && (
                          <div
                            className='col mc-item-box'
                            data-testid='rationale-container'
                          >
                            <CKEditorBase
                              type='inline'
                              data={
                                item.rationale.optionList[i].rationaleText
                              }
                              onChange={
                                /* istanbul ignore next */
                                (data) => {
                                  handleRationaleChange(data, i);
                                }
                              }
                              placeholder={label.enter_rationale_content}
                              config={{ removePlugins: ['TagAccessibility'] }}
                            />
                          </div>
                        )}
                      </div>
                      {item.item_json.feedback === true && (
                        <div className='row response-feedback rationale align-items-center p-2'>
                          <div
                            className='col col-4 col-sm-3 col-lg-2 text-end text-right'
                          >
                            <button
                              className='btn btn-sm btn-primary'
                              onClick={() => showHideFeedback(id)}
                              data-testid='feedback-button'
                            >
                              {label.multiple_choice_feedback}
                            </button>
                          </div>
                          {showFeedback.indexOf(id) !== -1 && (
                            <div
                              className='col mc-item-box'
                              data-testid='feedback-container'
                            >
                              <CKEditorBase
                                type='inline'
                                data={
                                  item.item_json.feedbackList?.[i]?.feedbackText
                                }
                                onChange={
                                  /* istanbul ignore next */
                                  (data) => {
                                    handleFeedbackChange(data, i);
                                  }
                                }
                                placeholder={label.enter_feedback_content}
                                config={{ removePlugins: ['TagAccessibility'] }}
                              />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </fieldset>
            </div>
          </div>

          <div className='row p-3' data-testid='mc-correct-response-container'>
            <fieldset className='bg-light p-3 rounded m-1'>
              <legend>{label.correct_response}</legend>
              <MultipleChoiceResponse
                item={item}
                stemComponent={null}
                config={config}
                showCorrectResponse={true}
                isPreview={false}
              />
            </fieldset>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

MultipleChoice.propTypes = itemProps;

export default MultipleChoice;
