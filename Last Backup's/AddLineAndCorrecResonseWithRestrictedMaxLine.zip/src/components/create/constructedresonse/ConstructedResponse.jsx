import React, { useState } from 'react';
import uuid from 'react-uuid';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';

import DisplayResponse from '../../display/response/constructedresponse/DisplayResponse';

import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';
import fetch from '../../../utility/default';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/ConstructedResponse.css';

const defaultMaxCharacters = fetch('cr-max-characters');
const defaultMaxFieldSize = fetch('cr-max-field-size');

/**
 * React functional component to create Constructed Response item
 *
 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace ConstructedResponse
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating Constructed Response item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {ConstructedResponse} ConstructedResponse component for creating Constructed Response item
 * 
 * @example
 * <ConstructedResponse item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'cr' },
    user_id: 0,
  }} />
 */
const ConstructedResponse = ({ item, onUpdate, config }) => {
  const [showRationale, setShowRationale] = useState([]);

  // event handler for content update
  const updateItemKeys = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };
  const handleExistingCorrectResponses = (oldValues, newValues) => {
    return newValues.map(each => {
      const existingResponse = oldValues.find(el => el.id === each.id);
      if (existingResponse) {
        if (existingResponse.value !== each.value) {
          existingResponse.value = each.value;
          return existingResponse;
        } else {
          return existingResponse;
        }
      } else {
        return each;
      }
    })
  }
  
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    // Modify the stem so that the correct responses are displayed

    const data = document.createElement('div');
    data.innerHTML = value;
    const inputElements = data.getElementsByClassName(
      'constructedResponse-placeholder'
    );
    let optionListTemp = [];
    let correctResponseTemp = [];
    let optionList = [];
    const correctResponse = item?.item_json.correctResponse || [];
    if (inputElements.length > 0) {
      for (const element of inputElements) {
        const index = optionListTemp.length;
        const text = element.innerText;
        const responseUuid = element.id;
        if (responseUuid !== '') {
          // If the response is not present in the correct response list, add it
          optionList = [
            ...optionList,
            {
              id: responseUuid,
              rationaleText: ''
            }
          ];
          let responseType = isNumber(text) ? 'Numeric' : 'AlphaNumeric';
          optionListTemp.push({
            id: responseUuid,
            index: index,
            maxFieldSize: text.length + 2 ,
            responseName: `Response ${index + 1}`,
            responseType: responseType,
            caseSensitive: false,
            maxCharacters: text.length
          });
          correctResponseTemp.push({
            id: responseUuid,
            value: text,
            acceptableValues: []
          });
        }
        // Handle if the correct response element is not in inputElements then remove it from list
        for (const cr of optionListTemp) {
          for (const input of inputElements) {
            if (cr.id === input.id) {
              break;
            }
            if (input === inputElements[inputElements.length - 1]) {
              optionListTemp = optionListTemp.filter(({ id }) => id !== cr.id);
              correctResponseTemp = correctResponseTemp.filter(
                ({ id }) => id !== cr.id
              );
            }
          }
        }
      }
    }
    let newCorrectResponseList = handleExistingCorrectResponses(correctResponse, correctResponseTemp).map((each, index) => {
      each.responseName = `Response ${index + 1}`
      return each;
    });
    
    onUpdate({
      rationale: {
        optionList: optionList
      },
      item_json: {
        ...item.item_json,
        ...{
          stemContent: value,
          [key]: value,
          optionList: optionListTemp,
          correctResponse: newCorrectResponseList
        }
      }
    });
  };

  const updateItemDimensions = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  /**
   * Sets case sensitive value for the given option id
   *
   * @param {object} e - Event object
   * @param {string} id - Id of the option whose case sensitive value should be set
   */
  const updateCaseSensitive = (e) => {
    const newOptionList = item.item_json.optionList.map((res) => {
      if (res.id === e.target.id) {
        return { ...res, caseSensitive: e.target.checked };
      } else {
        return res;
      }
    });
    onUpdate({
      item_json: { ...item.item_json, optionList: newOptionList }
    });
  };

  const updateCorrectResponseName = (key, value) => {
    const newOptionList = JSON.parse(
      JSON.stringify(
        item.item_json.optionList.map((res) => {
          if (res.id === key) {
            return { ...res, responseName: value };
          } else {
            return res;
          }
        })
      )
    );
    onUpdate({
      item_json: { ...item.item_json, optionList: newOptionList }
    });
  };

  const updateCorrectResponse = (e) => {
    const newCorrectResponse = JSON.parse(
      JSON.stringify(
        item.item_json.correctResponse.map((res) => {
          if (res.id === e.target.id) {
            return { ...res, value: e.target.value };
          } else {
            return res;
          }
        })
      )
    );
    onUpdate({
      item_json: { ...item.item_json, correctResponse: newCorrectResponse }
    });
  };

  const updateResponseType = (key, value) => {
    const newOptionList = JSON.parse(
      JSON.stringify(
        item.item_json.optionList.map((res) => {
          if (res.id === key) {
            return { ...res, responseType: value };
          } else {
            return res;
          }
        })
      )
    );
    onUpdate({
      item_json: { ...item.item_json, optionList: newOptionList }
    });
  };

  const updateMaxCharacters = (e) => {
    const newOptionList = JSON.parse(
      JSON.stringify(
        item.item_json.optionList.map((res) => {
          if (res.id === e.target.id) {
            return { ...res, maxCharacters: parseInt(e.target.value) };
          } else {
            return res;
          }
        })
      )
    );
    onUpdate({
      item_json: { ...item.item_json, optionList: newOptionList }
    });
  };

  const updateMaxFieldSize = (e) => {
    const newOptionList = JSON.parse(
      JSON.stringify(
        item.item_json.optionList.map((res) => {
          if (res.id === e.target.id) {
            return { ...res, maxFieldSize: parseInt(e.target.value) };
          } else {
            return res;
          }
        })
      )
    );
    onUpdate({
      item_json: { ...item.item_json, optionList: newOptionList }
    });
  };

  const updateAcceptableValue = (
    correctResponseIndex,
    acceptableValueIndex,
    e
  ) => {
    const newCorrectResponse = JSON.parse(
      JSON.stringify(item.item_json.correctResponse)
    );
    let acceptableValues =
      newCorrectResponse[correctResponseIndex].acceptableValues;
    acceptableValues[acceptableValueIndex] = {
      id: uuid(),
      value: e.target.value
    };
    newCorrectResponse[correctResponseIndex].acceptableValues = [
      ...acceptableValues
    ];
    onUpdate({
      item_json: { ...item.item_json, correctResponse: [...newCorrectResponse] }
    });
  };

  const removeResponse = (optionItemId) => {
    const optionList = JSON.parse(JSON.stringify(item.item_json.optionList));
    const newOptionList = optionList.filter((res) => res.id !== optionItemId);

    const correctResponse = JSON.parse(
      JSON.stringify(item.item_json.correctResponse)
    );
    const newCorrectResponse = correctResponse.filter(
      (res) => res.id !== optionItemId
    );
    const stemContentEL = document.createElement('div');
    stemContentEL.id = 'stem-content-constructed-response';
    stemContentEL.innerHTML = item?.item_json?.stemContent;
    stemContentEL.style.display = 'none';
    const inputElements = stemContentEL.getElementsByClassName(
      'constructedResponse-placeholder'
    );

    for (const inputElement of inputElements) {
      if (inputElement.id === optionItemId) {
        const textNode = document.createTextNode(inputElement.innerHTML);
        inputElement.replaceWith(textNode);
      }
    }

    const updatedStem = stemContentEL.innerHTML;

    onUpdate({
      item_json: {
        ...item.item_json,
        optionList: [...newOptionList],
        correctResponse: [...newCorrectResponse],
        stemContent: updatedStem
      }
    });
  };

  const removeAcceptableValue = (
    correctResponseIndex,
    acceptableValueIndex
  ) => {
    let itemJson = JSON.parse(JSON.stringify({ ...item.item_json }));
    let correctResponse = JSON.parse(
      JSON.stringify([...itemJson.correctResponse])
    );
    let acceptableValues = [
      ...item.item_json.correctResponse[correctResponseIndex].acceptableValues
    ];
    acceptableValues.splice(acceptableValueIndex, 1);
    correctResponse[correctResponseIndex].acceptableValues = acceptableValues;
    onUpdate({
      item_json: { ...itemJson, correctResponse: [...correctResponse] }
    });
  };

  const addAcceptableValue = (optionItemIndex) => {
    let itemJson = JSON.parse(JSON.stringify({ ...item.item_json }));
    let correctResponse = JSON.parse(
      JSON.stringify(
        itemJson.correctResponse ? [...itemJson.correctResponse] : []
      )
    );
    let acceptableValues = correctResponse[optionItemIndex]?.acceptableValues
      ? correctResponse[optionItemIndex]?.acceptableValues
      : [];
    acceptableValues = [...acceptableValues, { id: uuid(), value: '' }];
    correctResponse[optionItemIndex].acceptableValues = acceptableValues;
    onUpdate({
      item_json: { ...item.item_json, correctResponse: [...correctResponse] }
    });
  };

  // Toggles the rationale text box
  const showHideRationale = (id) => {
    const showing = new Set([...showRationale]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowRationale([...showing]);
  };

  // Event handler for adding rationale data
  /* istanbul ignore next */
  const handleRationaleChange = (data, index) => {
    const newList = [...(item?.rationale?.optionList || [])];
    newList[index] = { ...newList[index], rationaleText: data };
    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newList }
    };
    onUpdate(updatedItem);
  };

  const isNumber = (n) => {
    return /^-?[\d.]+(?:e-?\d+)?$/.test(n);
  };

  const getResponseTypeValue = (optionItem) => {
    if (optionItem.responseType) {
      return optionItem.responseType;
    }
    if (
      isNumber(
        item?.item_json?.correctResponse.find((cr) => cr.id === optionItem.id)
          .value
      )
    ) {
      return 'Numeric';
    } else {
      return 'AlphaNumeric';
    }
  };

  const determineMaxCharacters = (correctResponse) => {
    let options = [
      correctResponse.value,
      ...correctResponse?.acceptableValues?.map((av) => av.value)
    ];
    return options.reduce((acc, curr) => {
      return acc.length > curr.length ? acc : curr;
    }).length;
  };

  const responseTypes = [
    {
      id: 'AlphaNumeric',
      name: 'Alpha Numeric'
    },
    {
      id: 'Numeric',
      name: 'Numeric'
    }
  ];

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemDimensions('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemDimensions('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
              config={{
                insertResponse: {
                  type: 'cr-dropdown',
                  label: 'Insert Response'
                }
              }}
            />
          </div>
          {item.item_json.optionList?.map((optionItem, optionItemIndex) => (
            <div className='row' data-testid='design-container' key={optionItem.id}>
              <div className='col'>
                <fieldset
                  className='bg-light p-3 rounded m-1'
                  title='Acceptable Values'
                >
                  <div className='row'>
                    <div className='col'>
                      <legend>
                        {optionItem.responseName}:
                        {
                          item.item_json.correctResponse?.find(
                            (response) => response.id === optionItem.id
                          ).value
                        }
                      </legend>
                      <div className='row p-2 m-2 tab-container'>
                        <div className='col'>
                          <div className='row'>
                            <div className='col'>
                              <legend>{label.acceptable_values}</legend>
                            </div>
                            <div className='col text-right'>
                              <button
                                className='btn btn-primary'
                                onClick={(e) => {
                                  e.preventDefault();
                                  addAcceptableValue(optionItemIndex);
                                }}
                                data-testid='option-remove-button'
                              >
                                <span className='icon-add'>{label.plus_add}</span>
                              </button>
                            </div>
                          </div>
                          <hr></hr>
                          {item.item_json.correctResponse
                            ?.find((response) => response.id === optionItem.id)
                            .acceptableValues.map(
                              (acceptableValue, acceptableValueIndex) => (
                                <div
                                  key={acceptableValueIndex}
                                  className='row text-align-center'
                                >
                                  <div className='col'>
                                    <div className='p-2 m-2'>
                                      <input
                                        type='text'
                                        id={optionItem.id}
                                        value={acceptableValue.value || ''}
                                        onChange={(e) => {
                                          updateAcceptableValue(
                                            optionItemIndex,
                                            acceptableValueIndex,
                                            e
                                          );
                                        }}
                                        className='form-control form-control-sm mw-100'
                                      />
                                    </div>
                                  </div>
                                  <div className='col col-1'>
                                    <button
                                      className='icon'
                                      onClick={(e) => {
                                        e.preventDefault();
                                        removeAcceptableValue(
                                          optionItemIndex,
                                          acceptableValueIndex
                                        );
                                      }}
                                      data-testid='option-remove-button'
                                    >
                                      <span className='icon-minus'>-</span>
                                    </button>
                                  </div>
                                </div>
                              )
                            )}
                        </div>
                        <div className='col'>
                          <div className='row p-2 text-align-center'>
                            <div className='col text-right'>
                              <label
                                htmlFor={'correct-response-name-' + optionItem.id}
                                className='form-label text-nowrap'
                              >
                                {label.response_name}:
                                <i className='required-field text-danger ms-1'>*</i>
                              </label>
                            </div>
                            <div className='col'>
                              <input
                                type='text'
                                id={'correct-response-name-' + optionItem.id}
                                value={optionItem?.responseName || ''}
                                onChange={(e) => {
                                  let val = e.target.value;
                                  updateCorrectResponseName(optionItem.id, val);
                                }}
                                className='form-control form-control-sm'
                              />
                            </div>
                          </div>
                          <div className='row p-2 text-align-center'>
                            <div className='col text-right'>
                              <label
                                className='form-label text-nowrap'
                              >
                                {label.correct_response}:
                                <i className='required-field text-danger ms-1'>*</i>
                              </label>
                            </div>
                            <div className='col'>
                              <input
                                type='text'
                                id={
                                  item.item_json?.correctResponse?.find(
                                    (response) => response.id === optionItem.id
                                  )?.id
                                }
                                value={
                                  item.item_json?.correctResponse?.find(
                                    (response) => response.id === optionItem.id
                                  )?.value || ''
                                }
                                onChange={updateCorrectResponse}
                                className='form-control form-control-sm'
                                disabled={true}
                              />
                            </div>
                          </div>
                          <div className='row p-2 text-align-center'>
                            <div className='col p-2'>
                              <div className='row align-items-center p-1'>
                                <div
                                  className='col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end'
                                  data-testid='dd-required'
                                >
                                  <label
                                    htmlFor={'response-type-' + optionItem.id}
                                  >
                                    {label.response_type}:
                                    <i className='required-field text-danger ms-1'>*</i>
                                  </label>
                                </div>
                                <div className='col'>
                                  <select
                                    required={true}
                                    id={'response-type-' + optionItem.id}
                                    className='form-select form-select-sm mx-0'
                                    onChange={(e) => {
                                      let val = e.target.value;
                                      updateResponseType(optionItem.id, val);
                                    }}
                                    value={getResponseTypeValue(optionItem)}
                                  >
                                    {
                                      responseTypes.map((types, ind) => (
                                        <option
                                          key={types?.id || ind}
                                          value={types?.id || ''}
                                        >
                                          {types?.name}
                                        </option>
                                      ))
                                    }
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className='row p-2 text-align-center'>
                            <div className='col text-right' sm={12} md={6}>
                              <label className='form-label p-2'>
                                {label.max_characters}:
                              </label>
                            </div>
                            <div className='col'>
                              <input
                                id={optionItem.id}
                                value={optionItem.maxCharacters}
                                onChange={updateMaxCharacters}
                                min={
                                  item.item_json?.correctResponse?.find(
                                    (response) => response.id === optionItem.id
                                  )?.value?.length || defaultMaxCharacters
                                }
                                type='number'
                                className='form-control'
                              ></input>
                            </div>
                          </div>
                          <div className='row p-2 text-align-center'>
                            <div className='col text-right' sm={12} md={6}>
                              <label className='form-label p-2'>
                                {label.max_field_size}:
                              </label>
                            </div>
                            <div className='col'>
                              <input
                                id={optionItem.id}
                                value={optionItem.maxFieldSize}
                                onChange={updateMaxFieldSize}
                                min={
                                  item.item_json?.correctResponse?.find(
                                    (response) => response.id === optionItem.id
                                  )?.value?.length+2 || defaultMaxFieldSize
                                }
                                type='number'
                                className='form-control'
                              ></input>
                            </div>
                          </div>
                          <div className='row p-2 text-align-center'>
                            <div className='col text-right'>
                              <label
                                htmlFor='constructed-response-correct-response'
                                className='form-label text-nowrap p-2 pt-0'
                              >
                                {label.case_sensitive}:
                              </label>
                            </div>
                            <div className='col'>
                              <input
                                type='checkbox'
                                checked={optionItem.caseSensitive}
                                id={optionItem.id}
                                onChange={updateCaseSensitive}
                              />
                            </div>
                          </div>
                          <div className='row p-2 text-align-center'>
                            <div className='col col-sm-2 p-2'>
                              <button
                                className='btn btn-sm btn-primary'
                                onClick={() => {
                                  showHideRationale(optionItemIndex);
                                }}
                                data-testid='rationale-button'
                              >
                                {label.rationale}
                              </button>
                            </div>
                            {showRationale.indexOf(optionItemIndex) !== -1 && (
                              <div
                                className='col mc-item-box'
                                data-testid='rationale-container'
                              >
                                <CKEditorBase
                                  type='inline'
                                  data={
                                    item?.rationale?.optionList?.[optionItemIndex]?.rationaleText
                                    || ''
                                  }
                                  onChange={
                                    /* istanbul ignore next */
                                    (data) => {
                                      handleRationaleChange(
                                        data,
                                        optionItemIndex
                                      );
                                    }
                                  }
                                  placeholder={label.enter_rationale_content}
                                  config={{
                                    removePlugins: ['TagAccessibility']
                                  }}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className='col-1'>
                      <button
                        className='icon'
                        onClick={(e) => {
                          e.preventDefault();
                          removeResponse(optionItem.id);
                        }}
                        data-testid='option-remove-button'
                      >
                        <span className='icon-minus'>-</span>
                      </button>
                    </div>
                  </div>
                </fieldset>
              </div>
            </div>
          ))}

          <div className='row p-3' data-testid='cr-correct-response-container'>
            <fieldset className='bg-light p-3 rounded m-1'>
              <legend>{label.correct_response}</legend>
              <DisplayResponse
                item={item}
                config={config}
                showCorrectResponse={true}
                isPreview={false}
              />
            </fieldset>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

ConstructedResponse.propTypes = itemProps;

export default ConstructedResponse;
