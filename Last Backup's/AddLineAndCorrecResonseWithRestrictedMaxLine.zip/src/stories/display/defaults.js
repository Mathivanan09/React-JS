const generalConfig = {
    styleCode: 'general'
};

export const defaultArgs = { newItem: false, config: generalConfig };