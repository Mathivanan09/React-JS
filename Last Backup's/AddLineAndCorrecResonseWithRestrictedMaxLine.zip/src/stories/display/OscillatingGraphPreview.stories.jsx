import OscillatingGraphPreview from '../../components/display/item/oscillatinggraph/OscillatingGraphPreview';

export default {
  title: 'Display Items/OscillatingGraphPreview',
  component: OscillatingGraphPreview,
};
