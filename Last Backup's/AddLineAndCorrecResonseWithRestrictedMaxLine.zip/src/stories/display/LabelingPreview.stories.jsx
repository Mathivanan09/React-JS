import LabelingPreview from '../../components/display/item/labeling/LabelingPreview';

export default {
  title: 'Display Items/LabelingPreview',
  component: LabelingPreview
};
