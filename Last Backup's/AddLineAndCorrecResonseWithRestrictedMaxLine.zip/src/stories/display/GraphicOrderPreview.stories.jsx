import GraphicOrderPreview from '../../components/display/item/graphicorder/GraphicOrderPreview';

export default {
  title: 'Display Items/GraphicOrderPreview',
  component: GraphicOrderPreview
};
