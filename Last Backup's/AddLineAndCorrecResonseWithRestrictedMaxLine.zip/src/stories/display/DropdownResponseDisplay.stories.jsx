import data from '../assets/dd/DropDown.json';

import React from 'react';
import ItemLoader from '../ItemLoader';

export default {
  title: 'Display Items/DropdownResponse',
  component: ItemLoader
};

const Template = (args) => (
  <ItemLoader {...args} newItem={false} data={data}></ItemLoader>
);

export const Preview = Template.bind({});
