import MultiDropBucketPreview from '../../components/display/item/multidropbucket/MultiDropBucketPreview';

export default {
  title: 'Display Items/MultiDropBucketPreview',
  component: MultiDropBucketPreview
};
