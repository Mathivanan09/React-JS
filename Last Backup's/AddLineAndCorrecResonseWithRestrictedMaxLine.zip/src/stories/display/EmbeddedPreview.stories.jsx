import EmbeddedPreview from '../../components/display/item/embedded/EmbeddedPreview';

export default {
  title: 'Display Items/EmbeddedPreview',
  component: EmbeddedPreview
};
