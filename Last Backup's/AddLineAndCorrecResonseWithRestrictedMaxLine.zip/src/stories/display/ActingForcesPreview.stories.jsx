import ActingForcesPreview from '../../components/display/item/actingforces/ActingForcesPreview';

export default {
  title: 'Display Items/ActingForcesPreview',
  component: ActingForcesPreview
};
