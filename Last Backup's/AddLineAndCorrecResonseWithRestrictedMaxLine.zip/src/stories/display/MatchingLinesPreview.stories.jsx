import MatchingLinesPreview from '../../components/display/item/matchinglines/MatchingLinesPreview';

export default {
  title: 'Display Items/MatchingLinesPreview',
  component: MatchingLinesPreview
};
