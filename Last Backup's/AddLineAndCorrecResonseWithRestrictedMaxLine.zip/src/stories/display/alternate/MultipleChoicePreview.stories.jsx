import singleItem from '../../assets/mc/mc_single.json';
import multipleItem from '../../assets/mc/mc_multiple.json';
import trueFalseItem from '../../assets/mc/mc_true_false.json';
import stackedZItem from '../../assets/mc/mc_stackedZ.json';
import rightSideZItem from '../../assets/mc/mc_rightsideZ.json';
import rightSideVerticalItem from '../../assets/mc/mc_rightsideVertical.json';
import stackedVerticalItem from '../../assets/mc/mc_stackedVertical.json';
import stackedHorizontalItem from '../../assets/mc/mc_stackedHorizontal.json';

import React from 'react';
import ItemLoader from '../../ItemLoader';
import MultipleChoicePreview from '../../../components/display/item/multiplechoice/MultipleChoicePreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Display Items/Alternate/MultipleChoice',
  component: MultipleChoicePreview,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const alternateConfig = {
  styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
let defaultArgs = { newItem: false, config: alternateConfig };

const AlternateTemplate = (args) => <ItemLoader {...args}></ItemLoader>;

// Stacked Z alignement - Alternate
export const StackedZAlt = AlternateTemplate.bind({});
StackedZAlt.args = {...defaultArgs, data: stackedZItem};

// RightSideZ alignement - Alternate
export const RightSideZAlt = AlternateTemplate.bind({});
RightSideZAlt.args = {...defaultArgs, data: rightSideZItem };

// RightSideVertical alignement - Alternate
export const RightSideVerticalAlt = AlternateTemplate.bind({});
RightSideVerticalAlt.args = {...defaultArgs, data: rightSideVerticalItem };


// StackedVertical alignement - Alternate
export const StackedVerticalAlt = AlternateTemplate.bind({});
StackedVerticalAlt.args = {...defaultArgs, data: stackedVerticalItem };


// StackedHorizontal alignement - Alternate
export const StackedHorizontalAlt = AlternateTemplate.bind({});
StackedHorizontalAlt.args = {...defaultArgs, data: stackedHorizontalItem };

