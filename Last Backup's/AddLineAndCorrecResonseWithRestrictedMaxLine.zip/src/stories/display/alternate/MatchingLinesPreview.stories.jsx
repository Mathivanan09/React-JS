import React from 'react';

import MatchingLinesPreview from '../../../components/display/item/matchinglines/MatchingLinesPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/Alternate/MatchingLines',
    component: MatchingLinesPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const alternateConfig = {
    styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const AlternateTemplate = (args) => (
    <MatchingLinesPreview {...args} config={alternateConfig} />
);

// Matching Lines Preview - Alternate
export const MLPAlt = AlternateTemplate.bind({});
MLPAlt.args = require('../../assets/ml/MatchingLines.json');