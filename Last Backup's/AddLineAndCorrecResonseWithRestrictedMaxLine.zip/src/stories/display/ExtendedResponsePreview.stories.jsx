import ExtendedResponsePreview from '../../components/display/item/extendedresponse/ExtendedResponsePreview';

export default {
  title: 'Display Items/ExtendedResponsePreview',
  component: ExtendedResponsePreview
};
