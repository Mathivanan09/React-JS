import GraphingSimPreview from '../../components/display/item/graphingsimulation/GraphingSimPreview';

export default {
  title: 'Display Items/GraphingSimPreview',
  component: GraphingSimPreview
};
