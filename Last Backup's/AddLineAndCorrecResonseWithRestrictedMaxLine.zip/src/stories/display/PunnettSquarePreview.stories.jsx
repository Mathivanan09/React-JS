import PunnettSquarePreview from '../../components/display/item/punnettsquare/PunnettSquarePreview';

export default {
  title: 'Display Items/PunnettSquarePreview',
  component: PunnettSquarePreview,
};
