import ChemistrySimulationPreview from '../../components/display/item/chemistrysimulation/ChemistrySimulationPreview';

export default {
  title: 'Display Items/ChemistrySimulationPreview',
  component: ChemistrySimulationPreview
};
