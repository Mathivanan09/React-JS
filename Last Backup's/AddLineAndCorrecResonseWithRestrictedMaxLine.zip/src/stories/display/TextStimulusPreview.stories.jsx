import textStimuluslItem from '../assets/ts/TextStimulus.json';

import React from 'react';
import ItemLoader from '../ItemLoader';

export default {
  title: 'Display Items/TextStimulus',
  component: ItemLoader
};

const generalConfig = {
  styleCode: 'general'
};

let defaultArgs = { newItem: false, config: generalConfig };

const Template = (args) => <ItemLoader {...args}></ItemLoader>;

export const Preview = Template.bind(defaultArgs);
Preview.args = { ...defaultArgs, data: textStimuluslItem }