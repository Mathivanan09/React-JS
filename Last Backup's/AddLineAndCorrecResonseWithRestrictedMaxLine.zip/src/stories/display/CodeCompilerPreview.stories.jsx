import CodeCompilerPreview from '../../components/display/item/codecompiler/CodeCompilerPreview';

export default {
  title: 'Display Items/CodeCompilerPreview',
  component: CodeCompilerPreview
};
