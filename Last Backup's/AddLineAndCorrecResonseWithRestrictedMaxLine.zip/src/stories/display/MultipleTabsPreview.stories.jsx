import MultipleTabsPreview from '../../components/display/item/multipletabs/MultipleTabsPreview';

export default {
  title: 'Display Items/MultipleTabsPreview',
  component: MultipleTabsPreview
};
