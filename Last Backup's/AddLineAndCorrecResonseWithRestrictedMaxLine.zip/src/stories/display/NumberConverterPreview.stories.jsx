import NumberConverterPreview from '../../components/display/item/numberconverter/NumberConverterPreview';

export default {
  title: 'Display Items/NumberConverterPreview',
  component: NumberConverterPreview,
};
