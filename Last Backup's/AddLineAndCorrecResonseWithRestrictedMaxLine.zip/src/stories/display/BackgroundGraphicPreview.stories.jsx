import BackgroundGraphicPreview from '../../components/display/item/backgroundgraphic/BackgroundGraphicPreview';

export default {
  title: 'Display Items/BackgroundGraphicPreview',
  component: BackgroundGraphicPreview
};
