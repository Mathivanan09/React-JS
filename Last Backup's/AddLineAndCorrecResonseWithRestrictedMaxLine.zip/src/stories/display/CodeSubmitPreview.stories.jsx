import CodeSubmitPreview from '../../components/display/item/codesubmit/CodeSubmitPreview';

export default {
  title: 'Display Items/CodeSubmitPreview',
  component: CodeSubmitPreview
};
