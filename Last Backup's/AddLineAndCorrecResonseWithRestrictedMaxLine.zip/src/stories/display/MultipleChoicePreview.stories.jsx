import MultipleChoicePreview from '../../components/display/item/multiplechoice/MultipleChoicePreview';

export default {
  title: 'Display Items/MultipleChoice',
  component: MultipleChoicePreview,
};
