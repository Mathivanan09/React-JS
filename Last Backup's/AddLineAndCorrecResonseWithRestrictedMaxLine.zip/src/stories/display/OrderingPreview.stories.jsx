import OrderingPreview from '../../components/display/item/ordering/OrderingPreview';

export default {
  title: 'Display Items/OrderingPreview',
  component: OrderingPreview
};
