import ConstructedResponsePreview from '../../components/display/item/constructedresonse/ConstructedResponsePreview';

export default {
  title: 'Display Items/ConstructedResponsePreview',
  component: ConstructedResponsePreview
};
