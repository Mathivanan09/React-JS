import React from 'react';

// Existing Dummy Item Types Category (like questions)
import DummyItems from "../assets/com/DummyItems.json";

import MCMS from "../assets/mc/mc_multiple.json";
import TF from "../assets/mc/mc_true_false.json";
import TCC_TWO from "../assets/tcc/tcc_two_column.json";
import TCC_THREE from "../assets/tcc/tcc_three_column.json";
import CreateInterface from '../../components/create/CreateInterface';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Interfaces/CreateInterface',
  component: CreateInterface,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const generalConfig = {
  styleCode: 'general'
};

const alternateConfig = {
  styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template = (args) => <CreateInterface config={generalConfig} {...args} />;

export const MultipleChoiceGeneral = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
MultipleChoiceGeneral.args = {
  item: { item_json: { itemTypeCode: 'mc' } },
  onUpdate: (content) => {
    console.log(content);
  }
};

// Create Interface with TwoColumnClick
export const TwoColumnClick = Template.bind({});
TwoColumnClick.args = {
  item: { id: -1, item_json: { itemTypeCode: 'tcc' } },
  onUpdate: (content) => {
    console.log(content);
  }
};

export const DropdownResponse = Template.bind({});
DropdownResponse.args = {
  item: { item_json: { itemTypeCode: 'dd' } },
  onUpdate: (content) => {
    console.log(content);
  }
};

let compositeItem = JSON.parse(
  JSON.stringify({
    ...require('../assets/com/CompositeItems.json')
  })
);

compositeItem.item.item_json.itemList = [];

export const CompositeItems = Template.bind({});
CompositeItems.args = {
  ...compositeItem,
  config: {
    fetchItems: async (categoryCodes, excludeIds, callback) => {
      const savedItemList = DummyItems;
      savedItemList[0] = { ...savedItemList[0], ...TCC_THREE?.item };
      savedItemList[1] = { ...savedItemList[1], ...TCC_TWO?.item };
      savedItemList[2] = { ...savedItemList[2], ...MCMS?.item };
      savedItemList[3] = { ...savedItemList[3], ...TF?.item };
      if (categoryCodes.includes('question')) {
        const questions = savedItemList?.filter((item) =>
          item.id && item?.category &&
          excludeIds?.includes(item.id) === false &&
          categoryCodes.includes(item?.category)
        ) || [];
        callback(questions);
      }
    }
  },
  onUpdate: (data) => {
    console.log(data);
  }
};
