import React from 'react';
import MCMS from "../assets/mc/mc_multiple.json";
import TF from "../assets/mc/mc_true_false.json";
import DisplayInterface from '../../components/display/DisplayInterface';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Interfaces/DisplayInterface',
  component: DisplayInterface,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
  }
};

const generalConfig = {
  styleCode: 'general'
};

const alternateConfig = {
  styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template = (args) => <DisplayInterface config={generalConfig} {...args} />;

export const MultipleChoiceGeneral = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
MultipleChoiceGeneral.args = require('../assets/mc/mc_single.json')

const AlternateTemplate = (args) => <DisplayInterface config={alternateConfig} {...args} />;
export const MultipleChoiceAlternate = AlternateTemplate.bind({});
MultipleChoiceAlternate.args = require('../assets/mc/mc_single.json')

export const TwoColumnClick = Template.bind({});
TwoColumnClick.args = require('../assets/tcc/tcc_two_column.json')

export const DropdownResponse = Template.bind({});
DropdownResponse.args = require('../assets/dd/DropDown.json')

const compositeItem = {
  ...require('../assets/com/CompositeItems.json')
};

compositeItem.item.item_json.itemList = [
  { ...MCMS?.item },
  { ...TF?.item }
];

export const CompositeItemsGeneral = Template.bind({});
CompositeItemsGeneral.args = {
  ...compositeItem,
  onUpdate: (data) => {
    console.log(data)
  }
};

export const CompositeItemsAlternate = AlternateTemplate.bind({});
CompositeItemsAlternate.args = {
  ...compositeItem,
  onUpdate: (data) => {
    console.log(data)
  }
};

export const ExtendedResponseRightSideAlignment = Template.bind({});
ExtendedResponseRightSideAlignment.args = {
  ...require('../assets/er/ExtendedResponse.json'),
  onUpdate: (data) => {
    console.log(data)
  }
};

export const ExtendedResponseVerticalStacked = Template.bind({});
ExtendedResponseVerticalStacked.args = {
  ...require('../assets/er/ExtendedResponseVerticalStack.json'),
  onUpdate: (data) => {
    console.log(data)
  }
};
