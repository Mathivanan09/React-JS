import React from 'react';

// Existing Dummy Item Types Category (like questions)
import DummyItems from "../assets/com/DummyItems.json";

import MCMS from "../assets/mc/mc_multiple.json";
import TF from "../assets/mc/mc_true_false.json";
import TCC_TWO from "../assets/tcc/tcc_two_column.json";
import TCC_THREE from "../assets/tcc/tcc_three_column.json";
import ER from "../assets/er/ExtendedResponse.json";
import PNP from "../assets/er/ExtendedResponsePaperNPencil.json";
import PreviewInterface from '../../components/display/PreviewInterface';
import ST from '../assets/st/select_text_manual_selection.json';

export default {
  title: 'Interfaces/Preview',
  component: PreviewInterface,
  argTypes: {}
};

const generalConfig = {
  styleCode: 'general',
  clickHistoryRequired: true
};

const alternateConfig = {
  styleCode: 'alternate'
};

const onUpdate = (data) => {
  console.log(data)
}

const GeneralTemplate = (args) => {
  let config = { generalConfig };
  if (args.config) {
    config = { ...config, ...args.config };
  }
  return (
    <PreviewInterface {...args} config={config} />
  )
};
const AlternateTemplate = (args) => {
  let config = { alternateConfig };
  if (args.config) {
    config = { ...config, ...args.config };
  }
  return (
    <PreviewInterface {...args} config={config} />
  )
};

export const MultipleChoiceMultiple = GeneralTemplate.bind({});
MultipleChoiceMultiple.args = require('../assets/mc/mc_multiple.json');

export const MultipleChoiceSingle = GeneralTemplate.bind({});
MultipleChoiceSingle.args = require('../assets/mc/mc_single.json');

export const MultipleChoiceTrueFalse = GeneralTemplate.bind({});
MultipleChoiceTrueFalse.args = require('../assets/mc/mc_true_false.json');

export const MultipleChoiceMultipleAlt = AlternateTemplate.bind({});
MultipleChoiceMultipleAlt.args = require('../assets/mc/mc_multiple.json');

export const MultipleChoiceSingleAlt = AlternateTemplate.bind({});
MultipleChoiceSingleAlt.args = require('../assets/mc/mc_single.json');

export const MultipleChoiceTrueFalseAlt = AlternateTemplate.bind({});
MultipleChoiceTrueFalseAlt.args = require('../assets/mc/mc_true_false.json');

// Two Column Click
export const TwoColumnClickPreviewGeneral = GeneralTemplate.bind({});
TwoColumnClickPreviewGeneral.args = require('../assets/tcc/tcc_two_column.json');

export const ThreeColumnClickPreviewGeneral = GeneralTemplate.bind({});
ThreeColumnClickPreviewGeneral.args = require('../assets/tcc/tcc_three_column.json');

export const TwoColumnClickPreviewAlternate = AlternateTemplate.bind({});
TwoColumnClickPreviewAlternate.args = require('../assets/tcc/tcc_two_column.json');

export const ThreeColumnClickPreviewAlternate = AlternateTemplate.bind({});
ThreeColumnClickPreviewAlternate.args = require('../assets/tcc/tcc_three_column.json');

const compositeItem = {
  ...require('../assets/com/CompositeItems.json')
};

const savedItemList = DummyItems;
savedItemList[0] = { ...savedItemList[0], ...TCC_THREE?.item };
savedItemList[1] = { ...savedItemList[1], ...TCC_TWO?.item };
savedItemList[2] = { ...savedItemList[2], ...MCMS?.item };
savedItemList[3] = { ...savedItemList[3], ...TF?.item };

compositeItem.item.item_json.itemList = savedItemList?.filter((item) => item.id && item?.category === 'question') || [];

export const CompositeItemsPreviewGeneral = GeneralTemplate.bind({});
CompositeItemsPreviewGeneral.args = {
  ...compositeItem,
  onUpdate
}

export const CompositeItemsPreviewAlternate = AlternateTemplate.bind({});
CompositeItemsPreviewAlternate.args = {
  ...compositeItem,
  onUpdate
}

export const ExtendedResponsePreviewGeneral = GeneralTemplate.bind({});
ExtendedResponsePreviewGeneral.args = {
  ...ER,
  onUpdate
}

export const ExtendedResponsePreviewAlternate = AlternateTemplate.bind({});
ExtendedResponsePreviewAlternate.args = {
  ...ER,
  onUpdate
}

export const ExtendedResponsePreviewPaperAndPencil = GeneralTemplate.bind({});
ExtendedResponsePreviewPaperAndPencil.args = {
  ...PNP,
  onUpdate
}

export const ManualSelectTextPreview = GeneralTemplate.bind({});
ManualSelectTextPreview.args = {
  ...ST,
  onUpdate
}