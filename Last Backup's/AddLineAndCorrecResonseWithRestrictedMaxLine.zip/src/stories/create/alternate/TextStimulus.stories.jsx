import React from 'react';

import TextStimulus from '../../../components/create/textstimulus/TextStimulus';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/Alternate/TextStimulus',
    component: TextStimulus,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const alternateConfig = {
    styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateAlt = (args) => <TextStimulus {...args} config={alternateConfig} />;

// Text Stimulus alternate
export const TSAlternate = TemplateAlt.bind({});
TSAlternate.args = {
    item: { item_json: { itemTypeCode: 'ts' } },
    onUpdate: (content) => {
        console.log(content);
    }
};