import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/ChemistrySimulation',
  component: ItemLoader
};
