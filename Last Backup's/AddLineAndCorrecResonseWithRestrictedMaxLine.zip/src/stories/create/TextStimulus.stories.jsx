import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/TextStimulus',
  component: ItemLoader
};

const Template = (args) => (
  <ItemLoader
    {...args}
    newItem={true}
    data={{
      item: {
        id: -1,
        name: '',
        assessment_program_id: 0,
        item_type_id: 0,
        item_type_code: '',
        item_json: {
          itemTypeCode: 'ts',
        },
        user_id: 0
      }
    }}
  ></ItemLoader>
);

export const NewItem = Template.bind({});