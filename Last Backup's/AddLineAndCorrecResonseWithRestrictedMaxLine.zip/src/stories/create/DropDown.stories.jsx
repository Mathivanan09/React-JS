import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/DropDown',
  component: ItemLoader
};
