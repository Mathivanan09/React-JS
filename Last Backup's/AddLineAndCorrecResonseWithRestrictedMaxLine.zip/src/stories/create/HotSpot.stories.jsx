import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/HotSpot',
  component: ItemLoader
};
