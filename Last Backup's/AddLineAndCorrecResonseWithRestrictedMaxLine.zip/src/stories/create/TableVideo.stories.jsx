import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/TableVideo',
  component: ItemLoader
};
