import React from 'react';

import TextStimulus from '../../../components/create/textstimulus/TextStimulus';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/KELPA_Grade_K-1/TextStimulus',
    component: TextStimulus,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG1Config = {
    styleCode: 'kelpa_grade_k_1'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG1 = (args) => <TextStimulus {...args} config={kelpaG1Config} />;

// Text Stimulus kelpaG1
export const TSKelpaG1 = TemplateKelpaG1.bind({});
TSKelpaG1.args = {
    item: { item_json: { itemTypeCode: 'ts' } },
    onUpdate: (content) => {
        console.log(content);
    }
};