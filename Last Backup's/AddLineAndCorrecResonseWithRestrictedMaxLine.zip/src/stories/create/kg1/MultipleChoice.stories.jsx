import React from 'react';

import MultipleChoice from '../../../components/create/multiplechoice/MultipleChoice';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Create Items/KELPA_Grade_K-1/MultipleChoice',
  component: MultipleChoice,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const kelpaG1Config = {
  styleCode: 'kelpa_grade_k_1'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG1 = (args) => <MultipleChoice {...args} config={kelpaG1Config}/>;

// multiple choice kelpaG1
export const MCKelpaG1 = TemplateKelpaG1.bind({});
MCKelpaG1.args = {
  item: { item_json: { itemTypeCode: 'mc' } },
  onUpdate: (content) => {
    console.log(content);
  }
};