import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/CodeSubmit',
  component: ItemLoader
};
