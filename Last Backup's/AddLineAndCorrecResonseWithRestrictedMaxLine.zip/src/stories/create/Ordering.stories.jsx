import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/Ordering',
  component: ItemLoader
};
