import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/MultipleChoice',
  component: ItemLoader
};
