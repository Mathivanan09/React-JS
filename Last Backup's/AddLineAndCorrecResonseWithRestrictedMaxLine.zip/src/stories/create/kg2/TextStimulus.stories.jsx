import React from 'react';

import TextStimulus from '../../../components/create/textstimulus/TextStimulus';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/KELPA_Grade_2-3/TextStimulus',
    component: TextStimulus,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG2Config = {
    styleCode: 'kelpa_grade_2_3'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG2 = (args) => <TextStimulus {...args} config={kelpaG2Config} />;

// Text Stimulus kelpaG2
export const TSKelpaG2 = TemplateKelpaG2.bind({});
TSKelpaG2.args = {
    item: { item_json: { itemTypeCode: 'ts' } },
    onUpdate: (content) => {
        console.log(content);
    }
};