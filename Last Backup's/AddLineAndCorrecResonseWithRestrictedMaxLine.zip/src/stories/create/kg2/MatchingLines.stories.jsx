import React from 'react';

import ML from '../../assets/ml/MatchingLines.json';
import MatchingLines from '../../../components/create/matchinglines/MatchingLines';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/KELPA_Grade_2-3/MatchingLines',
    component: MatchingLines,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG2Config = {
    styleCode: 'kelpa_grade_2_3'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG2 = (args) => <MatchingLines {...args} config={kelpaG2Config} />;

// Matching Lines kelpaG2
export const MLKelpaG2 = TemplateKelpaG2.bind({});
MLKelpaG2.args = {
    item: {
        ...ML
    },
    onUpdate: (content) => {
        console.log(content);
    }
};