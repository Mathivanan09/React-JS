export default {
  // Normal/Common Label
  name: 'Name',
  status: 'Status',
  stem: 'Stem',
  stem_placeholder: 'Enter stem content',
  item_min_height: 'Height',
  item_min_width: 'Width',
  item_dim: 'Minimum Item Dimensions',
  drop_down_placeholder: 'Select',
  correct_response: 'Correct Response',
  answer_alignment: 'Response Alignment',
  yes: 'Yes',
  no: 'No',
  response_name: 'Response Name',
  plus_add:'+ Add',
  rationale: 'Rationale',
  enter_rationale_content: 'Rationale',
  add: 'Add',
  okay: 'Okay',
  cancel: 'Cancel',
  add_items: 'Add Items',
  available_media: 'Available Media',
  available_items: 'Available Items',
  missing_item_data: 'Missing item data',

  // af
  af_add_image: 'Select Image',
  af_add_Symbol: '+ Add Symbol',

  // Multiple Choice
  multiple_choice_selection: 'Response Type/Selection',
  multiple_choice_single_select: 'Single Select',
  multiple_choice_multi_select: 'Multi Select',
  multiple_choice_true_false_select: 'True/False',
  response_options: 'Response Option',
  multiple_choice_shuffle_option: 'Shuffle',
  multiple_choice_feedback_option: 'Response Feedback',
  multiple_choice_add_options: '+ Add Response Options',
  mc_correct: 'Correct',
  enter_response_content: 'Enter response option content',
  enter_table_header: 'Enter table header',
  enter_feedback_content: 'Feedback',
  multiple_choice_feedback: 'Feedback',
  multiple_choice_choice_options: 'Required Choice Options',
  multiple_choice_selection_required: 'Responses Required',
  multiple_choice_selection_allowed: 'Responses Allowed',
  response_labels: 'Response Labels',

  // Maze Runner
  maze_interaction_design: 'Maze Interaction Design',

  // Two Column Click
  two_column_click_title: 'Title',
  two_column_click_col_type: 'Number of Levels',
  two_column_click_col_width: 'Column Widths(%)',
  two_column_click_add_tab: '+ Add Tab',
  two_column_click_add_sub_tab: '+ Add Subtab',
  two_column_click_tab_placeholder: 'Level',
  two_column_click_tab_alignment: 'Tab Alignment',

  // Constructed Response
  response: 'Response',
  response_type: 'Response Type',
  acceptable_values: 'Acceptable Values',
  max_characters: 'Max Characters',
  max_field_size: 'Max Field Size',
  case_sensitive: 'Case Sensitive',

  // Validation Label
  invalid_chars: 'Value contains invalid characters',

  // Stories Label
  noSpecialChars: 'No Special Characters or Space Allowed',

  // Preview Label
  display_correct_response: 'Display Correct Response',

  // Extended Response
  enable_spell_check: 'Enable SpellCheck',
  expected_lines: 'Expected Lines',
  er_answer_alignment: 'Response Alignment',

  // Dropdown response Labels
  dd_options: 'Dropdown Options',
  dd_default_value: 'Default Value',

  // Text Stimulus
  enter_content: 'Enter Content',
  genre: 'Genre',
  description_viewed: 'Description Viewed By',
  description: 'Description',
  source: 'Source',
  publisher: 'Publisher',
  author: 'Author',
  begin_date: 'Term Begin Date',
  end_date: 'Term End Date',
  citation: 'Citation and/or Url',
  acknowledgement: 'Acknowledgement',

  // matrix interaction
  response_layout: 'Response Layout',
  configuration: 'Configuration',

  // Select Text Label
  selection_type: 'Selection Type',
  border_at_start: 'Border at Start',
  highlight_at_start: 'Highlight at Start',
  border_on_hover: 'Border on Hover',
  highlight_on_hover: 'Highlight on Hover',
  border_on_select: 'Border on Select',
  hightlight_on_select: 'Highlight on Select',
  st_add_option: 'Rationale',
  bolded_border_on_select: 'Bolded Border on Select',
  max_response_selection: 'Max Response Selection',
  response_passage: 'Response Passage',
  enter_passage_content: 'Enter Passage Content',

  // Ordering
  ordering_choice_options: 'Response Type/Selection',
  ordering_add_options: '+ Add Response Options',
  ord_initial_view: "Student's Initial View",
  ord_set_correct_response: 'Drag to set correct response',
  st_add_option: "Rationale",
  response_option_width:'Response Option Width',
  response_option_height:'Response Option Height',

  // Background Graphic
  background_alignment: 'Background Alignment',
  select_image: 'Select Image',
  background_image: 'Background Image',
  reusable_response: 'Reusable Response',
  drop_zone_height: 'Drop Zone Height',
  drop_zone_width: 'Drop Zone Width',
  invisible_dropzones: 'Invisible Dropzones',

  // Table Video Simulation
  tvs_input_option_title_placeholder: "Enter input title",
  tvs_output_title_placeholder: "Enter output title",
  tvs_output_value_placholder: "Enter output value",
  tvs_input_option_placholder: "Enter option text",
  tvs_input_label: 'Inputs',
  tvs_output_label: 'Outputs',
  tvs_input_options_label: 'Options',
  tvs_simulations_label: 'Simulations',
  tvs_display_table: 'Display Output Table',
  tvs_default_image: 'Default Media',
  tvs_select_media: 'Select Media',
  tvs_plus_add_input: '+ Add Input',
  tvs_inputs_empty_state: 'No Input created please click +Add Input to create simulation input',
  tvs_plus_add_output: '+ Add Output',
  tvs_output_empty_state: 'please click +Add Output to add output',

  // Matching Lines
  ml_width: 'Width',
  ml_height: 'Height',
  ml_left_column_header: 'Enter left column header',
  ml_right_column_header: 'Enter right column header',
  ml_left_column_options: 'Enter left response text',
  ml_right_column_options: 'Enter right response text',
  ml_rationale: 'Rationale',

  // Speech Interaction
  attempts_allowed: 'Attempts Allowed',
  seconds_allowed_per_attempt: 'Seconds Allowed Per Attempt',
  retain_all_attempts: 'Retain All Attempts',

//Straight Line
rationale : 'Rationale',
incremental_label: 'Increment Label',
addLine: "+ Add Line"


};
