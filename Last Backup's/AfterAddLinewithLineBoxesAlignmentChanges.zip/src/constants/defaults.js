// common default data that can be used across the application regardless of item (which does not need any advance configurations/filter).
export default {
    'multiple_choice_no_shuffle': true,
    'multiple_choice_no_feedback': true,
    'response_labels': 'No Response Label',
    'answer_alignment': 'right_vertical_stacked',
    'selection_type': 'multiple',
    'text-stimulus-description': [
        { id: 'TS_EDUCATOR', name: 'Educator' },
        { id: 'TS_PROCTOR', name: 'Proctor' }
    ],
    'answerAlignment': 'Vertical',
    //Matching Lines
    'min-option-width': 40,
    'max-option-width': 550,
    'min-option-height': 30,
    'max-option-height': 400,
    'default-width': 150,
    'default-height': 35,
    // Extended Response
    'enable_spell_check': true,
    'expected_lines': '20LINES_EXT',
    'er_answer_alignment': 'vertical_stacked',
    //Background Graphic 
    'bg-default-option-width': 150,
    'bg-default-option-height': 50,
   //Speech Interaction
    'defaultTimeAllowed':5,    
    'minTimeAllowed': 1,
    'maxTimeAllowed': 300,    
    'noOfAttempt': 1,
    'maxNoOfAttempt': 15,
    'cr-max-characters': 15,
    'cr-max-field-size': 15,
	//Two Column Click
    'two-column-column1': '50',
    'two-column-column2': '50',
    'three-column-column1': '34',
    'three-column-column2': '33',
    'three-column-column3': '33'
}
