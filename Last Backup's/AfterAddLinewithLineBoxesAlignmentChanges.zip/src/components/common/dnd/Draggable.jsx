import React, { forwardRef } from 'react';
import styles from './Draggable.module.css';
import parse from 'html-react-parser';

const Draggable = (
  {
    dragOverlay,
    dragging,
    handle,
    label,
    listeners,
    transform,
    createComponent,
    style,
    id,
    buttonStyle,
    ...props
  },
  ref
) => {
  const border = createComponent||dragging ? '1px solid #000' : 'none';
  return (
    <>
      <div
        className={'Draggable dragOverlay dragging'}
        style={{
          ...style,
         zIndex: dragging ? '1' : '0',
          height: `${style?.height}px`, width: `${style?.width}px`,
          '--translate-x': `${transform?.x ?? 0}px`,
          '--translate-y': `${transform?.y ?? 0}px`,
        }}
      >
        <div
          {...props}
          id={id}
          className={createComponent?'bg-create-draggable':'bg-preview-draggable'}
          style={{
            height: `${style?.height}px`, width: `${style?.width}px`,
            border: border,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
          aria-label='Draggable'
          data-cypress='draggable-item'
          data-testid='bggraphic-optionItem'
          {...(handle ? {} : listeners)}
          tabIndex={handle ? -1 : undefined}
          ref={ref}
        >
          {label ? parse(label) : null}
        </div>
      </div>
    </>
  );
};

export default forwardRef(Draggable);
