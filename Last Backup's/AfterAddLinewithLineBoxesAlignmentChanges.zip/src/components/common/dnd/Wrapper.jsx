import React from 'react';

import styles from './Wrapper.module.css';

const Wrapper = ({ children, center, style }) => {
  return (
    <div className={'Wrapper'}>
      {children}
    </div>
  );
};
export default Wrapper;
