import React, { useState } from 'react';
import { DndContext, DragOverlay, useDraggable } from '@dnd-kit/core';

import Droppable from './Droppable';
import Draggable from './Draggable';
import Wrapper from './Wrapper';
import DraggableItem from './DraggableItem';
import parse from 'html-react-parser';
import SortableItem from './SortableItem';
const DroppableContainer = ({
  containers,
  collisionDetection,
  modifiers,
  item,
  isDragging,
  parent
}) => {

  const getText = (id) => {
    let rItem = item?.item_json?.correctResponse?.find(
      (crItem) => crItem.id === id
    );
    let text = item?.item_json?.optionList?.find(
      (rowItem) =>{
        return rowItem.id === rItem?.id;
      }
    )?.optionText;
    return parse(text || '');
  }

  return (
    <Wrapper>
      {item?.item_json?.matchList?.map((dropItem) => (
        <Droppable
          key={dropItem.id}
          id={dropItem.id}
          dragging={isDragging}
          coordinates={dropItem.coordinates}
          dropzoneHeight={item?.item_json?.dropzoneHeight}
          dropzoneWidth={item?.item_json?.dropzoneWidth}
        >
          {parent === dropItem.id ? (
            <SortableItem id={dropItem.id}
                          key={dropItem.id}
                          optionText={getText(dropItem.id)}/>
          ) : null}
        </Droppable>
      ))}
    </Wrapper>
  );
};

export default DroppableContainer;
