import React, { useState, useEffect, useRef } from 'react';

import '../../../styles/bootstrap/formElements.css';

/**
 * TagsInput is a react functional wrapper component with bootstrap
 * to create TagsInput (tagged input)
 * 
 * @inner
 * @memberof BasicInputComponents
 * 
 * @namespace TagsInput
 * 
 * @param {array} tagNames - Tagged Input(s)
 * @param {function} onTagChange -  (add or remove) onChange function for tagInputs
 * @param {html} value - HTML input element's value where user can type
 * @param {function} onKeyDown - HTML input element's onKeyDown function which will trigger
 * when user types
 * @param {object} props - pass HTML input element's and/or bootstrap related attribute as
 * props such as id, class, name, etc...
 * @return {html} TagsInput (tagged input)
 *
 * Example
    <TagsInput
        tagNames={["Bootstrap", "TagsInput"]}
        placeholder="Tagged Input(s)"
        onTagChange={()=> {
            //...
        }}
    />
 */
const TagsInput = React.forwardRef(
  ({ tagNames, onTagChange, value, onKeyDown, ...props }, ref) => {
    const [tags, setTags] = useState(tagNames || []);
    const tagInput = useRef(ref || null);

    const removeTag = (event, index) => {
      if (tags) {
        const opt = tags[index];
        if (opt !== undefined) {
          if (
            typeof onTagChange === 'function' &&
            event?.target?.value !== undefined
          ) {
            const del = { ...event };
            del.target.value = opt;
            onTagChange(del);
          }
          const newTags = [...tags];
          newTags.splice(index, 1);
          setTags(newTags);
        }
      }
    };

    const customKeyDown = (e) => {
      if (typeof onKeyDown === 'function') {
        onKeyDown(e);
      }
    };

    const inputKeyDown = (e) => {
      let val = e?.target?.value;
      if (e?.key === 'Enter' && val) {
        if (typeof onTagChange === 'function') {
          const suggestion = onTagChange(e);
          if (!suggestion) {
            customKeyDown(e);
            return;
          }
          if (suggestion) {
            val = suggestion;
          }
        }
        const index = tags?.findIndex((key) => key === val);
        if (index !== -1) {
          customKeyDown(e);
          return;
        }
        if (tagInput?.current?.value !== undefined) {
          tagInput.current.value = null;
        }
        setTags([...tags, val]);
      } else if (e?.key === 'Backspace' && !val) {
        removeTag(e, tags?.length - 1);
      }
      customKeyDown(e);
    };

    useEffect(() => {
      setTags(tagNames || []);
    }, [tagNames]);

    return (
      <div className='input-tag'>
        <ul className='input-tag-filter'>
          {tags?.map((tag, i) => (
            <li key={tag}>
              {tag}
              <button
                type='button'
                onClick={(e) => {
                  removeTag(e, i);
                }}
              >
                +
              </button>
            </li>
          ))}
          <li className='input-tag-filter-input'>
            <input
              className='form-control'
              value={value}
              type='text'
              {...props}
              onKeyDown={inputKeyDown}
              ref={tagInput}
            />
          </li>
        </ul>
      </div>
    );
  }
);

export default TagsInput;
