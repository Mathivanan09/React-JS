import React from 'react';
import PropTypes from 'prop-types';

import label from '../../../constants/labelCodes';

import '../../../styles/bootstrap/label.css';

/** 
 * Label is a React functional wrapper component of the boostrap label (based on the code/customLabel)
 * 
 * @inner
 * @memberof BasicInputComponents
 * 
 * @namespace Label
 * @param {string} code - mandatory, the key to show/return the label
 * @param {string} id - optional, the id of the label to show/return
 * @param {string} key - optional, react key attribute can be used for uniquely identifying items 
 * and rendered as a list
 * @param {string} className - optional, can specify additional classname, to modify the behaviour.
 * @param {boolean} addColon - optional, return with/without colon symbol using CSS
 * @param {string} customLabel - optional, return the custom label with HTML label 
 * where the custom label is generated dynamically.
 * @param {string} htmlFor - optional, used connect with input and label (can be pass this, 
 * when the label is calling separately)
 * @return {HTML} return Label with its respective changes based on the props (or) 
 * if there is no customLabel/code data then return user friendly screen label error message
 * 
 * Example: 
 * 
 * <Label code='name' /> (or)
 * <Label code='name' id='' className='' addColon={true} /> (or)
 * <Label 
        customLabel='Custom Label' 
        id='' 
        key='' 
        className='' 
        addColon={false} 
    >
 */
const Label = ({
  code,
  id,
  key,
  className,
  addColon,
  customLabel,
  ...props
}) => {
  let classes = className || '';
  classes += ' form-label';
  if (addColon && classes.indexOf('label-add-colon') === -1) {
    classes += ' label-add-colon ';
  }
  
  classes = classes?.trim() || undefined;

  return (
    <label {...props} id={id} key={key} className={classes}>
      {customLabel || label[code]}
    </label>
  );
};

Label.propTypes = {
  code: PropTypes.string,
  id: PropTypes.string,
  key: PropTypes.string,
  className: PropTypes.string,
  addColon: PropTypes.bool,
  customLabel: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.elementType
  ])
};

export default Label;
