import PropTypes from 'prop-types';

export const itemProps = {
    item: PropTypes.any,
    onUpdate: PropTypes.func,
    config: PropTypes.object,
    api: PropTypes.object
}

export const itemPreviewProps = {
    item: PropTypes.object,
    onUpdate: PropTypes.func,
    config: PropTypes.object,
    clickHistory: PropTypes.object,
    onClickHistoryUpdate: PropTypes.func,
    showCorrectResponse: PropTypes.bool
}