import React from 'react';
import PropTypes from 'prop-types';

import label from '../../constants/labelCodes';
import messages from '../../constants/messages';

/**
 * React functional Component where return the messages based on the key
 * 
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace MessagePreview
 * @param {{ code: string, onClose: function, onCancel: function, customMessage: string,
 * header: string, showHideFlag: boolean}} param passed in parameters
 * @param {string} param.code Mandatory, the key to show/return the Message, and used
 * connect with input using HTMLfor as well
 * @param {function} param.onClose Optional, method to execute on Okay Click
 * @param {function} param.onCancel Optional, method to execute on Cancel Click
 * @param {string} param.customMessage Optional, If Organisation has custom messages
 * that will be passed in this attribute.
 * @param {string} param.header Optional, If message popup has any header,
 * this attribute holds the header value
 * @param {boolean} param.showHideFlag Mandatory, Flag to hide show model
 * @return {MessagePreview} HTML Label with its respective changes
 * @example
 * <MessagePreview
    code={'mc_maximum_selected'}
    showHideFlag={showMessage}
    onCancel={() => {
      setShowMessage(false);
    }}
    onClose={() => {
      setShowMessage(false);
    }}
  />
 */

const MessagePreview = ({
  code,
  onClose,
  onCancel,
  customMessage,
  header,
  showHideFlag
}) => {
  /**
   * This Handle Close will close the popup and executes onClose attribute passed to it if any.
   *
   * @inner
   * @memberof MessagePreview
   */
  const handleClose = () => {
    onClose && onClose();
  };

  // /**
  //  * This Handle Cancel will close the popup and executes onCancel attribute passed to it if any.
  //  *
  //  * @inner
  //  * @memberof MessagePreview
  //  */
  // const handleCancel = () => {
  //   onCancel && onCancel();
  // };

  return (
    <div data-testid='message-preview-container'>
      {showHideFlag ?
        <>
          <div className='fade modal-backdrop show'></div>
          <div
            className='modal show'
            tabIndex='-1'
            aria-modal='true'
            aria-labelledby='preview-warning-message'
            role='dialog'
            style={{ display: 'block' }}
          >
            <div className='modal-dialog modal-dialog-centered'>
              <div className='modal-content'>
                <div className='modal-header'>
                  <div className='modal-title'>{header}</div>
                </div>
                <div className='modal-body' id='preview-warning-message'>{customMessage || messages[code]}</div>{' '}
                <div className='modal-footer'>
                  <button
                    type='button'
                    className='btn btn-primary'
                    variant='primary'
                    data-testid='mp-okay-button'
                    onClick={handleClose}
                  >
                    {label.okay}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
        :
        <></>
      }
    </div>
  );
};

MessagePreview.propTypes = {
  code: PropTypes.string,
  onClose: PropTypes.func,
  onCancel: PropTypes.func,
  customMessage: PropTypes.string,
  header: PropTypes.string,
  showHideFlag: PropTypes.bool
};

export default MessagePreview;
