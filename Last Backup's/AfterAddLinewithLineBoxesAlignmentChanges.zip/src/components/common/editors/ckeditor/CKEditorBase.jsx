import React, { useState } from 'react';
import { CKEditor } from '@ckeditor/ckeditor5-react';

// NOTE: We use editor from source (not a build)!
import WProofreader from '@webspellchecker/wproofreader-ckeditor5/src/wproofreader';
import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';
import InlineEditor from '@ckeditor/ckeditor5-editor-inline/src/inlineeditor';
import PropTypes from 'prop-types';
import defaultEditorConfig from './editorConfig';
import Delayed from './Delayed';
import AddMedia from '../../../../components/create/shared/AddMedia';

// custom styles
import '../../../../styles/common/ckeditor-custom.css';

/**
 * React functional component with the custom CKEditor
 * which will be used across the application.
 * This is to build the CKEditor from ClassicEditor source. If the type is 'inline',
 * it will be from InlineEditor source.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace CKEditorBase
 * @param {{fieldName: string, data: string, type: string, onReady: function,
 * onChange: function, onBlur: function, onFocus: function,
 * config: object, placeholder: string, className: string, dataTestId: string}} param passed in parameters
 * @param {string} param.fieldName - name of the field for the CKEditor
 * @param {string} param.data - inital data that will be displayed in the CKEditor
 * @param {string} param.type - indicates if it is inline editor or classic editor. Default is classic.
 * @param {function} param.onReady - function that need to be called onReady event
 * @param {function} param.onChange - function that need to be called onChange event
 * @param {function} param.onBlur - function that need to be called onBlur event
 * @param {function} param.onFocus - function that need to be called onFocus event
 * @param {object} param.config - optional, custom config object that can add/modify/override the default configuration only for the respective editor.
 * @param {string} param.placeholder - optional, string will show as the placeholer for the editor
 * @param {string} param.className - optional, apply class name to the editor container that can use for styling/identification/other development purpose
 * @param {string} param.dataTestId - optional, test id to the editor container for testing purpose
 * @param {boolean} param.displayEditorCount - optional, is the word/char count details needs to displayed or not for the editor, default is true
 * @param {number} param.delay - optional, represent the delay in loading the editor, has the minimum delay as default
 * @param {boolean} param.trim - optional, it will return space, if space is typed in ckeditor.
 * @return {Component} - Classic CKEditor with default configuration
 *
 * @example
 * <CKEditorBase data={data} onChange= {onUpdate}/>
 */

const CKEditorBase = ({
  fieldName = null,
  data = '',
  type = 'classic',
  onReady,
  onChange,
  onBlur,
  onFocus,
  config = {},
  placeholder,
  className,
  dataTestId,
  displayEditorCount = true,
  delay = 0.005,
  trim = true,
  ...props
}) => {
  let configuration = defaultEditorConfig;
  let options = {};

  // get the global editor configuration, if available
  const session = window?.sessionStorage?.configuration;
  let mediaLibrary = [];
  if (session && Object.keys(session).length > 0) {
    const editor = JSON.parse(session)?.editor;
    // configure spell check configuration, if exists
    if (editor?.spellCheck && Object.keys(editor?.spellCheck).length > 0) {
      configuration = {
        ...configuration,
        wproofreader: editor.spellCheck
      };
    }
    const media = JSON.parse(session)?.mediaLibrary;
    if (media && Object.keys(media).length > 0) {
      mediaLibrary = media;
    }
  }
  const [showModal, setShowModal] = useState(false);
  const [editor, setEditor] = useState(null);

  const onAddImage = (data) => {
    editor.editing.view.focus();
    const selectedMediaItem = data[0];
    const url = `/media/${selectedMediaItem.assessment_program_id}/${selectedMediaItem?.id}/${selectedMediaItem.attachment_id}/${selectedMediaItem?.file_name}.${selectedMediaItem.file_type}`;
    editor.execute('insertImage', {
      source: url
    });
    setShowModal(false);
  };

  const handleOpenModal = () => {
    setShowModal(true)
  }

  if (configuration.buttonCallbacks === undefined) {
    configuration = {
      ...configuration,
      buttonCallbacks: [
        {
          name: 'mediaRepo',
          set: {
            tooltip: 'Media Library',
            withText: true,
            icon: '<svg width="20" height="20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"></path></svg>',
          },
          call: handleOpenModal,
        },
      ],
    }
  }

  // if exists, add the placeholder or the custom configuration that can add/modify/overrides the default configuration to the configuration for the respective editor
  configuration = { ...configuration, ...config, placeholder: placeholder };

  // Configure the spell check to the CKEditor, only when it is passed directly or when it is available in the session storage which can help to avoid No WProofReader Configuration issue, probably during the reload or loading the new window ex: preview.
  if (configuration.wproofreader && Object.keys(configuration.wproofreader).length > 0) {
    configuration.plugins.push(WProofreader);
  } else {
    // If the spell check is not configured, then the WProofreader plugin tool must not available for the editor
    configuration = {
      ...configuration,
      toolbar: {
        ...configuration.toolbar,
        items: configuration.toolbar.items.filter(data => (data !== 'wproofreader'))
      }
    };
  }

  // if insert response is not configured, then the editor plugins, and toolbar item must not have the InsertResponse that is related to constructed response, dropdown or select text
  if (configuration.insertResponse === undefined) {
    configuration = {
      ...configuration,
      plugins: configuration.plugins.filter(
        (data) => data.name !== 'InsertResponse'
      ),
      toolbar: {
        ...configuration.toolbar,
        items: configuration.toolbar.items.filter(data => (data !== 'insertResponse'))
      }
    };
  }

  const [wordsCount, setWordsCount] = useState(0);
  const [charsCount, setCharsCount] = useState(0);

  if (displayEditorCount) {
    configuration.wordCount = {};
    configuration.wordCount.onUpdate = ({ words = 0, characters = 0 }) => {
      setWordsCount(words);
      setCharsCount(characters)
    };
  }

  // Hide CKEditor toolbar when scroll to avoid overlapping.
  if (editor?.id) {
    const handleScroll = () => {
      document.querySelectorAll('#' + editor.id + ' [contenteditable="true"]').forEach((element) => {
        element.blur();
      });
      document.querySelectorAll('.ck.ck-button.ck-button-cancel.ck-off.ck-button_with-text').forEach((element) => {
        element.click();
      });
    };
    window.removeEventListener('scroll', handleScroll);
    if (editor?.editing?.view?.document?.isFocused) {
      window.addEventListener("scroll", handleScroll);
    }
  }

  if (trim === false) {
    options.trim = 'none';
  }

  return (
    <div
      id={editor?.id}
      className={className}
      data-testid={
        dataTestId !== undefined ? dataTestId : 'ck-editor-5-container'
      }
    >
      <Delayed waitBeforeShow={delay}>
        <CKEditor
          {...props}
          editor={type === 'inline' ? InlineEditor : ClassicEditor}
          config={{ ...configuration }}
          data={data}
          onReady={(ckeditor) => {
            if (!editor) {
              setEditor(ckeditor);
              if (onReady) {
                onReady(ckeditor);
              }
            }
          }}
          onChange={
            /* istanbul ignore next */
            (_event, editor) => {
              if (editor?.editing?.view?.document?.isFocused) { // to handle calling onChange indirectly by CKEditor issue, When having the duplicate inline editor that updates the content dynamically. This issue rarely occurs, yet to find the actual steps for those.
                const value = editor.getData(options);
                if (type === 'inline') {
                  // provide a way to parent component to update stemContents in case of a loop
                  onChange(value);
                } else {
                  // update store directly using fieldName in case of stem update
                  onChange(fieldName, value);
                }
              }
            }
          }
          onBlur={onBlur}
          onFocus={onFocus}
        />
        {displayEditorCount &&
          <div className={type === 'inline' ? 'wordscount-inline' : 'wordscount'}>
            <span> Words : {wordsCount}, </span>
            <span>Characters : {charsCount} </span>
          </div>
        }
        {showModal && (
          <AddMedia
            setMedia={onAddImage}
            media={mediaLibrary}
            cancelMedia={() =>
              setShowModal(false)
            }
          />
        )}
      </Delayed>
    </div>
  );
};

CKEditorBase.propTypes = {
  fieldName: PropTypes.string,
  data: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.elementType
  ]),
  type: PropTypes.string,
  config: PropTypes.object,
  onChange: PropTypes.func,
  onReady: PropTypes.func,
  onBlur: PropTypes.func,
  onFocus: PropTypes.func,
  placeholder: PropTypes.string,
  className: PropTypes.string,
  dataTestId: PropTypes.string,
  displayEditorCount: PropTypes.bool,
  delay: PropTypes.number,
  trim: PropTypes.bool
};

export default CKEditorBase;
