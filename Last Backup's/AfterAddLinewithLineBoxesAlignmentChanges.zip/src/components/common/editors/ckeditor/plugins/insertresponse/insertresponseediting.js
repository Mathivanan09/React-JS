import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import InsertResponseCommand from './insertresponsecommand';

const INSERTRESPONSE = 'insertResponse'
const ID = 'id'
export default class InsertResponseEditing extends Plugin {
	static get pluginName() {
		return 'InsertResponseEditing';
	}

	init() {
		const editor = this.editor;
		const schema = editor.model.schema;
		const type = editor.config.get('insertResponse')?.type;
		const elemClass = (type && type !== 'cr-dropdown') ? 'cked-highlight' : 'constructedResponse-placeholder';

		// Schema defintion to handle InsertResponse
		schema.extend('$text', { allowAttributes: INSERTRESPONSE });
		schema.setAttributeProperties(INSERTRESPONSE, {
			isFormatting: true,
			copyOnEnter: true,
		});

		//This will convert the 'insertresponse' (model) to 'span' element (view) with required class
		//This is to create a span tag around the selected text for identifying the required text as Insert Response
		editor.conversion.for('downcast').attributeToElement({
			model: INSERTRESPONSE,
			view: (attributeValue, { writer }) => {
				return writer.createAttributeElement('span', { class: elemClass });
			},
			converterPriority: 5
		});

		//This will convert the 'span' tag (view) with required class to 'insertresponse' (model).
		editor.conversion.for('upcast').elementToAttribute({
			model: INSERTRESPONSE,
			view: {
				name: 'span',
				classes: elemClass
			},
			converterPriority: 5
		});

		editor.commands.add(INSERTRESPONSE, new InsertResponseCommand(editor, INSERTRESPONSE));

		//  new schema definition to handle ID's
		schema.extend('$text', { allowAttributes: ID });
		schema.setAttributeProperties(ID, {
			isFormatting: true,
			copyOnEnter: true,
		});
		
		//This will convert the 'id' (model) to 'span' element (view) with id attribute. 
		//Giving the same priority will ensure to add id in the same span tag as insertresponse.
		editor.conversion.for('downcast').attributeToElement({
			model: ID,
			view: (attributeValue, { writer }) => {
				return writer.createAttributeElement('span', { id: attributeValue });
			},
			converterPriority: 5
		});

		//This will convert the 'id' attribute (view) to 'id' attribute (model)
		editor.conversion.for('upcast').attributeToAttribute({
			model: ID,
			view: ID,
			converterPriority: 5
		});

		editor.commands.add(ID, new InsertResponseCommand(editor, ID));
	}
}