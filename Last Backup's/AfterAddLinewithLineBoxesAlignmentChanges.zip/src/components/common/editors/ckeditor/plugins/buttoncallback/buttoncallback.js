import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import ButtonView from '@ckeditor/ckeditor5-ui/src/button/buttonview';

// Plugin enabling the creation of buttons that fire client-defined callbacks
export default class ButtonCallback extends Plugin {
  
  static get pluginName() {
    return 'ButtonCallback';
  }

  init() {
    const editor = this.editor;
    const buttonCallbacks = editor.config.get('buttonCallbacks');

    if (buttonCallbacks) {
      let view = null;
      // buttonCallbacks shape:
      // [
      //    {
      //        name:   <string>,                   -> name to be used in the toolbar config for the button
      //        set:    <object>,                   -> key-value pairs of observable properties to be set for the button (see https://ckeditor.com/docs/ckeditor5/latest/api/module_ui_button_buttonview-ButtonView.html)
      //        call:   <function (<EventInfo>)>,   -> function to be executed when the button is clicked
      //    },
      //    ...
      // ]
      for (const buttonCallback of buttonCallbacks) {
        editor.ui.componentFactory.add(buttonCallback.name, locale => {
          view = new ButtonView(locale);
          view.set({ ...buttonCallback.set });
          view.on('execute', buttonCallback.call);

          this.listenTo(view, 'execute', () => {
            if (editor?.editing?.view?.document?.isFocused) {
              editor.editing.view.focus();
            }
          });

          return view;
        });
      }
    }
  }
}
