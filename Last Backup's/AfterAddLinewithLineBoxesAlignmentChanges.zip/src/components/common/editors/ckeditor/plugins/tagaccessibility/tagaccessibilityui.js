import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import ButtonView from '@ckeditor/ckeditor5-ui/src/button/buttonview';
import uid from '@ckeditor/ckeditor5-utils/src/uid';
const TAG_ACCESSIBILITY = 'tagAccessibility';
const ID = 'data-access-id';

/**
 * Class component to create Tag Accessibility Icon Plugin
 * Icon initialization and it's funtionality for CK-Editor toolbar
 *
 * @memberof TagAccessibility
 * @inner
 * 
 * @class
 * @namespace TagAccessibilityUI
 * 
 */

export default class TagAccessibilityUI extends Plugin {
	static get pluginName() {
		return 'Tag Accessibility UI';
	}

	init() {
		const editor = this.editor;
		const t = editor.t;

		editor.ui.componentFactory.add(TAG_ACCESSIBILITY, locale => {
			const tagAccessibilityCommand = editor.commands.get(TAG_ACCESSIBILITY);
			const view = new ButtonView(locale);
			view.set({
				label: 'Tag Accessibility',
				tooltip: true,
				withText: false,
				isToggleable: true.valueOf,
				icon: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bookmark-plus" viewBox="0 0 16 16">
				<path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"/>
				<path d="M8 4a.5.5 0 0 1 .5.5V6H10a.5.5 0 0 1 0 1H8.5v1.5a.5.5 0 0 1-1 0V7H6a.5.5 0 0 1 0-1h1.5V4.5A.5.5 0 0 1 8 4z"/>
			  </svg>`
			});
			view.bind('isOn', 'isEnabled').to(tagAccessibilityCommand, 'value', 'isEnabled');


			// Execute command.
			this.listenTo(view, 'execute', () => {
				editor.execute(TAG_ACCESSIBILITY, {});
				editor.execute(ID, { value: `cke-atp-${uid()}` });
				editor.editing.view.focus();
			});

			return view;
		});
	}
}
