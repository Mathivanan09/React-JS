import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import InsertResponseEditing from './insertresponseediting';
import InsertResponseUI from './insertresponseui';

import './theme/insertresponse.css';

export default class InsertResponse extends Plugin {
    static get requires() {
        return [InsertResponseEditing, InsertResponseUI];
    }

    static get pluginName() {
        return 'Insert Response';
    }
}