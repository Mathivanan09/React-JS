import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import TagAccessibilityEditing from './tagaccessibilityediting';
import TagAccessibilityUI from './tagaccessibilityui';
import './theme/tagaccessibility.css';

/**
 * Class component to create Tag Accessibility Plugin
 * Initialize the icon and it's funtionalities
 * 
 * @class
 * @namespace TagAccessibility
 * 
 */
export default class TagAccessibility extends Plugin {
    static get requires() {
        return [TagAccessibilityEditing, TagAccessibilityUI];
    }

    static get pluginName() {
        return 'TagAccessibility';
    }
}