import View from '@ckeditor/ckeditor5-ui/src/view';
import ViewCollection from '@ckeditor/ckeditor5-ui/src/viewcollection';

import ButtonView from '@ckeditor/ckeditor5-ui/src/button/buttonview';
import KeystrokeHandler from '@ckeditor/ckeditor5-utils/src/keystrokehandler';
import FocusTracker from '@ckeditor/ckeditor5-utils/src/focustracker';
import FocusCycler from '@ckeditor/ckeditor5-ui/src/focuscycler';

import checkIcon from '@ckeditor/ckeditor5-core/theme/icons/check.svg';
import cancelIcon from '@ckeditor/ckeditor5-core/theme/icons/cancel.svg';

import submitHandler from '@ckeditor/ckeditor5-ui/src/bindings/submithandler';


import '../theme/mathform.css';

class MathLiveView extends View {

	constructor(locale) {
		super(locale);
		this.setTemplate({
			tag: 'math-field',
			attributes: {
				id: `math-formula`
			}
		});
	}
}

export default class MainFormView extends View {
	constructor(locale, engine, lazyLoad, previewEnabled, previewUid, previewClassName, popupClassName) {
		super(locale);

		const t = locale.t;

		// Create key event & focus trackers
		this._createKeyAndFocusTrackers();

		// Submit button
		this.saveButtonView = this._createButton(t('Save'), checkIcon, 'ck-button-save', null);
		this.saveButtonView.type = 'submit';

		// Equation input
		this.mathLiveInput = this._createMathLiveInput();

		// Cancel button
		this.cancelButtonView = this._createButton(t('Cancel'), cancelIcon, 'ck-button-cancel', 'cancel');

		this.previewEnabled = previewEnabled;

		let children = [this.mathLiveInput];

		// Add UI elements to template
		this.setTemplate({
			tag: 'form',
			attributes: {
				class: [
					'ck',
					'ck-math-form',
					...popupClassName
				],
				id: previewUid,
				tabindex: '-1',
				spellcheck: 'false'
			},
			children: [
				{
					tag: 'div',
					attributes: {
						class: [
							'ck-math-view'
						]
					},
					children
				},
				this.saveButtonView,
				this.cancelButtonView
			]
		});
	}

	render() {
		super.render();

		// Prevent default form submit event & trigger custom 'submit'
		submitHandler({
			view: this
		});

		// Register form elements to focusable elements
		const childViews = [
			this.mathLiveInput,
			this.saveButtonView,
			this.cancelButtonView,
		];

		childViews.forEach(v => {
			this._focusables.add(v);
			this.focusTracker.add(v.element);
		});

		// Listen to keypresses inside form element
		this.keystrokes.listenTo(this.element);
	}

	focus() {
		this._focusCycler.focusFirst();
	}

	get equation() {
		return this.mathLiveInput.element.value;
	}

	set equation(equation) {
		this.mathLiveInput.element.value = equation;
	}

	_createKeyAndFocusTrackers() {
		this.focusTracker = new FocusTracker();
		this.keystrokes = new KeystrokeHandler();
		this._focusables = new ViewCollection();

		this._focusCycler = new FocusCycler({
			focusables: this._focusables,
			focusTracker: this.focusTracker,
			keystrokeHandler: this.keystrokes,
			actions: {
				focusPrevious: 'shift + tab',
				focusNext: 'tab'
			}
		});
	}

	_createMathLiveInput() {
		const mathLiveInput = new MathLiveView(this.locale);
		return mathLiveInput;
	}

	_createButton(label, icon, className, eventName) {
		const button = new ButtonView(this.locale);

		button.set({
			label,
			icon,
			tooltip: true
		});

		button.extendTemplate({
			attributes: {
				class: className
			}
		});

		if (eventName) {
			button.delegate('execute').to(this, eventName);
		}

		return button;
	}

}
