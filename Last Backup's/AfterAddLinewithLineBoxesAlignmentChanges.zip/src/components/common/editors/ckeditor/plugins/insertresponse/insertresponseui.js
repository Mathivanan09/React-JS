import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import ButtonView from '@ckeditor/ckeditor5-ui/src/button/buttonview';
import uid from '@ckeditor/ckeditor5-utils/src/uid';

const INSERTRESPONSE = 'insertResponse';
const ID = 'id'

export default class InsertResponseUI extends Plugin {
	static get pluginName() {
		return 'Insert Response UI';
	}

	init() {
		const editor = this.editor;
		const t = editor.t;

		editor.ui.componentFactory.add(INSERTRESPONSE, locale => {
			const insertResponseCommand = editor.commands.get(INSERTRESPONSE);
			const view = new ButtonView(locale);
			const label = editor.config.get('insertResponse')?.label;
			const type = editor.config.get('insertResponse')?.type;
			view.set({
				label: label ? t(label) : t('Insert Response'),
				tooltip: true,
				withText: true,
				isToggleable: true.valueOf,
				icon: (type && type !== 'cr-dropdown')
					? `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<rect width="20" height="20" fill="white"/>
				<path d="M10 16H16.75" stroke="black" stroke-opacity="0.85" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.375 3.62505C13.6734 3.32668 14.078 3.15906 14.5 3.15906C14.7089 3.15906 14.9158 3.20021 15.1088 3.28016C15.3019 3.36012 15.4773 3.47731 15.625 3.62505C15.7727 3.77278 15.8899 3.94817 15.9699 4.1412C16.0498 4.33423 16.091 4.54112 16.091 4.75005C16.091 4.95898 16.0498 5.16587 15.9699 5.35889C15.8899 5.55192 15.7727 5.72731 15.625 5.87505L6.25 15.25L3.25 16L4 13L13.375 3.62505Z" stroke="black" stroke-opacity="0.85" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>`
					: `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<rect width="20" height="20" fill="white"/>
				<path d="M8.08 3V4.896H6.208V14.568H8.08V16.476H4V3H8.08Z" fill="black" fill-opacity="0.85"/>
				<path d="M16.2264 16.476H12.1464V14.568H14.0184V4.896H12.1464V3H16.2264V16.476Z" fill="black" fill-opacity="0.85"/>
				</svg>`
			});

			view.bind('isOn', 'isEnabled').to(insertResponseCommand, 'value', 'isEnabled');

			// Execute command.
			this.listenTo(view, 'execute', () => {
				editor.execute(INSERTRESPONSE, {});
				editor.execute(ID, { value: `cke-${uid()}` });
				editor.editing.view.focus();
			});

			return view;
		});
	}
}
