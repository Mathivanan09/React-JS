import React from "react";
import { unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import {render, screen, fireEvent } from '@testing-library/react';

// import component here
import MessagePreview from './MessagePreview';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("Test empty component", () => {
  act(() => {
    render(<MessagePreview />, container);
  });

  // test the empty container
  const msgPreviewContainer = document.querySelector("[data-testid=message-preview-container]");
  expect(msgPreviewContainer).not.toBeNull;
  expect(msgPreviewContainer.children.length).toBe(0);
});

it('calls onClick prop when clicked', () => {
  //const mockedOnCancel = jest.fn()

  let showHideFlag = true;
  const mockedOnCancel = jest.fn().mockImplementation((val) => {
    showHideFlag = val;
  });


  act(() => {
    render(<MessagePreview
       onCancel={() => {
        mockedOnCancel(false);
      }}
      onClose ={() => {
        mockedOnCancel(false);
      }}
        showHideFlag={showHideFlag}/>)
  });
  const msgPreviewOkayButton = document.querySelector("[data-testid=mp-okay-button]");
  expect(msgPreviewOkayButton.innerHTML).toBe("Okay");
  act(() => {
    msgPreviewOkayButton.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  });
  expect(mockedOnCancel).toHaveBeenCalledTimes(1);
  expect(showHideFlag).toBe(false);

  
})
