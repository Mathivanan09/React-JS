import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import MultipleChoice from './MultipleChoice';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

describe('MultipleChoice', () => {

  /**
  * Test an empty component and verify the element with Missing item data
  */
  it("Should render base component", () => {
    act(() => {
      render(
        <MultipleChoice />, container);
    });

    const emptyComponent = document.querySelector("[data-testid=missing-item]");
    expect(emptyComponent).not.toBeNull;
    expect(emptyComponent.textContent).toBe('Missing item data');
  });

  /**
   * Test component by passing skeleton item json and verify the 
   * elements and values when opened from new  item
   */
  it("Test skeleton component when opened from new item", () => {
    act(() => {
      render(
        <MultipleChoice item={{
          item_json: {
            itemTypeCode: 'MC'
          }
        }
        } />, container);
    });

    /**
     * Verify that there 3 main containers item dimensions, stem content and options
     */
    const component = document.querySelector("[data-testid=container]");
    expect(component).not.toBeNull;
    expect(component.children.length).toBe(4);

    // Verify that the 4 containers exists
    expect(document.querySelector("[data-testid=container]")).not.toBeNull;
    expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
    expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
    expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
  });

  /**
   * Test default response labels
   */
  it("Test default response labels", () => {
    act(() => {
      render(
        <MultipleChoice
          item={{
            item_json: {
              itemTypeCode: 'MC'
            }
          }
          }
        />, container);
    });

    const responseLabels = document.querySelector("[data-testid=mc-response-labels]");
    expect(responseLabels).not.toBeNull;
    // Expected 3 defualt labels and one for Select
    expect(responseLabels.children.length).toBe(4);
  });

  /**
   * Test Response labels passed in config object
   */
  it("Test Response labels passed in config object", () => {
    act(() => {
      render(
        <MultipleChoice
          config={{ responseLabels: [{ id: 'Letters', name: 'Letters' }, { id: 'Numbers', name: 'Numbers' }] }}
          item={{
            item_json: {
              itemTypeCode: 'MC'
            }
          }
          }
        />, container);
    });

    const responseLabels = document.querySelector("[data-testid=mc-response-labels]");
    expect(responseLabels).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(responseLabels.children.length).toBe(3);
  });

  /**
   * Test component for default selection type as single
   */
  it("Test component for default selection type as single", () => {
    act(() => {
      render(
        <MultipleChoice item={{
          item_json: {
            itemTypeCode: 'MC',
            selectionType: 'single'
          }
        }
        } />, container);
    });

    const singleTtypeSelection = document.querySelector("[data-testid=ts-single-radio-input]");
    const multipleSelection = document.querySelector("[data-testid=ts-multiple-radio-input]");
    const booleanTtypeSelection = document.querySelector("[data-testid=ts-boolean-radio-input]");

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleTtypeSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanTtypeSelection.checked).toBe(false);
  });

  /**
   * Test component for default selection type as boolean
   */
  it("Test component for default selection type as boolean", () => {
    act(() => {
      render(
        <MultipleChoice item={{
          item_json: {
            itemTypeCode: 'MC',
            selectionType: 'true/false'
          }
        }
        } />, container);
    });

    const singleTtypeSelection = document.querySelector("[data-testid=ts-single-radio-input]");
    const multipleSelection = document.querySelector("[data-testid=ts-multiple-radio-input]");
    const booleanTtypeSelection = document.querySelector("[data-testid=ts-boolean-radio-input]");

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleTtypeSelection.checked).toBe(false);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanTtypeSelection.checked).toBe(true);
  });

  it('Test type selection event handling', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'multiple' },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(false);
    expect(multipleSelection.checked).toBe(true);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for single
    fireEvent.click(singleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>)
    });
    expect(singleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).toBeChecked;
    expect(multipleSelection).not.toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('radio');
    });

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>)
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(3);
    mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // verify type change expectations for boolean
    fireEvent.click(booleanSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>)
    });
    expect(booleanSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).not.toBeChecked;
    expect(booleanSelection).toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(4);
    mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(2);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('radio');
    });
  });

  it('Test type selection for true/false when feedback is true', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'multiple', feedback: true },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(false);
    expect(multipleSelection.checked).toBe(true);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for single
    fireEvent.click(singleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>)
    });
    expect(singleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).toBeChecked;
    expect(multipleSelection).not.toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('radio');
    });

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>)
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(3);
    mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // verify type change expectations for boolean
    fireEvent.click(booleanSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>)
    });
    expect(booleanSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).not.toBeChecked;
    expect(booleanSelection).toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(4);
    mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(2);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('radio');
    });
  });

  it('Test add option event handle', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single' },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // Verify add option button exists
    const addOption = screen.getByTestId('multiplechoice-addoption');
    expect(addOption).not.toBeNull;

    // Fire event 'add option' then update the component
    fireEvent.click(addOption);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    // Expected new option in list of mc-correct elementsas 5 and type checkbox
    expect(updateItem).toHaveBeenCalledTimes(3);
    mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(5);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // Expected that the feedbackList is empty
    expect(item.item_json.feedbackList.length).toBe(0);

    // Verify feedback 
    const responseFeedback = screen.getByTestId('multiple_choice_yes_feedback');
    expect(responseFeedback).not.toBeNull;

    // Fire event 'add option' then update the component to verify if feedback is enabled
    // so that feedback get added to json
    fireEvent.click(responseFeedback);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    // Fire event 'add option' then update the component again
    fireEvent.click(addOption);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    // Expected new option in list of mc-correct elements as 6 and type checkbox
    expect(updateItem).toHaveBeenCalledTimes(6);
    mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(6);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });
    // Expected that the feedbackList is not empty
    expect(item.item_json.feedbackList.length).toBeGreaterThan(0);
  });

  it('Test toggle response feedback event handle', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single' },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // Verify feedback 
    const responseFeedback = screen.getByTestId('multiple_choice_yes_feedback');
    expect(responseFeedback).not.toBeNull;

    // Fire event 'add option' then update the component
    fireEvent.click(responseFeedback);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    // Verify that there are 4 feedback buttons exists
    let fbButtons = screen.getAllByTestId('feedback-button');
    expect(fbButtons.length).toBe(4);
    fbButtons.forEach((fbButton) => {
      expect(fbButton.type).toBe('button');
    });
  });

  it('Test feedback button click event handler', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single' },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // Verify feedback 
    const responseFeedback = screen.getByTestId('multiple_choice_yes_feedback');
    expect(responseFeedback).not.toBeNull;

    // Fire event 'add option' then update the component
    fireEvent.click(responseFeedback);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    // Verify that there are 4 feedback buttons exists but not containers
    let fbButtons = screen.getAllByTestId('feedback-button');
    expect(fbButtons.length).toBe(4);
    fbButtons.forEach((fbButton) => {
      expect(fbButton.type).toBe('button');
    });

    let feedbackContainers = screen.queryAllByTestId('feedback-container');
    expect(feedbackContainers.length).toBe(0);

    // Verify feedback buttons click and existence of 4 feedback containers
    fbButtons.forEach((fbButton) => {
      fireEvent.click(fbButton, { bubbles: true });
    });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    feedbackContainers = screen.getAllByTestId('feedback-container');
    expect(feedbackContainers.length).toBe(4);

    // Verify feedback buttons click and non existence of feedback containers
    fbButtons.forEach((fbButton) => {
      fireEvent.click(fbButton, { bubbles: true });
    });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    feedbackContainers = screen.queryAllByTestId('feedback-container');
    expect(feedbackContainers.length).toBe(0);
  });

  it('Test rationale button click event handler', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single' },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // Verify that there are 4 rationale buttons exists but not containers
    let rationaleButtons = screen.getAllByTestId('rationale-button');
    expect(rationaleButtons.length).toBe(4);
    rationaleButtons.forEach((rationaleButton) => {
      expect(rationaleButton.type).toBe('button');
    });

    let rationaleContainers = screen.queryAllByTestId('rationale-container');
    expect(rationaleContainers.length).toBe(0);

    // Verify rationale buttons click and existence of 4 rationale containers
    rationaleButtons.forEach((rationaleButton) => {
      fireEvent.click(rationaleButton, { bubbles: true });
    });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    rationaleContainers = screen.getAllByTestId('rationale-container');
    expect(rationaleContainers.length).toBe(4);

    // Verify rationale buttons click and non existence of rationale containers
    rationaleButtons.forEach((rationaleButton) => {
      fireEvent.click(rationaleButton, { bubbles: true });
    });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    rationaleContainers = screen.queryAllByTestId('rationale-container');
    expect(rationaleContainers.length).toBe(0);
  });

  it('Test option remove event handler', () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single' },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);
    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
    });

    // Verify that there are 4 options and corresponding remove buttons exists
    let optionRemoveButtons = screen.queryAllByTestId('option-remove-button');
    expect(optionRemoveButtons.length).toBe(4);
    optionRemoveButtons.forEach((optionRemoveButton) => {
      expect(optionRemoveButton.type).toBe('button');
    });

    // Verify 4 option containers exists
    let optionContainers = screen.getAllByTestId('multiplechoice-option');
    expect(optionContainers.length).toBe(4);

    // mock item with feedback & correct responses
    // Verify feedback 
    const responseFeedback = screen.getByTestId('multiple_choice_yes_feedback');
    expect(responseFeedback).not.toBeNull;

    // Fire event 'add option' then update the component
    fireEvent.click(responseFeedback);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    // Verify that there are 4 feedback buttons exists but not containers
    let fbButtons = screen.getAllByTestId('feedback-button');
    expect(fbButtons.length).toBe(4);
    fbButtons.forEach((fbButton) => {
      expect(fbButton.type).toBe('button');
    });

    let feedbackContainers = screen.queryAllByTestId('feedback-container');
    expect(feedbackContainers.length).toBe(0);

    // Verify feedback buttons click and existence of 4 feedback containers
    fbButtons.forEach((fbButton) => {
      fireEvent.click(fbButton, { bubbles: true });
    });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    feedbackContainers = screen.getAllByTestId('feedback-container');
    expect(feedbackContainers.length).toBe(4);

    // correct responses
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
      fireEvent.click(mccInput);
      act(() => {
        rerender(<Provider store={store}>
          <MultipleChoice item={item} onUpdate={updateItem} />
        </Provider>);
      });
    });

    expect(item.item_json.feedbackList.length).toBe(4);
    expect(item.item_json.correctResponse.length).toBe(4);

    // Fire remove event and rerender 
    optionRemoveButtons.reverse().forEach((optionRemoveButton) => {
      fireEvent.click(optionRemoveButton, { bubbles: true });
      act(() => {
        rerender(<Provider store={store}>
          <MultipleChoice item={item} onUpdate={updateItem} />
        </Provider>);
      });
    });

    // Verify no option containers exists
    optionContainers = screen.queryAllByTestId('multiplechoice-option');
    expect(optionContainers.length).toBe(0);

    // Verify that the feedback and correct responses are in sync with remove operation
    expect(item.item_json.feedbackList.length).toBe(0);
    expect(item.item_json.correctResponse.length).toBe(0);
  });

  it('Test correct response set event', async () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single', feedback: true },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);


    // Verify that there are no readable responses exists
    expect(item.readableResponse).not.toBeNull;
    // mock that the option text changed for now
    let optionList = item.item_json.optionList.map((opt, index) => {
      opt.optionText = '' + (index + 1);
      return opt;
    });
    updateItem({ item_json: { optionList: optionList } });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(4);

    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
      fireEvent.click(mccInput);
      act(() => {
        rerender(<Provider store={store}>
          <MultipleChoice item={item} onUpdate={updateItem} />
        </Provider>);
      });
    });

    // Verify that there exists readable response and the value
    expect(item.readableResponse).not.toBeNull;
    expect(item.readableResponse).toBe('1\n\n2\n\n3\n\n4');

    // Now unselect the correct responses
    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('checkbox');
      fireEvent.click(mccInput);
      act(() => {
        rerender(<Provider store={store}>
          <MultipleChoice item={item} onUpdate={updateItem} />
        </Provider>);
      });
    });

    // Verify that there exists readable response and the value
    expect(item.readableResponse).not.toBeNull;
    expect(item.readableResponse).toBe('');
  });

  it('Test correct response set event for true/false selection type', async () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single', feedback: true },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(booleanSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(booleanSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).not.toBeChecked;
    expect(booleanSelection).toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);


    // Verify that there are no readable responses exists
    expect(item.readableResponse).not.toBeNull;
    // mock that the option text changed for now
    let optionList = item.item_json.optionList.map((opt, index) => {
      opt.optionText = '' + (index + 1);
      return opt;
    });
    updateItem({ item_json: { optionList: optionList } });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    let mccInputs = screen.getAllByTestId('mc-correct');
    expect(mccInputs.length).toBe(2);

    mccInputs.forEach((mccInput) => {
      expect(mccInput.type).toBe('radio');
      fireEvent.click(mccInput);
      act(() => {
        rerender(<Provider store={store}>
          <MultipleChoice item={item} onUpdate={updateItem} />
        </Provider>);
      });
    });

    // Verify that last option only selected for readable response
    expect(item.readableResponse).not.toBeNull;
    expect(item.readableResponse).toBe('\n\n2');
  });

  it('Test reorder options event', async () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: { itemTypeCode: 'mc', selectionType: 'single', feedback: true },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );

    const singleSelection = screen.getByTestId('ts-single-radio-input');
    const multipleSelection = screen.getByTestId('ts-multiple-radio-input');
    const booleanSelection = screen.getByTestId('ts-boolean-radio-input');

    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection.checked).toBe(true);
    expect(multipleSelection.checked).toBe(false);
    expect(booleanSelection.checked).toBe(false);

    // verify type change expectations for multiple
    fireEvent.click(multipleSelection);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(multipleSelection).not.toBeNull;
    // Expected 2 passed in labels and one for Select
    expect(singleSelection).not.toBeChecked;
    expect(multipleSelection).toBeChecked;
    expect(booleanSelection).not.toBeChecked;
    expect(updateItem).toHaveBeenCalledTimes(2);

    // Find the reorder first button and click
    let reorderContainers = document.querySelectorAll('[data-testid=ri-container]')
    let firstButton = reorderContainers[0].querySelector('button');

    expect(firstButton).not.toBeNull;
    // verify type change expectations for multiple

    let idOneBefore = item.item_json.optionList[0].id;
    let idTwoBefore = item.item_json.optionList[1].id;

    fireEvent.click(firstButton);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    let idOneAfter = item.item_json.optionList[0].id;
    let idTwoAfter = item.item_json.optionList[1].id;

    expect(idOneBefore).toBe(idTwoAfter);
    expect(idTwoBefore).toBe(idOneAfter);

    // Find the reorder last button and click
    let lastButton = reorderContainers[3].querySelector('button');
    expect(lastButton).not.toBeNull;

    // verify type change expectations for multiple
    let idThirdBefore = item.item_json.optionList[2].id;
    let idLastBefore = item.item_json.optionList[3].id;

    fireEvent.click(lastButton);
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    let idThirdAfter = item.item_json.optionList[2].id;
    let idLastAfter = item.item_json.optionList[3].id;

    expect(idThirdBefore).toBe(idLastAfter);
    expect(idLastBefore).toBe(idThirdAfter);
  });

  it('Test minimum item dimensions event', async () => {
    let item = {
      id: -1,
      name: '',
      assessment_program_id: 0,
      item_type_id: 0,
      item_type_code: '',
      item_json: {
        itemTypeCode: 'mc', selectionType: 'single', feedback: true,
        minItemWidth: 400, minItemHeight: 400
      },
      user_id: 0
    };

    const updateItem = jest.fn().mockImplementation((payload) => {
      item = {
        ...item,
        ...payload,
        item_json: { ...item.item_json, ...payload.item_json }
      };
    });

    const store = mockStore({});
    const { rerender } = render(
      <Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>
    );
    expect(item.item_json.minItemWidth).toBe(400);
    expect(item.item_json.minItemHeight).toBe(400);

    let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
    let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

    // Verify that the inputs exists
    expect(minItemWidthInput).not.toBeNull;
    expect(minItemHeightInput).not.toBeNull;

    // Update inputs with value and verify store update
    fireEvent.change(minItemWidthInput, { target: { value: 555 } });
    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });

    fireEvent.change(minItemHeightInput, { target: { value: 666 } });

    act(() => {
      rerender(<Provider store={store}>
        <MultipleChoice item={item} onUpdate={updateItem} />
      </Provider>);
    });
    expect(item.item_json.minItemWidth).toBe(555);
    expect(item.item_json.minItemHeight).toBe(666);
  });

  it.todo("Users can switch the Single Select, Multi Select and True/False items by changing respective radio buttons. ");

  it.todo("Users can add text/media in stem content/questions for the student");

  it.todo("Users can select Shuffle yes/no radio button");

  it.todo("If Users select Shuffle yes it need to re-arrange the response options order in correct response, preview and SP, if no it need to show response option in same order");

  it.todo("Users can select Response Feedback yes/no radio button");

  it.todo("If user select Response Feedback yes it needs to show feedback button in every response option added and if we click on feedback button able to add feedback content. If Response feedback no it should not show feedback button on response option");

  it.todo("Users can set the correct response by selecting the correct radio button for single select and true/false or check box for multi select. ");

  it.todo("If users select correct response in response option, it needs to display selected correct response in CP correct response");

  it.todo("Users can reorder the response options by selecting the reorder up/down arrow button on the response options");

  it.todo("If response options are reordered, then the new order needs to be displayed in the CP Correct Response and in the Scoring Accordion");

  it.todo("Users can add response options in response option panel by clicking Add Response Options button");

  it.todo("Added response option can be removed by clicking remove icon at the end of the added response option and respective rationale and feedback button also removed");

  it.todo("If users select Response Type is True/False, Add Response Options button and remove icon should be disabled");

  it.todo("Users can click on Rationale button and can add rationale content");

  it.todo("Users can select Response Labels dropdown and it should contain Letters, No Response Label and Numbers based on the selection correct response, preview and SP response option label format should display");

  it.todo("Users can select Response alignment dropdown and it should contain Horizontal, Vertical Right Align, Vertical Left Align, Z Left Align and Z Right Align based on the selection preview response option alignment should display");

  it.todo("If users select Response Type is True/False, Response alignment dropdown should contain Horizontal, Vertical Right Align and Vertical Left Align");

  it.todo("If users select Response Type is Single Select or Multi Select, it should contain default four response options with empty content and user can add text or media. ");

  it.todo("If users select Response Type is True/False, it should contain default two response options with content as True and False, User cannot edit content in the response option");

  it.todo("Users can set all the mandatory fields for each response type");

})