import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import { fireEvent } from '@testing-library/react';

// import component here
import TypeSelection from './TypeSelection';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("Should render base component", () => {
  act(() => {
    render(<TypeSelection />, container);
  });

  // get a hold of the selection element, and trigger change on it with a value
  const selection = document.querySelector("[data-testid=multiselect-typeselection]");
  expect(selection.children.length).toBe(4);
  const inputs = selection.querySelectorAll("[type=radio]");
  expect(inputs.length).toBe(3);
});

it("Test component with type", () => {
  act(() => {
    render(<TypeSelection selectionType={'single'} />, container);
  });

  // get a hold of the selection element, and trigger change on it with a value
  const selection = document.querySelector("[data-testid=multiselect-typeselection]");
  expect(selection.children.length).toBe(4);
  const inputs = selection.querySelectorAll("[type=radio]");
  expect(inputs.length).toBe(3);

  const singleInput = document.querySelector("[data-testid=ts-single-radio-input]");
  expect(singleInput.checked).toBeTruthy;

  const multipleInput = document.querySelector("[data-testid=ts-multiple-radio-input]");
  expect(multipleInput.checked).toBeFalsy;

  const booleanInput = document.querySelector("[data-testid=ts-boolean-radio-input]");
  expect(booleanInput.checked).toBeFalsy;
});

it("Testing onChange event", () => {
  let onChangeValue = '';
  const setOnChangeValue = jest.fn().mockImplementation((value) => {
    onChangeValue = value;
  });

  act(() => {
    render(
      <TypeSelection
        onChange={setOnChangeValue}
      />, container);
  });

  // get a hold of the multiple input element, and select the input
  const inputMultiple = document.querySelector("[data-testid=ts-multiple-radio-input]");
  expect(inputMultiple.checked).toBeFalsy;
  expect(setOnChangeValue).toHaveBeenCalledTimes(0);

  expect(onChangeValue).toBe('');
  // Click on Multiple radio button
  fireEvent.click(inputMultiple);

  expect(setOnChangeValue).toHaveBeenCalledTimes(1);
  expect(onChangeValue).toBe('multiple');
  expect(inputMultiple.checked).toBeTruthy;

  onChangeValue = '';
  expect(onChangeValue).toBe('');
  const inputBoolean = document.querySelector("[data-testid=ts-boolean-radio-input]");
  expect(inputBoolean.checked).toBeFalsy;
  // Click on Boolean radio button
  fireEvent.click(inputBoolean);

  expect(setOnChangeValue).toHaveBeenCalledTimes(2);
  expect(onChangeValue).toBe('true/false');
  expect(inputBoolean.checked).toBeTruthy;
  expect(inputMultiple.checked).toBeFalsy;

  onChangeValue = '';
  expect(onChangeValue).toBe('');
  const inputSingle = document.querySelector("[data-testid=ts-single-radio-input]");
  expect(inputSingle.checked).toBeFalsy;
  // Click on Single radio button
  fireEvent.click(inputSingle);
  
  // expect(setOnChangeValue).toHaveBeenCalledTimes(3);
  // expect(onChangeValue).toBe('single');
  expect(inputSingle.checked).toBeTruthy;
  expect(inputMultiple.checked).toBeFalsy;
});