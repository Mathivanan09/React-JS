import React from 'react';
import { itemProps } from '../common/ItemHelper';

import applyStyles from '../../utility/applyStyles';

import ActingForces from './actingforces/ActingForces';
import BackgroundGraphic from './backgroundgraphic/BackgroundGraphic';
import BiologySimulation from './biologysimulation/BiologySimulation';
import ChemistrySimulation from './chemistrysimulation/ChemistrySimulation';
import CodeCompiler from './codecompiler/CodeCompiler';
import CodeSubmit from './codesubmit/CodeSubmit';
import CompositeItems from './composite/CompositeItems';
import ConstructedResponse from './constructedresonse/ConstructedResponse';
import DropDown from './dropdown/DropDown';
import Embedded from './embedded/Embedded';
import ExtendedResponse from './extendedresponse/ExtendedResponse';
import Firewall from './firewall/Firewall';
import Gears from './gears/Gears';
import GraphicOrder from './graphicorder/GraphicOrder';
import GraphingSim from './graphingsimulation/GraphingSim';
import HotSpot from './hotspot/HotSpot';
import Labeling from './labeling/Labeling';
import LikertScale from './likertscale/LikertScale';
import LineGraph from './linegraph/LineGraph';
import MatchingLines from './matchinglines/MatchingLines';
import MatrixInteraction from './matrixinteraction/MatrixInteraction';
import MazeRunner from './mazerunner/MazeRunner';
import MultiDropBucket from './multidropbucket/MultiDropBucket';
import MultipleChoice from './multiplechoice/MultipleChoice';
import MultipleTabs from './multipletabs/MultipleTabs';
import NumberConverter from './numberconverter/NumberConverter';
import ObjectCanvas from './objectcanvas/ObjectCanvas';
import Ordering from './ordering/Ordering';
import OscillatingGraph from './oscillatinggraph/OscillatingGraph.jsx';
import PlacingPoints from './placingpoints/PlacingPoints';
import PunnettSquare from './punnettsquare/PunnettSquare';
import SampleReaction from './samplereaction/SampleReaction';
import ScatterPlot from './scatterplot/ScatterPlot';
import SelectText from './selecttext/SelectText';
import SingleLine from './singleline/SingleLine';
import SpeechInteraction from './speechinteraction/SpeechInteraction';
import StraightLine from './straightline/StraightLine';
import TableVideo from './tablevideo/TableVideo';
import TextStimulus from './textstimulus/TextStimulus';
import TwoColumnClick from './twocolumnclick/TwoColumnClick';
import VennDiagram from './venndiagram/VennDiagram';

import ProcessMath from './shared/MathJaxRender';

import '../../styles/item/CreateInterface.css';
/**
 * React functional component to create item based on itemTypeCode.
 * This is an entry point component to start a new item creation.
 * 
 * @component
 * @memberof Interfaces
 * @inner
 * @namespace CreateInterface
 * 
 * @param {{item: object, onUpdate: function, config: object}} param passed in parameters
 * @param {object} param.item - Data that will contain the item information for creating/updating items
 * @param {function} param.onUpdate - Callback function that need to be called
 * if there is any change in the state of the item
 * @param {object} param.config Configuration object which contains, 
 * style code, program specific defaults, etc...
 * @param {object} param.api API information, if available.
 * @return {Component} - Item create component based on the itemTypeCode in item JSON
 * 
 * @example
 * <CreateInterface item={item} onUpdate={updateItem} />
 */
const CreateInterface = ({ item, onUpdate, config, api }) => {

  // can't show an item if we don't know the type
  const typeCode = item?.item_json?.itemTypeCode?.toLowerCase();

  if (!item || !typeCode) {
    // NOTE: show warning that says to select item type
    return '';
  }

  // Create props payload to pass to module
  const payload = {
    item,
    onUpdate,
    config,
    api
  };

  // Applying required styles based on style code
  // if style code is not passed default style will be applied
  applyStyles(config?.styleCode);

  const componentManifest = Object.freeze({
    af: <ActingForces {...payload} />,
    bg: <BackgroundGraphic {...payload} />,
    bs: <BiologySimulation {...payload} />,
    chm: <ChemistrySimulation {...payload} />,
    com: <CompositeItems {...payload} />,
    ccom: <CodeCompiler {...payload} />,
    csub: <CodeSubmit {...payload} />,
    cr: <ConstructedResponse {...payload} />,
    dd: <DropDown {...payload} />,
    embedded: <Embedded {...payload} />,
    er: <ExtendedResponse {...payload} />,
    firewall: <Firewall {...payload} />,
    gr: <Gears {...payload} />,
    'g-ord': <GraphicOrder {...payload} />,
    'g-sim': <GraphingSim {...payload} />,
    htsp: <HotSpot {...payload} />,
    lbng: <Labeling {...payload} />,
    ls: <LikertScale {...payload} />,
    lg: <LineGraph {...payload} />,
    ml: <MatchingLines {...payload} />,
    mcrb: <MatrixInteraction {...payload} />,
    mr: <MazeRunner {...payload} />,
    mdb: <MultiDropBucket {...payload} />,
    mc: <MultipleChoice {...payload} />,
    mts: <MultipleTabs {...payload} />,
    nc: <NumberConverter {...payload} />,
    ocs: <ObjectCanvas {...payload} />,
    ord: <Ordering {...payload} />,
    og: <OscillatingGraph {...payload} />,
    pp: <PlacingPoints {...payload} />,
    ps: <PunnettSquare {...payload} />,
    sr: <SampleReaction {...payload} />,
    sp: <ScatterPlot {...payload} />,
    st: <SelectText {...payload} />,
    s1l: <SingleLine {...payload} />,
    si: <SpeechInteraction {...payload} />,
    sl: <StraightLine {...payload} />,
    tvs: <TableVideo {...payload} />,
    ts: <TextStimulus {...payload} />,
    tcc: <TwoColumnClick {...payload} />,
    vd: <VennDiagram {...payload} />
  });
  
  const selectedComponent = componentManifest[typeCode];

  if (!selectedComponent) {
    return <div data-testid={'not-implemented'}>{typeCode} Not implemented</div>;
  }

  return (
    <div className='item-create-container'>
      <ProcessMath>{selectedComponent}</ProcessMath>
    </div>
  )
};

CreateInterface.propTypes = itemProps;

export default CreateInterface;
