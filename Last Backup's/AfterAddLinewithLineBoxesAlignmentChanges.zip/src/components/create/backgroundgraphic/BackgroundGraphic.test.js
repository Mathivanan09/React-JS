import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import BackgroundGraphic from './BackgroundGraphic';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <BackgroundGraphic />, container);
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the 
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <BackgroundGraphic item={{
                    item_json: {
                        itemTypeCode: 'BG'
                    }
                }
                } />, container);
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=container]");
        expect(component).not.toBeNull;
        // expect(component.children.length).toBe(4);

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=container]")).not.toBeNull;
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
    });

    it('The User will be able to set Item dimensions for the item in item dimensions field', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'bg',
                correctResponse: [],
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull;
        expect(minItemHeightInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

    it('The User will be able to set option dimensions for the options in item dimensions field', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'bg',
                dropzoneWidth: "180",
                dropzoneHeight: "60",
                correctResponse: [],
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let dropzoneWidthInput = document.querySelector('[data-testid=dropzoneWidth]');
        let dropzoneHeighttInput = document.querySelector('[data-testid=dropzoneHeight]');

        // Verify that the inputs exists
        expect(dropzoneWidthInput).not.toBeNull;
        expect(dropzoneHeighttInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(dropzoneWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(dropzoneHeighttInput, { target: { value: 666 } });

        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.dropzoneWidth).toBe(555);
        expect(item.item_json.dropzoneHeight).toBe(666);
    });

   it('Reusable checkbox to be on/off on check', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'bg',
                correctResponse: [],
                reusableAnswers: false,
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.reusableAnswers).toBe(false);

        let reusableAnswersCheckbox = document.querySelector('[data-testid=reusableAnswers]');

        // Verify that the checkbox exists
        expect(reusableAnswersCheckbox).not.toBeNull;

        // Update checkbox and verify store update
        fireEvent.click(reusableAnswersCheckbox);
        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.reusableAnswers).toBe(true);
    });

    it('invisibleDropzones checkbox to be on/off on selection' , async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'bg',
                correctResponse: [],
                invisibleDropzones: false,
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.invisibleDropzones).toBe(false);

        let invisibleDropzonesCheckbox = document.querySelector('[data-testid=invisibleDropzones]');

        // Verify that the checkbox exists
        expect(invisibleDropzonesCheckbox).not.toBeNull;

        // Update checkbox and verify store update
        fireEvent.click(invisibleDropzonesCheckbox);
        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.invisibleDropzones).toBe(true);
    });

    it('imageAlignment dropdown on change', async () => {

        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'bg',
                correctResponse: [],
                imageAlignment: 'Center',
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.imageAlignment).toBe('Center');

        let imageAlignmentDropdown = document.querySelector('[data-testid=imageAlignment]');

        // Verify that the dropdown exists
        expect(imageAlignmentDropdown).not.toBeNull;

        // Update dropdown and verify store update
        fireEvent.change(imageAlignmentDropdown, { target: { value: 'Left' } });
        act(() => {
            rerender(<Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.imageAlignment).toBe('Left');
    });

    it('Test add option event handler', async () => {
        
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'bg',
                correctResponse: [],
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        }
        );

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <BackgroundGraphic item={item} onUpdate={updateItem} />
            </Provider>
        );

         // Verify add option button exists
    const addOption = document.querySelector('[data-testid=bggraphic-addoption]');
    expect(addOption).not.toBeNull;

            // Fire event 'add option' then update the component
            fireEvent.click(addOption);
            act(() => {
                rerender(<Provider store={store}>
                    <BackgroundGraphic item={item} onUpdate={updateItem} />
                </Provider>);
            }
            );

            // Verify that the option was invoked
            expect(updateItem).toHaveBeenCalledTimes(0);


    });


         

})