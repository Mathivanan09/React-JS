import React, { useState } from 'react';
import PropTypes from 'prop-types';


import ReorderItems from '../../shared/ReorderItems';

import label from '../../../../constants/labelCodes';

/**
 * React functional component to create dropdown item
 *
 * @memberof DropdownResponse
 * @inner
 * 
 * @component
 * @namespace DropdownOptions
 * 
 * @param {{item: Object, onUpdate: func }} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating dropdown item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @return {DropdownOptions} DropdownOptions component for creating dropdown item
 * 
 * @example
 * <DropdownOptions item={} />
*/

const DropdownOptions = ({ options, onUpdate, correctResponse }) => {
  const DIR_UP = -1;
  const DIR_DOWN = 1;
  const PLACE_HOLDER_TEXT = 'Enter Text';
  const [optionDisablePosition, setOptionDisablePosition] = useState([]);

  const addOption = () => {
    onUpdate([...options, '']);
  }

  const saveOption = (i, value) => {
    const newOptions = [...options];
    newOptions[i] = value;
    onUpdate(newOptions);
  }

  const reorderItems = (counter, index) => {
    if (
      (counter === DIR_UP && index === 0) ||
      (counter === DIR_DOWN &&
        index === options.length - 1)
    ) {
      return;
    }

    const optionItem = options[index];
    const updatedOptionItems = options?.filter((_value, idx) => index !== idx) || [];

    updatedOptionItems.splice(index + counter, 0, optionItem);
    onUpdate(updatedOptionItems);
  };

  const removeOption = (index) => {
    const updatedOptions = options?.filter((_value, idx) => index !== idx) || [];
    onUpdate(updatedOptions)
  };

  return (
    <>
      {options ? (
        <div data-testid='options-container' className="p-3 rounded">
          <div className="row">
            <div className='col col-8'>
              <legend>
                {label.dd_options}
              </legend>
            </div>
            <div className='col col-4 text-right'>
              <button
                id={`arrow-plus`}
                icon='add'
                className='btn-sm btn-primary'
                onClick={(e) => {
                  e.preventDefault();
                  addOption();
                }}
                aria-label='plus-icon'
              ><span className='icon-add'>+ Add</span></button>
            </div>
          </div>
          <hr />
          {options.map(
            (option, i) => (
              <div className='row align-items-center' key={i}>
                <div className='col col-2 col-sm-1'>
                  <ReorderItems
                    listLength={options.length}
                    option={i}
                    onDownClick={() => reorderItems(DIR_DOWN, i)}
                    onUpClick={() => reorderItems(DIR_UP, i)}
                  />
                </div>
                {(optionDisablePosition[i] || (option !== correctResponse) && !optionDisablePosition[i]) ?
                  <>
                    <div className='col col-8 col-sm-10'>
                      <div className="input-group input-group-sm">
                        <input
                          id={`dropdown-option-${i}`}
                          type='text'
                          className='form-control'
                          style={{
                            'maxWidth': '100%'
                          }}
                          value={
                            option
                          }
                          placeholder={PLACE_HOLDER_TEXT}
                          onChange={(e) => {
                            saveOption(i, e.target.value);
                            optionDisablePosition[i] = true;
                          }}
                          onBlur={(e) => {
                            optionDisablePosition[i] = false;
                            setOptionDisablePosition({ ...optionDisablePosition });
                          }}
                          data-testid={`dropdown-option-${i}`}
                        />
                      </div>
                    </div>
                    <div className='col col-2 col-sm-1'>
                      <button
                        className='icon'
                        onClick={(e) => {
                          e.preventDefault();
                          removeOption(i);
                        }}
                        data-testid='option-item-remove-button'
                      >
                        <span className='icon-minus'>-</span>
                      </button>
                    </div>
                  </> :
                  <div className='col col-8 col-sm-10'>
                    <div className="input-group input-group-sm">
                      <input value={option}
                        id={`dropdown-option-${i}`}
                        type='text'
                        className='form-control'
                        style={{
                          'maxWidth': '100%'
                        }}
                        disabled={true}
                        placeholder={PLACE_HOLDER_TEXT}
                        data-testid={`dropdown-option-${i}`}
                      />
                    </div>
                  </div>
                }
              </div>
            ))}
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  )
}

DropdownOptions.propTypes = {
  options: PropTypes.any,
  onUpdate: PropTypes.func
};

export default DropdownOptions;
