import React from 'react';
import PropTypes from 'prop-types';

import label from '../../../../constants/labelCodes';

/**
 * React functional component to display the dropdown
 * 
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace Option
 *
 * @param {{data: object, value: string, onUpdate: function, updateKey: string, showSelect: boolean,
 * dataItemKey: string, textField: string, labelCode: string, isRequired: boolean}} param passed in parameters
 * @param {object} param.data - input values to be rendered, overrides default values
 * @param {string} param.value - Value that is selected and rendered as selected value
 * @param {function} param.onUpdate - function that trigger when a value is selected in dropdown
 * @param {string} param.updateKey - key in item JSON object that need to be updated with value
 * @param {bool} param.showSelect - controls whether to show Select as an option in dropdown
 * @param {string} param.dataItemKey - key value of the object treated as value while saving
 * @param {string} param.textField - text value of the object treated as label in dropdown
 * @param {string} param.labelCode - label code to look up and render the label of this component
 * @return {component} - component with dropdown
 * 
 * @example
 * <Option
    labelCode='multiple_choice_selection_required'
    onUpdate={updateItemJson}
    updateKey='min_selections'
    isRequired={true}
    value={item.item_json.min_selections}
  ></Option>
 *
  <Option
    labelCode='multiple_choice_selection_allowed'
    onUpdate={updateItemJson}
    updateKey='max_selections'
    isRequired={true}
    value={item.item_json.max_selections}
  ></Option>
 */
const Option = ({
    data,
    value,
    onUpdate,
    updateKey,
    showSelect,
    dataItemKey,
    textField,
    labelCode,
    disabled,
    isRequired,
    ...props
}) => {
    // Initialize component based on parameters passed
    if (data && data.length > 0) {
        defaultValues = data;
    }
    
    return (
        <div className='container'>
            <div className='align-items-center p-1 row'>
                <div
                    className='col col-12 col-lg-7 text-right'
                    align='end'
                    data-testid='dd-required'
                >
                    {label[labelCode || '']}:&nbsp;
                    <i className='required-field text-danger ms-1'>*</i>
                </div>
                <div className='col'>
                    <div className="input-group input-group-sm">
                        <input
                            required={isRequired}
                            id={labelCode}
                            type={'text'}
                            className='form-control'
                            value={
                                value
                            }
                            disabled={disabled}
                            onChange={(e) => {
                                let val = e.target.value;
                                onUpdate(updateKey, val);
                            }}
                            data-testid={props.dataTestId || 'dd-select'}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

Option.propTypes = {
    value: PropTypes.any,
    onUpdate: PropTypes.func,
    updateKey: PropTypes.string,
    dataItemKey: PropTypes.string,
    textField: PropTypes.string,
    labelCode: PropTypes.string,
    isRequired: PropTypes.bool,
    disabled: PropTypes.bool,
    dataTestId: PropTypes.string
};

export default Option;
