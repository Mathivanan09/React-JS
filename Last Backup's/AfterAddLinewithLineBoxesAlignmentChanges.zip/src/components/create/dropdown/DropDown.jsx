import React, { useState } from 'react';

import ItemDimensions from "../shared/ItemDimensions";
import StemContent from "../shared/StemContent";

import Option from './dropdown-options/Option';
import DropdownOptions from './dropdown-options/DropdownOptions';
import DropDownResponse from '../../display/response/dropdown/DropDownResponse';

import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import { itemProps } from '../../common/ItemHelper';
import label from '../../../constants/labelCodes';

/**
 * React functional component to create dropdown item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace DropDown
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating dropdown item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {DropDown} DropDown component for creating dropdown item
 *
 * @example
 * <DropDown item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'mc' },
    user_id: 0,
  }} />
*/

const DropDown = ({ item, onUpdate, config }) => {
  const [showRationale, setShowRationale] = useState([]);
  const correctResponse = item?.item_json.correctResponse || [];
  const rationaleList = item?.rationale?.optionList || [];
  const showHideRationale = (id) => {
    const showing = new Set([...showRationale]);
    if (showing.has(id)) {
      showing.delete(id);
    } else {
      showing.add(id);
    }
    setShowRationale([...showing]);
  };

  const handleDropdownValues = (key, value) => {
    const data = document.createElement('div');
    data.innerHTML = value;
    const dropdownElements = data.getElementsByClassName('constructedResponse-placeholder');
    const correctResponseTemp = [];
    const optionListTemp = [];
    const rationaleListTemp = [];
    if (dropdownElements.length > 0) {
      for (const element of dropdownElements) {
        const index = optionListTemp.length;
        const text = element.innerText;
        const elementId = element.id;
        if (elementId !== '') {
          rationaleListTemp.push({
            id: elementId,
            rationaleText: ''
          });

          optionListTemp.push({
            id: elementId,
            index,
            optionTags: [text],
            responseName: `Response ${index + 1}`,
            defaultValue: 'Select',
          });
          correctResponseTemp.push({
            id: elementId,
            value: text,
          });
        }
      }
    }


    const optionData = item?.item_json?.optionList || [];
    const newCorrectResponseList = handleExistingCorrectResponses(correctResponse, correctResponseTemp).map((each, index) => {
      each.responseName = `Response ${index + 1}`
      return each;
    });
    const newOptionList = handleExistingOptionList(optionData, optionListTemp, newCorrectResponseList);
    const newRationaleList = handleExistingRationaleResponses(rationaleList, rationaleListTemp);
    onUpdate({
      rationale: {
        optionList: newRationaleList
      },
      item_json: {
        ...item.item_json, ...{
          [key]: value,
          optionList: newOptionList,
          correctResponse: newCorrectResponseList
        }
      }
    });
  }

  const handleExistingCorrectResponses = (oldValues, newValues) => {
    return newValues.map(each => {
      const existingDropdown = oldValues.find(el => el.id === each.id);
      if (existingDropdown) {
        if (existingDropdown.value !== each.value) {
          existingDropdown.value = each.value;
          return existingDropdown;
        } else {
          return existingDropdown;
        }
      } else {
        return each;
      }
    })
  }

  const handleExistingOptionList = (oldValues, newValues, newCorrectResponseList) => {
    return newValues.map((each, index) => {
      const existingDropdown = oldValues.find(el => el.id === newCorrectResponseList[index].id);
      if (existingDropdown) {
        if (existingDropdown.value !== each.value) {
          existingDropdown.optionTags[existingDropdown.optionTags.findIndex(option => option === existingDropdown.value)] = newCorrectResponseList[index].value;
          existingDropdown.index = each.index;
          return existingDropdown;
        } else {
          return existingDropdown;
        }
      } else {
        return each;
      }
    })
  }

  const handleExistingRationaleResponses = (oldValues, newValues) => {
    return newValues.map(each => {
      const existingDropdown = oldValues.find(el => el.id === each.id);
      if (existingDropdown) {
        return existingDropdown;
      }

      return each;
    })
  }

  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  const handleRationaleChange = (data, index) => {
    const newList = [...(item.rationale?.optionList || [])];
    newList[index] = { ...newList[index], rationaleText: data };
    // prepare the payload
    const updatedItem = {
      rationale: { optionList: newList }
    };
    onUpdate(updatedItem);
  };

  const handleDropdownOptionsValueChange = (key, value, i) => {
    let updatedItem = {};
    if (key === 'correctResponse') {
      const correctResponse = [...(item?.item_json.correctResponse || [])];
      correctResponse[i] = { ...correctResponse[i], [key]: value }
      updatedItem = {
        item_json: {
          correctResponse: correctResponse
        }
      };
    }
    else {
      const optionList = [...(item?.item_json.optionList || [])];
      optionList[i] = { ...optionList[i], [key]: value }
      updatedItem = {
        item_json: {
          optionList: optionList
        }
      };
    }

    onUpdate(updatedItem);
  }

  const removeOption = (optionId) => {
    let newList = [...(item.rationale?.optionList || [])];
    let corretResponseList = [...(item?.item_json?.correctResponse || [])];
    let optionList = [...(item?.item_json?.optionList || [])];
    newList = newList.filter(({ id }) => id !== optionId);
    corretResponseList = corretResponseList.filter(({ id }) => id !== optionId);
    optionList = optionList.filter(({ id }) => id !== optionId);
    const stemContentEL = document.createElement('div');
    stemContentEL.id = 'stem-content-dropdown';
    stemContentEL.innerHTML = item?.item_json?.stemContent;
    stemContentEL.style.display = 'none';
    const dropDownEls = stemContentEL.getElementsByClassName(
      'constructedResponse-placeholder'
    );

    for (const elem of dropDownEls) {
      if (elem.id === optionId) {
        if (elem.childNodes.length > 0) {
          const textNode = document.createTextNode(elem.innerHTML);
          elem.replaceWith(textNode);
        }

      }
    }

    const updatedStem = stemContentEL.innerHTML;

    onUpdate({
      item_json: {
        stemContent: updatedStem,
        optionList: optionList,
        correctResponse: corretResponseList
      },
      rationale: { optionList: newList }
    });
  }

  return (<>
    {item ? (
      <div data-testid={'container'}>
        <div data-testid={'id-container'}>
          <ItemDimensions
            minWidth={item?.item_json?.minItemWidth || 0}
            minHeight={item?.item_json?.minItemHeight || 0}
            onChange={(dimension) => {
              if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                updateItemJson('minItemWidth', dimension.minWidth);
              }
              if (dimension?.minHeight !== item.item_json.minItemHeight) {
                updateItemJson('minItemHeight', dimension.minHeight);
              }
            }}
          />
        </div>
        <div data-testid={'stem-container'}>
          <StemContent
            data={item?.item_json?.stemContent}
            onUpdate={(key, value) => {
              handleDropdownValues(key, value);
            }}
            config={{
              insertResponse: { type: 'cr-dropdown', label: 'Insert Response' }
            }}
            fieldName={'stemContent'}
          />
        </div>
        <div data-testid={'dropdown-container'} className="mt-3">
          {item.item_json?.optionList?.map(
            (responseOption, i) => (
              <div key={responseOption?.id}
                data-testid='dropdown-item-container' className='container mb-3'>
                <div className="row justify-content-sm-center">
                  <div className='col col-12 col-sm-12'>
                    <div className='row'>
                      <div className='col col-8 col-sm-10'>
                        <legend>{responseOption?.responseName} : {item?.item_json?.correctResponse[i]?.value}</legend>
                      </div>
                      <div className=' col col-4 col-sm-2 text-right'>
                        <button
                          className='icon'
                          onClick={(e) => {
                            e.preventDefault();
                            removeOption(responseOption?.id);
                          }}
                          data-testid={'option-remove-button'}
                        >
                          <span className='icon-minus'>-</span>
                        </button>
                      </div>
                    </div>
                    <div className='row bg-light p-3 rounded'>
                      <div className='col col-12 col-sm-7'>
                        <DropdownOptions options={responseOption?.optionTags}
                          correctResponse={item?.item_json?.correctResponse[i]?.value}
                          onUpdate={(options) => {
                            handleDropdownOptionsValueChange('optionTags', options, i)
                          }}
                        ></DropdownOptions>
                        <div className='my-2'>
                          <button
                            className='btn btn-primary btn-sm'
                            onClick={() => showHideRationale(responseOption?.id)}
                            data-testid={'rationale-button'}
                          >
                            {label.rationale}
                          </button>
                        </div>
                        {
                          showRationale.indexOf(responseOption?.id) !== -1 && (
                            <div className="mt-2">
                              <CKEditorBase
                                type='inline'
                                data={
                                  item?.rationale?.optionList[i]?.rationaleText
                                }
                                onChange={
                                  (data) => {
                                    handleRationaleChange(data, i);
                                  }
                                }
                                placeholder={label.enter_rationale_content}
                                config={{ removePlugins: ['TagAccessibility'] }}
                              />
                            </div>
                          )
                        }
                      </div>
                      <div className='col col-12 col-sm-5'>
                        {/* Response Name */}
                        <div className="row mt-2">
                          <div className='col col-12 col-sm-12'>
                            <Option
                              labelCode='response_name'
                              onUpdate={
                                (key, value) => {
                                  handleDropdownOptionsValueChange(key, value, i)
                                }
                              }
                              updateKey='responseName'
                              isRequired={true}
                              value={responseOption?.responseName}
                              dataTestId={'dd_response_name'}
                            />
                          </div>
                        </div>
                        {/* Default Value */}
                        <div className="row mt-2">
                          <div className='col col-12 col-sm-12'>
                            <Option
                              labelCode='dd_default_value'
                              onUpdate={
                                (key, value) => {
                                  handleDropdownOptionsValueChange(key, value, i)
                                }
                              }
                              updateKey='defaultValue'
                              isRequired={true}
                              value={responseOption?.defaultValue}
                              dataTestId={'dd_default_value'}
                            />
                          </div>
                        </div>
                        {/* Correct Response */}
                        <div className="row mt-2">
                          <div className='col col-12 col-sm-12'>
                            <Option
                              labelCode='correct_response'
                              onUpdate={
                                (key, value) => {
                                  handleDropdownOptionsValueChange(key, value, i)
                                }
                              }
                              disabled={true}
                              updateKey='correctResponse'
                              isRequired={true}
                              value={item?.item_json?.correctResponse[i]?.value}
                              dataTestId={'dd_correct_response'}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
        <div data-testid={'dropdown-correctresponse-container'} className="mt-3">
          <div className={'row p-3'} data-testid={'dropdown-response-container'}>
            <fieldset className={'bg-light p-3 rounded m-1'}>
              <legend>{label.correct_response}</legend>
              <div className='bg-white p-3 rounded'>
                <DropDownResponse
                  item={item}
                  stemComponent={null}
                  config={config}
                  showCorrectResponse={true}
                  isPreview={false}
                />
              </div>
            </fieldset>
          </div>
        </div>
      </div>
    ) : (
      <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
    )}
  </>)
}

DropDown.propTypes = itemProps;

export default DropDown;
