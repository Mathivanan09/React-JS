import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import SourceDetails from './SourceDetails';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <SourceDetails />, container);
        });

    });

    it("The User will be able to select Source from Source drop-down field", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'TS',
                source: {
                    sourceType: "COPYRIGHT"
                }
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    source: {
                        ...item.item_json.source, ...payload.item_json.source
                    }
                }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SourceDetails item_json={item?.item_json} updateItemJson={updateItem} />
            </Provider>
        );
        expect(item.item_json.source.sourceType).toBe("COPYRIGHT");

        let sourceType = screen.getByTestId('ts-source');

        // Verify that the inputs exists
        expect(sourceType).not.toBeNull;

    });

    it("When the User select the Commissioned and Public Domain from Source drop-down, the User will be able to enter content in Citation and/or URL and in Acknowledgment and also can give Publisher name in publisher field", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'TS',
                source: {
                    acknowledge: "<p id=\"cb-44693-9-9\">Acknowledge</p>\n",
                    author: null,
                    information: "<p id=\"cb-44693-9-9\">Citation</p>\n",
                    publisher: 'KAP',
                    sourceType: 'COMMISSIONED',
                    termBegin: null,
                    termEnd: null,
                },
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    source: {
                        ...item.item_json.source, ...payload.item_json.source
                    }
                }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SourceDetails item_json={item?.item_json} updateItemJson={updateItem} />
            </Provider>
        );
        expect(item.item_json.source.sourceType).toBe("COMMISSIONED");
        expect(item.item_json.source.publisher).toBe("KAP");
        expect(item.item_json.source.acknowledge).toBe("<p id=\"cb-44693-9-9\">Acknowledge</p>\n");
        expect(item.item_json.source.information).toBe("<p id=\"cb-44693-9-9\">Citation</p>\n");

        let sourceType = screen.getByTestId('ts-source');
        let publisher = screen.getByTestId('ts-publisher');
        let acknowledge = screen.getByTestId('ts-acknowledge');
        let information = screen.getByTestId('ts-citation');

        // Verify that the inputs exists
        expect(sourceType).not.toBeNull;
        expect(publisher).not.toBeNull;
        expect(acknowledge).not.toBeNull;
        expect(information).not.toBeNull;

    });

    it("When the User select the Copyright from Source drop-down, the User will be able to enter content in Citation and / or URL and in Acknowledgment and also able to give Term begin and end date for Copyright and also can give Publisher name in publisher field", async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'TS',
                source: {
                    acknowledge: "<p id=\"cb-44693-9-9\">Acknowledge</p>\n",
                    author: null,
                    information: "<p id=\"cb-44693-9-9\">Citation</p>\n",
                    publisher: 'KAP',
                    sourceType: 'COPYRIGHT',
                    termBegin: "2022-02-16T18:30:00.000Z",
                    termEnd: "2022-02-22T18:30:00.000Z",
                },
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    source: {
                        ...item.item_json.source, ...payload.item_json.source
                    }
                }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SourceDetails item_json={item?.item_json} updateItemJson={updateItem} />
            </Provider>
        );
        expect(item.item_json.source.sourceType).toBe("COPYRIGHT");
        expect(item.item_json.source.publisher).toBe("KAP");
        expect(item.item_json.source.acknowledge).toBe("<p id=\"cb-44693-9-9\">Acknowledge</p>\n");
        expect(item.item_json.source.information).toBe("<p id=\"cb-44693-9-9\">Citation</p>\n");
        expect(item.item_json.source.termBegin).toBe("2022-02-16T18:30:00.000Z");
        expect(item.item_json.source.termEnd).toBe("2022-02-22T18:30:00.000Z");


        let sourceType = screen.getByTestId('ts-source');
        let publisher = screen.getByTestId('ts-publisher');
        let acknowledge = screen.getByTestId('ts-acknowledge');
        let information = screen.getByTestId('ts-citation');
        let termBegin = screen.getByTestId('ts-termBegin');
        let termEnd = screen.getByTestId('ts-termEnd');


        // Verify that the inputs exists
        expect(sourceType).not.toBeNull;
        expect(publisher).not.toBeNull;
        expect(acknowledge).not.toBeNull;
        expect(information).not.toBeNull;
        expect(termBegin).not.toBeNull;
        expect(termEnd).not.toBeNull;

    });

    it("When the User select Myself from Source drop-down, the User will get their Author name and Publisher name in author and publisher field", async () => {

        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'TS',
                source: {
                    acknowledge: null,
                    author: 'User Two',
                    information: null,
                    publisher: 'KAP',
                    sourceType: 'MYSELF',
                    termBegin: null,
                    termEnd: null,
                },
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: {
                    source: {
                        ...item.item_json.source, ...payload.item_json.source
                    }
                }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SourceDetails item_json={item?.item_json} updateItemJson={updateItem} />
            </Provider>
        );
        expect(item.item_json.source.sourceType).toBe("MYSELF");
        expect(item.item_json.source.publisher).toBe("KAP");
        expect(item.item_json.source.author).toBe("User Two");

        let sourceType = screen.getByTestId('ts-source');
        let publisher = screen.getByTestId('ts-publisher');
        let author = screen.getByTestId('ts-author');

        // Verify that the inputs exists
        expect(sourceType).not.toBeNull;
        expect(publisher).not.toBeNull;
        expect(author).not.toBeNull;
    })

})
