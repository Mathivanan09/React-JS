import React, { useState } from 'react';
import uuid from 'react-uuid';
import { MultiSelect } from '@progress/kendo-react-dropdowns';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';

import SourceDetails from './SourceDetails';

import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import { itemProps } from '../../common/ItemHelper';
import label from '../../../constants/labelCodes';
import fetch from '../../../utility/default';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '@progress/kendo-theme-bootstrap/dist/all.css';
import '../../../styles/item/TextStimulus.css';

/**
 * React functional component to create Text Stimulus item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace TextStimulus
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Text Stimulus item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {TextStimulus} TextStimulus component for creating Text Stimulus item
 *
 * @example
 * <TextStimulus item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'ts' },
    user_id: 0,
  }} />
 */
const TextStimulus = ({ item, onUpdate, config }) => {

    const itemJson = item?.item_json;
    const descriptionPlaceholder = label.enter_content;
    const stemPlaceholder = label.enter_content;
    const [author] = useState(item?.userName ? item?.userName : item?.created_user_name)
    const defaultDate = new Date(9999, 11, 31);
    const genreOptions = [
        { code: 'TS_ARGUMENTATIVE', name: 'Argumentative' },
        { code: 'TS_EXPOSITORY', name: 'Expository' },
        { code: 'TS_INSTRUCTIONAL', name: 'Instructional' },
        { code: 'TS_NARRATIVE', name: 'Narrative' }
    ]

    const descriptionViewedBy = [
        { id: 'TS_EDUCATOR', name: 'Educator' },
        { id: 'TS_PROCTOR', name: 'Proctor' },
        { id: 'TS_SCORER', name: 'Scorer' },
        { id: 'TS_STUDENT', name: 'Student' }
    ]
    const default_description = fetch('text-stimulus-description')
    let updatedValue = []

    //Return descriptionViewedBy updated value
    const getUpdatedValue = () => {

        for (let i = 0; i < descriptionViewedBy.length; i++) {
            for (let j = 0; j < itemJson.descriptionViewBy.length; j++) {
                if (descriptionViewedBy[i].id === itemJson.descriptionViewBy[j] || descriptionViewedBy[i].id === itemJson.descriptionViewBy[j].id) {
                    updatedValue.push({ id: descriptionViewedBy[i].id, name: descriptionViewedBy[i].name })
                }
            }
        }
        return updatedValue
    }
    const dataObj = itemJson?.descriptionViewBy ? getUpdatedValue() : default_description

    const [defaultValue, setDefaultValue] = useState(dataObj);

    // update item json based on key/value pairs
    const updateItemJson = (key, value) => {
        let updatedItem = {}
        let itemID = uuid();

        if (key == 'termBegin' || key == 'termEnd') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        ...itemJson.source, ...{ [key]: value }
                    }
                }
            }
        }
        else if (key == 'acknowledge') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        ...itemJson.source,
                        ...{
                            [key]: value
                        }
                    }
                }
            }
        }
        else if (key == 'information') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        ...itemJson.source,
                        ...{
                            [key]: value
                        }
                    }
                }
            }
        }
        else if (key == 'sourceType' && value == '') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        acknowledge: null,
                        author: null,
                        information: null,
                        publisher: itemJson?.source?.publisher,
                        sourceType: value,
                        termBegin: null,
                        termEnd: null
                    },
                    uuid: itemID || ''
                }
            };
        }
        else if (key == 'sourceType' && value == 'COMMISSIONED' || value == 'PUBLIC_DOMAIN') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        acknowledge: itemJson?.source?.acknowledge || null,
                        author: null,
                        information: itemJson?.source?.information || null,
                        publisher: itemJson?.source?.publisher,
                        sourceType: value,
                        termBegin: null,
                        termEnd: null,
                    },
                    uuid: itemID || ''
                }
            };
        }
        else if (key == 'sourceType' && value == 'MYSELF') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        acknowledge: null,
                        author: author,
                        information: null,
                        publisher: itemJson?.source?.publisher,
                        sourceType: value,
                        termBegin: null,
                        termEnd: null
                    },
                    uuid: itemID || ''
                }
            };
        }
        else if (key == 'sourceType' && value == 'COPYRIGHT') {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    source: {
                        acknowledge: itemJson?.source?.acknowledge || null,
                        author: null,
                        information: itemJson?.source?.information || null,
                        publisher: itemJson?.source?.publisher,
                        sourceType: value,
                        termBegin: itemJson?.source?.termBegin || null,
                        termEnd: itemJson?.source?.termEnd || defaultDate
                    },
                    uuid: itemID || ''
                }
            };
        }
        else {
            updatedItem = {
                ...item,
                item_json: {
                    ...itemJson,
                    [key]: value
                }
            }
        }
        onUpdate(updatedItem);
    };

    //update stem item json based on key/value pairs
    const updateItemStem = (key, value) => {
        onUpdate({
            ...item,
            item_json: {
                ...itemJson,
                ...{
                    [key]: value
                }
            }
        });
    };

    //update description item json based on key/value pairs
    const updateItemDescription = (key, value) => {
        onUpdate({
            ...item,
            item_json: {
                ...itemJson,
                ...{
                    [key]: value
                }
            }
        });
    };

    // update item json for Description Viewed By
    const updateDescriptionViewedBY = (event) => {
        setDefaultValue(event.value)
        let descriptionView = event.value;
        let descriptionViewValue = [];
        if (descriptionView !== null || descriptionView !== undefined) {
            for (let i = 0; i < descriptionView.length; i++) {
                descriptionViewValue.push(descriptionView[i]?.id);
            }
        }

        // update item json on changing the Description type
        const updatedItem = {
            ...item,
            item_json: {
                ...itemJson,
                descriptionViewBy: descriptionViewValue,
            }
        };
        onUpdate(updatedItem);
    };

    return (
        <>
            {item ? (
                <div>
                    <div data-testid={'container'}>
                        <div data-testid={'id-container'}>
                            <ItemDimensions
                                minWidth={item?.item_json?.minItemWidth || 0}
                                minHeight={item?.item_json?.minItemHeight || 0}
                                onChange={(dimension) => {
                                    if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                                        updateItemJson('minItemWidth', dimension.minWidth);
                                    }
                                    if (dimension?.minHeight !== itemJson.minItemHeight) {
                                        updateItemJson('minItemHeight', dimension.minHeight);
                                    }
                                }}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className='col-md-5 col-sm-12'>
                            <fieldset className={'bg-light p-3 rounded m-1'}>
                                <div className='row p-1'>
                                    <div className='col-4 col-md-5 text-right'>
                                        {label.genre}:&nbsp;
                                    </div>
                                    <div className='col-8 col-md-7' data-testid={'ts-genre'}>
                                        <select
                                            id='ts-genre'
                                            className='form-select form-select-sm'
                                            value={itemJson.stimulusType}
                                            onChange={(e) => updateItemJson('stimulusType', e.target.value)}
                                        >
                                            <option value=''>Select</option>
                                            {genreOptions.map((options) => (
                                                <option key={options.code} value={options.code}>
                                                    {options.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                                <div className='row p-1 mt-2'>
                                    <div className='col-4 col-md-5 text-right'>
                                        {label.description_viewed}:&nbsp;
                                    </div>
                                    <div className='col-8 col-md-7' data-testid={'ts-descriptionViewedBy'}>
                                        <MultiSelect data={descriptionViewedBy}
                                            id='text-stimulus-description'
                                            value={defaultValue}
                                            onChange={updateDescriptionViewedBY}
                                            dataItemKey="id"
                                            textField="name" />
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                        <div className='col-md-7 col-sm-12 ml-2'>
                            <fieldset className={'bg-light p-3 rounded m-1'}>
                                <div className='row pt-2'>
                                    <div className='col-lg-2 col-md-3'>
                                        <legend className='pt-1'>Description</legend>
                                    </div>
                                    <div className='col-lg-10 col-md-9' data-testid={'ts-description'}>
                                        <CKEditorBase
                                            type='inline'
                                            data={itemJson?.description}
                                            fieldName='description'
                                            placeholder={descriptionPlaceholder}
                                            className='description_height content_style'
                                            onChange={(value) => updateItemDescription('description', value)}
                                            config={{ removePlugins: ['TagAccessibility'] }}
                                        />
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                    <div data-testid={'stem-container'}>
                        <StemContent
                            placeholder={stemPlaceholder}
                            data={itemJson?.passageContent}
                            onUpdate={updateItemStem}
                            fieldName={'passageContent'}
                        />
                    </div>

                    <SourceDetails item_json={item?.item_json} updateItemJson={updateItemJson} />

                </div>
            ) : (
                <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
            )}
        </>
    );
};

TextStimulus.propTypes = itemProps;

export default TextStimulus;
