import React from 'react';
import PropTypes from 'prop-types';

import label from '../../../constants/labelCodes';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';

import { DatePicker } from '@progress/kendo-react-dateinputs';

/**
 * React functional component
 *
 * @param {JSON} item_json - JSON data that will contain the item?.item_json information
 * for creating/updating text stimulus item
 * @param {function} updateItemJson - the function that needs to be called
 * if there is any change in the input field
 * @return {component} - SourceDetails component is common for media and text stimulus item
 */

const SourceDetails = ({ updateItemJson, item_json }) => {

    const descriptionPlaceholder = label.enter_content;
    let sourceOptions = [
        { code: 'COMMISSIONED', name: 'Commissioned' },
        { code: 'COPYRIGHT', name: 'Copyright' },
        { code: 'MYSELF', name: 'Myself' },
        { code: 'PUBLIC_DOMAIN', name: 'Public Domain' }
    ]
    const endDate = new Date(9999, 11, 31)

    return (
        <>
            <fieldset className="bg-light p-3 rounded m-1">
                <legend>Source Details</legend>
                <div className='row align-items-center p-1'>
                    <div className='col-md-4 pt-2'>
                        <div className='row'>
                            <div className='col-4 col-md-6 col-lg-6 text-right'>
                                {label.source}:&nbsp;
                                <i className='required-field text-danger ms-1'>*</i>
                            </div>
                            <div className='col-8 col-md-6 col-lg-6' data-testid={'ts-source'}>
                                <select
                                    required
                                    id='ts-source'
                                    className='form-select form-select-sm'
                                    value={item_json?.source?.sourceType || ''}
                                    onChange={(e) => { updateItemJson('sourceType', e.target.value) }}
                                >
                                    <option value=''>Select</option>
                                    {sourceOptions.map((options) => (
                                        <option key={options.code} value={options.code}>
                                            {options.name}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>

                    {item_json?.source?.sourceType == "MYSELF" && (
                        <div className="col-md-4 pt-2">
                            <div className='row'>
                                <div className='col-4 col-md-6 col-lg-6 text-right'>
                                    {label.author}:&nbsp;
                                </div>
                                <div className='col-8 col-md-6 col-lg-6' data-testid='ts-author'>
                                    <input type='text' className='form-control' value={item_json?.source?.author} disabled={true} />
                                </div>
                            </div>
                        </div>
                    )}
                    {
                        <div className="col-md-4 pt-2">
                            <div className='row'>
                                <div className='col-4 col-md-6 col-lg-6 text-right'>
                                    {label.publisher}:&nbsp;
                                </div>
                                <div className='col-8 col-md-6 col-lg-6' data-testid='ts-publisher'>
                                    <input type='text' className='form-control' value={item_json?.source?.publisher} disabled={true} />
                                </div>
                            </div>
                        </div>
                    }
                </div>
            </fieldset>

            {item_json?.source?.sourceType != "MYSELF" &&
                item_json?.source?.sourceType != "" &&
                item_json?.source?.sourceType != null && (
                    <div>
                        <fieldset className={'bg-light mt-2 p-3 rounded m-1'}>
                            {label.citation}:&nbsp;
                            <i className='required-field text-danger ms-1'>*</i>
                            <div className='pt-2' data-testid='ts-citation'>
                                <CKEditorBase
                                    required={true}
                                    type='inline'
                                    data={item_json?.source?.information || ''}
                                    fieldName='information'
                                    placeholder={descriptionPlaceholder}
                                    className='description_height content_style'
                                    onChange={(value) => updateItemJson('information', value)}
                                    config={{ removePlugins: ['TagAccessibility'] }}
                                />
                            </div>
                        </fieldset>
                        {item_json?.source.sourceType == "COPYRIGHT" &&
                            <fieldset className={'bg-light mt-2 p-3 rounded m-1'}>
                                <legend className='pt-1'>Copyright Permission</legend>
                                <div className="row">
                                    <div className='col-md-1'></div>
                                    <div className='col-md-5'>
                                        <div className='row'>
                                            <div className="col-6 col-md-6 text-right">
                                                {label.begin_date}:&nbsp;
                                            </div>
                                            <div className='col-6 col-md-6' data-testid='ts-termBegin'>
                                                <DatePicker
                                                    name="termBegin"
                                                    format="MM/dd/yyyy"
                                                    className='ps-2'
                                                    max={(item_json?.source?.termEnd && new Date(item_json?.source?.termEnd)) || undefined}
                                                    onChange={(e) =>
                                                        updateItemJson('termBegin', e.target.value)
                                                    }
                                                    value={
                                                        item_json?.source?.termBegin &&
                                                        new Date(item_json?.source?.termBegin)
                                                    }
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-md-5'>
                                        <div className='row'>
                                            <div className="col-6 col-md-6 text-right">
                                                {label.end_date}:&nbsp;
                                            </div>
                                            <div className='col-6 col-md-6' data-testid='ts-termEnd'>
                                                <DatePicker
                                                    name="termEnd"
                                                    format="MM/dd/yyyy"
                                                    className='ps-2'
                                                    min={((item_json?.source?.termBegin && new Date(item_json?.source?.termBegin)) || undefined)}
                                                    value={
                                                        item_json?.source?.termEnd &&
                                                        new Date(item_json?.source?.termEnd)
                                                    }
                                                    defaultValue={endDate}
                                                    onChange={(e) => updateItemJson('termEnd', e.target.value)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        }
                        <fieldset className={'bg-light mt-2 p-3 rounded m-1'}>
                            {label.acknowledgement}:&nbsp;
                            <i className='required-field text-danger ms-1'>*</i>
                            <div className='pt-2' data-testid='ts-acknowledge'>
                                <CKEditorBase
                                    required={true}
                                    type='inline'
                                    data={item_json?.source?.acknowledge || ''}
                                    fieldName='acknowledge'
                                    placeholder={descriptionPlaceholder}
                                    className='description_height content_style'
                                    onChange={(value) => updateItemJson('acknowledge', value)}
                                    config={{ removePlugins: ['TagAccessibility'] }}
                                />
                            </div>
                        </fieldset>
                    </div>
                )}
        </>
    )
}


SourceDetails.propTypes = {
    updateItemJson: PropTypes.func,
    item_json: PropTypes.object
};

export default SourceDetails;
