import React, { useState } from 'react';
import uuid from 'react-uuid';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';
import AddMedia from '../shared/AddMedia';

import TableVideoOutputOptions from './tablevideo-commons/TableVideoOutputOption';
import TableVideoSimulationOption from './tablevideo-commons/TableVideoSimulationOption';
import TableVideoInputOptions from './tablevideo-commons/TableVideoInputOptions';

import { itemProps } from '../../common/ItemHelper';
import label from '../../../constants/labelCodes';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/TableVideo.css';

const OC = 'Create';
const OU = 'Update';

/**
 * React functional component to create Table Video item
 *

 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace TableVideo
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Table Video item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {TableVideo} TableVideo component for creating Table Video item
 *
 * @example
 * <TableVideo item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'tvs' },
    user_id: 0,
  }} />
 */
const TableVideo = ({ item, onUpdate, config }) => {

  const stemPlaceholder = label.enter_content;

  const [selectMedia, setSelectMedia] = useState({
    show: false,
    index: 0
  });
  const [showDefaultMedia, setShowDefaultMedia] = useState(false);

  /**
   * Event handler for stem content update
   *
   * @param {String} key
   * @param {String} value
   */
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  /**
   *  Event handeler for updating inputs and input option items.
   *
   * @param {Object} data
   * @param {Number} i
   */
  const handleInputOptions = (data, i, isReorder) => {
    const updatedInputList = [...item?.item_json?.inputList];
    updatedInputList[i] = data;
    const optionList = generateSimulations(updatedInputList, isReorder);
    onUpdate({
      item_json: {
        ...item.item_json,
        ...{
          inputList: updatedInputList,
          optionList
        }
      }
    });
  };

  /**
   *  Used to create and input option
   *
   */
  const addNewInput = () => {
    onUpdate({
      item_json: {
        ...item.item_json,
        ...{
          noOfInputs: (item?.item_json?.inputList?.length || 0) + 1,
          inputList: [
            ...(item?.item_json?.inputList || []),
            ...[
              {
                index: item?.item_json?.inputList?.length || 0,
                id: uuid(),
                options: [],
                title: ''
              }
            ]
          ],
          optionList: []
        }
      }
    });
  };

  /**
   * Used to remove input based on ID
   *
   * @param {String} id
   */
  const removeInputOption = (id) => {
    let inputList = [...(item.item_json.inputList || [])];
    if (inputList.length > 0) {
      inputList = inputList.filter((each) => each.id !== id);
      const optionList = generateSimulations(inputList, false);
      onUpdate({
        item_json: {
          ...item.item_json,
          ...{
            inputList,
            noOfInputs: inputList.length,
            optionList
          }
        }
      });
    }
  };

  /**
   *  Event handeler for updating outputs and input option items.
   *
   * @param {Object} data
   * @param {Number} i
   */
  const handleOutputOptions = (data, i) => {
    const updatedOutputList = [...item?.item_json?.outputList];
    updatedOutputList[i] = data;
    const optionList = updateOptionList(data, i, OU);
    onUpdate({
      item_json: {
        ...item.item_json,
        ...{ outputList: updatedOutputList, optionList }
      }
    });
  };

  /**
   *
   *
   * @param {String || Object} data
   * @param {Number} i
   * @param {String} type
   * @return {Array}
   */
  const updateOptionList = (data, i, type) => {
    let optionList = [...(item?.item_json?.optionList || [])];
    optionList = optionList.map((each) => {
      let outputs = [...(each.outputs || [])];
      if (type === OC) {
        outputs = [...outputs, ...[{ label: data }]];
      } else if (type === OU) {
        if (outputs) {
          outputs[i] = { ...outputs[i], ...{ label: data.textHtml } };
        }
      } else {
        outputs.splice(i, 1);
      }
      return { ...each, ...{ outputs } };
    });

    return optionList;
  };

  /**
   * Used to create and output option
   *
   */
  const addNewOutput = () => {
    const optionList = [...updateOptionList('data', 0, OC)];
    onUpdate({
      item_json: {
        ...item.item_json,
        ...{
          noOfOutputs: (item?.item_json?.outputList?.length || 0) + 1,
          outputList: [
            ...(item?.item_json?.outputList || []),
            ...[
              {
                index: item?.item_json?.outputList?.length || 0,
                id: uuid(),
                textHtml: ''
              }
            ]
          ],
          optionList
        }
      }
    });
  };

  /**
   *  Removed Output from outputs data and updates input object array.
   *
   * @param {String} id
   * @param {Number} index
   */
  const removeOutputOption = (id, index) => {
    let outputList = [...(item.item_json.outputList || [])];
    if (outputList.length > 0) {
      outputList = outputList.filter((each) => each.id !== id);
      const optionList = updateOptionList(null, index, null);
      onUpdate({
        item_json: {
          ...item.item_json,
          ...{
            outputList,
            noOfOutputs: outputList.length,
            optionList
          }
        }
      });
    }
  };

  /**
   *  Used to update simulation output values
   *
   * @param {String} value
   * @param {Number} index
   */
  const handleSimulationOutputs = (value, index) => {
    const optionList = [...item?.item_json?.optionList];

    optionList[index] = {
      ...optionList[index],
      ...value
    };

    onUpdate({
      item_json: {
        ...item.item_json,
        ...{
          optionList
        }
      }
    });
  };

  /**
   *  Generate combinations of input options using Cartesian/combination algorithm
   *
   * @param {Array} args
   * @return {*}
   */
  const generateCombinations = (args) => {
    const r = [];
    const max = args.length - 1;
    function helper(arr, i) {
      for (let j = 0, l = args[i].length; j < l; j++) {
        const a = arr.slice(0); // clone arr
        a.push(args[i][j]);
        if (i == max) r.push(a);
        else helper(a, i + 1);
      }
    }
    helper([], 0);
    return r;
  };

  /**
   * Generates simulations based on input and output options.
   *
   * @param {Object} inputObject
   * @return {*}
   */
  const generateSimulations = (inputObject, isReorder) => {
    const combinations = generateCombinations(
      inputObject.map((each) => each.options || [])
    );
    const outputList = [...(item?.item_json?.outputList || [])];
    let inputArrayObject = [];
    if (inputObject.length > 0) {
      inputArrayObject = combinations.map((combination, index) => {
        let outputs;
        const previousData = getPreviousCombinationOutputs(combination);
        if (isReorder) {
          outputs = previousData.outputs;
        } else {
          outputs = outputList.map((each) => {
            return {
              label: each?.textHtml
            };
          });
        }

        return isReorder ? {
          index,
          combination,
          outputs,
          fileName: previousData.fileName,
          id: previousData.id,
          url: previousData.url,
          mediaType: previousData.mediaType,
          mediaFormat: previousData.mediaFormat,
          fileType: previousData.fileType
        } : {
          index,
          combination,
          outputs,
        };
      });
      return inputArrayObject;
    } else {
      return [];
    }
  };

  const getPreviousCombinationOutputs = (newCombination) => {
    const optionList = [...(item?.item_json?.optionList || [])];
    const requiredOutputOptions = optionList.find((each) => {
      const rightCombination = each.combination.filter((combination, i) => {
        return combination.index === newCombination[i].index;
      });
      if (rightCombination.length === newCombination.length) {
        return each;
      }
    });

    return requiredOutputOptions;
  };

  /**
   *  Save / Update Media data for respective simulations
   *
   * @param {Object} data
   */
  const saveMediaData = (data) => {
    const selectedMediaItem = data[0];
    if (selectMedia.show) {
      const optionList = [...item?.item_json?.optionList];

      optionList[selectMedia.index] = {
        ...optionList[selectMedia.index],
        ...{
          fileName: selectedMediaItem?.file_name,
          id: selectedMediaItem?.id,
          url: `/${selectedMediaItem?.media_type.toLowerCase()}/${selectedMediaItem.assessment_program_id
            }/${selectedMediaItem?.id}/${selectedMediaItem.attachment_id}/${selectedMediaItem?.file_name
            }.${selectedMediaItem.file_type}`,
          mediaType: selectedMediaItem?.media_type,
          mediaFormat: selectedMediaItem?.media_format,
          fileType: selectedMediaItem?.file_type
        }
      };

      onUpdate({
        item_json: {
          ...item.item_json,
          ...{
            optionList
          }
        }
      });

      setSelectMedia({
        show: false,
        index: 0
      });
    }
  };

  const removeSimulationMedia = (index) => {
    const optionList = [...item?.item_json?.optionList];

    optionList[index] = {
      ...optionList[index],
      ...{
        fileName: '',
        id: 0,
        url: '',
        mediaType: '',
        mediaFormat: '',
        fileType: ''
      }
    };

    onUpdate({
      item_json: {
        ...item.item_json,
        ...{
          optionList
        }
      }
    });
  };

  const onAddImage = (data) => {
    const selectedMediaItem = data[0];
    if (showDefaultMedia) {
      const defaultMedia = {
        fileName: selectedMediaItem?.file_name,
        id: selectedMediaItem?.id,
        url: `/${selectedMediaItem?.media_type.toLowerCase()}/${selectedMediaItem.assessment_program_id
          }/${selectedMediaItem?.id}/${selectedMediaItem.attachment_id}/${selectedMediaItem?.file_name
          }.${selectedMediaItem.file_type}`,
        mediaType: selectedMediaItem?.media_type,
        mediaFormat: selectedMediaItem?.media_format,
        fileType: selectedMediaItem?.file_type
      };

      onUpdate({
        item_json: {
          ...item.item_json,
          ...{
            defaultMedia
          }
        }
      });

      setShowDefaultMedia(false);
    }
  };

  const removeDefaultMedia = () => {
    const defaultMedia = {
      fileName: '',
      id: 0,
      url: '',
      mediaType: '',
      mediaFormat: '',
      fileType: ''
    };

    onUpdate({
      item_json: {
        ...item.item_json,
        ...{
          defaultMedia
        }
      }
    });
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              placeholder={stemPlaceholder}
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className='row' data-testid='design-container'>
            <div className='col-sm-12 col-xs-12'>
              <section>
                <div className='row p-2 bg-light p-1 rounded m-3'>
                  <div className='col-sm-9 mb-2'>
                    <div className='row p-1 m-2'>
                      <div className='col-sm-2 p-1'>
                        <legend>{label.tvs_default_image}</legend>
                      </div>
                      <div className='col-sm-2 p-1'>
                        <input
                          type='text'
                          disabled={true}
                          value={
                            item?.item_json?.defaultMedia?.id
                              ? `${item?.item_json?.defaultMedia?.id} / ${item?.item_json?.defaultMedia?.fileName}`
                              : ''
                          }
                          className='form-control form-select-sm'
                        />
                      </div>
                      <div className='col-sm-1 p-1'>
                        {item?.item_json?.defaultMedia?.id ? (
                          <button
                            className='icon'
                            onClick={(e) => {
                              e.preventDefault();
                              removeDefaultMedia();
                            }}
                            data-testid='default-media-remove'
                          >
                            <span className='icon-minus'>-</span>
                          </button>
                        ) : (
                          <></>
                        )}
                      </div>
                      <div className='col-sm-3 p-1'>
                        <button
                          className='btn btn-primary btn-sm'
                          onClick={(e) => {
                            e.preventDefault();
                            setShowDefaultMedia(true);
                          }}
                        >
                          {label.tvs_select_media}
                        </button>
                        {showDefaultMedia && (
                          <AddMedia
                            setMedia={onAddImage}
                            media={item?.media_library}
                            cancelMedia={() => setShowDefaultMedia(false)}
                          />
                        )}
                      </div>
                    </div>
                  </div>
                  <div className='col-sm-3 mb-2'>
                    <div className='row p-1 m-2'>
                      <div className='col-sm-10 text-right p-1'>
                        <label htmlFor='display_table'>
                          {label.tvs_display_table}:
                        </label>
                      </div>
                      <div className='col-sm-2 mt-2'>
                        <input
                          type='checkbox'
                          name='displayTable'
                          id='display_table'
                          className='form-check-input'
                          data-testid='st_checkbox'
                          value={item.item_json?.displayTable}
                          checked={item?.item_json?.displayTable || false}
                          onChange={(e) => {
                            updateItemJson('displayTable', e?.target?.checked);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
            <div className='col-sm-8 col-xs-12'>
              <section data-testid='input-container'>
                <div className='row p-3'>
                  <div className='col-sm-6'>
                    <legend>{label.tvs_input_label}</legend>
                  </div>
                  <div className='col-sm-6 text-right'>
                    <button
                      data-testid='add-input'
                      className='btn btn-primary btn-sm'
                      onClick={(e) => {
                        e.preventDefault();
                        addNewInput();
                      }}
                    >
                      {label.tvs_plus_add_input}
                    </button>
                  </div>
                  <div className='col-sm-12'>
                    <section data-testid='input-options' className='row'>
                      {item.item_json.inputList ? (
                        item.item_json.inputList.map((each, index) => (
                          <div className='col-sm-6 mb-2' key={each.id}>
                            <TableVideoInputOptions
                              data={each}
                              onUpdate={(data) =>
                                handleInputOptions(data, index, false)
                              }
                              onDelete={(id) => removeInputOption(id)}
                              onReorder={(data) =>
                                handleInputOptions(data, index, true)
                              }
                            />
                          </div>
                        ))
                      ) : (
                        <div className='col-sm-12 mb-2'>
                          <p
                            className='text-center text-muted m-5'
                            data-testid='inputs-empty-state'
                          >
                            {label.tvs_inputs_empty_state}
                          </p>
                        </div>
                      )}
                    </section>
                  </div>
                </div>
              </section>
            </div>
            <div className='col-sm-4 col-xs-12'>
              <section>
                <div className='row p-3'>
                  <div className='col-sm-6'>
                    <legend>{label.tvs_output_label}</legend>
                  </div>
                  <div className='col-sm-6 text-right'>
                    <button
                      className='btn btn-primary btn-sm'
                      data-testid='add-output'
                      onClick={(e) => {
                        e.preventDefault();
                        addNewOutput();
                      }}
                    >
                      {label.tvs_plus_add_output}
                    </button>
                  </div>
                  <section data-testid='output-options'>
                    {item.item_json.outputList ? (
                      item.item_json.outputList.map((each, index) => (
                        <div
                          className='col-sm-12 test-input-options'
                          key={each?.id}
                        >
                          <TableVideoOutputOptions
                            data={each}
                            onUpdate={(data) =>
                              handleOutputOptions(data, index)
                            }
                            onDelete={(id) => removeOutputOption(id, index)}
                          />
                        </div>
                      ))
                    ) : (
                      <div className='col-sm-12 mb-2'>
                        <p
                          className='text-center text-muted m-5'
                          data-testid='output-empty-state'
                        >
                          {label.tvs_output_empty_state}
                        </p>
                      </div>
                    )}
                  </section>
                </div>
              </section>
            </div>
          </div>
          {item?.item_json?.optionList &&
            item?.item_json?.optionList.length > 0 && (
              <div className='row p-3'>
                <div className='col-sm-12'>
                  <legend>{label.tvs_simulations_label}</legend>
                </div>
                <div className='col-sm-12'>
                  {item?.item_json?.optionList.map((each, index) => (
                    <TableVideoSimulationOption
                      data={each}
                      selectMedia={() => {
                        setSelectMedia({ show: true, index });
                      }}
                      removeMedia={() => {
                        removeSimulationMedia(index);
                      }}
                      onUpdate={(value) =>
                        handleSimulationOutputs(value, index)
                      }
                    />
                  ))}
                </div>
              </div>
            )}

          {selectMedia.show && (
            <AddMedia
              setMedia={saveMediaData}
              media={item?.media_library}
              cancelMedia={() =>
                setSelectMedia({
                  show: false,
                  index: 0
                })
              }
            />
          )}
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

TableVideo.propTypes = itemProps;

export default TableVideo;
