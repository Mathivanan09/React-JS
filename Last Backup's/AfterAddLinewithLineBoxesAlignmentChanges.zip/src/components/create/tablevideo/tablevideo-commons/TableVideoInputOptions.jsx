import React from 'react';
import uuid from 'react-uuid';

import ReorderItems from '../../shared/ReorderItems';

import CKEditorBase from '../../../common/editors/ckeditor/CKEditorBase';
import { itemProps } from '../../../common/ItemHelper';
import label from '../../../../constants/labelCodes';

/**
 * React functional component to create Table Video item
 *

 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace TableVideoInputOptions
 *
 * @param {{item: Object, onUpdate: func }} param passed in parameters
 * @param {Object} param.data JSON data that will contain the input information
 * for creating/updating inputnoptions of Table Video item
 * @param {Function} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Function} param.onDelete Callback function to delete item_son attributes
 * if there is any change in the state of the item
 * @return {TableVideoInputOptions} TableVideoInputOptions component for creating Table Video item
 *
 * @example
 * <TableVideoInputOptions data={{}} onUpdate={}, onDelete={} />
 */
const TableVideoInputOptions = ({ data, onUpdate, onDelete, onReorder }) => {
  const DIR_UP = -1;
  const DIR_DOWN = 1;
  const titlePlacholder = label.tvs_input_option_title_placeholder;
  const optionPlaceholder =  label.tvs_input_option_placholder; 
  /**
   * Used to update input title.
   *
   * @param {String} key
   * @param {Sting} value
   */
  const handleUpdate = (key, value) => {
    onUpdate({ ...data, ...{ [key]: value } });
  };

  /**
   *  Event handler to update input option data.
   *
   * @param {String} key
   * @param {String} value
   * @param {Number} i
   */
  const updateOptions = (key, value, i) => {
    const options = [...data?.options];
    options[i] = { ...options[i], ...{ [key]: value } };
    onUpdate({ ...data, ...{ options: options } });
  };

  /**
   * Used to reorder option inside input data.
   *
   * @param {Number} counter
   * @param {Number} index
   * @return {null}
   */
  const reorderItems = (counter, index) => {
    const options = [...data?.options];
    if (
      (counter === DIR_UP && index === 0) ||
      (counter === DIR_DOWN && index === options.length - 1)
    ) {
      return;
    }

    const optionItem = options[index];
    const updatedOptionItems =
      options?.filter((value, idx) => index !== idx) || [];

    updatedOptionItems.splice(index + counter, 0, optionItem);
    onReorder({ ...data, ...{ options: updatedOptionItems } });
  };

  /**
   * Removes option from input array based on ID
   *
   * @param {String} id
   */
  const removeOption = (id) => {
    let options = [...data?.options];
    options = options.filter((each) => each.id !== id);
    onUpdate({ ...data, ...{ options: options } });
  };

  /**
   *  Create option from input data
   *
   */
  const addOption = () => {
    onUpdate({
      ...data,
      ...{
        options: [
          ...(data?.options || []),
          ...[
            {
              id: uuid(),
              index: data?.options?.length || 0
            }
          ]
        ]
      }
    });
  };

  return (
    <>
      <div className='bg-light p-3 rounded m-1'>
        <div className='row'>
          <div className='col-sm-11'>
            <label className='mb-1'>Input Title {data?.index + 1}: </label>
          </div>
          <div className='col-sm-1 text-right'>
            <button
              className='icon'
              onClick={(e) => {
                e.preventDefault();
                onDelete(data.id);
              }}
              data-testid='option-item-remove-button'
            >
              <span className='icon-minus'>-</span>
            </button>
          </div>
          <div className='col-sm-12'>
            <CKEditorBase
              type='inline'
              data={data?.title}
              className='content_style'
              onChange={(value) => {
                handleUpdate('title', value);
              }}
              placeholder={titlePlacholder}
            />
          </div>
        </div>
        <hr />
        <section className='options'>
          <div className='row'>
            <div className='col-sm-6'>
              <legend>{label.tvs_input_options_label}</legend>
            </div>
            <div className='col-sm-6 text-right'>
              <button
                className='btn btn-primary btn-sm'
                onClick={(e) => {
                  e.preventDefault();
                  addOption();
                }}
              >
                + Add Option
              </button>
            </div>
          </div>
        </section>
        {data?.options?.map((option, i) => (
          <div className='row m-2 align-items-center' key={option.id}>
            <div className='col-sm-2'>
              <ReorderItems
                listLength={data?.options?.length}
                option={i}
                onDownClick={() => reorderItems(DIR_DOWN, i)}
                onUpClick={() => reorderItems(DIR_UP, i)}
              />
            </div>
            <div className='col-sm-8'>
              <CKEditorBase
                type='inline'
                data={option?.textHtml}
                className='content_style'
                onChange={(value) => {
                  updateOptions('textHtml', value, i);
                }}
                placeholder={optionPlaceholder}
              />
            </div>
            <div className='col-sm-2 text-center'>
              <button
                className='icon'
                onClick={(e) => {
                  e.preventDefault();
                  removeOption(option?.id);
                }}
                data-testid='option-item-remove-button'
              >
                <span className='icon-minus'>-</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

TableVideoInputOptions.propTypes = itemProps;

export default TableVideoInputOptions;
