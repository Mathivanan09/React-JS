import React from 'react';
import PropTypes from 'prop-types';
import label from '../../../constants/labelCodes';
import defaultValue from '../../../utility/default';

/**
 * React functional component to display the dropdown
 * 
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace DropDown
 *
 * @param {{data: object, value: string, onUpdate: function, updateKey: string, showSelect: boolean,
 * dataItemKey: string, textField: string, labelCode: string, isRequired: boolean}} param passed in parameters
 * @param {object} param.data - drop down values to be rendered, overrides default values
 * @param {string} param.value - Value that is selected and rendered as selected value
 * @param {function} param.onUpdate - function that trigger when a value is selected in dropdown
 * @param {string} param.updateKey - key in item JSON object that need to be updated with value
 * @param {bool} param.showSelect - controls whether to show Select as an option in dropdown
 * @param {string} param.dataItemKey - key value of the object treated as value while saving
 * @param {string} param.textField - text value of the object treated as label in dropdown
 * @param {string} param.labelCode - label code to look up and render the label of this component
 * @return {component} - component with dropdown
 * 
 * @example
 * <DropDown
    data={getResponsesRequiredData()}
    labelCode='st_selection_type_required'
    onUpdate={updateItemJson}
    updateKey='selectionType'
    isRequired={true}
    showSelect={true}
    value={item.item_json.selectionType}
  ></DropDown>
 */
const DropDown = ({
  data,
  value,
  onUpdate,
  updateKey,
  showSelect,
  dataItemKey,
  textField,
  labelCode,
  isRequired,
  ...props
}) => {
  // Initialize component based on parameters passed

  let defaultValues = [];

  if (data && data.length > 0) {
    defaultValues = data;
  }

  // Add Select if showSelect is true
  if (showSelect) {
    defaultValues = [{ id: null, name: 'Select' }, ...defaultValues];
  }

  return (
    <div className='container'>
      <div className='row align-items-center p-1'>

        <div className="col-5 pt-1 pb-1 hstack gap-2 text-end">
          <div
            className='col text-right'
            align='end'
            data-testid='dd-required'
          >
            <label
              className="form-label"
              htmlFor="specification-header-name"
            >
              {label[labelCode || '']}:&nbsp;
              <i className='required-field text-danger ms-1'>*</i>
            </label>
          </div>
        </div>

        <div className="col-7 pt-1 pb-1 hstack gap-2 text-start">
          <div className='col'>
            <select
              required={isRequired}
              id={labelCode}
              className='form-select form-select-sm'
              aria-label='form-select-columns-number'
              value={
                value !== undefined
                  ? value
                  : defaultValue(labelCode)
              }
              onChange={(e) => {
                let val = e.target.value;
                onUpdate(updateKey, val);
              }}
              data-testid={props.dataTestId || 'dd-select'}
            >
              {defaultValues.map((value) => (
                <option
                  key={value[dataItemKey || 'id']}
                  value={value[dataItemKey || 'id'] || ''}
                >
                  {value[textField || 'name']}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

DropDown.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  value: PropTypes.any,
  onUpdate: PropTypes.func,
  updateKey: PropTypes.string,
  showSelect: PropTypes.bool,
  dataItemKey: PropTypes.string,
  textField: PropTypes.string,
  labelCode: PropTypes.string,
  isRequired: PropTypes.bool,
  dataTestId: PropTypes.string
};

export default DropDown;
