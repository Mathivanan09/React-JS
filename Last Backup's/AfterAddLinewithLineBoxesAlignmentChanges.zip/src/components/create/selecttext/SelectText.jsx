import React, { useState } from 'react';
import uuid from "react-uuid";
import StemContent from '../shared/StemContent';
import ItemDimensions from '../shared/ItemDimensions';

import DropDown from './DropDown';
import SelectTextResponse from '../../display/response/selecttext/SelectTextResponse'
import {
  WHOLE_WORDS,
  WHOLE_SENTENCES,
  WHOLE_PARAGRAPHS,
  MANUALLY_SELECTED_RESPONSE
} from "../../display/response/selecttext/constants";

import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import { readableResponseParser } from '../../../utility/readableResponse';

/**
 * React functional component to create Select Text item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace SelectText
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating Select Text item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {SelectText} SelectText component for creating Select Text item
 *
 * @example
 * <SelectText item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'st' },
    user_id: 0,
  }} />
 */
const SelectText = ({ item, onUpdate, config }) => {

  // All event methods go here and uses dispatch method
  const [showRationale, toggleRationale] = useState(false);

  const selectionLabels = [
    { id: 'MANUAL_SELECTION', name: 'Manual Selections' },
    { id: 'PARAGRAPH', name: 'Paragraphs' },
    { id: 'SENTENCES', name: 'Sentences' },
    { id: 'WORDS', name: 'Words' }
  ];

  const borderLabels = [
    { id: 'RED', name: 'Red' },
    { id: 'BLACK', name: 'Black' },
    { id: 'NONE', name: 'None' }
  ];

  const highlightLabels = [
    { id: 'YELLOW', name: 'Yellow' },
    { id: 'NONE', name: 'None' }
  ];

console.log(item.item_json);
console.log(item.item_json.borderAtStart);

  // event handler for updating item json content
  const updateItemJson = (key, value) => {

    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
    if (key === 'selectionType') {
      handleSelectTypeChange(value);
    }
  };

  // Event handler for selection type
  const handleSelectTypeChange = (eventData) => {
    if (eventData !== MANUALLY_SELECTED_RESPONSE) {
      /*While changing the selection type from Manual Selection to any other,
      *then we need to remove the selected content identification from the passage content
      *so we find and remove the span tags which has class name 'cked-highlight'
      */
      const parser = new DOMParser();
      const doc = parser.parseFromString(item.item_json.passageContent, "text/html");
      let elementListLength = doc.querySelectorAll(".cked-highlight").length;
      let newPassageString = item.item_json.passageContent;

      for (let index = 0; index < elementListLength; index++) {
        newPassageString = newPassageString.replace(doc.querySelectorAll(".cked-highlight")[index].outerHTML.toString(),
          doc.querySelectorAll(".cked-highlight")[index].innerHTML);
      }
      const updatedItem = {
        item_json: {
          passageContent: newPassageString,
          correctResponse: [],
          optionList: []
        }
      };
      onUpdate(updatedItem);

      generateFoilObject(eventData, newPassageString);
    } else {
      const updatedItem = {
        item_json: {
          correctResponse: [],
          optionList: []
        }
      };
      onUpdate(updatedItem);

      generateFoilObject(eventData, item.item_json.passageContent);
    }
  };


  //Event handler for adding passage content data
  /* istanbul ignore next */
  const handlePassageContentChange = (_fieldName, value) => {
    if (value !== item?.item_json?.passageContent) {
      // prepare the payload
      const updatedItem = {
        item_json: {
          passageContent: value
        }
      };
      onUpdate(updatedItem);
      generateFoilObject(item?.item_json?.selectionType, value);
    }
  };

  // Event handler for getting Selection type labels
  const getSelectionLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Manual Selections', 'Paragraphs', 'Sentences', 'Words'].map((val, i) => {
        return {
          id: selectionLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for getting border start labels
  const getBorderStartLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Red', 'Black', 'None'].map((val, i) => {
        return {
          id: borderLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for getting hover start labels
  const getBorderHoverLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Red', 'Black', 'None'].map((val, i) => {
        return {
          id: borderLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for getting border select labels
  const getBorderSelectLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Red', 'Black', 'None'].map((val, i) => {
        return {
          id: borderLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for getting Highlight start labels
  const getHighlightStartLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Yellow', 'None'].map((val, i) => {
        return {
          id: highlightLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for getting Highlight hover labels
  const getHighlightHoverLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Yellow', 'None'].map((val, i) => {
        return {
          id: highlightLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for getting Highlight select labels
  const getHighlightSelectLabels = () => {
    // TODO Need to re-factor at later to use proper values
    return (
      (config && config.responseLabels) ||
      ['Yellow', 'None'].map((val, i) => {
        return {
          id: highlightLabels[i].id,
          name: val
        };
      })
    );
  };

  // Event handler for Bolded Border on the checkbox selection
  const handleCheckBox = (e) => {
    const updatedItem = {
      item_json: { boldedBorderOnSelect: e.target.checked }
    };
    onUpdate(updatedItem);
  }

  // Event handler for Maximum Response Selection
  const handleMaxResponseSelection = (e) => {
    let crData = [];
    for (let i = 0; i < item?.item_json?.optionList?.length; i++) {
      let foilData = {}
      foilData.id = item?.item_json?.optionList[i].id;
      foilData.value = false;
      crData.push(foilData);
    }

    const updatedItem = {
      item_json: {
        correctResponse: crData,
        maxResponseSelection: e.target.value
      }
    };
    onUpdate(updatedItem);
  }

  //Common method for foil generation based on selection type and passage data
  const generateFoilObject = (selectType, data = '') => {
    let commonData = data;
    if (selectType === WHOLE_WORDS) {
      commonData = commonData.replace(/<\/p>/gm, "</p> ");
      commonData = commonData.replace(/<br>/gm, " ");
      commonData = commonData.replace(/<br \/>/gm, " ");
    }
    let splitedData = [];
    let foilsObject = [];
    const parser = new DOMParser();
    const doc = parser.parseFromString(data, "text/html");
    let div = document.createElement("div");
    div.innerHTML = commonData;
    let text = div.textContent || div.innerText || "";
    text = text.replace(/\s/gm, " "); // some of the space characters are accepting, so manually replace them with spaces
    text = text.replace(/[\r\n]+/gm, " ").trim(); //Regular expression is used for removing new line from the content before splitting

    if (selectType === WHOLE_PARAGRAPHS) {
      let pNodelist = doc.querySelectorAll("p");

      for (let i = 0; i < pNodelist.length; i++) {
        foilsObject.push({
          index: i,
          id: uuid(),
          optionText: pNodelist[i].innerHTML,
        });
      }
    } else if (selectType === WHOLE_WORDS) {
      splitedData = text.split(" ");
      for (let i = 0; i < splitedData.length; i++) {
        if (splitedData[i] != null) {
          // eslint-disable-next-line
          let format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.\/?~]/;
          let text = splitedData[i].trim();
          while (text && (text.slice(-1).match(format) !== null || text.slice(0, 1).match(format) !== null)) { // trim characters before and after the text
            if (text.slice(-1).match(format)?.[0]) {
              text = text.slice(0, text.length - 1);
            } else if (text.slice(0, 1).match(format) !== null) {
              text = text.slice(1, text.length);
            }
          }

          if (text.trim() !== "") {
            foilsObject.push({
              index: i,
              id: uuid(),
              optionText: text,
            });
          }
        }
      }
    } else if (selectType === WHOLE_SENTENCES) {
      let pNodelist = doc.querySelectorAll("p");
      let wholeSentenceText = "";
      for (let i = 0; i < pNodelist.length; i++) {
        wholeSentenceText = wholeSentenceText + " " + pNodelist[i].innerHTML;
      }
      wholeSentenceText = wholeSentenceText.replace(/&nbsp;/gi, " ");

      const honorificWithPunctuationRegEx = /(Prof|Pres|Gen|Hon|Maj|Mrs|Emi|Ven|Col|Mr|Ms|Dr|Sr|Jr|Lt|Mx|Pr|Fr|Br)(\.)/g;
      const honorificCleanedText = wholeSentenceText.replace(honorificWithPunctuationRegEx, "$1");
      const sentenceRegEx = /([.?!]<\/.{1,}?>{1}\x20{0,2}|[.?!]+"*\x20{1,2}(?=[A-Z\d])*|[.?!]+"{0,1}[^\w]|[.?!]+$)/g;
      // put the periods back in honorific abbreviations after sentence splitting
      const honorificWithoutPunctuationAbbreviationRegEx = /(Prof|Pres|Gen|Hon|Maj|Mrs|Emi|Ven|Col|Mr|Ms|Dr|Sr|Jr|Lt|Mx|Pr|Fr|Br)(\s+)/g;

      const sentences = honorificCleanedText
        .replace(sentenceRegEx, "$1|")
        .replace(honorificWithoutPunctuationAbbreviationRegEx, "$1. ")
        .replace(/(&nbsp;)/g, "")
        .replace(/(\.{2,})/g, "$1|")
        .split("|");

      for (let i = 0; i < sentences.length; i++) {
        if (sentences[i].trim() !== "") {
          foilsObject.push({
            index: i,
            id: uuid(),
            optionText: sentences[i].trim(),
          });
        }
      }
    } else if (selectType === MANUALLY_SELECTED_RESPONSE) {
      let selectTextNodelist = doc.documentElement.querySelectorAll(".cked-highlight");
      for (let i = 0; i < selectTextNodelist.length; i++) {
        foilsObject.push({
          index: i,
          id: selectTextNodelist[i].id,
          optionText: selectTextNodelist[i].innerHTML,
        });
      }
    }

    let crData = [];
    for (let i = 0; i < foilsObject.length; i++) {
      let foilData = {}
      foilData.id = foilsObject[i].id;
      foilData.value = false;
      crData.push(foilData);
    }

    const updatedItem = {
      item_json: {
        correctResponse: crData,
        optionList: foilsObject,
        selectionType: selectType
      }
    };
    onUpdate(updatedItem);
  }

  /**
   * @summary This method is used to Build readable response for Select Text Item.
   *
   * @inner
   * @memberof UtilityMethods
   *
   * @function
   * @namespace generateReadableResponse
   */
  const generateReadableResponse = (updatedCorrectResponses) => {
    let readableResponse = '';
    if (updatedCorrectResponses) {
      updatedCorrectResponses.forEach((updatedCorrectResponse, index) => {
        const optIndex = item.item_json?.option_list.findIndex(
          (element) => element.id === updatedCorrectResponse
        );
        if (optIndex >= 0) {
          let responseText = item.item_json?.option_list[optIndex].option_text;
          let parseElement = readableResponseParser({
            responseText: responseText
          });
          if (index === 0) {
            readableResponse = `${parseElement}`;
          } else {
            readableResponse = readableResponse + `\n\n${parseElement}`;
          }
        }
      });
    }
    return readableResponse;
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className="mine">
            <div className='row' >
              <div className='col col-5 col-sm-6'>
                <fieldset className='bg-light p-3 rounded m-1 text-right'>
                  <DropDown
                    data={getSelectionLabels()}
                    labelCode='selection_type'
                    onUpdate={updateItemJson}
                    updateKey='selectionType'
                    isRequired={true}
                    showSelect={true}
                    value={item.item_json?.selectionType}
                    dataTestId='st-selection-type'
                  />
                </fieldset>
              </div>
              <div className='col col-12 col-sm-12'></div>
            </div>
          </div>
          <div>
            <div className='row' data-testid='passage-content-container'>
              <div className='col col-12 col-sm-12 stem-container m-1'>
                <fieldset className='bg-light p-3 rounded m-1'>
                  <h5 className="text-primary">{label.response_passage}</h5>
                  <div data-testid='response-container'>
                    {item.item_json.selectionType !== MANUALLY_SELECTED_RESPONSE &&
                      <CKEditorBase
                        data={item.item_json.passageContent}
                        onChange={(fieldName, value) => handlePassageContentChange(fieldName, value)}
                        fieldName='passageContent'
                        placeholder={label.enter_passage_content}
                      />
                    }
                    {item.item_json.selectionType === MANUALLY_SELECTED_RESPONSE &&
                      <CKEditorBase
                        data={item.item_json.passageContent}
                        onChange={(fieldName, value) => handlePassageContentChange(fieldName, value)}
                        fieldName='passageContent'
                        config={{
                          insertResponse: {
                            type: 'selectText',
                            label: 'Select Response'
                          }
                        }}
                        placeholder={label.enter_passage_content}
                      />
                    }
                  </div>
                </fieldset>
              </div>
            </div>
          </div>
          <div className='row' >
            <div className='col col-12 col-sm-12'>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className='row' >
                  <div className='col'>
                    <DropDown
                      data={getBorderStartLabels()}
                      labelCode='border_at_start'
                      onUpdate={updateItemJson}
                      updateKey='borderAtStart'
                      isRequired={true}
                      showSelect={true}
                      value={item.item_json?.borderAtStart}
                      dataTestId='border_at_start'
                    />
                  </div>
                  <div className='col'>
                    <DropDown
                      data={getHighlightStartLabels()}
                      labelCode='highlight_at_start'
                      onUpdate={updateItemJson}
                      updateKey='highlightAtStart'
                      isRequired={true}
                      showSelect={true}
                      value={item.item_json?.highlightAtStart}
                      dataTestId='highlight_at_start'
                    />
                  </div>
                </div>
                <div className='row' >
                  <div className='col'>
                    <DropDown
                      data={getBorderHoverLabels()}
                      labelCode='border_on_hover'
                      onUpdate={updateItemJson}
                      updateKey='borderOnHover'
                      isRequired={true}
                      showSelect={true}
                      value={item.item_json?.borderOnHover}
                      dataTestId='border_on_hover'
                    />
                  </div>
                  <div className='col'>
                    <DropDown
                      data={getHighlightHoverLabels()}
                      labelCode='highlight_on_hover'
                      onUpdate={updateItemJson}
                      updateKey='highlightOnHover'
                      isRequired={true}
                      showSelect={true}
                      value={item.item_json?.highlightOnHover}
                      dataTestId='highlight_on_hover'
                    />
                  </div>
                </div>
                <div className='row' >
                  <div className='col'>
                    <DropDown
                      data={getBorderSelectLabels()}
                      labelCode='border_on_select'
                      onUpdate={updateItemJson}
                      updateKey='borderOnSelect'
                      isRequired={true}
                      showSelect={true}
                      value={item.item_json?.borderOnSelect}
                      dataTestId='border_on_select'
                    />
                  </div>
                  <div className='col'>
                    <DropDown
                      data={getHighlightSelectLabels()}
                      labelCode='hightlight_on_select'
                      onUpdate={updateItemJson}
                      updateKey='highlightOnSelect'
                      isRequired={true}
                      showSelect={true}
                      value={item.item_json?.highlightOnSelect}
                      dataTestId='hightlight_on_select'
                    />
                  </div>
                </div>
                <div className='row' >
                  <div className='col-6'>
                    <div className='row'>
                      <div className='col-5 pt-1 pb-1 pe-3 text-right'>
                        <label htmlFor='bolded-border-on-select'>{label.bolded_border_on_select}:&nbsp;</label>
                      </div>
                      <div className="col-4 pt-1 pb-1 hstack gap-2 mx-2 text-start">
                        <input
                          type='checkbox'
                          id='bolded-border-on-select'
                          checked={item?.item_json?.boldedBorderOnSelect}
                          value={item.item_json?.boldedBorderOnSelect}
                          onChange={(e) => handleCheckBox(e)}
                          data-testid='st_checkbox'
                          className="form-check-input"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className='row' >
                  <div className='col-6'>
                    <div className='row'>
                      <div className='col-5 pt-2 pb-1 pe-3 text-right'>
                        <label htmlFor='max-response-selection'>{label.max_response_selection}:&nbsp;</label>
                      </div>
                      <div className="col-4 pt-1 pb-1 hstack gap-2 mx-2 text-start">
                        <input type="number"
                          className='form-control'
                          id='max-response-selection'
                          value={item.item_json?.maxResponseSelection || 0}
                          onChange={(e) => handleMaxResponseSelection(e)}
                          data-testid='st_number'
                          defaultValue={0}
                          min={0}
                        />
                      </div>
                    </div>
                  </div>
                  <div className='col-6 pt-2'>
                    <div className='row'>
                      <div className='col-12 col-lg-2 text-lg-center pb-1'>
                        <button
                          type='button'
                          className='btn btn-primary btn-sm'
                          data-testid='rationale-button'
                          onClick={() => toggleRationale(!showRationale)}
                        >
                          {label.rationale}
                        </button>
                      </div>
                      <div className='col rationale' data-testid='rationale'>
                        {showRationale &&
                          <CKEditorBase
                            type='inline'
                            dataTestId='rationale-text'
                            data={item?.rationale?.rationaleText || ''}
                            onChange={
                              /* istanbul ignore next */
                              (data) => {
                                onUpdate({
                                  ...item,
                                  rationale: {
                                    ...item?.rationale,
                                    'rationaleText': data
                                  }
                                });
                              }
                            }
                            placeholder={label.enter_rationale_content}
                            config={{ removePlugins: ['TagAccessibility'] }}
                          />
                        }
                      </div>
                    </div>
                  </div>
                </div>
              </fieldset>
            </div>
            <div className='col col-12 col-sm-12'></div>
          </div>
          <div className='row p-3' data-testid='st-correct-response-container'>
            <fieldset className='bg-light p-3 rounded m-1'>
              <legend>{label.correct_response}</legend>
              <SelectTextResponse
                item={item}
                stem={null}
                config={config}
                responseOnly={true}
                onUpdate={onUpdate}
                showCorrectResponse={false}
              />
            </fieldset>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

SelectText.propTypes = itemProps;

export default SelectText;
