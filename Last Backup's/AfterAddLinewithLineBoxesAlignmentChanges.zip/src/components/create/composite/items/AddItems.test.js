import React from 'react';
import { act } from "react-dom/test-utils";
import userEvent from '@testing-library/user-event';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { unmountComponentAtNode } from "react-dom";

// Existing Dummy Item Types Category (like questions)
import DummyItems from "../../../../stories/assets/com/DummyItems.json";

import MCMS from "../../../../stories/assets/mc/mc_multiple.json";
import TF from "../../../../stories/assets/mc/mc_true_false.json";
import TCC_TWO from "../../../../stories/assets/tcc/tcc_two_column.json";
import TCC_THREE from "../../../../stories/assets/tcc/tcc_three_column.json";

// import component here
import AddItems from './AddItems';

let container = null;

const fetch = async (categoryCodes, excludeIds, callback) => {
      const savedItemList = DummyItems;
      savedItemList[0] = { ...savedItemList[0], ...TCC_THREE?.item };
      savedItemList[1] = { ...savedItemList[1], ...TCC_TWO?.item };
      savedItemList[2] = { ...savedItemList[2], ...MCMS?.item };
      savedItemList[3] = { ...savedItemList[3], ...TF?.item };
      if (categoryCodes.includes('question')) {
            const questions = await savedItemList?.filter((item) =>
                  item.id && item?.category &&
                  excludeIds?.includes(item.id) === false &&
                  categoryCodes.includes(item?.category)
            ) || [];
            callback(questions);
            return questions;
      }
      return [];
};

beforeEach(() => {
      // setup a DOM element as a render target
      container = document.createElement("div");
      document.body.appendChild(container);
});

afterEach(() => {
      // cleanup on exiting
      unmountComponentAtNode(container);
      container.remove();
      container = null;
});


describe('Add Available Items with the Item Grid', () => {

      /**
      * Basic Component Check before Add Items clicked
      */
      test("Basic Component Check before Add Items clicked", () => {
            act(() => {
                  render(<AddItems item={[]} />, container);
            });

            expect(screen.getByTestId('show-add-item-modal')).toBeInTheDocument();
            // the modal should not be available, when the first item is loaded.
            expect(document.querySelectorAll('[data-testid=add-item-modal-container]').length).toBe(0);
      });

      /**
      * Basic Component Check with Add Available Items Model
      */
      test("Basic Component Check with Add Available Items Model", async () => {
            // set up test mock data as empty
            let items = [];
            const config = {
                  fetchItems: jest.fn(async (_categoryCodes, _excludeIds, callback) => {
                        await callback([]);
                        return [];
                  })
            }

            // set up test mock onUpdate function
            const onUpdate = jest.fn(data => { items = [...[data]] });

            act(() => {
                  render(
                        <AddItems
                              item={items}
                              config={config}
                              setItems={onUpdate}
                              categories={['question']}
                        />,
                        container
                  );
            });

            const showModel = screen.getByTestId('show-add-item-modal');
            expect(showModel).toBeInTheDocument();

            act(() => {
                  fireEvent.click(showModel); // load the add item modal
            });

            await waitFor(() => {
                  expect(config.fetchItems).toHaveBeenCalledTimes(1);
            });

            // check the add item modal component is available or not
            expect(screen.getByTestId('add-item-modal-container')).toBeInTheDocument();
            expect(screen.getByTestId('add-item-modal-title')).toBeInTheDocument();
            expect(screen.getByTestId('add-item-body')).toBeInTheDocument();
            expect(screen.getByTestId('add-item-close')).toBeInTheDocument();
            expect(screen.getByTestId('add-item-submit')).toBeInTheDocument();
      }, 1000000);

      /**
      * Check loading functionality of the Available Items
      */
      test("Check loading functionality of the Available Items", async () => {
            // set up test mock data as empty
            let items = [];
            const config = {
                  fetchItems: jest.fn(fetch)
            }

            // set up test mock onUpdate function
            const onUpdate = jest.fn(data => { items = [...[data]] });

            act(() => {
                  render(
                        <AddItems
                              item={items}
                              config={config}
                              setItems={onUpdate}
                              categories={['question']}
                        />,
                        container
                  );
            });

            const showModel = screen.getByTestId('show-add-item-modal');
            expect(showModel).toBeInTheDocument();

            act(() => {
                  fireEvent.click(showModel); // load the add item modal
            });

            await waitFor(() => {
                  expect(config.fetchItems).toHaveBeenCalledTimes(1);
            });

            expect(screen.getByTestId('add-item-modal-container')).toBeInTheDocument();

            expect(onUpdate).toHaveBeenCalledTimes(0);
            expect(items?.length).toBe(0);

            let itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');

            await waitFor(() => {
                  expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).toBeInTheDocument();
            });
            
            itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');
            expect(itemListCheckbox?.length).toBe(2);

            act(() => {
                  // select the first item of the list
                  userEvent.click(itemListCheckbox[0]);
            });

            await waitFor(() => {
                  expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).toBeChecked();
            });

            const addItemsButton = screen.getByTestId('add-item-submit');

            act(() => {
                  fireEvent.click(addItemsButton); // add the item by clicking the add item button
            });

            // the modal should not be available, after item added to the array.
            await waitFor(() => {
                  expect(document.querySelectorAll('[data-testid=add-item-modal-container]').length).toBe(0);
                  expect(onUpdate).toHaveBeenCalledTimes(1);
                  expect(items?.length).toBe(1);
            });

      }, 1000000);

      /**
      * Check close/cancel functionality of the add Items model
      */
      test("Check close/cancel functionality of the add Items model", async () => {
            // set up test mock data as empty
            let items = [];
            const config = {
                  fetchItems: jest.fn(fetch)
            }

            // set up test mock onUpdate function
            const onUpdate = jest.fn(data => { items = [...[data]] });

            act(() => {
                  render(
                        <AddItems
                              item={items}
                              config={config}
                              setItems={onUpdate}
                              categories={['question']}
                        />,
                        container
                  );
            });

            const showModel = screen.getByTestId('show-add-item-modal');
            expect(showModel).toBeInTheDocument();

            act(() => {
                  fireEvent.click(showModel); // load the add item modal
            });

            await waitFor(() => {
                  expect(config.fetchItems).toHaveBeenCalledTimes(1);
            });

            expect(screen.getByTestId('add-item-modal-container')).toBeInTheDocument();

            expect(onUpdate).toHaveBeenCalledTimes(0);
            expect(items?.length).toBe(0);

            let itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');
            const cancelButton = screen.getByTestId('add-item-close');

            await waitFor(() => {
                  expect(config.fetchItems).toHaveBeenCalledTimes(1);
            });

            await waitFor(() => {
                  expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).toBeInTheDocument();
            });
            
            itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');
            expect(itemListCheckbox?.length).toBe(2);

            act(() => {
                  // select the first item of the list
                  userEvent.click(itemListCheckbox[0]);
                  fireEvent.click(cancelButton); // cancel the add items by clicking the cancel item button
            });

            // the modal should not be available, after cancel operation and that should not add any the items to the array
            await waitFor(() => {
                  expect(document.querySelectorAll('[data-testid=add-item-modal-container]').length).toBe(0);
                  expect(onUpdate).toHaveBeenCalledTimes(0);
                  expect(items?.length).toBe(0);
            });

            act(() => {
                  fireEvent.click(showModel); // load the add item modal
            });

            await waitFor(() => {
                  expect(config.fetchItems).toHaveBeenCalledTimes(2);
            });

            expect(screen.getByTestId('add-item-modal-container')).toBeInTheDocument();
            expect(onUpdate).toHaveBeenCalledTimes(0);
            expect(items?.length).toBe(0);

            const closeButton = screen.getByTestId('add-item-close');
            act(() => {
                  fireEvent.click(closeButton); // close the add items popup by clicking the close popup button
            });

            await waitFor(() => {
                  // the modal should not be available, after close operation
                  expect(document.querySelectorAll('[data-testid=add-item-modal-container]').length).toBe(0);
                  expect(onUpdate).toHaveBeenCalledTimes(0);
                  expect(items?.length).toBe(0);
            });

      }, 1000000);

});