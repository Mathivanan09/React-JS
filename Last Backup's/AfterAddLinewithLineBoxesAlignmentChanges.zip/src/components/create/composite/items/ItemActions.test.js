import React from 'react';
import { act } from "react-dom/test-utils";
import { render, fireEvent, screen } from '@testing-library/react';
import { unmountComponentAtNode } from "react-dom";

// Existing Dummy Item Types Category (like questions)
import DummyItems from "../../../../stories/assets/com/DummyItems.json";

import MCS from "../../../../stories/assets/mc/mc_single.json";
import MCSZ from "../../../../stories/assets/mc/mc_stackedZ.json";
import MCMS from "../../../../stories/assets/mc/mc_multiple.json";
import TF from "../../../../stories/assets/mc/mc_true_false.json";

const questionItems = [];
questionItems[0] = { ...DummyItems[0], ...MCS?.item, order: 0, category: 'question' };
questionItems[1] = { ...DummyItems[1], ...MCSZ?.item, order: 1, category: 'question' };
questionItems[2] = { ...DummyItems[2], ...MCMS?.item, order: 2 };
questionItems[3] = { ...DummyItems[3], ...TF?.item, order: 3 };

// import component here
import ItemActions from './ItemActions';

let container = null;
beforeEach(() => {
      // setup a DOM element as a render target
      container = document.createElement("div");
      document.body.appendChild(container);
});

afterEach(() => {
      // cleanup on exiting
      unmountComponentAtNode(container);
      container.remove();
      container = null;
});

describe('Item Actions Functionality Check', () => {

      /**
      * Item Actions Functionality Check for the first item
      */
      test("Item Actions Functionality Check for the first item based on order", () => {
            // set up test mock onUpdate function
            const onUpdate = jest.fn((_action, _index, _key) => { });

            act(() => {
                  render(
                        <ItemActions
                              items={questionItems}
                              data={questionItems[0]}
                              onUpdate={onUpdate}
                        />,
                        container
                  );
            });

            // only one item action container should be rendered with appropriate action funcationality
            const actionContainer = document.querySelectorAll('[data-testid^=item-actions-container-]');
            expect(actionContainer?.length).toBe(1);
            expect(actionContainer[0]).toBeInTheDocument();

            // respective button should be rendered for the respective item based on the order
            const deleteButton = screen.getByTestId("item-0-actions-delete");
            const shiftDownButton = screen.getByTestId("item-0-actions-down");

            expect(deleteButton).toBeInTheDocument();
            expect(shiftDownButton).toBeInTheDocument();

            // for the first item up arrow button should not be rendered
            const shiftUpButton = document.querySelector('[data-testid=item-0-actions-up]');
            expect(shiftUpButton).toBeNull();

      });

      /**
      * Item Actions Functionality Check for the first item
      */
      test("Item Actions Functionality Check for the last item based on order", () => {
            // set up test mock onUpdate function
            const onUpdate = jest.fn((_action, _index, _key) => { });

            act(() => {
                  render(
                        <ItemActions
                              items={questionItems}
                              data={questionItems[3]}
                              onUpdate={onUpdate}
                        />,
                        container
                  );
            });

            // only one item action container should be rendered with appropriate action funcationality
            const actionContainer = document.querySelectorAll('[data-testid^=item-actions-container-]');
            expect(actionContainer?.length).toBe(1);
            expect(actionContainer[0]).toBeInTheDocument();

            // respective button should be rendered for the respective item based on the order
            const deleteButton = screen.getByTestId("item-3-actions-delete");
            const shiftUpButton = screen.getByTestId("item-3-actions-up");

            expect(deleteButton).toBeInTheDocument();
            expect(shiftUpButton).toBeInTheDocument();

            // for the first item up arrow button should not be rendered
            const shiftDownButton = document.querySelector('[data-testid=item-3-actions-down]');
            expect(shiftDownButton).toBeNull();

      });

      /**
      * Item Actions Functionality Check for the first item
      */
      test("Check All Item Actions Functionality with the middle item based on order", () => {
            const deleteAction = jest.fn(() => { });
            const shiftUpAction = jest.fn(() => { });
            const shiftDownAction = jest.fn(() => { });
            // set up test mock onUpdate function
            const onUpdate = jest.fn((action, index, key) => {
                  if (action === 'delete' && index >= 0) {
                        deleteAction();
                  } else if (action === 'sort' && key === 'up') {
                        shiftUpAction();
                  } else if (action === 'sort' && key === 'down') {
                        shiftDownAction();
                  }
            });

            act(() => {
                  render(
                        <ItemActions
                              items={questionItems}
                              data={questionItems[1]}
                              onUpdate={onUpdate}
                        />,
                        container
                  );
            });

            // the item action container should be rendered with appropriate action funcationality
            const actionContainer = screen.getByTestId("item-actions-container-1");
            expect(actionContainer).toBeInTheDocument();

            // respective button should be rendered for the respective item based on the order
            const deleteButton = screen.getByTestId("item-1-actions-delete");
            const shiftUpButton = screen.getByTestId("item-1-actions-up");
            const shiftDownButton = screen.getByTestId("item-1-actions-down");

            expect(deleteButton).toBeInTheDocument();
            expect(deleteAction).toHaveBeenCalledTimes(0);

            act(() => {
                  // perform delete action
                  fireEvent.click(deleteButton);
            });

            // respective callback function should be called to perform the delete action
            expect(deleteAction).toHaveBeenCalledTimes(1);

            expect(shiftUpButton).toBeInTheDocument();
            expect(shiftUpAction).toHaveBeenCalledTimes(0);

            act(() => {
                  // perform shift up action
                  fireEvent.click(shiftUpButton);
            });

            // respective callback function should be called to perform the shift up action
            expect(shiftUpAction).toHaveBeenCalledTimes(1);

            expect(shiftDownButton).toBeInTheDocument();
            expect(shiftDownAction).toHaveBeenCalledTimes(0);

            act(() => {
                  // perform shift up action
                  fireEvent.click(shiftDownButton);
            });

            // respective callback function should be called to perform the shift down action
            expect(shiftDownAction).toHaveBeenCalledTimes(1);

            // respective callback function with the enter key as well
            act(() => {
                  fireEvent.keyDown(deleteButton, { key: 'Enter', code: 'Enter', charCode: 13, keyCode: 13 });
                  fireEvent.keyDown(shiftUpButton, { key: 'Enter', code: 'Enter', charCode: 13, keyCode: 13 });
                  fireEvent.keyDown(shiftDownButton, { key: 'Enter', code: 'Enter', charCode: 13, keyCode: 13 });
            });

            expect(deleteAction).toHaveBeenCalledTimes(2);
            expect(shiftUpAction).toHaveBeenCalledTimes(2);
            expect(shiftDownAction).toHaveBeenCalledTimes(2);

      });

});