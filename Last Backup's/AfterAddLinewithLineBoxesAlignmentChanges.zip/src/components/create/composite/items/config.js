/**
   * update item json based on key/value pairs
   *
   * @inner
   * @memberof CompositeItems
   *
   * @function
   * @namespace getConfig
   *
   * @param {{ item: Object, config: Object, api: Object }} param passed in parameters
  */
const getConfig = (item, config, api) => {
    const questionConfig = { ...config };
    if (!questionConfig.defaultColDef) {
        // Default column properties
        const defaultColDef = {
            sortable: true,
            filter: true,
            filterParams: { buttons: ["reset"] },
            flex: 1
        };
        questionConfig.defaultColDef = defaultColDef;
    };

    if (!questionConfig.columnDefs) {
        // columns definitions
        const columnDefs = [
            { headerName: "ID", field: "id", headerCheckboxSelection: true, checkboxSelection: true },
            { headerName: "Name", field: "name" },
            { headerName: "Grade Level", field: "grade" },
            { headerName: "Content Area", field: "content_area" },
            { headerName: "Framework", field: "framework_type" },
            { headerName: "Item Type", field: "item_type_name" },
            { headerName: "Status", field: "item_status_name" },
            { headerName: "Item Type Category", field: "item_type_category_name" },
            { headerName: "Testing Program", field: "testing_program" }
        ];
        questionConfig.columnDefs = columnDefs;
    };

    if (api) {
        if (!questionConfig?.fetchItems) {
            // filter the existing item list based on the categoriesCode, and excludeIds
            const filterItems = async (categoryCodes = [], excludeIds = [], callback) => {
                const filters = excludeIds.map(id => {
                    return { "field": "id", "operator": "neq", "value": id }
                });
                filters.push({ "field": "item_type_id", "operator": "neq", "value": item?.item_type_id });
                const attribute = item?.attributes_list?.[0].group_info;
                const filter = filters.length > 0 ? { "logic": "and", "filters": filters } : {};
                const payload = {
                    assessment_program_id: item?.assessment_program_id,
                    content_area_id: attribute?.content_area_id,
                    grade_ids: attribute?.grade_id,
                    filter: filter,
                    sort: [],
                    skip: 0,
                    take: 100000
                };
                if (categoryCodes?.includes('question') && api?.genericRepository?.SearchByArguments) {
                    payload.item_type_category_code = 'question';
                    const response = await api.genericRepository.SearchByArguments(api?.lookups?.apiResources.ITEM, payload);
                    callback(response?.search_results || []);
                };
            };
            questionConfig.fetchItems = filterItems;
        };

        if (!questionConfig?.fetchItemsDetails) {
            // fetch the existing item details by passing items ids
            const fetchItemsDetails = async (ids) => {
                if (api?.BlocksRepository?.GetItemList) {
                    const data = await api.BlocksRepository.GetItemList({ listOfItems: ids });
                    return data;
                }
            };
            questionConfig.fetchItemsDetails = fetchItemsDetails;
        };
    };
    return { questionConfig };
};

export default getConfig;