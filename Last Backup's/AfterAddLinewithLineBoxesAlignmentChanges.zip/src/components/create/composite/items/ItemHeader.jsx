import React, { useState } from "react";
import PropTypes from "prop-types";
import contentParser from "../../../../utility/contentParser";
import CKEditorBase from "../../../common/editors/ckeditor/CKEditorBase";

/**
 * React functional component - Common Item Header Component
 *
 * @memberof ItemGrid
 * @inner
 * 
 * @component
 * @namespace ItemHeader
 * 
 * @param {{data: Object, onUpdate: Func}} param passed in parameters
 * @param {Object} param.data Respective grid Row data
 * @param {Func} param.onUpdate Callback function to update the Item List of the item_Json 
 * if there is any change in the state of the item header
 * @return {ItemHeader} Display Component with the Item Header, When hover allow to edit the item header using CK-Editor
 * 
 * @example
 * <ItemHeader 
    data={{...}}
    onUpdate={()=>{
        ...
    }}
  }} />
 */
const ItemHeader = ({ data, onUpdate }) => {
    const [editor, setEditor] = useState(data?.header || '');
    const [focused, setFocus] = useState(false);
    const index = data?.order;

    return (
        <>
            {!focused &&
                <div
                    tabIndex="0"
                    role="presentation"
                    aria-label={"Item Header " + index}
                    className='item-header-parser'
                    data-testid={'item-header-parser-' + index}
                    onClick={(event) => {
                        event.target.focus();
                    }}
                    onKeyDown={() => {
                        setFocus(true);
                    }}
                    onFocus={() => {
                        setFocus(true);
                    }}
                >
                    {
                        contentParser(editor)
                    }
                </div>
            }
            {focused &&
                <CKEditorBase
                    type='inline'
                    data={editor}
                    placeholder='Enter Item Header'
                    dataTestId={'item-header-editor-' + index}
                    onReady={(editor, _event) => {
                        if (editor?.editing?.view) {
                            editor.editing.view.focus();
                        }
                    }}
                    onChange={(value) => {
                        setEditor(value);
                    }}
                    onBlur={() => {
                        onUpdate('edit', index, 'header', editor);
                        setFocus(false);
                    }}
                    onFocus={() => {
                        setFocus(true);
                    }}
                    displayEditorCount={false}
                    config={{ removePlugins: ['TagAccessibility'] }}
                />
            }
        </>
    );
};

ItemHeader.propTypes = {
    data: PropTypes.object,
    onUpdate: PropTypes.func
};

export default ItemHeader;
