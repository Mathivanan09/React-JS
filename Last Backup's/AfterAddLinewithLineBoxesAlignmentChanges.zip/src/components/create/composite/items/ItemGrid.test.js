import React from 'react';
import { act } from "react-dom/test-utils";
import { unmountComponentAtNode } from "react-dom";

import userEvent from '@testing-library/user-event';
import { render, screen, waitFor } from '@testing-library/react';

import DummyItems from "../../../../stories/assets/com/DummyItems.json";

import MCS from "../../../../stories/assets/mc/mc_single.json";
import MCSZ from "../../../../stories/assets/mc/mc_stackedZ.json";
import MCMS from "../../../../stories/assets/mc/mc_multiple.json";
import TF from "../../../../stories/assets/mc/mc_true_false.json";

// import component here
import ItemGrid from './ItemGrid';

let container = null;
beforeEach(() => {
      // setup a DOM element as a render target
      container = document.createElement("div");
      document.body.appendChild(container);
});

afterEach(() => {
      // cleanup on exiting
      unmountComponentAtNode(container);
      container.remove();
      container = null;
});

describe('Item Grid Component Check', () => {

      /**
      * Item Grid Component Check Add Items
      */
      test("Item Grid Component Check Add Items", async () => {
            // set up test mock data as empty
            let selectedItem = [];
            let gridData = [];
            // Default column properties and columns definitions
            const defaultColDef = {
                  sortable: true,
                  filter: true,
                  filterParams: { buttons: ["reset"] },
                  flex: 1
            };
            const columnDefs = [
                  { headerName: "ID", field: "id", headerCheckboxSelection: true, checkboxSelection: true },
                  { headerName: "Name", field: "name" },
                  { headerName: "Grade", field: "grade" },
                  { headerName: "Framework", field: "framework_type" },
                  { headerName: "Item Type", field: "item_type_name" },
                  { headerName: "Status", field: "item_status_name" },
                  { headerName: "Item Type Category", field: "item_type_category_name" },
                  { headerName: "Testing Program", field: "testing_program" }
            ];

            let config = { defaultColDef, columnDefs };

            const fetch = async () => {
                  const itemList = JSON.parse(JSON.stringify(DummyItems));
                  itemList[0] = { ...itemList[0], ...MCSZ?.item, category: 'question', order: 0 };
                  itemList[1] = { ...itemList[1], ...MCS?.item, category: 'question', order: 1 };
                  itemList[2] = { ...itemList[2], ...MCMS?.item, category: 'question', order: 2 };
                  itemList[3] = { ...itemList[3], ...TF?.item, category: 'question', order: 3 };
                  const questions = await itemList?.filter((item) => item.id);
                  if (gridData?.length === 0) {
                        gridData = questions;
                  }
                  return;
            };

            const fetchItems = jest.fn(fetch);

            // set up test mock onUpdate function
            const itemSelectionsHandler = jest.fn(event => {
                  if (event.api.getSelectedNodes) {
                        const selectedData = event.api.getSelectedNodes().map((node) => node.data);
                        selectedItem = selectedData;
                  }
            });
            
            let update;
            act(() => {
                  const { rerender } = render(
                        <ItemGrid
                              items={gridData}
                              config={config}
                              fetchItems={fetchItems}
                              itemSelectionsHandler={itemSelectionsHandler}
                              isAddItems={true}
                        />,
                        container
                  );
                  update = rerender;
            });

            expect(gridData?.length).toBe(0);

            const itemGrid = screen.getByTestId("add-items-container");
            expect(itemGrid).toBeInTheDocument();
            expect(itemGrid).toHaveClass("add-items");

            await waitFor(() => {
                  expect(fetchItems).toHaveBeenCalledTimes(1);
            });

            expect(gridData?.length).toBe(4);

            update(
                  <ItemGrid
                        items={gridData}
                        config={config}
                        fetchItems={fetchItems}
                        itemSelectionsHandler={itemSelectionsHandler}
                        isAddItems={true}
                  />,
                  container
            );

            expect(itemSelectionsHandler).toHaveBeenCalledTimes(0);

            await waitFor(() => {
                  expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).toBeInTheDocument();
            });

            let itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');

            act(() => {
                  // select the first item of the list
                  userEvent.click(itemListCheckbox[0]);
            });

            await waitFor(() => {
                  expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).toBeChecked();
            });

            // selected data need to be reflect back to the selectedItem array
            expect(itemSelectionsHandler).toHaveBeenCalledTimes(1);
            expect(selectedItem?.length).toBe(1);

            // unselect the first item of the list
            itemListCheckbox = document.querySelectorAll('.add-items .ag-selection-checkbox .ag-checkbox-input');
            act(() => {
                  userEvent.click(itemListCheckbox[0]);
            });

            // unselected data need to be reflect back to the selectedItem array
            await waitFor(() => {
                  expect(document.querySelector('.add-items .ag-selection-checkbox .ag-checkbox-input')).not.toBeChecked();
                  expect(itemSelectionsHandler).toHaveBeenCalledTimes(2);
                  expect(selectedItem?.length).toBe(0);
            });

      }, 1000000);

      test("Item Grid Component Check for Saved Items", async () => {
            // set up test mock data as empty
            let items = JSON.parse(JSON.stringify(DummyItems)).map((item, index) => { return { ...item, order: index, category: 'question' } });
            const config = {};

            // set up test mock onUpdate function
            const onUpdate = jest.fn(data => { items = [...[data]] });
            act(() => {
                  render(
                        <ItemGrid
                              items={items}
                              onUpdateItems={onUpdate}
                              config={config}
                              isAddItems={false}
                        />,
                        container
                  );
            });

            const itemGrid = screen.getByTestId("item-grid-container");
            expect(itemGrid).toBeInTheDocument();
            expect(itemGrid).toHaveClass("item-grid");

            expect(items?.length).toBe(4);
            expect(onUpdate).toHaveBeenCalledTimes(0);

            await waitFor(() => {
                  expect(document.querySelector('.item-grid .grid-cell-actions')).toBeInTheDocument();
            });

            let itemActions = document.querySelectorAll('.item-grid .grid-cell-actions');
            expect(itemActions?.length).toBe(4);

            await waitFor(() => {
                  expect(document.querySelector('.item-grid .item-actions')).toBeInTheDocument();
                  expect(screen.getByTestId('item-actions-container-0')).toBeInTheDocument();
            });

            // respective button should be rendered for the respective item based on the order
            const deleteButton = screen.getByTestId("item-1-actions-delete");
            const shiftUpButton = screen.getByTestId("item-1-actions-up");
            const shiftDownButton = screen.getByTestId("item-1-actions-down");

            // click all the action item for the second item
            act(() => {
                  userEvent.click(deleteButton);
                  userEvent.click(shiftUpButton);
                  userEvent.click(shiftDownButton);
            });

            // all the actions should be call the onUpdate function to make the actions work
            await waitFor(() => {
                  expect(onUpdate).toHaveBeenCalledTimes(3);
            });

      }, 1000000);

});