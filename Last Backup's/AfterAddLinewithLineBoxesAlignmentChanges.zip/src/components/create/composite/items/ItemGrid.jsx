import React, { memo } from "react";
import PropTypes from "prop-types";
import ItemHeader from "./ItemHeader";
import ItemActions from './ItemActions';
import { AgGridReact } from "ag-grid-react";

import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";

/**
 * React functional component - Common Item Grid that will load the items, and its functionality (such as add, edit/view items).
 *
 * @memberof CompositeItems
 * @inner
 * 
 * @component
 * @namespace ItemGrid
 * 
 * @param {{items: Array, onUpdateItems: Func, config: Object, fetchItems: Func, itemSelectionsHandler: Func, isAddItems: Boolean}} param passed in parameters
 * @param {Array} param.items will hold the list of items information within an array 
 * @param {Func} param.onUpdateItems Callback function to update the Item List of the item_Json 
 * if there is any change in the state of the item (such as sort, delete, add)
 * @param {Object} param.config Configuration object, if any
 * @param {Func} param.fetchItems Optional, Callback function to get and load the Item in the grid dynamically once the grid is loaded.
 * @param {Func} param.itemSelectionsHandler Callback function to selection of the Item in the grid
 * @param {Func} param.isAddItems is the component need to add items, or load the item list
 * @return {ItemGrid} component for the Item List and its functionality based on the isAddItems
 * 
 * @example
 * <ItemGrid 
    items={[{}]
    onUpdateItems={()=>{
        ...
    }}
    config={{...}}
    fetchItems={()=>{
        ...
    }}
    itemSelectionsHandler={()=>{}}
    isAddItems={false/true}
  }} />
 */
const ItemGrid = memo(({ items, onUpdateItems, config, fetchItems, itemSelectionsHandler, isAddItems }) => {

    // Performing the deep clone on array of the items, that will isolate from the original data, so can avoid mutating state through grid behavior.
    const rows = items?.filter(item => item?.id != undefined)?.map(item => { return { ...item } }) || [];

    // Default column properties
    let defaultColDef = {
        suppressKeyboardEvent: ((params) => !isAddItems && params?.nextHeaderPosition?.headerRowIndex !== -1),
        filterParams: { buttons: ["reset"] },
        suppressCellFocus: !isAddItems && true,
        autoHeight: true,
        resizable: true,
        sortable: true,
        filter: true,
        flex: 1
    };

    // sort order will be start by zero, and to make user friendly, will just the number start from one
    const orderFormatter = ((row) => row?.value != undefined ? (row.value + 1) : '');

    // Default columns definitions
    let columnDefs = [
        {
            headerName: "Actions",
            field: "actions",
            cellClass: "grid-cell-actions grid-normal-cell",
            maxWidth: 120,
            sortable: false,
            filter: false
        },
        {
            headerName: "ID",
            field: "id",
            cellClass: "grid-cell-id grid-normal-cell",
            maxWidth: 120
        },
        {
            headerName: "Order",
            field: "order",
            cellClass: "grid-cell-order grid-normal-cell",
            maxWidth: 120,
            valueFormatter: orderFormatter,
            filter: false
        },
        {
            headerName: "Name",
            field: "name",
            cellClass: "grid-cell-name grid-normal-cell"
        },
        {
            headerName: "Type",
            field: "type",
            cellClass: "grid-cell-type grid-normal-cell"
        },
        {
            headerName: "Category",
            field: "category",
            cellClass: "grid-cell-category",
            hide: true,
            suppressToolPanel: true
        },
        {
            headerName: "Header",
            field: "header",
            wrapText: true,
            cellClass: "grid-cell-header",
            minWidth: 300,
            suppressCellFocus: false,
            suppressKeyboardEvent: (params) => {
                if (!isAddItems) {
                    const event = params?.event;
                    const key = event?.key;
                    const target = event?.target;
                    if (target) {
                        const targetClass = target?.className?.split(' ') || [];
                        if (params?.nextHeaderPosition?.headerRowIndex === -1) {
                            return false;
                        } else if (targetClass?.includes('ck-editor__editable')) {
                            return ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Enter'].includes(key);
                        } else if (key && (targetClass?.includes('grid-cell-header'))) {
                            const editor = target?.querySelector(".ck-editor__editable");
                            const parser = target?.querySelector(".item-header-parser");
                            if (!editor && parser) {
                                parser.focus();
                            }
                        }
                    }
                }
                return true;
            }
        }
    ];

    /**
     * Customizing the Tab to default Next Cell functionality
     *
     * @inner
     * @memberof ItemGrid
     *
     * @function
     * @namespace tabToNextCell
     *
    */
    const tabToNextCell = (params) => {
        const allowed = ['actions', 'header'];
        const current = params.previousCellPosition;
        const colId = current.column.colId;
        const cell = params.nextCellPosition;
        if (cell) {
            const rowIndex = cell.rowIndex;
            let gridColumns = cell.column;
            const cursorAt = allowed.findIndex(field => field === colId);
            const nextColId = allowed[(params.backwards ? cursorAt - 1 : cursorAt + 1)];
            if (colId !== nextColId) {
                const nextAt = params?.api?.columnModel?.columnDefs?.findIndex(column => nextColId === column.field);
                if (nextAt && params.api.columnModel.gridColumns[nextAt]) {
                    gridColumns = params.api.columnModel.gridColumns[nextAt];
                }
            }
            return {
                rowIndex: rowIndex,
                column: gridColumns,
                rowPinned: null
            };
        }
        return null;
    };

    /**
     * async function to call the fetchItems callback to get & set the list of the items by calling the fetchItems function when the grid is loaded.
     * while fetchItem the grid will show the loading progress status for the grid, if fetchItem exists
     *
     * @inner
     * @memberof ItemGrid
     *
     * @function
     * @namespace onGridReady
     *
    */
    const onGridReady = async (params) => {
        if (params?.api && typeof fetchItems === 'function') {
            params.api.showLoadingOverlay();
            await fetchItems();
            params.api.hideOverlay();
        }
    };

    // register the components for the columnDefs
    const frameworkComponents = {};

    // update the defaultColDef and columnDefs based on configuration
    if (isAddItems) {
        defaultColDef = config?.defaultColDef ? config?.defaultColDef : defaultColDef;
        if (config?.columnDefs == undefined) {
            const fields = ['actions', 'order', 'header'];
            columnDefs = columnDefs.filter(data => fields.includes(data.field) === false);
        } else {
            columnDefs = config?.columnDefs;
        }
        columnDefs[0].checkboxSelection = true;
        columnDefs[0].headerCheckboxSelection = true;
    } else { // prepare action column
        const actionRender = (params) => {
            return {
                component: 'itemActions',
                params: {
                    items: items,
                    data: params?.data,
                    onUpdate: onUpdateItems
                }
            };
        };
        frameworkComponents.itemActions = ItemActions;
        columnDefs[0].cellRendererSelector = actionRender;

        const headerAction = (params) => {
            return {
                component: 'itemHeader',
                params: {
                    data: params?.data,
                    onUpdate: onUpdateItems
                }
            };
        };
        frameworkComponents.itemHeader = ItemHeader;
        columnDefs[columnDefs?.length - 1].cellRendererSelector = headerAction;
    }

    return (
        <div className={"fluid " + (isAddItems ? 'add-items' : 'item-grid')} data-testid={(isAddItems ? 'add-items-container' : 'item-grid-container')}>
            <div
                className="ag-theme-alpine"
                style={{ height: "61vh", width: "100%" }}
                data-testid={"item-grid"}
            >
                <AgGridReact
                    frameworkComponents={frameworkComponents}
                    defaultColDef={defaultColDef}
                    columnDefs={columnDefs}
                    rowData={rows}
                    pagination={true}
                    rowSelection="multiple"
                    paginationPageSize={10}
                    onGridReady={onGridReady}
                    onSelectionChanged={itemSelectionsHandler}
                    enableCellTextSelection={!isAddItems && true}
                    suppressCellSelection={!isAddItems && true}
                    tabToNextCell={!isAddItems ? tabToNextCell : null}
                />
            </div>
        </div>
    );
});

ItemGrid.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object),
    onUpdateItems: PropTypes.func,
    config: PropTypes.object,
    fetchItems: PropTypes.func,
    itemSelectionsHandler: PropTypes.func,
    isAddItems: PropTypes.bool
};

export default ItemGrid;
