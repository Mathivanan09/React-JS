import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";

// import component here
import CreateInterface from './CreateInterface';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

/**
 * Test an empty component and verify the element with Missing item data
 */
it("Test default component", () => {
  act(() => {
    render(
      <CreateInterface />, container);
  });

  expect(container.children).toBeNull;
  const emptyComponent = document.querySelector("[data-testid=missing-item]");
  expect(emptyComponent).toBeNull;
});

/**
 * Test non implemented item
 */
it("Test non implemented item", () => {
  act(() => {
    render(
      <CreateInterface item={{
        item_json: {
          itemTypeCode: 'XYZ'
        }
      }
      } />, container);
  });

  expect(container.children).toBeNull;
  const notImplemented = document.querySelector("[data-testid=not-implemented]");
  expect(notImplemented).not.toBeNull;
  expect(notImplemented.textContent).toBe('xyz Not implemented');
});

/**
 * Test component by passing skeleton item json and verify the 
 * elements and values when opened from new  item
 */
it("Test skeleton component when opened from new item", () => {
  act(() => {
    render(
      <CreateInterface item={{
        item_json: {
          itemTypeCode: 'MC'
        }
      }
      } />, container);
  });

  /**
   * Verify that there 3 main containers item dimensions, stem content and options
   */
  const component = document.querySelector("[data-testid=container]");
  expect(component).not.toBeNull;
  expect(component.children.length).toBe(4);

  // Verify that the 4 containers exists
  expect(document.querySelector("[data-testid=container]")).not.toBeNull;
  expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
  expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
  expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
});