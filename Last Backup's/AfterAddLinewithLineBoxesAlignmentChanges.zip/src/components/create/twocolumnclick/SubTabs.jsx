import React from 'react';
import Editor from './Editor';
import PropTypes from 'prop-types';

/**
 * React functional component to create Sub Tab of the two column click
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @namespace SubTabs
 * @param {string} id - the unique id of the subTab
 * @param {number} index - index of the main tab
 * @param {number} subIndex - index of the sub-tab that is going to create
 * @param {JSON} item - item is a JSON object data of the sub-tab properties
 * that are going to create for the respective main tab
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the items/data
 * @return {component} - Sub Tab(s) of the two column click for each Main Tab
 */
const SubTabs = ({ id, index, subIndex, item, onUpdate, columnNumber }) => {
  const items = item ? item : {};
  return Object.values(items).map((data = '', ind) => {
    const key = `editor-${id}-${index}-${subIndex}-${ind}`;
    const colCode = columnNumber === 2 ? ind - 1 : ind;
    const testId = index + 1 + '-col-' + (subIndex + 1) + '-' + (colCode + 1);

    const onChange = (value) => {
      const keys = Object.keys(item);
      if (keys && keys[ind]) {
        const key = keys[ind];
        onUpdate(key, value);
      }
    };

    return (
      <div
        id={id + '-' + ind}
        key={key}
        className='col'
        data-testid={'tcc-sub-tab-row-' + testId}
      >
        <Editor
          id={key}
          key={key}
          data={data}
          index={colCode}
          onUpdate={onChange}
        />
      </div>
    );
  });
};

SubTabs.propTypes = {
  id: PropTypes.string,
  index: PropTypes.number,
  subIndex: PropTypes.number,
  item: PropTypes.object,
  onUpdate: PropTypes.func
};

export default SubTabs;
