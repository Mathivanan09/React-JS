import React, { useState } from 'react';
import PropTypes from 'prop-types';

/**
 * React functional component to configure Main Tab column width
 * based on choosen columnNumber
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @namespace ColumnWidths
 *
 * @param {JSON} columnWidth - columnWidth is a JSON object
 * that will be stored the width properties of each main tab(column)
 * @param {string} columnType - column type code
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the items/data
 * @return {component} - Column Width Inputs based on the columnType
 */
const ColumnWidths = ({ columnWidth = {}, columnType, onUpdate }) => {
  const [currentKey, setCurrentKey] = useState(-1);
  const [previousKey, setPreviousKey] = useState(-1);
  const [previousVal, setPreviousVal] = useState(-1);
  const [currentVal, setCurrentVal] = useState(-1);

  // function to set total column widths to be 100 percent
  const setColumnWidths = (i, val) => {
    val = parseInt(val > 100 ? 100 : val < 0 ? 0 : val);
    const key = Object.keys(columnWidth);
    let columnWidthJSON = {};
    if (key && key[i]) {
      if (columnType === 'twocolumn') {
        //logic for setting two columns
        const selectKey = i;
        const otherKey = i === 0 ? 1 : 0;
        const selectVal = val;
        const otherVal = 100 - val; // other column value will be 100 - entered value
        const selectName = key[selectKey];
        const otherName = key[otherKey];
        columnWidth[selectName] = selectVal;
        columnWidth[otherName] = otherVal;
        columnWidthJSON[selectName] = selectVal;
        columnWidthJSON[otherName] = otherVal;
      } else {
        //logic for setting three columns
        if (currentKey !== i) {
          //storing the state for previous key and previous value
          setPreviousKey(currentKey);
          setPreviousVal(currentVal);
        }
        if (previousKey > -1 && previousKey !== i) {
          //logic if previous value exists
          const thirdKey = 3 - (previousKey + i); //identifying the third key
          let firstVal = previousVal;
          let thirdVal = 100 - firstVal - val; //calculating the third value
          if (thirdVal < 0) {
            //incase the third value is less than zero then resetting the other values
            thirdVal = parseInt((100 - val) / 2);
            firstVal = 100 - val - thirdVal;
          }
          const firstName = key[previousKey];
          const secondName = key[i];
          const thirdName = key[thirdKey];
          columnWidth[firstName] = firstVal;
          columnWidth[secondName] = val;
          columnWidth[thirdName] = thirdVal;
          columnWidthJSON[firstName] = firstVal;
          columnWidthJSON[secondName] = val;
          columnWidthJSON[thirdName] = thirdVal;
        } else {
          //this is when user enters the values for the first time
          const secondKey = i === 0 ? 1 : 0; //setting the second key to be 0 or 1
          const secondVal = parseInt((100 - val) / 2); //setting the second value to be average
          const thirdKey = 3 - (secondKey + i); //setting third key
          const thirdVal = 100 - secondVal - val; //setting third value, this cannot be less than zero as entered value will be less than or equal to 100
          const firstName = key[i];
          const secondName = key[secondKey];
          const thirdName = key[thirdKey];
          columnWidth[firstName] = val;
          columnWidth[secondName] = secondVal;
          columnWidth[thirdName] = thirdVal;
          columnWidthJSON[firstName] = val;
          columnWidthJSON[secondName] = secondVal;
          columnWidthJSON[thirdName] = thirdVal;
        }
        setCurrentVal(val);
        setCurrentKey(i);
      }
    }

    onUpdate(columnWidthJSON);
  };

  return Object.values(columnWidth)
    .filter((data) => data !== undefined)
    .map((width, i) => (
      <div key={i} className="col p-1">
        <input
          min={0}
          max={100}
          type='number'
          value={width || 0}
          id={`tcc-column-${i + 1}-width`}
          aria-labelledby='tcc-column-width'
          className='form-control form-control-sm'
          data-testid={`tcc-column-${i + 1}-width`}
          onChange={(e) => {
            let val = e?.target?.value;
            if (val !== undefined) {
              setColumnWidths(i, val);
            }
          }}
        />
      </div>
    ));
};

ColumnWidths.propTypes = {
  columnWidth: PropTypes.object,
  columnType: PropTypes.string,
  onUpdate: PropTypes.func
};

export default ColumnWidths;
