/**
 * @file Editor - Two Column Click Simulation Item Creation Component Test
 */
import React from 'react';
import { act } from 'react-dom/test-utils';
import { render, screen } from '@testing-library/react';

// import component here
import Editor from './Editor';

// set up test mock variable
let content;

// set up dummy test mock onUpdate function
const onUpdate = jest.fn(data => {
    content = data;
});

describe('Editor - Two Column Click Simulation Item Creation Component Test', () => {

    test('Loading Editor Component - TCC Empty Data With Placeholder Without Any Suffix', () => {
        // set up test mock data 
        content = null;
        const index = null;

        // Loading with empty data and initial index value for placeholder
        act(() => {
            render(
                <Editor id='121' data={content} index={index} onUpdate={onUpdate} />
            );
        });

        // check the tab Editor exists or not with correct placeholder (A for index as zero)
        expect(screen.getByTestId('tcc-tab-editor-col')).toBeInTheDocument();
        expect(onUpdate).toHaveBeenCalledTimes(0);
    });

    test('Loading Editor Component - TCC Heading Data With Appropriate Placeholder', () => {
        // set up test mock data 
        content = 'Heading';
        const index = -1;

        // Loading with TCC Heading data and initial index value for placeholder
        act(() => {
            render(
                <Editor id='121' data={content} index={index} onUpdate={onUpdate} />
            );
        });

        // check the heading tab Editor as index as -1 exists or not with correct placeholder A
        expect(screen.getByTestId('tcc-tab-editor-col-a')).toBeInTheDocument();
        expect(onUpdate).toHaveBeenCalledTimes(0);
    });

    test('Loading Editor Component - TTC SubTabs Data With Appropriate Placeholder', () => {
        // set up test mock data 
        content = '<p>Any content</p>';
        const index = 1;

        // Loading with TCC SubTabs data and its index value for placeholder
        act(() => {
            render(
                <Editor id='122' data={content} index={index} onUpdate={onUpdate} />
            );
        });

        // check the sub-tab Editor as index as 1 exists or not with correct placeholder C
        expect(screen.getByTestId('tcc-tab-editor-col-c')).toBeInTheDocument();
        expect(onUpdate).toHaveBeenCalledTimes(0);

    });

});