import React from 'react';
import Editor from './Editor';
import SubTabs from './SubTabs';
import PropTypes from 'prop-types';
import label from '../../../constants/labelCodes';

/**
 * React functional component helps to create the Main Tab of the TCC
 * based on the existing data and the column type, and manage the tabs (add/remove)
 *
 * @inner
 * @memberof TwoColumnClick
 *
 * @component
 * @namespace Tabs
 *
 * @param {JSON} data - data is a JSON array of the object that will help to create the main tab
 * for creating/updating two column click item
 * @param {Number} columnNumber - selected column type value
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the optionList/data
 * @return {component} - Main Tab of the two column click
 */
const Tabs = ({ data = [], columnNumber, onUpdate }) => (
  <div className='row' data-testid='tcc-all-tabs-container'>
    {data?.map(({ id, header = '', items = [] }, index) => (
      <div className='row' key={id + '-' + index}>
        <div
          className='tab-container col'
          data-testid={'tcc-tabs-container-' + (index + 1)}
        >
          {id !== undefined &&
            items?.length > 0 &&
            items.map(({ id: itemId, ...item }, subIndex) => (
              <React.Fragment key={'row-' + itemId + '-' + subIndex}>
                <div className='row p-2'>
                  {columnNumber !== 2 && subIndex === 0 && (
                    <div
                      className='col'
                      data-testid={'tcc-tab-head-' + (index + 1)}
                    >
                      <Editor
                        id={`editor-${id}-${index}-main-tab`}
                        index={-1}
                        data={header}
                        onUpdate={(val) => {
                          onUpdate(index, 'header', val);
                        }}
                      />
                    </div>
                  )}
                  {columnNumber !== 2 && subIndex > 0 && (
                    // This is to align the Column B and C subtab elements same as parent tab
                    <div className='col'></div>
                  )}
                  <SubTabs
                    id={itemId}
                    key={itemId}
                    index={index}
                    subIndex={subIndex}
                    item={item}
                    columnNumber={columnNumber}
                    onUpdate={(key, value) => {
                      onUpdate(index, key, value, subIndex);
                    }}
                  />
                  <div
                    className='col-md-1'
                    style={{
                      marginLeft: '-20px',
                      width: '4%',
                      marginRight: '10px'
                    }}
                  >
                    {columnNumber !== 2 && subIndex !== 0 && (
                      <div
                        key={'remove-sub-tab' + subIndex}
                        className={'remove-sub-tab'}
                      >
                        <button
                          data-testid={
                            'tcc-remove-sub-tab-' +
                            (index + 1) +
                            '-' +
                            (subIndex + 1)
                          }

                          className="icon"
                          onClick={() => {
                            onUpdate(index, null, null, subIndex, true);
                          }}
                        >
                          <span className='icon-minus'>-</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                {columnNumber !== 2 && subIndex === 0 && (
                  <div key={'addSubTab' + subIndex} className='row'>
                    <div className='col-md-10'></div>
                    <div className='col'>
                      <button
                        data-testid={'tcc-add-sub-tab-' + (index + 1)}
                        variant='primary'
                        className='btn btn-primary btn-sm float-sm-end'
                        onClick={() => {
                          onUpdate(
                            index,
                            null,
                            null,
                            data[index]?.items?.length - 1,
                            false
                          );
                        }}
                      >
                        {label.two_column_click_add_sub_tab}
                      </button>
                    </div>
                  </div>
                )}
              </React.Fragment>
            ))}
        </div>
        <div
          key={'remove-tab' + index}
          className={'col-auto remove-tab'}
          style={{
            marginTop: '12px',
            marginLeft: '5px'
          }}
        >
          <button
            data-testid={'tcc-tab-remove-' + (index + 1)}
            className="icon"
            onClick={() => {
              onUpdate(index, null, null, null, true);
            }}
          >
            <span className='icon-minus'>-</span>
          </button>
        </div>
      </div>
    ))}
  </div>
);

Tabs.propTypes = {
  data: PropTypes.array,
  columnNumber: PropTypes.number,
  onUpdate: PropTypes.func
};

export default Tabs;
