/**
 * @file Editor - Two Column Click Simulation Item Creation Component Test
 */
import React from 'react';
import { unmountComponentAtNode } from 'react-dom';
import { act } from 'react-dom/test-utils';
import { render, screen, fireEvent } from '@testing-library/react';

// import component here
import ColumnWidths from './ColumnWidths';

let container = null;

beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement('div');
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('ColumnWidths - Two Column Click Simulation Item Creation Component Test', () => {

    test('Testing Column Width with New Two Column Click Data As Two Column Type', () => {
        // set up test mock data 
        let content = null;
        let columnWidth = undefined;

        let columnType = "twocolumn";

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => {
            content = data;
        });

        // Loading with empty data
        let update;
        act(() => {
            const { rerender } = render(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />
                , container
            );
            update = rerender;
        });

        // Loading with null data
        columnWidth = {
            "column1": null,
            "column2": null
        };

        act(() => {
            update(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />,
                container
            )
        });

        // check the column width value exists or not with two column type
        const widthOne = screen.getByTestId('tcc-column-1-width');
        const widthTwo = screen.getByTestId('tcc-column-2-width');
        expect(widthOne).toBeInTheDocument();
        expect(widthTwo).toBeInTheDocument();
        expect(widthOne?.value).toBe("0");
        expect(widthTwo?.value).toBe("0");
        expect(onUpdate).toHaveBeenCalledTimes(0);

        act(() => {
            // trigger the change event to add new column width data with two column type
            fireEvent.change(widthOne, { target: { value: 50 } });
        });

        expect(onUpdate).toHaveBeenCalledTimes(1);

        // re-render, to check is that the column width data value got updated or not
        act(() => {
            update(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />,
                container
            )
        });

        // check is that the column width data value got updated or not
        expect(widthOne?.value).toBe("50");
        // check third value dynamically corrected the value or not within 100 percentage
        expect(widthTwo?.value).toBe("50");

        act(() => {
            // trigger the change event to add new column width data that is more than 100 percentage with two column type
            fireEvent.change(widthTwo, { target: { value: 600 } });
        });

        expect(onUpdate).toHaveBeenCalledTimes(2);

        // re-render, to check is that the column width data value got updated or not
        act(() => {
            update(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />,
                container
            )
        });

        // check is that the column width data value got updated as default zero or not
        expect(widthOne?.value).toBe("0");
        // check third value dynamically corrected the value as 100 percentage or not
        expect(widthTwo?.value).toBe("100");

        act(() => {
            // trigger the change event to add new column width data that is less than 0 percentage with two column type
            fireEvent.change(widthOne, { target: { value: -7 } });
        });

        expect(onUpdate).toHaveBeenCalledTimes(3);

        // re-render, to check is that the column width data value got updated or not
        act(() => {
            update(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />,
                container
            )
        });

        // check is that the column width data value got updated as default zero or not
        expect(widthOne?.value).toBe("0");
        // check third value dynamically corrected the value as 100 percentage or not
        expect(widthTwo?.value).toBe("100");

    });

    test('Testing Column Width vaildation with existing Two Column Click Data As Three Column Type', () => {
        // set up test mock data 
        let content = null;
        let columnWidth = {
            "column1": "30",
            "column2": "30",
            "column3": "40"
        };

        let columnType = "threecolumn";

        // set up test mock onUpdate function
        const onUpdate = jest.fn(data => {
            content = data;
        });

        expect(document.querySelector('div')?.children?.length).toBe(0);

        // Loading with valid data
        let update;
        act(() => {
            const { rerender } = render(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />
                , container
            );
            update = rerender;
        });

        // check the column width value exists or not with three column type
        const widthOne = document.querySelector('[data-testid=tcc-column-1-width]');
        const widthTwo = document.querySelector('[data-testid=tcc-column-2-width]');
        const widthThree = document.querySelector('[data-testid=tcc-column-3-width]');

        expect(widthOne).toBeInTheDocument();
        expect(widthTwo).toBeInTheDocument();
        expect(widthThree).toBeInTheDocument();

        expect(widthOne?.value).toBe("30");
        expect(widthTwo?.value).toBe("30");
        expect(widthThree?.value).toBe("40");

        expect(onUpdate).toHaveBeenCalledTimes(0);

        act(() => {
            // trigger the change event to add new column width data with three column type
            fireEvent.change(widthThree, { target: { value: 10 } });
        });

        expect(onUpdate).toHaveBeenCalledTimes(1);

        // re-render, to check is that the column width data value got updated or not
        act(() => {
            update(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />,
                container
            )
        });

        // check is that the column width data value got updated or not
        expect(widthThree?.value).toBe("10");
        // check third value dynamically corrected the value or not within 100 percentage based on the last change
        expect(widthOne?.value).toBe("45");
        expect(widthTwo?.value).toBe("45");

        act(() => {
            // trigger the change event to add new column width data with three column type
            fireEvent.change(widthOne, { target: { value: 40 } });
            fireEvent.change(widthTwo, { target: { value: 12 } });
        });

        expect(onUpdate).toHaveBeenCalledTimes(3);

        // re-render, to check is that the column width data value got updated or not
        act(() => {
            update(
                <ColumnWidths columnWidth={columnWidth} columnType={columnType} onUpdate={onUpdate} />,
                container
            )
        });

        // check is that the column width data value got updated or not
        expect(widthTwo?.value).toBe("12");
        // check third value dynamically corrected the value or not within 100 percentage based on the last change
        expect(widthOne?.value).toBe("44");
        expect(widthThree?.value).toBe("44");

    });

});