import React, { useLayoutEffect } from 'react';
import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';
import CKEditorBase from '../../common/editors/ckeditor/CKEditorBase';
import label from '../../../constants/labelCodes';
import { addTab, tabHandler } from './template.js';
import { itemProps } from '../../common/ItemHelper';
import AnswerAlignment from '../shared/AnswerAlignment';
import defaultValue from '../../../utility/default';

import Tabs from './Tabs';
import ColumnWidths from './ColumnWidths';

import '../../../styles/item/Common.css';
import '../../../styles/item/TwoColumnClick.css';

const COLUMN_TYPE_CODE = ['twocolumn', 'threecolumn'];
const DEFAULT = 0;

/**
 * React functional component to create two column click item
 *
 * @memberof CreateComponents
 * @inner
 *
 * @namespace TwoColumnClick
 *
 * @param {JSON} item - JSON data that will contain the item information
 * for creating/updating two column click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - TwoColumnClick component for creating two column click item
 */
const TwoColumnClick = ({ item, onUpdate }) => {

  const stemPlaceholder = label.enter_content;
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };
  const itemJson = { ...(item?.item_json || {}) };
  const optionList = [...(itemJson?.optionList || [])];
  const titlePlaceholder = label.two_column_click_title;
  const answerAlignments = [
    { id: 'vertical_stacked', name: 'Vertical' },
    { id: 'horizontal_stacked', name: 'Horizontal' }
  ];
  const twoColumnColumn1 = defaultValue('two-column-column1');
  const twoColumnColumn2 = defaultValue('two-column-column2');
  const threeColumnColumn1 = defaultValue('three-column-column1');
  const threeColumnColumn2 = defaultValue('three-column-column2');
  const threeColumnColumn3 = defaultValue('three-column-column3');

  const columnTypes = COLUMN_TYPE_CODE.map((data, index) => ({
    id: data,
    name: index + 2
  })).filter((data) => data !== undefined && data);

  const columnType = itemJson?.columnType;

  const getColNumber = (type) =>
    COLUMN_TYPE_CODE.findIndex((code) => code === type) + 2;
  const columnNumber = getColNumber(columnType);

  const columnDimension = (columnNumb, dim = {}) => {
    let dimension = {};
    if (columnNumb === 2) {
      dimension = {
        column1: dim?.column1 !== undefined ? dim?.column1 : 50,
        column2: dim?.column2 !== undefined ? dim?.column2 : 50,
        column3: undefined
      };
    } else if (columnNumb === 3) {
      dimension = {
        column1: dim?.column1 !== undefined ? dim?.column1 : 34,
        column2: dim?.column2 !== undefined ? dim?.column2 : 33,
        column3: dim?.column3 !== undefined ? dim?.column3 : 33
      };
    }
    return dimension;
  };

  const columnWidth = columnDimension(columnNumber, itemJson);

  // update item json for column widths
  const updateColumnWidths = (data) => {
    onUpdate({ ...item, item_json: { ...item.item_json, ...data } });
  };

  // column on change handler for column type change or set default value for TCC
  const updateColumnType = (value) => {
    const type = value;
    const colNum = getColNumber(type);
    // update item json on changing the column type
    const updatedItem = {
      ...item,
      item_json: {
        ...item.item_json,
        optionList: [...addTab([], colNum)],
        columnType: type,
        ...columnDimension(colNum)
      }
    };
    onUpdate(updatedItem);
  };

  // TODO Once byron's default JSON skeleton api is available, useEffect can be removed
  useLayoutEffect(() => {
    if (item?.id < 0 && !columnType) {
      updateColumnType(COLUMN_TYPE_CODE[DEFAULT]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Here empty dependency only allowed, do not provide any dependecies here.

  // Event handler for getting Response Alignments
  const getResponseAlignment = () => {
    return (
      answerAlignments.map((val, i) => {
        return {
          id: answerAlignments[i].id,
          name: answerAlignments[i].name
        };
      })
    );
  };

  const updateResponseAlignment = (key, value) => {
    let updatedItem = {};
    // update item json on changing the Response Alignment
    if (value === 'horizontal_stacked') {
      updatedItem = {
        ...item,
        item_json: {
          ...item.item_json,
          [key]: value,
          column1: "",
          column2: "",
          column3: ""
        }
      };
    }
    else if (value === 'vertical_stacked' && itemJson?.columnType === 'twocolumn') {
      updatedItem = {
        ...item,
        item_json: {
          ...item.item_json,
          [key]: value,
          column1: twoColumnColumn1,
          column2: twoColumnColumn2,
        }
      };
    }
    else {
      updatedItem = {
        ...item,
        item_json: {
          ...item.item_json,
          [key]: value,
          column1: threeColumnColumn1,
          column2: threeColumnColumn2,
          column3: threeColumnColumn3
        }
      };
    }
    onUpdate(updatedItem);
  };

  return (
    <div
      className='two-column-click-container'
      data-testid='two-column-click-container'
    >
      <ItemDimensions
        minWidth={itemJson?.minItemWidth}
        minHeight={itemJson?.minItemHeight}
        onChange={(dimension) => {
          if (dimension?.minWidth !== itemJson?.minItemWidth) {
            updateItemJson('minItemWidth', dimension.minWidth);
          }
          if (dimension?.minHeight !== itemJson?.minItemHeight) {
            updateItemJson('minItemHeight', dimension.minHeight);
          }
        }}
      />
      <StemContent
        placeholder={stemPlaceholder}
        data={itemJson?.stemContent}
        onUpdate={updateItemJson}
        fieldName={'stemContent'}
      />

      <div className="row">
        <div className="col-md-12">
          <fieldset className={'bg-light p-3 rounded m-1'}>
            <CKEditorBase
              trim={false}
              type='inline'
              data={itemJson?.title}
              fieldName='title'
              placeholder={titlePlaceholder}
              className='content_style'
              dataTestId='ttc-title'
              onChange={(value) => updateItemJson('title', value)}
            />
          </fieldset>
        </div>
      </div>
      <div className="row">
        <div className="col-md-3">
          <fieldset className={'bg-light p-4 pb-3 rounded m-1 me-0'}>
            <label htmlFor='tcc-columns-type'>Number of Levels</label>
            <div className='column-select p-2'>
              <select
                id='tcc-columns-type'
                data-testid='tcc-columns-type'
                className='form-select form-select-sm'
                aria-label='form-select-columns-number'
                value={columnType}
                onChange={(e) => {
                  updateColumnType(e.target.value);
                }}
              >
                <option value=''>Select</option>
                {columnTypes.map((options, index) => (
                  <option key={options.id + '-' + index} value={options.id}>
                    {options.name}
                  </option>
                ))}
              </select>
            </div>
          </fieldset>
        </div>
        <div className="col-md-3">
          <fieldset className={'bg-light p-4 rounded m-1 ps-1 mx-0'}>
            <AnswerAlignment
              data={getResponseAlignment()}
              dataItemKey='id'
              labelCode='two_column_click_tab_alignment'
              onUpdate={updateResponseAlignment}
              updateKey='answerAlignment'
              value={item?.item_json?.answerAlignment}
              dataTestId={'answer-alignment'}
            />
          </fieldset>
        </div>
        {item?.item_json?.answerAlignment === 'vertical_stacked' &&
          <div className="col-md-6">
            <fieldset className={'bg-light p-4 rounded m-1 ms-0'}>
              <div className='row'>
                <label
                  id='tcc-column-width'
                  htmlFor='tcc-column-1-width'
                  className='col p-1'
                >Column Widths(%)</label>
                <ColumnWidths
                  columnWidth={columnWidth}
                  columnType={columnType}
                  onUpdate={updateColumnWidths}
                />
              </div>
            </fieldset>
          </div>
        }
      </div>
      <fieldset className={'bg-light p-3 rounded m-1'}>
        <div className="row">
          <div className="col">
            <button
              variant='primary'
              data-testid='tcc-add-tab'
              className="btn btn-primary btn-sm float-sm-end"
              onClick={() => {
                updateItemJson('optionList', [...addTab(optionList, columnNumber)]);
              }}
            >
              {label.two_column_click_add_tab}
            </button>
          </div>
        </div>
        <Tabs
          data={optionList}
          columnNumber={columnNumber}
          onUpdate={(...data) => {
            const newOptionList = tabHandler(optionList, ...data);
            const content = {
              ...item,
              item_json: {
                ...itemJson,
                ...{
                  optionList: [...newOptionList]
                }
              }
            };
            onUpdate(content);
          }}
        />
      </fieldset>
    </div>
  );
};

TwoColumnClick.propTypes = itemProps;

export default TwoColumnClick;
