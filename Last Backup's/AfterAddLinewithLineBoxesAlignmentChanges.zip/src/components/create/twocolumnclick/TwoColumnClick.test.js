/**
 * @file Two Column Click Simulation Item Creation Component Test
 */
import React from 'react';
import { act } from 'react-dom/test-utils';
import { unmountComponentAtNode } from 'react-dom';
import { render, fireEvent, screen } from '@testing-library/react';

// import component here
import TwoColumnClick from './TwoColumnClick';

let itemData = {};
let container = null;

beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement('div');
  document.body.appendChild(container);
  itemData = {
    id: -1,
    item_json: {
      itemTypeCode: 'tcc',
      answerAlignment: 'vertical_stacked'
    }
  };
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
  itemData = {};
});

describe('', () => {
  test('Testing Loading of Two Column Click Component with empty item json data', () => {
    // set up test mock data as undefined
    let content = undefined;

    // set up test mock onUpdate function
    const onUpdate = jest.fn(data => { content = { ...{ data } } })

    let update;
    act(() => {
      const { rerender } = render(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      );
      update = rerender;
    });

    expect(onUpdate).toHaveBeenCalledTimes(0);

    // set up test mock new data
    content = { ...itemData };
    update(<TwoColumnClick item={content} onUpdate={onUpdate} />);

    // check the TCC component exists and loaded or not
    expect(screen.getByTestId('two-column-click-container')).toBeInTheDocument();

    // We have seperate test for ItemDimensions. So will check only, is it rendering the item dimensions or not
    expect(screen.getByTestId('item-dimensions-container')).toBeInTheDocument();

    // We have seperate test for StemContent. So will check only, is it rendering the stem content or not
    expect(screen.getByTestId('stem-content-container')).toBeInTheDocument();

    // check the rest of the basic inputs component is loaded or not
    expect(screen.getByTestId('ttc-title')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-columns-type')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-add-tab')).toBeInTheDocument();

    // check the tab container exists or not even with empty data
    expect(screen.getByTestId('tcc-all-tabs-container')).toBeInTheDocument();

    // there is default value initilization call onUpdate and update the data, may need remove this when fix added for initilization
    expect(onUpdate).toHaveBeenCalledTimes(0);

  });

  test('Testing Add Tab with New Two Column Click data with default columnType value', () => {
    // set up test mock data
    let content = { ...itemData };

    // set up test mock onUpdate function
    const onUpdate = jest.fn(data => {
      content = data;
    });

    let update;
    act(() => {
      const { rerender } = render(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      );
      update = rerender;
    });

    // check the tab container exists or not
    const tabContainer = screen.getByTestId('tcc-all-tabs-container');
    expect(tabContainer).toBeInTheDocument();
    expect(tabContainer?.children?.length).toBe(0);

    expect(screen.getByTestId('tcc-columns-type')).toBeInTheDocument();
    const addTab = screen.getByTestId('tcc-add-tab');
    expect(addTab).toBeInTheDocument();

    // there is default value initilization call onUpdate and update the data, may need remove this when fix added for initilization
    expect(onUpdate).toHaveBeenCalledTimes(1);

    // re-render to check the component structure after onUpdate called
    act(() => {
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    // there is default value initilization call onUpdate and update the data, may need remove this when fix added for initilization
    expect(onUpdate).toHaveBeenCalledTimes(1);

    act(() => {
      // trigger the click event to add two more new tabs with two column column type as default value
      fireEvent.click(addTab);
      fireEvent.click(addTab);
    });

    // data should be updated two times, since tried to add two tabs in the new item
    expect(onUpdate).toHaveBeenCalledTimes(3);

    // re-render to check the component structure is match with the updated item data or not
    act(() => {
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    // check the tab container exists or not for two column type
    expect(screen.getByTestId('tcc-all-tabs-container')).toBeInTheDocument();

    // do the basic test, since we already has separate test for Tabs. Checking the number of tabs added, should be three
    expect(screen.getByTestId('tcc-tabs-container-1')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-tabs-container-2')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-tabs-container-3')).toBeInTheDocument();
    expect(document.querySelectorAll('[data-testid^=tcc-tab-head-]').length).toBe(0);
  });

  test('Testing Add Tab with New Two Column Click data with three columnType', () => {
    // set up test mock data
    let content = { ...itemData };

    // set up test mock onUpdate function
    const onUpdate = jest.fn(data => {
      content = data;
    });

    let update;
    act(() => {
      const { rerender } = render(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      );
      update = rerender;
    });

    // check the tab container exists or not
    const tabContainer = screen.getByTestId('tcc-all-tabs-container');
    expect(tabContainer).toBeInTheDocument();
    expect(tabContainer?.children?.length).toBe(0);

    const columnTypes = screen.getByTestId('tcc-columns-type');
    expect(columnTypes).toBeInTheDocument();
    const addTab = screen.getByTestId('tcc-add-tab');
    expect(addTab).toBeInTheDocument();

    // there is default value initilization call onUpdate and update the data, may need remove this when fix added for initilization
    expect(onUpdate).toHaveBeenCalledTimes(1);

    // re-render to check the component structure after onUpdate called
    act(() => {
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    // there is default value initilization call onUpdate and update the data, may need remove this when fix added for initilization
    expect(onUpdate).toHaveBeenCalledTimes(1);

    act(() => {
      // set three column column type
      fireEvent.change(columnTypes, { target: { value: 'threecolumn' } });

      // empty the existing default column width value
      content.item_json.column1 = undefined
      content.item_json.column2 = undefined;
      content.item_json.column3 = undefined;

      // re-render to check the component structure is match with the updated item data or not to update the TCC as three column type
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    // check the tab container exists or not for three column type
    expect(screen.getByTestId('tcc-all-tabs-container')).toBeInTheDocument();

    // default subtab is available or not
    const addFirstSubTab = screen.getByTestId('tcc-add-sub-tab-1');
    expect(addFirstSubTab).toBeInTheDocument();

    act(() => {
      // add two more new tabs by trigger the click event
      fireEvent.click(addTab);
      fireEvent.click(addTab);
    });

    // data should be updated two times, since tried to add two tabs in the new item
    expect(onUpdate).toHaveBeenCalledTimes(4);

    // re-render to check the component structure is match with the updated item data or not
    act(() => {
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    // do the basic test, since we already has separate test for Tabs. Checking the number of tabs added, should be three
    expect(screen.getByTestId('tcc-tabs-container-1')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-tabs-container-2')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-tabs-container-3')).toBeInTheDocument();

    act(() => {
      // trigger change event for add tabs
      fireEvent.click(addFirstSubTab);

      // re-render to check the component structure is match with the updated item data or not
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    expect(onUpdate).toHaveBeenCalledTimes(5);

    // check the basic case, is added sub-tab or not
    expect(screen.getByTestId('tcc-sub-tab-row-1-col-2-1')).toBeInTheDocument();
    expect(screen.getByTestId('tcc-sub-tab-row-1-col-2-2')).toBeInTheDocument();

    // do the basic test, since we already has separate test for column width.
    const widthOne = document.querySelector('[data-testid=tcc-column-1-width]');
    const widthTwo = document.querySelector('[data-testid=tcc-column-2-width]');
    const widthThree = document.querySelector('[data-testid=tcc-column-3-width]');

    expect(widthOne).toBeInTheDocument();
    expect(widthTwo).toBeInTheDocument();
    expect(widthThree).toBeInTheDocument();

    expect(widthOne?.value).toBe("34");
    expect(widthTwo?.value).toBe("33");
    expect(widthThree?.value).toBe("33");

    act(() => {
      // trigger the change event to add new column width data with three column type
      fireEvent.change(widthOne, { target: { value: 20 } });

      // re-render to check the component structure is match with the updated item data or not
      update(
        <TwoColumnClick item={content} onUpdate={onUpdate} />
        , container
      )
    });

    expect(onUpdate).toHaveBeenCalledTimes(6);

    // check the data updation dynamically reflect in other column width
    expect(widthOne?.value).toBe("20");
    expect(widthTwo?.value).toBe("40");
    expect(widthThree?.value).toBe("40");

  });

});