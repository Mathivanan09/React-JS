import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import StraightLine from './StraightLine';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <StraightLine />, container);
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the 
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <StraightLine item={{
                    item_json: {
                        itemTypeCode: 'SL'
                    }
                }
                } />, container);
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=container]");
        expect(component).not.toBeNull;
        // expect(component.children.length).toBe(4);

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=container]")).not.toBeNull;
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
    });
    it('The User will be able to set Item dimensions for the item in item dimensions field', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'SL',
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <StraightLine item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull;
        expect(minItemHeightInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(<Provider store={store}>
                <StraightLine item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(<Provider store={store}>
                <StraightLine item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

})