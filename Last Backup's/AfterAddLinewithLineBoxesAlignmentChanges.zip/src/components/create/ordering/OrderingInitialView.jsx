import React from 'react';
import parse from 'html-react-parser';
import PropTypes from 'prop-types';

import label from '../../../constants/labelCodes';

/**
 *  React functional component for Rendering Inital view, and to use it in create interface
 *  providing provision for item creators to correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace OrderingInitialView
 *
 * @function OrderingInitialView - React functional component to display Inital view item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Inital view item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - OrderingInitialView component for displaying Inital view item
 */

const OrderingInitialView = ({ item, config }) => {
  const style =
    item?.item_json?.answerAlignment === 'Horizontal'
      ? {
          width: item?.item_json?.responseOptionWidth + 'px',
          minHeight: item?.item_json?.responseOptionHeight + 'px',
          backgroundColor: 'white'
        }
      : {
        backgroundColor: 'white'
      };

  return (
    <div
      className={
        config?.styleCode == 'alternate'
          ? 'ord-item-response-alternateui'
          : 'ord-item-response-generalui'
      }
    >
      {item?.item_json?.optionList &&
        item?.item_json?.optionList.length > 0 && (
          <div className='row'>
            <div className='text-center'>
              <legend>{label.ord_initial_view}</legend>
            </div>
            {item?.item_json?.optionList?.map((option) => {
              if (item.item_json?.answerAlignment === 'Vertical') {
                return (
                  <div className='row' key={option.id}>
                    {option.optionText && (
                      <div
                        className='border border-dark rounded p-1 m-10'
                        style={style}
                      >
                        {parse(option.optionText || '<div></div>')}
                      </div>
                    )}
                  </div>
                );
              } else {
                return (
                  <>
                    {option.optionText && (
                      <span
                        className='border border-dark rounded p-1 m-10'
                        style={style}
                      >
                        {parse(option.optionText || '<div></div>')}
                      </span>
                    )}
                  </>
                );
              }
            })}
          </div>
        )}
    </div>
  );
};

OrderingInitialView.propTypes = {
  item: PropTypes.object,
  config: PropTypes.object
};

export default OrderingInitialView;
