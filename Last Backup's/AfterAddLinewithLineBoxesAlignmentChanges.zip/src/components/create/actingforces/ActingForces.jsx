import React from 'react';
import uuid from 'react-uuid';

import ItemDimensions from '../shared/ItemDimensions';
import StemContent from '../shared/StemContent';

import label from '../../../constants/labelCodes';
import { itemProps } from '../../common/ItemHelper';

// load common styles first and then load any specific item type or overrides
import '../../../styles/item/Common.css';
import '../../../styles/item/ActingForces.css';

/**
 * React functional component to create acting forces item
 *
 
 * @memberof CreateComponents
 * @inner
 * 
 * @component
 * @namespace ActingForces
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information 
 * for creating/updating acting forces item
 * @param {Object} param.onUpdate Callback function to update item_son attributes 
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains 
 * client passed in style code, program specific defaults
 * @return {ActingForces} ActingForces component for creating acting forces item
 * 
 * @example
 * <ActingForces item={{
    id: -1,
    name: '',
    assessment_program_id: 0,
    item_type_id: 0,
    item_type_code: '',
    item_json: { itemTypeCode: 'af' },
    user_id: 0,
  }} />
 */
const ActingForces = ({ item, onUpdate, config }) => {
  // event handler for stem content update
  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });
  };

  const defaultSelections = [
    { name: 'tag', dataTestId: 'af-tag'},
    { name: 'circle', dataTestId: 'af-circle'},
    { name: 'arrow', dataTestId: 'af-arrow'},
    { name: 'triangle', dataTestId: 'af-triangle'},
    { name: 'square', dataTestId: 'af-square'},
    { name: 'plus', dataTestId: 'af-plus'}
  ];

  // TODO - add dynamic image selection
  const addImage = (e) => {
    let payload = {
      ...item,
      item_json: {
        ...item.item_json,
        backgroundURL: '/bananas.png'
      }
    };
    onUpdate(payload);
  };

  // TODO - add dynamic image selection
  const addSymbol = (e) => {
    const customSelection = item.item_json?.rowList?.customSelection
      ? [...item.item_json.rowList.customSelection]
      : [];
    customSelection.push({
      foilId: uuid(),
      imageURL: '/bananas.png'
    });

    let payload = {
      ...item,
      item_json: {
        ...item.item_json,
        rowList: {
          ...item.item_json.rowList,
          customSelection: customSelection
        }
      }
    };
    onUpdate(payload);
  };

  const selectDefaultSymbol = (e) => {
    const symbol = e.target.name;
    const checked = e.target.checked;
    const defaultSelection = item.item_json?.rowList?.defaultSelection
      ? [...item.item_json.rowList.defaultSelection]
      : [];
    if (checked) {
      if (!defaultSelection.includes(symbol)) {
        defaultSelection.push(symbol);
      }
    } else {
      defaultSelection.splice(defaultSelection.indexOf(symbol), 1);
    }

    let payload = {
      ...item,
      item_json: {
        ...item.item_json,
        rowList: {
          ...item.item_json.rowList,
          defaultSelection: defaultSelection
        }
      }
    };
    onUpdate(payload);
  };
  const isSymbolSelected = (symbol) => {
    return item.item_json?.rowList?.defaultSelection?.includes(symbol);
  };

  const removeSymbol = (foidId) => {
    const customSelection = item.item_json?.rowList?.customSelection
      ? [...item.item_json.rowList.customSelection]
      : [];
    customSelection.splice(
      customSelection.filter((cs) => cs.foidId === foidId),
      1
    );
    let payload = {
      ...item,
      item_json: {
        ...item.item_json,
        rowList: {
          ...item.item_json.rowList,
          customSelection: customSelection
        }
      }
    };
    onUpdate(payload);
  };

  return (
    <>
      {item ? (
        <div data-testid='container'>
          <div data-testid='id-container'>
            <ItemDimensions
              minWidth={item?.item_json?.minItemWidth || 0}
              minHeight={item?.item_json?.minItemHeight || 0}
              onChange={(dimension) => {
                if (dimension?.minWidth !== item?.item_json?.minItemWidth) {
                  updateItemJson('minItemWidth', dimension.minWidth);
                }
                if (dimension?.minHeight !== item.item_json.minItemHeight) {
                  updateItemJson('minItemHeight', dimension.minHeight);
                }
              }}
            />
          </div>
          <div data-testid='stem-container'>
            <StemContent
              data={item.item_json?.stemContent}
              onUpdate={updateItemJson}
              fieldName='stemContent'
            />
          </div>
          <div className='row' data-testid='design-container'>
            <div className='col' xs={12} sm={5}>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className='row'>
                  <div className='col text-end text-right'>
                    <button
                      className='btn btn-primary'
                      data-testid='af-add-image'
                      icon='add'
                      onClick={addImage}
                    >
                      {label.af_add_image}
                    </button>
                  </div>
                </div>
                <div className='row'>
                  <div className='col m-1 p-4 text-center'>
                    <img
                      src={item.item_json?.backgroundURL}
                      alt='Place holder'
                    />
                  </div>
                </div>
              </fieldset>
            </div>
            <div className='col' xs={12} sm={7}>
              <fieldset className='bg-light p-3 rounded m-1'>
                <div className='row'>
                  <div className='col text-end text-right'>
                    <button
                      className='btn btn-primary'
                      data-testid='af-add-symbol'
                      icon='add'
                      onClick={(e) => {
                        e.preventDefault();
                        addSymbol(e);
                      }}
                    >
                      {label.af_add_Symbol}
                    </button>
                  </div>
                </div>
                <div className='row'>
                  {defaultSelections?.map((selection) => {
                    return (
                      <div
                        sm={12}
                        md={6}
                        lg={4}
                        className='col mt-2 align-items-center w-auto d-flex'
                        key={selection.name}
                      >
                        <div className='p-2 rounded'>
                          <input
                            type='checkbox'
                            id={selection.name}
                            name={selection.name}
                            className='form-check-input'
                            data-testid={selection.dataTestId}
                            checked={isSymbolSelected(selection.name)}
                            onChange={(value) => selectDefaultSymbol(value)}
                          />
                        </div>
                        <div className='p-2 shadow rounded m-2'>
                          <label htmlFor={selection.name}>
                            {/* <selection.component size={100} /> */}
                            <span></span>
                          </label>
                        </div>
                      </div>
                    );
                  })}
                  {item.item_json?.rowList?.customSelection?.map(
                    (selection, index) => {
                      return (
                        <div
                          sm={12}
                          md={6}
                          lg={4}
                          className='col ms-1 mt-2 align-items-center w-auto d-flex'
                          key={index}
                        >
                          <div className='p-2 rounded'>
                            <button
                              className='icon'
                              onClick={(e) => {
                                e.preventDefault();
                                removeSymbol(selection.foilId);
                              }}
                              data-testid='option-remove-button'
                            >
                              <span className='icon-minus'>-</span>
                            </button>
                          </div>
                          <div className='p-2 shadow rounded m-2'>
                            <img
                              src={selection.imageURL}
                              alt={selection.name}
                              style={{ width: '100px', height: '100px' }}
                            />
                          </div>
                        </div>
                      );
                    }
                  )}
                </div>
              </fieldset>
            </div>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

ActingForces.propTypes = itemProps;

export default ActingForces;
