import React from 'react';
import { unmountComponentAtNode } from "react-dom";
import { Provider } from 'react-redux'
import createMockStore from 'redux-mock-store'
import thunk from 'redux-thunk';
import { screen } from '@testing-library/dom';
import { render, fireEvent } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import CodeSubmit from './CodeSubmit';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <CodeSubmit />, container);
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the 
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <CodeSubmit item={{
                    item_json: {
                        itemTypeCode: 'CSUB'
                    }
                }
                } />, container);
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=container]");
        expect(component).not.toBeNull;
        // expect(component.children.length).toBe(4);

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=container]")).not.toBeNull;
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=options-container]")).not.toBeNull;
        // expect(document.querySelector("[data-testid=mc-correct-response-container]")).not.toBeNull;
    });

    it('The User will be able to set Item dimensions for the item in item dimensions field', async () => {
        let item = {
            id: -1,
            name: '',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: '',
            item_json: {
                itemTypeCode: 'CSUB',
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <CodeSubmit item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull;
        expect(minItemHeightInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(<Provider store={store}>
                <CodeSubmit item={item} onUpdate={updateItem} />
            </Provider>);
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(<Provider store={store}>
                <CodeSubmit item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

    it.todo("The User will be able enter content in stem");

    it.todo("The User will be able to choose the code Language from Language drop-down field");

    it.todo("The User will be able to choose the Theme from Theme drop-down field");

    it.todo("The User will be able to check the response option radio buttons, depending upon click action on the radio button, the text area field and response grid will be enabled");

    it.todo("The User will be able to check the extended response radio button, select, rubric and no scoring needed options will add on scoring method in scoring accordion");

    it.todo("The User will be able to check the program compiles radio button, select, correct only and no scoring needed options will add on scoring method in scoring accordion");

    it.todo(" The User will be able to check the program produces output radio button, select, correct only and no scoring needed options will add on scoring method in scoring accordion");

    it.todo("The User will be able to  check the verify the program produces output radio button, the data grid will display below the radio button and select, correct only, partial credit, no scoring needed options will add on scoring method in scoring accordion");

    it.todo("User can check whether the content screen is responsive");
})