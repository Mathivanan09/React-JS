import React, { useLayoutEffect, useRef, useState } from "react";
import '../../../utility/mathRender';

/**
 * React functional component to create item based on itemTypeCode.
 * This is an entry point component to start a new item creation.
 * 
 * @component
 * @memberof SharedComponents
 * @inner
 * @namespace ProcessMath
 * 
 * @param {object} param.children Pass child content, 
 * @return {Component} - Render the math content.
 * 
 * @example
 * <ProcessMath>Wrap child content</ProcessMath>
 */
export default function ProcessMath({ children }) {
  const rootElementRef = useRef(null);

  // Store this in local state so we can make the component re-render when
  // it's updated.
  const [isReady, setIsReady] = useState(__MathJax_State__.isReady);

  useLayoutEffect(() => {
    // Avoid running this script if the MathJax library hasn't loaded yet.
    if (!isReady) {
      // But trigger a re-render of this component once it is loaded.
      __MathJax_State__.promise.then(() => setIsReady(true));
      return;
    }

    // This element won't be null at this point
    const rootEl = rootElementRef.current;
    // Reset equation numbers.
    MathJax.texReset();

    // Run MathJax typsetting on just this element
    // Potentially this could/should be switched to use the asynchronous version
    // of this MathJax function, `MathJax.typesetPromise()`.
    MathJax.typeset([rootEl]);
  });

  return (
    <div ref={rootElementRef}>
      {children}
    </div>
  );
}