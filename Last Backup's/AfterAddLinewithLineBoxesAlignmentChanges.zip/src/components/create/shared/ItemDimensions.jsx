import React from 'react';
import PropTypes from 'prop-types';
import label from '../../../constants/labelCodes';
import '../../../styles/item/ItemDimensions.css';

/**
 * React functional component to display the minimum
 * height and minimum width of an item
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace ItemDimensions
 *
 * @param {{minWidth: number, minHeight: number, onChange: function}} param
 * @param {numeric} param.minWidth - minimum width of the item that need to be set
 * @param {numeric} param.minHeight - minimum height of the item that need to be set
 * @return {ItemDimensions} - component with min width and min height input fields
 *
 * @example
 * <ItemDimensions
    minWidth={item?.item_json?.minItemWidth}
    minHeight={item?.item_json?.minItemHeight}
    onChange={(dimenstion) => {
      if (dimenstion?.minWidth !== item?.item_json?.minItemWidth) {
        updateItemJson('minItemWidth', dimenstion.minWidth);
      }
      if (dimenstion?.minHeight !== item.item_json.minItemHeight) {
        updateItemJson('minItemHeight', dimenstion.minHeight);
      }
    }}
  />
 */

const ItemDimensions = ({ minWidth, minHeight, onChange }) => (
  <div className='row' data-testid='item-dimensions-container'>
    <div className='col' />
    <div className='col col-12 col-md-6'>
      <fieldset className='bg-light p-3 rounded m-1 mx-0'>
        <div className="row row-cols-1 row-cols-sm-3">
          <div className='col ps-lg-1 ps-md-0'>
            <legend className='pt-1'>{label.item_dim}</legend>
          </div>
          <div className='col hstack gap-1 px-lg-1 px-md-0 py-md-1'>
            <label
              htmlFor='item-dim-min-width'
            >Width:</label>
            <input
              min={0}
              type='number'
              value={minWidth || 0}
              id='item-dim-min-width'
              data-testid='item-dim-min-width'
              className='form-control form-control-sm'
              onChange={(e) => {
                const val = e?.target?.value !== undefined ? parseInt(e.target.value) : 0;
                onChange({ minWidth: val, minHeight: minHeight });
              }}
            />
          </div>
          <div className='col hstack gap-1 pe-lg-1 pe-md-0'>
            <label
              htmlFor='item-dim-min-height'
            >Height:</label>
            <input
              min={0}
              type='number'
              value={minHeight || 0}
              id='item-dim-min-height'
              data-testid='item-dim-min-height'
              className='form-control form-control-sm'
              onChange={(e) => {
                const val = e?.target?.value !== undefined ? parseInt(e.target.value) : 0;
                onChange({ minWidth: minWidth, minHeight: val });
              }}
            />
          </div>
        </div>
      </fieldset>
    </div>
  </div>
);

ItemDimensions.propTypes = {
  minWidth: PropTypes.number,
  minHeight: PropTypes.number,
  onChange: PropTypes.func
};

export default ItemDimensions;
