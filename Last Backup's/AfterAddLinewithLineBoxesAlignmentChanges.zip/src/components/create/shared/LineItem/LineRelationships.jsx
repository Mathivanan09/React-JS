import React, { useState } from 'react';
/**
 * React functional component to create LineRelationships
 *
 * @memberof CreateComponents
 * @inner
 *
 * @component
 * @namespace LineRelationships
 *
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {Object} param.item JSON data that will contain the item information
 * for creating/updating StraightLine item
 * @param {Object} param.onUpdate Callback function to update item_son attributes
 * if there is any change in the state of the item
 * @param {Object} param.config Configuration object which contains
 * client passed in style code, program specific defaults
 * @return {LineRelationships} LineRelationships component for creating StraightLine item

 */
const LineRelationships = ({ item, onUpdate, config }) => {
  const [checkBoxValue, setCheckBoxValue] = useState()
  //Event handler for selecting radiobutton and updating the value

  const updateItemJson = (key, value) => {
    onUpdate({ item_json: { ...item.item_json, ...{ [key]: value } } });

  };

  const handleCheckBox = (e) => {
    setCheckBoxValue(e.target.value)
    const updatedItem = {
      item_json: { radioOnSelect: e.target.value }
    };
    onUpdate(updatedItem);
  }


  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <fieldset className={'bg-light rounded p-3 m-1'}>
              <h5 className="text-primary">LineRelationships</h5>
              <div className="row pt-2">
                <div className='col-1 pt-1 pb-1 text-right'>
                  <input
                    type={"radio"}
                    onChange={(e)=>handleCheckBox(e)}
                    value="Parallel"
                    checked={checkBoxValue === "Parallel"}
                    data-testid={'lr-parallel'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-left'>
                  <label>Parallel</label>
                </div>
                <div className='col-1 pt-1 pb-1 text-right'>
                  <input
                    type="radio"
                    onChange={(e)=>handleCheckBox(e)}
                    value="Perpendicular"
                    checked={checkBoxValue === "Perpendicular"}
                    data-testid={'lr-perpendicular'}
                  />
                </div>
                <div className='col-3 pt-1 pb-1 text-left'>
                  <label>Perpendicular</label>
                </div>
                <div className='col-1 pt-1 pb-1 text-right'>
                  <input
                    type="radio"
                    onChange={(e)=>handleCheckBox(e)}
                    value="Intersecting"
                    checked={checkBoxValue === "Intersecting"}
                    data-testid={'lr-intersecting'}
                  />
                </div>
                <div className='col-2 pt-1 pb-1 text-left'>
                  <label>Intersecting</label>
                </div>
              </div>
            </fieldset>
          </div>
        </div>
      </div>
    </>
  )
}
export default LineRelationships;
