import React from 'react';
import PropTypes from 'prop-types';

import defaultValue from '../../../utility/default';
import label from '../../../constants/labelCodes';

/**
 * React functional component to display the answer alignment dropdown
 * 
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace AnswerAlignment
 * 
 * @param {{item: Object, onUpdate: func, config: Object}} param passed in parameters
 * @param {string} param.data Drop down values to be rendered, overrides default values
 * @param {string} param.value Value that is selected and rendered as selected value
 * @param {function} param.onUpdate Callback function that trigger when a value is selected in dropdown
 * @param {string} param.updateKey Key in item JSON object that need to be updated with value
 * @param {boolean} param.showSelect Controls whether to show Select as an option in dropdown
 * @param {string} param.dataItemKey Key value of the object treated as value while saving
 * @param {string} param.textField Text value of the object treated as label in dropdown
 * @param {string} param.labelCode Label code to look up and render the label of this component
 * @param {boolean} param.isRequired Parameter to control if the value is required or not
 * @param {string} param.dataTestId - optional, test id to the answer alignment for testing purpose
 * @param {string} param.firstColumnClass - optional has default column styles, 
 * can be modify the styles of the label column, based on the conatainer that needs to be displayed with different resolutions
 * @param {string} param.secondColumnClass - optional has default column styles, 
 * can be modify the styles of the drop down column, based on the conatainer that needs to be displayed with different resolutions
 * @return {AnswerAlignment} AnswerAlignment component with answer alignment dropdown
 * 
 * @example
 * <AnswerAlignment
      labelCode='answer_alignment'
      onUpdate={updateItemJson}
      updateKey='answerAlignment'
      isRequired={true}
      showSelect={true}
      value={item.item_json?.answerAlignment}
  ></AnswerAlignment>
 */
const AnswerAlignment = ({
  data,
  value,
  onUpdate,
  updateKey,
  showSelect,
  dataItemKey,
  textField,
  labelCode,
  isRequired,
  dataTestId,
  firstColumnClass = "col-6 col-lg-6 col-sm-12 text-right end-xs text-sm-start text-md-start text-lg-end",
  secondColumnClass = "col"
}) => {
  // Initialize component based on parameters passed
  let defaultValues = [
    { id: 'stacked_z', name: 'Stacked Z' },
    { id: 'right_z', name: 'Right Side Z' },
    { id: 'right_vertical_stacked', name: 'Right Side Vertical' },
    { id: 'vertical_stacked', name: 'Stacked Vertical' },
    { id: 'horizontal', name: 'Stacked Horizontal' }
  ];

  if (data && data.length > 0) {
    defaultValues = data;
  }

  // Add Select if showSelect is true
  if (showSelect) {
    defaultValues = [{ id: null, code: null, name: 'Select' }, ...defaultValues];
  }

  return (
    <div className='row align-items-center p-1'>
      <div
        className={firstColumnClass}
        data-testid={dataTestId ? dataTestId + '-label' : 'aa-required'}
      >
        <label htmlFor={labelCode}>
          {label[labelCode || '']}:
          {isRequired &&
            <i className="required-field text-danger ms-1">*</i>
          }
        </label>
      </div>
      <div className={secondColumnClass}>
        <select
          required={isRequired}
          id={labelCode}
          className='form-select form-select-sm mx-0'
          aria-label='form-select-columns-number'
          value={
            value !== undefined
              ? value
              : defaultValue(labelCode)
          }
          onChange={(e) => {
            let val = e.target.value;
            onUpdate(updateKey, val);
          }}
          data-testid={dataTestId || 'aa-select'}
        >
          {defaultValues.map((value, index) => (
            <option
              key={value[dataItemKey || 'id'] || index}
              value={value[dataItemKey || 'id'] || ''}
            >
              {value[textField || 'name']}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

AnswerAlignment.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  value: PropTypes.string,
  onUpdate: PropTypes.func,
  updateKey: PropTypes.string,
  showSelect: PropTypes.bool,
  dataItemKey: PropTypes.string,
  textField: PropTypes.string,
  labelCode: PropTypes.string,
  isRequired: PropTypes.bool,
  dataTestId: PropTypes.string,
  firstColumnClass: PropTypes.string,
  secondColumnClass: PropTypes.string
};

export default AnswerAlignment;
