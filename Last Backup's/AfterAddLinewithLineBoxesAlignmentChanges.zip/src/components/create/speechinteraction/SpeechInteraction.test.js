import React from 'react';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux'
import { act } from "react-dom/test-utils";
import createMockStore from 'redux-mock-store'
import { unmountComponentAtNode } from "react-dom";
import { render, fireEvent } from '@testing-library/react';
// importing Speech Interaction component here
import SpeechInteraction from './SpeechInteraction';

const mockStore = createMockStore([thunk]);

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('Speech Interaction Item', () => {

    /**
    * Test an empty component and verify the element with Missing item data
    */
    it("Should render base component", () => {
        act(() => {
            render(
                <SpeechInteraction />, container
            );
        });

        const emptyComponent = document.querySelector("[data-testid=missing-item]");
        expect(emptyComponent).not.toBeNull;
        expect(emptyComponent.textContent).toBe('Missing item data');
    });

    /**
     * Test component by passing skeleton item json and verify the 
     * elements and values when opened from new  item
     */
    it("Test skeleton component when opened from new item", () => {
        act(() => {
            render(
                <SpeechInteraction item={{
                    item_json: {
                        itemTypeCode: 'SI'
                    }
                }
                } />, container
            );
        });

        /**
         * Verify that there 3 main containers item dimensions, stem content and options
         */
        const component = document.querySelector("[data-testid=container]");
        expect(component).not.toBeNull;

        // Verify that the 4 containers exists
        expect(document.querySelector("[data-testid=container]")).not.toBeNull;
        expect(document.querySelector("[data-testid=id-container]")).not.toBeNull;
    });

    it('The User will be able to set Item dimensions for the item in item dimensions field', async () => {
        let item = {
            id: -1,
            name: 'Speech_Interaction_demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'SI',
            item_json: {
                itemTypeCode: 'SI',
                minItemWidth: 400, minItemHeight: 400
            },
            user_id: 0
        };

        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });

        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SpeechInteraction item={item} onUpdate={updateItem} />
            </Provider>
        );
        expect(item.item_json.minItemWidth).toBe(400);
        expect(item.item_json.minItemHeight).toBe(400);

        let minItemWidthInput = document.querySelector('[data-testid=item-dim-min-width]');
        let minItemHeightInput = document.querySelector('[data-testid=item-dim-min-height]');

        // Verify that the inputs exists
        expect(minItemWidthInput).not.toBeNull;
        expect(minItemHeightInput).not.toBeNull;

        // Update inputs with value and verify store update
        fireEvent.change(minItemWidthInput, { target: { value: 555 } });
        act(() => {
            rerender(
                <Provider store={store}>
                    <SpeechInteraction item={item} onUpdate={updateItem} />
                </Provider>
            );
        });

        fireEvent.change(minItemHeightInput, { target: { value: 666 } });

        act(() => {
            rerender(
                <Provider store={store}>
                    <SpeechInteraction item={item} onUpdate={updateItem} />
                </Provider>
            );
        });
        expect(item.item_json.minItemWidth).toBe(555);
        expect(item.item_json.minItemHeight).toBe(666);
    });

    /**
    * Identify the data for Attempts Allowed
    */
    it("Identify the data for Attempts Allowed", () => {
        act(() => {
            render(
                <SpeechInteraction
                    item={{
                        item_json: {
                            itemTypeCode: 'SI'
                        }
                    }
                    }
                />, container
            );
        });

        const attemptsAllowed = document.querySelector("[dataTestId=si_attemptsAllowed_number]");
        expect(attemptsAllowed).not.toBeNull;
    });

    /**
    * Identify the data for Seconds Allowed Per Attempt
    */
    it("Identify the data for Seconds Allowed Per Attempt", () => {
        act(() => {
            render(
                <SpeechInteraction
                    item={{
                        item_json: {
                            itemTypeCode: 'SI'
                        }
                    }
                    }
                />, container
            );
        });

        const secondsAllowed = document.querySelector("[dataTestId=si_secondsAllowed_number]");
        expect(secondsAllowed).not.toBeNull;
    });

    /**
   * Identify the data for Response Alignment
   */
    it("Identify the data for Response Alignment", () => {
        act(() => {
            render(
                <SpeechInteraction
                    item={{
                        item_json: {
                            itemTypeCode: 'SI'
                        }
                    }
                    }
                />, container
            );
        });

        const responseAlignment = document.querySelector("[dataTestId=si_response_alignment]");
        expect(responseAlignment).not.toBeNull;
    });

    /**
    * Identify the data for Retain All Attempts
    */
    it("Identify the data for Retain All Attempts", () => {
        act(() => {
            render(
                <SpeechInteraction
                    item={{
                        item_json: {
                            itemTypeCode: 'SI'
                        }
                    }
                    }
                />, container
            );
        });

        const retainAttempts = document.querySelector("[dataTestId=si_checkbox]");
        expect(retainAttempts).not.toBeNull;
    });

    /**
   * Identify the data for rationale-button
   */
    it("Identify the data for rationale-button", () => {
        act(() => {
            render(
                <SpeechInteraction
                    item={{
                        item_json: {
                            itemTypeCode: 'SI'
                        }
                    }
                    }
                />, container
            );
        });

        const rationaleButton = document.querySelector("[dataTestId=rationale-button]");
        expect(rationaleButton).not.toBeNull;
    });

    it('The user will be restricted from recording multiple times based on the value given in Attempts Allowed field', async () => {
        let item = {
            id: -1,
            name: 'Speech_Interaction_demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'SI',
            item_json: {
                itemTypeCode: 'SI',
                maxNumberofAttempts: 1
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });
        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SpeechInteraction item={item} onUpdate={updateItem} />
            </Provider>
        );

        expect(item.item_json.maxNumberofAttempts).toBe(1);

        let maxNumberofAttemptsInput = document.querySelector('[data-testid=si_attemptsAllowed_number]');

        expect(maxNumberofAttemptsInput).not.toBeNull;

        fireEvent.change(maxNumberofAttemptsInput, { target: { value: 5 } });

        act(() => {
            rerender(
                <Provider store={store}>
                    <SpeechInteraction item={item} onUpdate={updateItem} />
                </Provider>
            );
        });
        expect(item.item_json.maxNumberofAttempts).toBe("5");
    });

    it('The user Can use the Seconds allowed Per Attempts field Only when the User Having the Attempts Allowed Count atleast One (Or) More', async () => {
        let item = {
            id: -1,
            name: 'Speech_Interaction_demo',
            assessment_program_id: 0,
            item_type_id: 0,
            item_type_code: 'SI',
            item_json: {
                itemTypeCode: 'SI',
                maxTimeAllowedForEachAttempt: 1
            },
            user_id: 0
        };
        const updateItem = jest.fn().mockImplementation((payload) => {
            item = {
                ...item,
                ...payload,
                item_json: { ...item.item_json, ...payload.item_json }
            };
        });
        const store = mockStore({});
        const { rerender } = render(
            <Provider store={store}>
                <SpeechInteraction item={item} onUpdate={updateItem} />
            </Provider>
        );

        expect(item.item_json.maxTimeAllowedForEachAttempt).toBe(1);

        let maxTimeAllowedForEachAttemptInput = document.querySelector('[data-testid=si_secondsAllowed_number]');

        expect(maxTimeAllowedForEachAttemptInput).not.toBeNull;

        fireEvent.change(maxTimeAllowedForEachAttemptInput, { target: { value: 30 } });

        act(() => {
            rerender(<Provider store={store}>
                <SpeechInteraction item={item} onUpdate={updateItem} />
            </Provider>);
        });
        expect(item.item_json.maxTimeAllowedForEachAttempt).toBe("30");

    });

});
