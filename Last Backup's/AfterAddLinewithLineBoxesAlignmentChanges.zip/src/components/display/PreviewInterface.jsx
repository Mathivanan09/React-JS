import React, { Component, useState } from 'react';
import PropTypes from 'prop-types';
import DisplayInterface from './DisplayInterface';
import PreviewOptions from './item/shared/PreviewOptions';
import '../../styles/common/ui-styles.css';

/**
 * React functional component to display the preview of the items
 * 
 * @component
 * @memberof Interfaces
 * @inner
 * @namespace PreviewInterface
 * 
 * @param {{item: object, onUpdate: function, config: object}} param passed in parameters
 * @param {object} param.item Data that will contain the item information for displaying items
 * @param {function} onUpdate Callback function that need to be called if there is any change
 *  in the state of the item
 * @return {Component} Preview display component based on the itemTypeCode in item JSON
 *
 * @example
 * <PreviewInterface {...args} config={config} />
 */

const PreviewInterface = ({ item, onUpdate = () => {}, config, api}) => {
  const [displayCorrectResponse, setDisplayCorrectResponse] = useState(false);
  if (!item?.item_json) {
    // NOTE: show warning that says to select item type
    return '';
  }
  const { minItemWidth, minItemHeight } = item?.item_json;
  
  const onSelect = () => {
    setDisplayCorrectResponse(!displayCorrectResponse)
  }

  return (
    <>
      <div className='row preview-options-body p-2' data-testid={'preview-container'}>
        <div className='col'>
          <PreviewOptions itemType={item?.item_type_code} itemTypeCategory={item?.item_type_category_code} onSelect={onSelect}/>
        </div>
      </div>
      <div className='row content-body pt-3' style={{
        minWidth: `${minItemWidth+20}px`,
        minHeight: `${minItemHeight+20}px`
      }}>
        <div
          className={
            config?.styleCode === 'alternate' ? 'col alt-content' : 'col gen-content'
          }
        >
          <DisplayInterface item={item} onUpdate={onUpdate} config={config} showCorrectResponse={displayCorrectResponse} api={api}/>
        </div>
      </div>
    </>
  );
};

PreviewInterface.propTypes = {
  item: PropTypes.any,
  onUpdate: PropTypes.func,
  config: PropTypes.any
};

export default PreviewInterface;
