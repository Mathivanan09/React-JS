import React from 'react';
import PropTypes from 'prop-types';
import applyStyles from '../../utility/applyStyles';
import ProcessMath from '../create/shared/MathJaxRender';

import ActingForcesPreview from './item/actingforces/ActingForcesPreview';
import BackgroundGraphicPreview from './item/backgroundgraphic/BackgroundGraphicPreview';
import BiologySimulationPreview from './item/biologysimulation/BiologySimulationPreview';
import ChemistrySimulationPreview from './item/chemistrysimulation/ChemistrySimulationPreview';
import CodeCompilerPreview from './item/codecompiler/CodeCompilerPreview';
import CodeSubmitPreview from './item/codesubmit/CodeSubmitPreview';
import CompositeItemsPreview from './item/composite/CompositeItemsPreview';
import ConstructedResponsePreview from './item/constructedresonse/ConstructedResponsePreview';
import DropDownPreview from './item/dropdown/DropDownPreview';
import EmbeddedPreview from './item/embedded/EmbeddedPreview';
import ExtendedResponsePreview from './item/extendedresponse/ExtendedResponsePreview';
import FirewallPreview from './item/firewall/FirewallPreview';
import GearsPreview from './item/gears/GearsPreview';
import GraphicOrderPreview from './item/graphicorder/GraphicOrderPreview';
import GraphingSimPreview from './item/graphingsimulation/GraphingSimPreview';
import HotSpotPreview from './item/hotspot/HotSpotPreview';
import LabelingPreview from './item/labeling/LabelingPreview';
import LikertScalePreview from './item/likertscale/LikertScalePreview';
import LineGraphPreview from './item/linegraph/LineGraphPreview';
import MatchingLinesPreview from './item/matchinglines/MatchingLinesPreview';
import MatrixInteractionPreview from './item/matrixinteraction/MatrixInteractionPreview';
import MazeRunnerPreview from './item/mazerunner/MazeRunnerPreview';
import MultiDropBucketPreview from './item/multidropbucket/MultiDropBucketPreview';
import MultipleChoicePreview from './item/multiplechoice/MultipleChoicePreview';
import MultipleTabsPreview from './item/multipletabs/MultipleTabsPreview';
import NumberConverterPreview from './item/numberconverter/NumberConverterPreview';
import ObjectCanvasPreview from './item/objectcanvas/ObjectCanvasPreview';
import OrderingPreview from './item/ordering/OrderingPreview';
import OscillatingGraphPreview from './item/oscillatinggraph/OscillatingGraphPreview';
import PlacingPointsPreview from './item/placingpoints/PlacingPointsPreview';
import PunnettSquarePreview from './item/punnettsquare/PunnettSquarePreview';
import SampleReactionPreview from './item/samplereaction/SampleReactionPreview';
import ScatterPlotPreview from './item/scatterplot/ScatterPlotPreview';
import SelectTextPreview from './item/selecttext/SelectTextPreview';
import SingleLinePreview from './item/singleline/SingleLinePreview';
import SpeechInteractionPreview from './item/speechinteraction/SpeechInteractionPreview';
import StraightLinePreview from './item/straightline/StraightLinePreview';
import TableVideoPreview from './item/tablevideo/TableVideoPreview';
import TextStimulusPreview from './item/textstimulus/TextStimulusPreview';
import TwoColumnClickPreview from './item/twocolumnclick/TwoColumnClickPreview';
import VennDiagramPreview from './item/venndiagram/VennDiagramPreview';

/**
 * React functional component to display item based on itemTypeCode.
 * This is an entry point component to render the item's preview.
 * 
 * @component
 * @memberof Interfaces
 * @inner
 * @namespace DisplayInterface
 * 
 * @param {{item: object, onUpdate: function, config: object, clickHistory: function}} param passed in parameters
 * @param {object} param.item Data that will contain the item information for displaying items
 * @param {function} param.onUpdate Callback function that need to be called if there is any change
 *  in the state of the item
 * @param {function} param.clickHistory TODO
 * @return {Component} - Item display component based on the itemTypeCode in item JSON
 *
 * @example
 * <DisplayInterface item={item} onUpdate={onUpdate} config={config} />
 */

const DisplayInterface = ({ item, onUpdate, config, showCorrectResponse, clickHistory = {}, onClickHistoryUpdate, api}) => {
  // can't show an item if we don't know the type
  const typeCode = item?.item_json?.itemTypeCode?.toLowerCase();

  if (!item || !typeCode) {
    // NOTE: show warning that says to select item type
    return '';
  }

  const { minItemWidth, minItemHeight } = item?.item_json;

  // For storing clickhistory
  if (config?.clickHistoryRequired) {
    clickHistory.id = item?.id;
    clickHistory.itemTypeCategory = item?.itemTypeCategory;
    clickHistory.itemType = item?.item_json?.itemTypeCode
  }

  // Create props payload to pass to module
  const payload = {
    item,
    onUpdate,
    config,
    showCorrectResponse,
    clickHistory,
    onClickHistoryUpdate,
    api
  };

  // Applying required styles based on style code
  // if style code is not passed default style will be applied
  applyStyles(config?.styleCode);

  const componentManifest = Object.freeze({
    af: <ActingForcesPreview  {...payload} />,
    bg: <BackgroundGraphicPreview  {...payload} />,
    bs: <BiologySimulationPreview  {...payload} />,
    chm: <ChemistrySimulationPreview  {...payload} />,
    ccom: <CodeCompilerPreview  {...payload} />,
    csub: <CodeSubmitPreview  {...payload} />,
    com: <CompositeItemsPreview  {...payload} />,
    cr: <ConstructedResponsePreview  {...payload} />,
    dd: <DropDownPreview  {...payload} />,
    embedded: <EmbeddedPreview  {...payload} />,
    er: <ExtendedResponsePreview  {...payload} />,
    firewall: <FirewallPreview  {...payload} />,
    gr: <GearsPreview  {...payload} />,
    'g-ord': <GraphicOrderPreview  {...payload} />,
    'g-sim': <GraphingSimPreview  {...payload} />,
    htsp: <HotSpotPreview  {...payload} />,
    lbng: <LabelingPreview  {...payload} />,
    ls: <LikertScalePreview  {...payload} />,
    lg: <LineGraphPreview  {...payload} />,
    ml: <MatchingLinesPreview  {...payload} />,
    mcrb: <MatrixInteractionPreview  {...payload} />,
    mr: <MazeRunnerPreview  {...payload} />,
    mdb: <MultiDropBucketPreview  {...payload} />,
    mc: <MultipleChoicePreview  {...payload} />,
    mts: <MultipleTabsPreview  {...payload} />,
    nc: <NumberConverterPreview  {...payload} />,
    ocs: <ObjectCanvasPreview  {...payload} />,
    ord: <OrderingPreview  {...payload} />,
    og: <OscillatingGraphPreview  {...payload} />,
    pp: <PlacingPointsPreview  {...payload} />,
    ps: <PunnettSquarePreview  {...payload} />,
    sr: <SampleReactionPreview  {...payload} />,
    sp: <ScatterPlotPreview  {...payload} />,
    st: <SelectTextPreview  {...payload} />,
    s1l: <SingleLinePreview  {...payload} />,
    si: <SpeechInteractionPreview  {...payload} />,
    sl: <StraightLinePreview  {...payload} />,
    tvs: <TableVideoPreview  {...payload} />,
    ts: <TextStimulusPreview  {...payload} />,
    tcc: <TwoColumnClickPreview  {...payload} />,
    vd: <VennDiagramPreview  {...payload} />
  });

  const selectedComponent = componentManifest[typeCode];

  if (!selectedComponent) {
    return <div data-testid={'not-implemented'}>{typeCode} Not implemented</div>;
  }

  return (
    <div
      className='item-display-container content_style'
      style={{
        minWidth: `${minItemWidth}px`,
        minHeight: `${minItemHeight}px`
      }}
    >
      <ProcessMath>{selectedComponent}</ProcessMath>
    </div>
  );
};

DisplayInterface.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  clickHistory: PropTypes.object,
  onClickHistoryUpdate: PropTypes.func
};

export default DisplayInterface;
