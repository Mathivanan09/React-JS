import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
  DndContext,
  DragOverlay,
  useDraggable,
  CollisionDetection,
  Modifiers,
  useSensor,
  MouseSensor,
  TouchSensor,
  KeyboardSensor,
  useSensors
} from '@dnd-kit/core';
import parse from 'html-react-parser';
import DroppableContainer from '../../../common/dnd/DroppableContainer';
import DraggableItem from '../../../common/dnd/DraggableItem';
import Draggable from '../../../common/dnd/Draggable';
import Droppable from '../../../common/dnd/Droppable';
import Wrapper from '../../../common/dnd/Wrapper';

const BgGraphicResponse = ({
  item,
  onDropResponse,
  activationConstraint,
  showCorrectResponse,
  onUpdate,
  isPreview,
}) => {
  const { correctResponse, optionList, matchList } = JSON.parse(JSON.stringify({ ...item.item_json }));
  const [isDragging, setIsDragging] = useState(false);

  const [previewResponse, setPreviewResponse] = useState(correctResponse.map(response => ({
    id: response.id,
    values: [],
  })));

  // Dropzone dragger associations; each dropzone has only one dragger
  const responses = isPreview && !showCorrectResponse ? [ ...previewResponse ] : [ ...correctResponse ];
  const dropzoneRels = Object.fromEntries(
    responses.map(response => (
      response.values.map((dropzoneId, index) => (
        [dropzoneId, `${response.id}--${index}`]
      ))
    )).flat()
  );

  const mouseSensor = useSensor(MouseSensor, {
    activationConstraint
  });
  const touchSensor = useSensor(TouchSensor, {
    activationConstraint
  });
  const keyboardSensor = useSensor(KeyboardSensor, {});
  const sensors = useSensors(mouseSensor, touchSensor, keyboardSensor);

  const onDragEndDropped = (active, over) => {
    // Extract the option ID by cutting off the dragger index
    const optionId = active.id.split('--')[0];
    const activeResponse = responses.find(response => (
      response.id === optionId
    ));

    /*
     * 1. Check if there's something already in the dropzone
     * 2. If not, just create the new correct association
     * 3. Otherwise remove the correct association between the existing dragger
     * and the dropzone as well as creating the new association
     */
    const occupyingResponse = responses.find(response => (
      response.values.includes(over.id)
    ));

    // If there's something already in the dropzone
    if (occupyingResponse) {
      occupyingResponse.values = occupyingResponse.values.filter(dropzoneId => (
        dropzoneId !== over.id
      ));
    }

    // Create the new correctResponse association
    activeResponse.values.push(over.id);

    // Check if this draggable was in a dropzone before
    const prevDropzoneId = Object.entries(dropzoneRels).find(relPair => (
      relPair[1] === active.id
    ))?.[0];

    if (prevDropzoneId) {
      activeResponse.values = activeResponse.values.filter(dropzoneId => (
        dropzoneId !== prevDropzoneId
      ));
    }

    if (isPreview && !showCorrectResponse) {
      setPreviewResponse(responses);
    } else {
      onUpdate({
        item_json: {
          correctResponse: responses
        }
      });
    }
  };

  const onDragEndRemoved = active => {
    // Extract the option ID by cutting off the dragger index
    const optionId = active.id.split('--')[0];
    const activeResponse = responses.find(response => (
      response.id === optionId
    ));

    // Get the ID of the dropzone we were removed from
    const prevDropzoneId = Object.entries(dropzoneRels).find(relPair => (
      relPair[1] === active.id
    ))?.[0];

    if (prevDropzoneId) { // If we were removed from a dropzone; need to update correctResponse
      activeResponse.values = activeResponse.values.filter(dropzoneId => (
        dropzoneId !== prevDropzoneId
      ));
    }

    if (isPreview && !showCorrectResponse) {
      setPreviewResponse(responses);
    } else {
      onUpdate({
        item_json: {
          correctResponse: responses
        }
      });
    }
  };

  return (
    <div>
      <DndContext
        sensors={sensors}
        onDragStart={(dragItem) => {
          setIsDragging(true);
        }}
        onDragEnd={({ over, active }) => {
          setIsDragging(false);
          if (over) {
            onDragEndDropped(active, over);
          } else {
            onDragEndRemoved(active);
          }
        }}
        onDragCancel={() => setIsDragging(false)}
      >
        {item?.item_json?.optionList && (
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <Wrapper>
              {item?.item_json?.optionList?.map((itm) => {
                const currentDraggerIndex = responses?.find(
                  (response) => response.id === itm.id
                )?.values?.length;
                if (!item.item_json.reusableAnswers) {
                  return responses?.find((response) => response.id === itm.id)
                    ?.values?.length > 0 ? null : (
                    <DraggableItem
                      id={`${itm.id}--${currentDraggerIndex}`}
                      label={itm.optionText}
                      style={{
                        position: 'relative',
                        margin: '10px',
                        height: item.item_json.dropzoneHeight || 50,
                        width: item.item_json.dropzoneWidth || 150
                      }}
                      disabled={isPreview && showCorrectResponse}
                    />
                  );
                } else {
                  return (
                    <DraggableItem
                      id={`${itm.id}--${currentDraggerIndex}`}
                      label={itm.optionText}
                      style={{
                        position: 'relative',
                        margin: '10px',
                        height: item.item_json.dropzoneHeight || 50,
                        width: item.item_json.dropzoneWidth || 150,
                        background:'white'
                      }}
                      disabled={isPreview && showCorrectResponse}
                    />
                  );
                }
              })}
            </Wrapper>
          </div>
        )}

        <div className='row item-content m-1 mt-4 p-4 content_style'>
          <div className='bg-image-zone'>
            <div
              id='imagePanel'
              className={
                item.item_json.imageAlignment === 'Center'
                  ? 'image-panel-center'
                  : 'image-panel-left'
              }
              style={{
                position: 'relative',
                float: item.item_json.imageAlignment
              }}
            >
              <img
                id='imgDiv'
                className='bg-image-size'
                src={item?.item_json?.imagePanel || ''}
                alt=''
              />
              <div
                id='planetmap'
                className='image-drop-box'
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0
                }}
              >
                <Wrapper>
                  {item?.item_json?.matchList?.map((cnt) => (
                    <Droppable
                      key={cnt.id}
                      id={cnt.id}
                      dragging={isDragging}
                      // imagePosition={imagePosition('imgDiv')}
                      coordinates={cnt.coordinates}
                      dropzoneHeight={item.item_json.dropzoneHeight || 50}
                      dropzoneWidth={item.item_json.dropzoneWidth || 150}
                      invisible={item.item_json.invisibleDropzones}
                    >
                      {dropzoneRels[cnt.id] ? (
                        <DraggableItem
                          id={dropzoneRels[cnt.id]}
                          label={
                            optionList.find(
                              (option) =>
                                // Extract the option ID by cutting off the dragger index
                                option.id ===
                                dropzoneRels[cnt.id].split('--')[0]
                            ).optionText
                          }
                          disabled={isPreview && showCorrectResponse}
                          style={{
                            height: item.item_json.dropzoneHeight || 50,
                            width: item.item_json.dropzoneWidth || 150,
                            background:'white'
                          }}
                        />
                      ) : null}
                    </Droppable>
                  ))}
                </Wrapper>
              </div>
            </div>
          </div>
        </div>
      </DndContext>
    </div>
  );
};

BgGraphicResponse.propTypes = {};

export default BgGraphicResponse;
