import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import parse from "html-react-parser";
import DOMPurify from "dompurify";

const TABLE = 'table';
const MEDIA = 'mediacontent';
const NUMERIC = "Numeric";
const UL = "ul";
const OL = "ol";
const BLOCK = "blockquote";

/**
 *  React functional component for Rendering constructed response, and to use it in create interface
 *  providing provision for item creators to add correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace DropDownResponse
 *
 * @function DropDownResponse - React functional component to display constructed response item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying constructed response item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - MultipleChoicePreview component for displaying constructed response item
 */

const DropDownResponse = ({
    item,
    onUpdate,
    config,
    showCorrectResponse,
    isPreview
}) => {
    const itemJson = item?.item_json || {};
    //Creates Option list based on number of responses.
    const createOptionListMap = (optionList, correctResponse) => {
        const optionListMap = {};

        if (optionList) {
            optionList.forEach(
                ({ id, optionTags, defaultValue }, i) => {
                    if (id) {
                        optionListMap[id] = getDropdown(
                            id,
                            [[defaultValue], ...optionTags],
                            defaultValue,
                            optionList,
                            correctResponse[i]?.value
                        );
                    } else if (optionList[0].defaultValue) {
                        optionListMap[id] = getDropdown(
                            id,
                            [[defaultValue], ...optionTags],
                            defaultValue,
                            optionList,
                            correctResponse[i]?.value
                        );
                    }
                }
            );
        }
        return optionListMap;
    };


    //To fetch drop-down values based on drop-down options
    const getDropdown = (id, options, defaultVal, optionList, correctResponse) => {
        const dropDown = (
            <select
                onChange={onUpdate}
                disabled={showCorrectResponse ? true : false}
                key={"input-key-" + id}
                style={{textAlign:"center"}}
            >
                {options &&
                    options.map((value, i) => (
                        <option defaultValue={value === defaultVal} value={value} key={"input-option-key-" + i} selected={value === defaultVal}>
                            {showCorrectResponse ? correctResponse : value}
                        </option>
                    ))}
            </select>
        );
        return dropDown;
    };

    const applyDropDown = (newStemContent, optionListMap) => {
        return newStemContent.map((item) => {
            if (item?.props?.className?.split(' ')?.indexOf(MEDIA) !== 0 && item?.type === TABLE) {
                item.props !== undefined &&
                    Array.isArray(item.props.children) &&
                    item.props.children.forEach((tableData, i) => {
                        if (tableData.props !== undefined && (tableData.props.children[i] !== undefined ? tableData.props.children[i].props !== undefined : true)) {
                            Array.isArray(item.props.children[i].props.children) &&
                                item.props.children[i].props.children.forEach((rowData, j) => {
                                    if (rowData.props !== undefined && rowData.props.children !== undefined) {
                                        Array.isArray(rowData.props.children) &&
                                            rowData.props.children.forEach((columnData, k) => {
                                                if (columnData.props !== undefined && columnData.props.children !== undefined) {
                                                    let groupCellData = columnData.props.children
                                                    if (Array.isArray(groupCellData)) {
                                                        groupCellData.forEach((cellData, l) => {
                                                            if (cellData?.props && item.props.children[i].props.type !== 'caption' &&
                                                                item.props.children[i].props.children[j].props.children[k].props.children[l]) {
                                                                let id = cellData?.props.id;
                                                                if (id && optionListMap[id]) {
                                                                    item.props.children[i].props.children[j].props.children[k].props.children[l] = optionListMap[id];
                                                                }
                                                            }
                                                        })
                                                    }
                                                }
                                            })
                                        if (!(Array.isArray(rowData.props.children))) {
                                            let id = rowData?.props.id;
                                            if (id && optionListMap[id]) {
                                                item.props.children[i].props.children[j] = optionListMap[id];
                                            }
                                        }
                                    }
                                })
                        }
                    })
            }
            if (item?.props?.className?.split(' ')?.indexOf(MEDIA) !== 0 && item?.type !== TABLE) {
                item.props !== undefined &&
                    Array.isArray(item.props.children) &&
                    item.props.children.forEach((optionData, i) => {
                        if (optionData.props !== undefined && item?.type !== UL && item?.type !== OL && item?.type !== BLOCK) {
                            let id = item.props.children[i].props.id;
                            if (id && optionListMap[id]) {
                                item.props.children[i] = optionListMap[id];
                            }
                        }
                        else {
                            if (item?.type === UL || item?.type === OL || item?.type === BLOCK) {
                                if (item.props.children[i]?.props?.children) {
                                    if (optionData.props !== undefined) {
                                        if (Array.isArray(item.props.children[i].props.children)) {
                                            item.props.children[i].props.children.forEach((optionData2, j) => {
                                                if (optionData2.props !== undefined) {
                                                    let id = item.props.children[i]?.props?.children[j]?.props?.id;
                                                    if (id && optionListMap[id]) {
                                                        item.props.children[i].props.children[j] = optionListMap[id];
                                                    }
                                                }
                                            })
                                        }
                                    }
                                }
                            }
                        }
                    })
            }
            if (typeof item === Object && item?.type === "p" && item?.props?.id && optionListMap[item?.props?.id]) {
                item = optionListMap[item?.props?.id];
            }
            if (Array.isArray(item) && item?.length > 0) {
                item = applyDropDown(item, optionListMap);
            }
            return item;
        });
    }
    //To get stem content with selected response
    const getStemContent = (stemContent, optionListMap) => {
        let newStemContent = null;
        if (stemContent) {
            stemContent = stemContent.replaceAll(/<table/g, "<table style='border: 1px solid black; border-collapse: collapse;'");
            stemContent = stemContent.replaceAll(/<td/g, "<td style='border: 1px solid black; border-collapse: collapse;'");
            let lastOption = "</span></p>"
            let lastOptionIndex = stemContent.lastIndexOf(lastOption)
            if (lastOptionIndex > -1 && stemContent.length === lastOptionIndex + lastOption.length) {
                stemContent = stemContent.substring(0, lastOptionIndex) + "</span>&nbsp;</p>"
            }
            newStemContent = parse(DOMPurify.sanitize(stemContent, { USE_PROFILES: { html: true }, }));
            newStemContent = [[], newStemContent];
            newStemContent = applyDropDown(newStemContent, optionListMap);
        }
        return newStemContent;
    };

    // To Display the correct response value
    const displayStemContent = (contentData) => {
        const data = contentData;
        const optionListMap = createOptionListMap(data.optionList, data.correctResponse);
        return (
            <div data-testid="correctresponse-container">
                {getStemContent(itemJson.stemContent, optionListMap)}
            </div>
        );
    };

    return (
        <div className={
            config?.styleCode == 'alternate'
                ? 'cr-item-response-alternateui'
                : 'cr-item-response-generalui'
        }>{displayStemContent(itemJson)}</div>
    );
};

DropDownResponse.propTypes = {
    item: PropTypes.object,
    onUpdate: PropTypes.func,
    config: PropTypes.object,
    showCorrectResponse: PropTypes.bool
};

export default DropDownResponse;
