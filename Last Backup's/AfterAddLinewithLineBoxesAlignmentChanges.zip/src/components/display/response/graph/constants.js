/**
 * @file Chart Items Constants
 * @author Mahalingam
 */

const PLACING_POINTS = "PP";
const STRAIGHT_LINE="SL";
const BOTTOM_LEFT = [-10, -10];
const UPPER_RIGHT = [10, 10];
const SINGLE_LINE = "S1L";
const ALTTEXT = "Background of the Graph";
const COLORCODE1 = ['#fff', 'forestgreen', 'forestgreen', '#fff'];
const COLORCODE2 = ['forestgreen', 'forestgreen'];
const COLORCODE3 = "forestgreen";
const RADIUS1 = [5, 8, 8, 5];
const RADIUS2 = [8, 8];
const RADIUS3 = 8;
export {
    PLACING_POINTS,
    STRAIGHT_LINE,
    BOTTOM_LEFT,
    UPPER_RIGHT,
    SINGLE_LINE,
    ALTTEXT,
    COLORCODE1,
    COLORCODE2,
    COLORCODE3,
    RADIUS1,
    RADIUS2,
    RADIUS3
}
