import React from 'react';
import PropTypes from 'prop-types';
import StemFormatter from '../../item/shared/StemFormatter';
import SelectTextRenderSwitch from './SelectTextRenderSwitch';
import { ST_RED, ST_BLACK, ST_YELLOW } from "./constants";

import '../../../../styles/item/SelectTextPreview.css';

/**
 *  React functional component for Rendering select text response, and to use it in create interface
 *  providing provision for item creators to add correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace SelectTextResponse
 *
 * @function SelectTextResponse - React functional component to display select text item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying select text item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - SelectTextPreview component for displaying select text item
 * @param {string} stem - An optional react component passed to display stem along with item content.
 * @param {boolean} showCorrectResponse - An boolean value passed to display Correct Response along with stem.
 */

const SelectTextResponse = ({
  item,
  config,
  onUpdate,
  showCorrectResponse,
  responseOnly
}) => {
  const content = item?.item_json || {};
  // Updated ClassName in correct response based on selection type
  const classNameForCR = {
    borderOnStart: "",
    borderOnHover: "",
    borderOnSelect: "",
    highlightStart: "",
    highlightHover: "",
    highlightOnSelect: ""
  };

  if (content.borderAtStart === ST_RED) {
    classNameForCR.borderOnStart = " st-border-start-red ";
  } else if (content.borderAtStart === ST_BLACK) {
    classNameForCR.borderOnStart = " st-border-start-black";
  } else {
    classNameForCR.borderOnStart = " st-border-start";
  }

  if (content.borderOnHover === ST_RED) {
    classNameForCR.borderOnHover = " st-border-hover-red";
  } else if (content.borderOnHover === ST_BLACK) {
    classNameForCR.borderOnHover = " st-border-hover-black";
  } else {
    classNameForCR.borderOnHover = " ";
  }

  if (content.borderOnSelect === ST_RED) {
    if (item.item_json?.boldedBorderOnSelect) {
      classNameForCR.borderOnSelect = " st-bold-border-select-red";
    } else {
      classNameForCR.borderOnSelect = " st-border-select-red";
    }
  } else if (content.borderOnSelect === ST_BLACK) {
    if (item.item_json?.boldedBorderOnSelect) {
      classNameForCR.borderOnSelect = " st-bold-border-select-black";
    } else {
      classNameForCR.borderOnSelect = " st-border-select-black";
    }
  } else {
    classNameForCR.borderOnSelect = " ";
  }

  if (content.highlightAtStart === ST_YELLOW) {
    classNameForCR.highlightStart = " st-highlight-start";
  } else {
    classNameForCR.highlightStart = " st-highlight-start-none";
  }

  if (content.highlightOnHover === ST_YELLOW) {
    classNameForCR.highlightHover = " st-highlight-hover-yellow";
  } else {
    classNameForCR.highlightHover = " st-highlight-hover-none";
  }

  if (content.highlightOnSelect === ST_YELLOW) {
    classNameForCR.highlightOnSelect = " st-selected-response-yellow";
  } else {
    classNameForCR.highlightOnSelect = " st-selected-response-none";
  }

  return (
    <div className='select-text-response'>
      {(responseOnly === false) ?
        (<div className={'row m-1'}>
          <StemFormatter stemContent={content?.stemContent} />
        </div>) : ''
      }

      <SelectTextRenderSwitch
        item={item}
        config={config}
        onUpdate={onUpdate}
        responseOnly={responseOnly}
        classNameForCR={classNameForCR}
        showCorrectResponse={showCorrectResponse}
        selectionType={item?.item_json.selectionType}
      />
    </div>
  );
};

SelectTextResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  stem: PropTypes.string,
  responseOnly: PropTypes.bool,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool
};

export default SelectTextResponse;
