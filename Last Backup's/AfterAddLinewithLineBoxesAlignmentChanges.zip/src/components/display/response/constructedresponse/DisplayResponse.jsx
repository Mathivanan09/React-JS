import React, { useEffect, useState } from 'react';
import parse from 'html-react-parser';
import PropTypes from 'prop-types';
import DOMPurify from "dompurify";

const TABLE = 'table';
const MEDIA = 'mediacontent';
const NUMERIC = 'Numeric';
const UL = 'ul';
const OL = 'ol';
const BLOCK = 'blockquote';

/**
 *  React functional component for Rendering constructed response, and to use it in create interface
 *  providing provision for item creators to add correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace DisplayResponse
 *
 * @function DisplayResponse - React functional component to display constructed response item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying constructed response item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - MultipleChoicePreview component for displaying constructed response item
 */

const DisplayResponse = ({
  item,
  onUpdate,
  config,
  showCorrectResponse,
  isPreview,
  clickHistory,
  onClickHistoryUpdate
}) => {
  const itemJson = item?.item_json || {};
  const [userInput, setUserInput] = useState([]);
  //Creates Option list based on number of responses.
  const createOptionListMap = (optionList, correctResponse) => {
    const optionListMap = {};
    if (optionList) {
      optionList.forEach(
        ({
          id,
          responseName,
          maxCharacters,
          responseType,
          maxFieldSize
        }) => {
          const acceptableValues = correctResponse?.find((response) => response.id === id)?.acceptableValues;
          const correctResponseValue = correctResponse?.find((response) => response.id === id)?.value;
          optionListMap[id] = getAnswerInput(
            id,
            acceptableValues,
            correctResponseValue,
            responseName,
            maxCharacters,
            responseType,
            maxFieldSize
          );
        }
      );
    }
    return optionListMap;
  };

  //Handles the Input box value change
  const handleChange = (e, id) => {
    setUserInput({ ...userInput, [id]: e.target.value });
  };



  const applyResponse = (newStemContent, optionListMap) => {
    return newStemContent.map((item) => {
        if (item?.props?.className?.split(' ')?.indexOf(MEDIA) !== 0 && item?.type === TABLE) {
            item.props !== undefined &&
                Array.isArray(item.props.children) &&
                item.props.children.forEach((tableData, i) => {
                    if (tableData.props !== undefined && (tableData.props.children[i] !== undefined ? tableData.props.children[i].props !== undefined : true)) {
                        Array.isArray(item.props.children[i].props.children) &&
                            item.props.children[i].props.children.forEach((rowData, j) => {
                                if (rowData.props !== undefined && rowData.props.children !== undefined) {
                                    Array.isArray(rowData.props.children) &&
                                        rowData.props.children.forEach((columnData, k) => {
                                            if (columnData.props !== undefined && columnData.props.children !== undefined) {
                                                let groupCellData = columnData.props.children
                                                if (Array.isArray(groupCellData)) {
                                                    groupCellData.forEach((cellData, l) => {
                                                        if (cellData?.props && item.props.children[i].props.type !== 'caption' &&
                                                            item.props.children[i].props.children[j].props.children[k].props.children[l]) {
                                                            let id = cellData?.props.id;
                                                            if (id && optionListMap[id]) {
                                                                item.props.children[i].props.children[j].props.children[k].props.children[l] = optionListMap[id];
                                                            }
                                                        }
                                                    })
                                                }
                                            }
                                        })
                                    if (!(Array.isArray(rowData.props.children))) {
                                        let id = rowData?.props.id;
                                        if (id && optionListMap[id]) {
                                            item.props.children[i].props.children[j] = optionListMap[id];
                                        }
                                    }
                                }
                            })
                    }
                })
        }
        if (item?.props?.className?.split(' ')?.indexOf(MEDIA) !== 0 && item?.type !== TABLE) {
            item.props !== undefined &&
                Array.isArray(item.props.children) &&
                item.props.children.forEach((optionData, i) => {
                    if (optionData.props !== undefined && item?.type !== UL && item?.type !== OL && item?.type !== BLOCK) {
                        let id = item.props.children[i].props.id;
                        if (id && optionListMap[id]) {
                            item.props.children[i] = optionListMap[id];
                        }
                    }
                    else {
                        if (item?.type === UL || item?.type === OL || item?.type === BLOCK) {
                            if (item.props.children[i]?.props?.children) {
                                if (optionData.props !== undefined) {
                                    if (Array.isArray(item.props.children[i].props.children)) {
                                        item.props.children[i].props.children.forEach((optionData2, j) => {
                                            if (optionData2.props !== undefined) {
                                                let id = item.props.children[i]?.props?.children[j]?.props?.id;
                                                if (id && optionListMap[id]) {
                                                    item.props.children[i].props.children[j] = optionListMap[id];
                                                }
                                            }
                                        })
                                    }
                                }
                            }
                        }
                    }
                })
        }
        if (typeof item === Object && item?.type === "p" && item?.props?.id && optionListMap[item?.props?.id]) {
            item = optionListMap[item?.props?.id];
        }
        if (Array.isArray(item) && item?.length > 0) {
            item = applyResponse(item, optionListMap);
        }
        return item;
    });
}

  //To get the Input box value for the response
  const getAnswerInput = (
    id,
    acceptableValues,
    correctResponse,
    responseName,
    maxCharacters,
    responseType,
    maxFieldSize
  ) => {
    const input = (
      <input
        maxLength={maxCharacters}
        onKeyPress={(event) => {
          if (responseType === NUMERIC) {
            if (!/[0-9.]/.test(event.key)) {
              event.preventDefault();
            }
          }
        }}
        onInput={(e) =>
          (e.target.value = e.target.value.slice(0, maxCharacters))
        }
        size={maxFieldSize}
        key={'input-key-' + id}
        id={id}
        name={responseName}
        value={
          showCorrectResponse
            ? correctResponse
            : userInput[id] === undefined
              ? ''
              : userInput[id]
        }
        disabled={!isPreview}
        aria-label={responseName}
        onChange={(e) => handleChange(e, id)}
      />
    );
    return input;
  };

  //This method will return the boolen value for correct response.
  const isCorrectResponse = (responseData) => {
    const response = existingResponseObject;
    if (response && response.length > 0) {
      for (let i = 0; i < response.length; i++) {
        if (response[i] === responseData[i]) {
          return true;
        }
      }
    }
    return false;
  };

  //Generate click histroy based on user selection
  const generateClickHistory = (responseData) => {
    if (clickHistory.length > 0) {
      const lastResponseObj = clickHistory[clickHistory.length - 1];
      let responseIdList = lastResponseObj.responseoption;

      let newResponseIdList = [...responseIdList];

      clickHistory.push({
        isCorrectResponse: isCorrectResponse(responseData),
        score: null,
        responseoption: newResponseIdList,
        ts: Date().toLocaleString()
      });
    } else {
      let responseIdListFromObj = [];

      if (responseObject !== undefined) {
        for (let i = 0; i < responseObject.length; i++) {
          responseIdListFromObj.push(responseObject[i]);
        }
      }
      clickHistory.push({
        isCorrectResponse: isCorrectResponse(responseData),
        score: null,
        responseoption: responseIdListFromObj,
        ts: Date().toLocaleString()
      });
    }

    if (onClickHistoryUpdate !== undefined) {
      onClickHistoryUpdate(clickHistory);
    }
  };


  const getStemContent = (stemContent,optionListMap) => {
    let newStemContent = null;
    if (stemContent) {
        let lastOption = "</span></p>"
        let lastOptionIndex = stemContent.lastIndexOf(lastOption)
        if (lastOptionIndex > -1 && stemContent.length === lastOptionIndex + lastOption.length) {
            stemContent = stemContent.substring(0, lastOptionIndex) + "</span>&nbsp;</p>"
        }
        newStemContent = parse(DOMPurify.sanitize(stemContent, { USE_PROFILES: { html: true }, }));
        newStemContent = [[], newStemContent];
        newStemContent = applyResponse(newStemContent, optionListMap);
    }
    return newStemContent;
  }

  // To Display the correct response value
  const displayStemContent = (contentData) => {
    const data = contentData;
    const optionListMap = createOptionListMap(data.optionList, data.correctResponse);
    return (
      <div data-testid='correctresponse-container'>
        {getStemContent(itemJson.stemContent, optionListMap)}
      </div>
    );
  };

  return (
    <div
      className={
        config?.styleCode == 'alternate'
          ? 'cr-item-response-alternateui'
          : 'cr-item-response-generalui'
      }
    >
      {displayStemContent(itemJson)}
    </div>
  );
};

DisplayResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  clickHistory: PropTypes.func,
  onClickHistoryUpdate: PropTypes.func
};

export default DisplayResponse;