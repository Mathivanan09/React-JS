import React from 'react';
import PropTypes from 'prop-types';

import {
  closestCenter,
  DndContext,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  rectSortingStrategy
} from '@dnd-kit/sortable';

import SortableOption from './SortableOption';

import label from '../../../../constants/labelCodes';

/**
 *  React functional component for Rendering ordering item, and to use it in create interface
 *  providing provision for item creators to add correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace OrderingResponse
 *
 * @function OrderingResponse - React functional component to display ordering item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying ordering item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {JSON} config - JSON data that will contain the configuration
 * @param {showCorrectResponse} showCorrectResponse - boolean value which determines visibility of correct response
 * @param {isPreview} isPreview - boolean value which determines visibility of preview
 * @return {component} - OrderingResponse component for displaying ordering item
 */

const OrderingResponse = ({
  item,
  onUpdate,
  config,
  showCorrectResponse,
  isPreview,
  ordered
}) => {
  const style =
    item?.item_json?.answerAlignment === 'Horizontal'
      ? {
          width: item?.item_json?.responseOptionWidth + 'px',
          minHeight: item?.item_json?.responseOptionHeight + 'px',
          backgroundColor: 'white'
        }
      : {
        backgroundColor: 'white'
      };

  let orderedResponses = showCorrectResponse
    ? item?.item_json?.correctResponse
    : ordered;
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates
    })
  );

  function handleDragEnd(event) {
    const { active, over } = event;

    if (active.id !== over.id) {
      let responses = orderedResponses;
      const oldIndex = responses.findIndex((response) => {
        return response.id === active.id;
      });
      const newIndex = responses.findIndex((response) => {
        return response.id === over.id;
      });
      let newItems = arrayMove(responses, oldIndex, newIndex).map((response, index) => ({
        ...response,
        value: index,
      }));
      if (isPreview) {
        onUpdate(newItems);
      } else {
        onUpdate({
          item_json: {
            ...item.item_json,
            correctResponse: newItems
          }
        });
      }
    }
  }

  const getOptionText = (optionId) => {
    return (
      item?.item_json?.optionList.find((option) => {
        return option.id === optionId;
      })?.optionText || ''
    );
  };

  return (
    <div
      className={
        config?.styleCode == 'alternate'
          ? 'ord-item-response-alternateui'
          : 'ord-item-response-generalui'
      }
    >
      <div className='row'>
        {showCorrectResponse && !isPreview && (
          <div className='text-center'>
            <legend>{label.ord_set_correct_response}</legend>
          </div>
        )}
        {orderedResponses && (
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={orderedResponses}
              strategy={
                item.item_json?.answerAlignment === 'Vertical'
                  ? verticalListSortingStrategy
                  : rectSortingStrategy
              }
            >
              {orderedResponses?.map((option, index) => {
                if (item.item_json?.answerAlignment === 'Vertical') {
                  return (
                    <div className='row' key={option.id}>
                      <SortableOption
                        id={option.id}
                        key={option.id}
                        style={style}
                        optionText={getOptionText(option.id)}
                      />
                    </div>
                  );
                } else {
                  return (
                      <SortableOption
                        id={option.id}
                        key={option.id}
                        index={index}
                        style={style}
                        optionText={getOptionText(option.id)}
                      />
                  );
                }
              })}
            </SortableContext>
          </DndContext>
        )}
      </div>
    </div>
  );
};

OrderingResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool
};

export default OrderingResponse;
