import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import parse from 'html-react-parser';

function SortableOption(props) {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: props.id });

  const style = {
    ...props.style,
    transform: CSS.Transform.toString(transform),
    transition
  };

  return (
    <>
      {props.optionText && (
        <div
          className={'border border-dark rounded p-1 m-10'}
          ref={setNodeRef}
          style={style}
          {...attributes}
          {...listeners}
        >
          {parse(props.optionText || '<div></div>')}
        </div>
      )}
    </>
  );
}

export default SortableOption;
