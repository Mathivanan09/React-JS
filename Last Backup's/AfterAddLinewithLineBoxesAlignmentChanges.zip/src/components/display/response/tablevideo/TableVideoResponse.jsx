import React, { useState } from 'react';
import PropTypes from 'prop-types';

/**
 *  React functional component for Rendering Table Video simulations, and to use it in create interface
 *  providing provision for item creators to add correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace TableVideoResponse
 *
 * @function TableVideoResponse - React functional component to display Table Video simulations item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Table Video simulations item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {function} clickHistoryUpdate - the function that needs to be called
 * if there is any simulation is performed
 * @param {Object} config - JSON data that will contain configuration of item
 * @param {Object} clickHistory - JSON data that will contain clickHistory.
 * if there is any simulation is performed
 *
 * @return {component} - TableVideoResponse component for displaying Table Video simulations item
 */
const TableVideoResponse = ({
  item,
  onUpdate,
  config,
  clickHistory,
  clickHistoryUpdate,
}) => {
  const [selectedOptions, setSelectedOptions] = useState({});
  const [simulatedValue, setSimulatedValue] = useState([]);
  const [defaultOption, setDefaultOption] = useState();

  /**
   * Used to select input options
   *
   * @param {String} value
   * @param {String} key
   */
  const handleSelection = (value, key) => {
    setDefaultOption();
    setSelectedOptions({
      ...selectedOptions,
      ...{
        [key]: value
      }
    });
  };

  /**
   * Create and Update clickHistory
   *
   * @param {Object} simulatedData
   */
  const generateClickHistory = (simulatedData) => {
    const responseOptions = [...(clickHistory?.responseOptions || [])];

    responseOptions = [
      ...responseOptions,
      ...[
        {
          ts: new Date(),
          order: (clickHistory?.responseOptions?.length || 0) + 1,
          combination: simulatedData.combination,
          id: simulatedData.id
        }
      ]
    ];

    clickHistoryUpdate({
      responseOptions
    });
  };

  /**
   * Runs simulation as per selected input options
   *
   */
  const startSimulation = () => {
    const optionList = [...item?.item_json?.optionList];
    const selectedOptionsLength = Object.keys(selectedOptions).length;
    if(selectedOptionsLength > 0){
      const simulatedData = optionList.filter(
        (each) =>
          selectedOptionsLength === checkCombination(each?.combination || [])
      );
  
      const isUndefined = simulatedValue.find(
        (each) =>
          selectedOptionsLength === checkCombination(each?.combination || [])
      );
  
      if (isUndefined === undefined) {
        setSimulatedValue([...simulatedData, ...simulatedValue]);
      }
    } else{
      setSimulatedValue([]);
    }
    // generateClickHistory(simulatedData);
  };

  /**
   *  Returns right simulation data as per selected input values.
   *
   * @param {Array} combination
   * @return {Number}
   */
  const checkCombination = (combination) => {
    const selectedData = { ...selectedOptions };
    let counter = 0;
    Object.keys(selectedData).map((key) => {
      const id = selectedData[key];
      const value = combination.find((each) => each.id === id);
      if (value) {
        counter++;
      }
    });

    return counter;
  };

  /**
   *  Reset previous simulation values.
   *
   */
  const clearData = () => {
    setSimulatedValue([]);
    setSelectedOptions({});
    setDefaultOption('select');
  };

  return (
    <div
      className={
        config?.styleCode == 'alternate'
          ? 'cr-item-response-alternateui'
          : 'cr-item-response-generalui'
      }
    >
      <section className='row mb-3'>
        {item?.item_json?.inputList.map((input) => (
          <div className='col-sm-12 mb-2' key={input.id}>
            <label
              htmlFor={input.id}
              className='mb-1'
              dangerouslySetInnerHTML={{
                __html: input.title
              }}
            ></label>
            <select
              id={input.id}
              className='form-select form-select-sm'
              aria-label='form-select-columns-number'
              value={defaultOption}
              onChange={(e) => {
                let val = e.target.value;
                if (val !== 'select') {
                  handleSelection(val, input.id);
                } else {
                  const options = {...selectedOptions};
                  delete options[input.id];
                  setSelectedOptions({
                    ...options
                  });
                }
              }}
              data-testid={`select-input-${input.id}`}
            >
              <option value={`select`}>Select Option</option>
              {input?.options.map((value) => (
                <option
                  key={value.id}
                  value={value.id}
                  dangerouslySetInnerHTML={{
                    __html: value.textHtml
                  }}
                ></option>
              ))}
            </select>
          </div>
        ))}
      </section>
      <section className='row'>
        <div className='col-sm-12'>
          <button
            className='btn btn-primary btn-sm'
            style={{ marginRight: '10px' }}
            type='button'
            onClick={startSimulation}
          >
            Start Simulation
          </button>
          <button
            className='btn btn-danger btn-sm'
            type='button'
            onClick={clearData}
          >
            Clear Data
          </button>
        </div>
      </section>
      <hr />
      {simulatedValue.length > 0 && (
        <>
          <section className='mt-2 tv-simulation-image'>
            <img
              src={simulatedValue[0]?.url}
              alt={simulatedValue[0]?.fileName}
            />
          </section>
          <hr />
        </>
      )}
      { simulatedValue.length ===  0 &&
        <>
          <section className='mt-2 tv-simulation-image'>
            <img
              src={item?.item_json?.defaultMedia?.url}
              alt={item?.item_json?.defaultMedia?.fileName}
            />
          </section>
          <hr />
        </>
      }
      {item?.item_json?.displayTable &&
        <section className='mt-2'>
          <table className='table table-hover'>
            <thead>
              <tr>
                {item?.item_json?.inputList.map((input) => (
                  <th
                    scope='col'
                    key={input.id}
                    dangerouslySetInnerHTML={{
                      __html: input.title
                    }}
                  ></th>
                ))}
                {item?.item_json?.outputList.map((output) => (
                  <th
                    scope='col'
                    key={output.id}
                    dangerouslySetInnerHTML={{
                      __html: output.textHtml
                    }}
                  ></th>
                ))}
              </tr>
            </thead>
            <tbody>
              {simulatedValue.length > 0 ? (
                simulatedValue.map((eachSimulation, index) => (
                  <tr key={index}>
                    {eachSimulation.combination.map((each, i) => (
                      <td
                        scope='col'
                        key={i}
                        dangerouslySetInnerHTML={{
                          __html: each.textHtml
                        }}
                      ></td>
                    ))}
                    {eachSimulation.outputs.map((each, i) => (
                      <td
                        scope='col'
                        key={i}
                        dangerouslySetInnerHTML={{
                          __html: each.value
                        }}
                      ></td>
                    ))}
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    className='text-center'
                    colSpan={
                      item.item_json.noOfInputs + item.item_json.noOfOutputs
                    }
                  >
                    No data available in table
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </section>
      }
    </div>
  );
};

TableVideoResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  clickHistory: PropTypes.object,
  updateClickHistory: PropTypes.func
};

export default TableVideoResponse;
