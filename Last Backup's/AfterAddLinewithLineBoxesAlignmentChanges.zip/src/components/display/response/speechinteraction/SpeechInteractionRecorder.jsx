import React, { useState, useEffect } from 'react'
import MicRecorder from 'mic-recorder-to-mp3';

const SpeechInteractionRecorder = ({ maxNumberofAttempts, maxTimeAllowedForEachAttempt, dataTestId, retainAttempts, api, assessmentProgramId, config }) => {

      // New instance for plugin
      const [recorder] = useState(new MicRecorder({ bitRate: 128 }));
      const attempts = parseInt(maxNumberofAttempts) || 1;
      const [timeooutdata, setTimeooutdata] = useState(null);
      const [audioRecording, setAudioRecording] = useState(true);
      const [attemptsCompleted, setAttemptsCompleted] = useState(1);
      const [disableRecording, setDisableRecording] = useState(false);

      let stopAudioRecording = maxTimeAllowedForEachAttempt * 1000;

      // Function clear the timeout option if user manually triggered the stop button.
      const stopRecording = () => {
            clearTimeout(timeooutdata);
            handleStop();
      }

      // Start recording. Browser will request permission to use your microphone.
      const handleStartRecording = () => {
            setAudioRecording(false);
            handlePauseAudio();
            recorder.start().then(() => {
                  setTimeooutdata(
                        // recordingTimeout based on maxTimeAllowedForEachAttempt 
                        setTimeout(() => {
                              handleStop();
                        }, stopAudioRecording)
                  );
            }).catch((e) => {
                  console.error(e);
            });
      }

      // Function to create a audio file once user stopped the audio recording
      const handleStop = () => {
            setAudioRecording(true);
            if (attemptsCompleted === attempts) {
                  setDisableRecording(true);
            } else {
                  setDisableRecording(false);
            }
            setAttemptsCompleted(attemptsCompleted + 1);
            recorder.stop()
                  .getMp3().then(async ([buffer, blob]) => {
                        // Creating a mp3 file and play
                        const file = new File(buffer, 'music.mp3', {
                              type: blob.type,
                              lastModified: Date.now()
                        });
                        const divContent = document.querySelector('#playlist');
                        let div = document.createElement("div")
                        let attemtCount = attemptsCompleted + '. ';
                        if (!config.isSaveAudioInS3) {
                              const player = new Audio(URL.createObjectURL(file));
                              player.controls = true;
                              if (!retainAttempts) {
                                    divContent.removeChild(divContent.firstChild);
                                    div.append(player)
                                    divContent.append(div);
                              } else {
                                    div.append(attemtCount, player)
                                    divContent.append(div);
                              }
                        } else {
                              const payload = {
                                    fileType: 'mp3',
                                    file: file,
                                    contentType: 'item',
                                    filePathId: assessmentProgramId,
                                    attemptNo: attemptsCompleted
                              };
                              const response = await api.audioRepository.saveAudio(payload);
                              const getPayload = {
                                    fileType: 'mp3',
                                    filePath: response.path,
                              };
                              const fileUrl = await api.audioRepository.signedGetUrl(getPayload);
                              const playerS3 = new Audio(fileUrl.data);
                              playerS3.controls = true;
                              if (!retainAttempts) {
                                    divContent.removeChild(divContent.firstChild);
                                    div.append(playerS3)
                                    divContent.append(div);
                              } else {
                                    div.append(attemtCount, playerS3)
                                    divContent.append(div);
                              }
                        }
                        document.querySelector('#playlist').appendChild(divContent);
                  }).catch((e) => {

                  });
      }

      // Pause recording, While user play another recording / start new recording
      const handlePauseAudio = (target) => {
            var audios = document.querySelectorAll('.speech-interaction-recorder audio');
            for (var i = 0, len = audios.length; i < len; i++) {
                  if (audios[i] != target) {
                        audios[i].pause();
                        audios[i].currentTime = 0;
                  }
            }
      }

      useEffect(() => {
            document.addEventListener('play', function (e) {
                  handlePauseAudio(e.target);
            }, true)
      });

      return (
            <>
                  <div className='row speech-interaction-recorder' >
                        <div className="col-sm-1  text-center mt-2">
                              <button
                                    className={audioRecording ? "btn btn-primary btn-sm" : "btn btn-danger btn-sm"}
                                    onClick={audioRecording === true ? handleStartRecording : stopRecording}
                                    disabled={disableRecording}
                                    data-testid={dataTestId}
                                    style={{ borderRadius: '50%' }}
                              >
                                    {
                                          audioRecording ?
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-mic icon-white" viewBox="0 0 16 16">
                                                      <path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z" />
                                                      <path d="M10 8a2 2 0 1 1-4 0V3a2 2 0 1 1 4 0v5zM8 0a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V3a3 3 0 0 0-3-3z" />
                                                </svg>
                                                :
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-mic-fill icon-white" viewBox="0 0 16 16">
                                                      <path d="M5 3a3 3 0 0 1 6 0v5a3 3 0 0 1-6 0V3z" />
                                                      <path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z" />
                                                </svg>
                                    }
                              </button>
                        </div>
                        <br />
                        <div className="col-sm-8 m-1">
                              <div id="playlist"> </div>
                        </div>
                  </div>
            </>
      )
}

export default SpeechInteractionRecorder;