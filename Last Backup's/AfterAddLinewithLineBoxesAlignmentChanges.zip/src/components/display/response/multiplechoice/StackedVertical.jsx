import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import StackedVerticalOption from './optioncomponents/StackedVerticalOption';

/**
 * React functional component which renders options in Stacked Vertical based on selection
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace StackedVertical
 * 
 * @function StackedVertical - React functional container component for stem and options
 * @param {object} ItemJson - Item content
 * @param {string} optionObject - option object with alignment type information
 * @param {boolean} stemComponent - stem content to be rendered
 * @param {function} onUpdate - dispatcher function to update the store
 * @return {component} - container for stem and stacked vertically aligned options
 *
 */
const StackedVertical = ({
  optionsList,
  correctResponses,
  optionObject,
  stemComponent,
  onUpdate,
  config,
  showCorrectResponse,
  selected
}) => {
  let content = [];
  optionsList?.forEach((obj, i) => {
    let correctResponseValue = correctResponses?.includes(obj.id)
      ? true
      : false;
    content.push(
      <div className='row' key={`option-list-${i}`}>
        <StackedVerticalOption
          id={obj.id}
          type={optionObject.selectionType}
          name={optionObject.inputName}
          checked={showCorrectResponse?correctResponseValue:selected.includes(obj.id)}
          className={optionObject.styleClass}
          inline={true}
          optionText={obj.optionText}
          responseLabels={optionObject.responseLabels(i)}
          onUpdate={onUpdate}
          config={config}
          disabled={showCorrectResponse}
        />
      </div>
    );
  });

  return (
    <>
      <div className={'row m-1'}>{stemComponent ? stemComponent : null}</div>
      <div className='row item-content m-1 mt-4 p-4 content_style'>{content}</div>
    </>
  );
};

StackedVertical.propTypes = {
  optionsList: PropTypes.array,
  correctResponses: PropTypes.array,
  optionObject: PropTypes.object,
  stemComponent: PropTypes.element,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  selected: PropTypes.array
};

export default StackedVertical;
