import React from 'react';
import PropTypes from 'prop-types';
import StackedZOption from './optioncomponents/StackedZOption';

/**
 * React functional component which renders options in Stacked Z based on selection
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace StackedZ
 * 
 * @function StackedZ - React functional container component for stem and options
 * @param {object} ItemJson - Item content
 * @param {string} optionObject - option object with alignment type information
 * @param {boolean} stemComponent - stem content to be rendered
 * @param {function} onUpdate - dispatcher function to update the store
 * @return {component} - container for stem and stacked Z aligned options
 *
 */
const StackedZ = ({
  optionsList,
  correctResponses,
  optionObject,
  stemComponent,
  onUpdate,
  config,
  showCorrectResponse,
  selected
}) => {
  let content = [];
  optionsList?.forEach((obj, i) => {
    let correctResponseValue = correctResponses?.includes(obj.id)
      ? true
      : false;
    content.push(
      <div className='col col-6' key={`option-list-${i}`}>
        <StackedZOption
          id={obj.id}
          type={optionObject.selectionType}
          name={optionObject.inputName}
          checked={showCorrectResponse?correctResponseValue:selected.includes(obj.id)}
          className={optionObject.styleClass}
          inline={true}
          optionText={obj.optionText}
          responseLabels={optionObject.responseLabels(i)}
          onUpdate={onUpdate}
          config={config}
          disabled={showCorrectResponse}
        />
      </div>
    );
  });
  return (
    <>
      <div className='row m-1'>{stemComponent ? stemComponent : null}</div>
      <div className='row item-content m-1 mt-4 p-4 content_style'>{content}</div>
    </>
  );
};

StackedZ.propTypes = {
  optionsList: PropTypes.array,
  correctResponses: PropTypes.array,
  optionObject: PropTypes.object,
  stemComponent: PropTypes.element,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  selected: PropTypes.any
};

export default StackedZ;
