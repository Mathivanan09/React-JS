import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import RenderSwitch from './RenderSwitch';
import '../../../../styles/item/MultipleChoicePreview.css';
import { setShuffle } from '../../../../utility/shuffleList';

/**
 *  React functional component for Rendering multiple choice options, and to use it in create interface
 *  providing provision for item creators to add correct response.
 *
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace MultipleChoiceResponse
 *
 * @function MultipleChoiceResponse - React functional component to display multiple choice item
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying multiple choice item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @return {component} - MultipleChoicePreview component for displaying multiple choice item
 * @param {component} stemComponent - An optional react component passed to display stem along with item content.
 */

const MultipleChoiceResponse = ({
  item,
  onUpdate,
  stemComponent,
  config,
  showCorrectResponse,
  selected,
  isPreview
}) => {
  const itemJson = item?.item_json || {};
  const alignment = itemJson?.answerAlignment;

  //method to generated shuffled response option based on user selection
  let shuffleNumber = Math.floor(Math.random() * 100000);
  const getShuffledData = (optionsList) => {
    let data = [];
    if (optionsList?.length > 0) {
      data = JSON.parse(JSON.stringify(optionsList));
      if (itemJson?.shuffle == true) {
        data = setShuffle(data, shuffleNumber);
      }
    } else {
      data = optionsList;
    }
    return data;
  };

  // state object which determines the shuffle usage
  const [shuffled, setShuffled] = useState(false);
  const [optionsList, setOptionsList] = useState([]);

  useEffect(() => {
    if (item?.item_json?.shuffle) {
      if (!shuffled) {
        setShuffled(true);
        setOptionsList(getShuffledData(itemJson?.optionList));
      }
      else {
        let data = optionsList.map((obj) => {
          let temp = itemJson.optionList.find(o => o.id == obj.id)
          if (temp) {
            return temp
          }
        })
        setOptionsList(data);
      }
    } else {
      setOptionsList(itemJson?.optionList);
    }
  }, [itemJson?.optionList]);

  const correctResponses = itemJson?.correctResponse
    ?.filter(response => response.value)
    ?.map(response => response.id) || [];
  let selectionTypecheck = '';

  //constructing selection type for options from itemJson
  if (itemJson.selectionType == 'single') {
    selectionTypecheck = 'radio';
  } else if (itemJson.selectionType == 'multiple') {
    selectionTypecheck = 'checkbox';
  } else {
    selectionTypecheck = 'radio';
  }

  //To get letter based on index
  const getLetterByNumber = (num) => {
    const number = num - 1;
    return `
          ${number >= 26 ? getLetterByNumber(Math.floor(number / 26) - 1) : ''}
          ${'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[number % 26]}
      `;
  };
  //create response label based on index by letter
  const createResponseLettersByIndex = (index) => {
    const i = parseInt(index);
    return isNaN(i) ? null : getLetterByNumber(i + 1);
  };

  //constructing label type for options from itemJson
  const renderLabel = (i) => {
    if (itemJson.responseLabels == 'Numbers') {
      return i + 1;
    } else if (itemJson.responseLabels == 'Letters') {
      return createResponseLettersByIndex(i);
    } else if (itemJson.responseLabels == 'No Response Label') {
      return null;
    } else {
    }
  };

  const optionObject = (type, labels, alignment, styleClass, inputName) => {
    return {
      selectionType: type,
      responseLabels: labels,
      alignment: alignment,
      styleClass: styleClass,
      inputName: inputName
    };
  };

  let newOption = optionObject(
    selectionTypecheck,
    renderLabel,
    alignment,
    '',
    'mc-option'
  );

  return (
    <div
      className={
        config?.styleCode == 'alternate'
          ? 'mc-item-response-alternateui'
          : 'mc-item-response-generalui'
      }
    >
      <RenderSwitch
        optionsList={isPreview ? optionsList : itemJson?.optionList}
        correctResponses={correctResponses}
        optionObject={newOption}
        stemComponent={stemComponent}
        onUpdate={onUpdate}
        config={config}
        showCorrectResponse={showCorrectResponse}
        selected={selected}
      />
    </div>
  );
};

MultipleChoiceResponse.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  stemComponent: PropTypes.element,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  selected: PropTypes.any
};

export default MultipleChoiceResponse;
