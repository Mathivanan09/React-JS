import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import RightSideZOption from './optioncomponents/RightSideZOption';

/**
 * React functional component which renders options in Right side Z based on selection
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace RightSideZ
 * 
 * @function RightSideZ - React functional container component for stem and options
 * @param {object} ItemJson - Item content
 * @param {string} optionObject - option object with alignment type information
 * @param {boolean} stemComponent - stem content to be rendered
 * @param {function} onUpdate - dispatcher function to update the store
 * @return {component} - container for stem and right side Z options
 *
 */
const RightSideZ = ({
  optionsList,
  correctResponses,
  optionObject,
  stemComponent,
  onUpdate,
  config,
  showCorrectResponse,
  selected
}) => {
  let content = [];
  optionsList?.forEach((obj, i) => {
    let correctResponseValue = correctResponses?.includes(obj.id)
      ? true
      : false;
    content.push(
      <div className='col-6' key={`option-list-${i}`}>
        <RightSideZOption
          id={obj.id}
          type={optionObject.selectionType}
          name={optionObject.inputName}
          checked={showCorrectResponse?correctResponseValue:selected.includes(obj.id)}
          className={optionObject.styleClass}
          inline={true}
          optionText={obj.optionText}
          responseLabels={optionObject.responseLabels(i)}
          onUpdate={onUpdate}
          config={config}
          disabled={showCorrectResponse}
        />
      </div>
    );
  });

  return (
    <>
      <div className='row'>
        <div className='col m-1'>{stemComponent ? stemComponent : null}</div>
        <div className='col'>
          <div className='row item-content m-1 p-4 content_style'>{content}</div>
        </div>
      </div>
    </>
  );
};

RightSideZ.propTypes = {
  optionsList: PropTypes.array,
  correctResponses: PropTypes.array,
  optionObject: PropTypes.object,
  stemComponent: PropTypes.element,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  showCorrectResponse: PropTypes.bool,
  selected: PropTypes.array
};

export default RightSideZ;
