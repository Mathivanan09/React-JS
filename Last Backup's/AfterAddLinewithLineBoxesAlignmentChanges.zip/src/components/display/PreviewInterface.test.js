import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";

// import component here
import PreviewInterface from './PreviewInterface';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

/**
 * Test an empty component and verify the element with Missing item data
 */
it("Test default component", () => {
  act(() => {
    render(
      <PreviewInterface />, container);
  });

  expect(container.children).toBeNull;
  const emptyComponent = document.querySelector("[data-testid=missing-item]");
  expect(emptyComponent).toBeNull;
});

/**
 * Test non implemented item
 */
it("Test non implemented item", () => {
  act(() => {
    render(
      <PreviewInterface item={{
        item_json: {
          itemTypeCode: 'XYZ'
        }
      }
      } />, container);
  });

  expect(container.children).toBeNull;
  const notImplemented = document.querySelector("[data-testid=not-implemented]");
  expect(notImplemented).not.toBeNull;
  expect(notImplemented.textContent).toBe('xyz Not implemented');
});

/**
 * Test preview with item dimensions
 */
it("Test preview with item dimensions", () => {
  act(() => {
    render(
      <PreviewInterface item={{
        item_json: {
          itemTypeCode: 'MC',
          minItemWidth: 400,
          minItemHeight: 400
        }
      }
      } />, container);
  });

  /**
   * Verify that item dimensions are applies
   */
  const component = document.querySelector("[data-testid=preview-container]");
  expect(component).not.toBeNull;
  expect(component.className).toContain('preview-options-body');
  expect(component.className).toContain('p-2');

});