import React, { useState } from 'react';

import { itemPreviewProps } from '../../../common/ItemHelper';
import label from '../../../../constants/labelCodes';

import SelectTextResponse from '../../response/selecttext/SelectTextResponse';

/**
 * React functional component to display Select Text click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace SelectTextPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Select Text click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - SelectTextPreview component for displaying Select Text click item
 */

const SelectTextPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {

  const itemJson = item?.item_json || {};
  // state object of selected responses
  const [selected, setSelected] = useState([]);

  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  const handleResponse = (e) => {
     // TODO
    // const id = e.target.id;
    // onUpdate(id, val);
    // Updating history
    let clickHistoryObj = { ...clickHistory };
    if (config?.clickHistoryRequired) {
      clickHistoryObj.selectionType = itemJson?.selection_type;
      const historyOption = {
        "isCorrectResponse": '',
        "score": null,
        "responseoption": '',
        "readableresponse": '',
        "ts": Date().toLocaleString(),
        "unselected": ''
      };

      if (!clickHistoryObj.options) {
        clickHistoryObj.options = [];
      }
      clickHistoryObj.options.push(historyOption);
    }
    onClickHistoryUpdate && onClickHistoryUpdate(clickHistoryObj);
  };

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <SelectTextResponse
              item={item}
              config={config}
              onUpdate={handleResponse}
              showCorrectResponse={showCorrectResponse}
              selected={selected}
              responseOnly={false}
            />
          </div>
        </div>
      ) : (<div className='row' data-testid='missing-item'>{label.missing_item_data}</div>)
      }
    </>
  );
};

SelectTextPreview.propTypes = itemPreviewProps;

export default SelectTextPreview;
