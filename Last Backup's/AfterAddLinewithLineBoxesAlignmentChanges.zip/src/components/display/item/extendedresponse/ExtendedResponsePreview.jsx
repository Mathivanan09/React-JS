import React, { useState } from 'react';
import ResponseAlignment from '../shared/ResponseAlignment';
import { itemPreviewProps } from '../../../common/ItemHelper';
import CKEditorBase from '../../../common/editors/ckeditor/CKEditorBase';

import '../../../../styles/item/ExtendedResponsePreview.css';

/**
 * React functional component to display Extended Response click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace ExtendedResponsePreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Extended Response click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @param {Function} onClickHistoryUpdate - update the click history for preview
 * @return {component} - component for displaying Extended Response click item
 */

const ExtendedResponsePreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate
}) => {
  const [response, setResponse] = useState('');
  const itemJson = item?.item_json || {};

  let displayEditor = true;
  let linestyle = '';
  let configuration;

  if (itemJson.expectedLines === 'PAPER_PENCIL') {
    displayEditor = false;
  } else {
    configuration = itemJson.spellCheck ? {
      removePlugins: ['TagAccessibility']
    } : {
      wproofreader: null,
      removePlugins: ['TagAccessibility', 'WProofreader']
    };
    if (itemJson.expectedLines === "5LINES_EXT") {
      linestyle += 'five-lines-editor';
    } else if (itemJson.expectedLines === "10LINES_EXT") {
      linestyle += 'ten-lines-editor';
    } else { // default
      linestyle += 'twenty-lines-editor';
    }
  };

  const container = displayEditor ? 'extended-response-preview-container' : 'extended-response-preview-pnp-container';

  // Generate click history based on user selection
  /* istanbul ignore next */
  const generateClickHistory = (data) => {
    if (config?.clickHistoryRequired && clickHistory) {
      // For storing clickhistory
      clickHistory.push({
        score: null,
        responseoption: data,
        isCorrectResponse: null,
        ts: Date().toLocaleString()
      });

      if (onClickHistoryUpdate !== undefined) {
        onClickHistoryUpdate(clickHistory);
      }
    }
  }

  // Handle the user response
  /* istanbul ignore next */
  const handleResponse = (fieldName, data) => {
    onUpdate(fieldName, data);
    generateClickHistory(data);
    setResponse(data);
  }

  return (
    <>
      {item ? (
        <div className={'row pb-3 ' + container} data-testid={container}>
          <ResponseAlignment
            stem={itemJson?.stemContent}
            responses={
              displayEditor ?
                (
                  <CKEditorBase
                    data={response}
                    config={configuration}
                    className={linestyle}
                    fieldName='extendedResponse'
                    dataTestId='extended-response-editor'
                    onChange={handleResponse}
                  />
                ) :
                <></>
            }
            alignment={itemJson?.answerAlignment}
          />
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

ExtendedResponsePreview.propTypes = itemPreviewProps;

export default ExtendedResponsePreview;
