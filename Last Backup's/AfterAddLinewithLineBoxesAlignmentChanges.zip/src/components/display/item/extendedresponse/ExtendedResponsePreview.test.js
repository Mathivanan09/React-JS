import React from "react";
import { render } from '@testing-library/react';
import { unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";

// import component here
import ExtendedResponsePreview from './ExtendedResponsePreview';

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});
const config = { styleCode: 'general' }

const ER_RSS = require('../../../../../src/stories/assets/er/ExtendedResponse.json').item;
const ER_VS = require('../../../../../src/stories/assets/er/ExtendedResponseVerticalStack.json').item;
const ER_PNP = require('../../../../../src/stories/assets/er/ExtendedResponsePaperNPencil.json').item;

it("Should render base component", () => {
    act(() => {
        render(<ExtendedResponsePreview />, container);
    });

    // test the empty container
    const previewContainer = document.querySelector("[data-testid=missing-item]");
    expect(previewContainer).not.toBeNull();
    //   expect(previewContainer.children.length).toBe(2);
});

it("Check ER component with Right Side Vertical Alignment with Five Lines as Expected Lines data", () => {
    act(() => {
        render(
            <ExtendedResponsePreview
                item={ER_RSS}
                onUpdate={() => { }}
                config={config}
            />,
            container
        );
    });

    // check the ER preview container
    const previewContainer = document.querySelector("[data-testid=extended-response-preview-container]");
    expect(previewContainer).not.toBeNull();

    // check the alignment conatiner for both stem and response
    expect(previewContainer.children.length).toBe(1);
    const responseAlignment = document.querySelector("[data-testid=response-alignment]");
    expect(responseAlignment).not.toBeNull();
    expect(responseAlignment.children.length).toBe(2);

    // check the stem preview container and its style behaviour
    expect(document.querySelector("[data-testid=stem-content]")).not.toBeNull();
    expect(responseAlignment.children[0].className).toBe('col-6');

    // check the user response editor container and its style behaviour
    const extendedResponseEditor = document.querySelector("[data-testid=extended-response-editor]");
    expect(extendedResponseEditor).not.toBeNull();
    expect(extendedResponseEditor.classList.contains('five-lines-editor')).toBeTruthy();
    expect(responseAlignment.children[1].className).toBe('col-6');
});

it("Check ER component with Vertical Stack Alignment with Ten Lines as Expected Lines data", () => {
    act(() => {
        render(
            <ExtendedResponsePreview
                item={ER_VS}
                onUpdate={() => { }}
                config={config}
            />,
            container
        );
    });

    // check the ER preview container
    const previewContainer = document.querySelector("[data-testid=extended-response-preview-container]");
    expect(previewContainer).not.toBeNull();

    // check the alignment conatiner for both stem and response
    expect(previewContainer.children.length).toBe(1);
    const responseAlignment = document.querySelector("[data-testid=response-alignment]");
    expect(responseAlignment).not.toBeNull();
    expect(responseAlignment.children.length).toBe(2);

    // check the stem preview container and its style behaviour
    expect(document.querySelector("[data-testid=stem-content]")).not.toBeNull();
    expect(responseAlignment.children[0].className).toBe('row mx-1');

    // check the user response editor container and its style behaviour
    const extendedResponseEditor = document.querySelector("[data-testid=extended-response-editor]");
    expect(extendedResponseEditor).not.toBeNull();
    expect(extendedResponseEditor.classList.contains('ten-lines-editor')).toBeTruthy();
    expect(responseAlignment.children[1].className).toBe('row mx-1 mt-4');
});

it("Check ER component with Twenty Lines as Expected Lines and Vertical Stack Alignment as default data", () => {
    act(() => {
        render(
            <ExtendedResponsePreview
                item={{
                    ...ER_VS,
                    item_json: {
                        ...ER_VS.item_json,
                        spellCheck: false,
                        answerAlignment: null,
                        expectedLines: null
                    }
                }}
                onUpdate={() => { }}
                config={config}
            />,
            container
        );
    });

    const responseAlignment = document.querySelector("[data-testid=response-alignment]");
    expect(responseAlignment).not.toBeNull();

    // check the stem preview container and its style behaviour
    expect(document.querySelector("[data-testid=stem-content]")).not.toBeNull();
    expect(responseAlignment.children[0].className).toBe('row mx-1');

    // check the user response editor container and its style behaviour
    const extendedResponseEditor = document.querySelector("[data-testid=extended-response-editor]");
    expect(extendedResponseEditor).not.toBeNull();
    expect(extendedResponseEditor.classList.contains('twenty-lines-editor')).toBeTruthy();
    expect(responseAlignment.children[1].className).toBe('row mx-1 mt-4');
});

it("Check ER component with Paper and Pencil as Expected Lines and Vertical Stack Alignment data", () => {
    act(() => {
        render(
            <ExtendedResponsePreview
                item={{
                    ...ER_PNP,
                    item_json: {
                        ...ER_PNP.item_json,
                        answerAlignment: 'vertical_stacked',
                    }
                }}
                onUpdate={() => { }}
                config={config}
            />,
            container
        );
    });

    // check the ER preview container for no response
    expect(document.querySelector("[data-testid=extended-response-preview-pnp-container]")).not.toBeNull();
    const responseAlignment = document.querySelector("[data-testid=response-alignment]");

    // check the stem preview container and its style behaviour
    expect(document.querySelector("[data-testid=stem-content]")).not.toBeNull();
    expect(responseAlignment.children[0].className).toBe('row mx-1');

    // user response will be using the paper and pencil so there will no editor
    const extendedResponseEditor = document.querySelector("[data-testid=extended-response-editor]");
    expect(extendedResponseEditor).toBeNull();
    expect(responseAlignment.children[1].className).toBe('row mx-1 mt-4');
});
