import React, { useState } from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';
import BgGraphicResponse from '../../response/backgroundgraphic/BgGraphicResponse';

import '../../../../styles/item/BackgroundGraphicPreview.css';

/**
 * React functional component to display Background Graphic click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace BackgroundGraphicPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Background Graphic click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - BackgroundGraphicPreview component for displaying Background Graphic click item
 */

const BackgroundGraphicPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  const [studentResponse, setStudentResponse] = useState(null);
  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  const onDropResponse = (response) => {
    console.log('onDropResponse', response);
  };

  const onRemoveResponse = (response) => {
    console.log('onRemoveResponse', response);
  };


  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className={'row m-1'}>
            <StemFormatter stemContent={item.item_json?.stemContent} />
          </div>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <BgGraphicResponse
              item={item}
              onUpdate={onUpdate}
              onDropResponse={onDropResponse}
              showCorrectResponse={showCorrectResponse}
              onRemoveResponse={onRemoveResponse}
              isPreview={true}
            />
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

BackgroundGraphicPreview.propTypes = itemPreviewProps;

export default BackgroundGraphicPreview;
