import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import { fireEvent } from '@testing-library/react';

// import component here
import MultipleChoicePreview from './MultipleChoicePreview';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

let selectedValue = '';
let keyToUpdate = '';
const setSelectedValue = jest.fn().mockImplementation((updateKey, value) => {
  keyToUpdate = updateKey;
  selectedValue = value;
});


  const optionList = [
    {
      id: '8814f56-3adc-a35-6554-cceb6ef7cfc2',
      optionText: '<p id="cb-949629-6-55">Trapezoid</p>\n'
    },
    {
      id: '1bea8bd-f432-b2e1-2205-a6d6adc78de',
      optionText: '<p id="cb-168278-4-84">Rhombus</p>\n'
    },
    {
      id: '02270c0-642b-6cea-fe6a-02c107616ee6',
      optionText: '<p id="cb-710978-0-15">Rectangle</p>\n'
    }
  ];

  const correctResponse = [
    {
      id: '1bea8bd-f432-b2e1-2205-a6d6adc78de',
      value: true
    },
    {
      id: '02270c0-642b-6cea-fe6a-02c107616ee6',
      value: true
    },
    {
      id: '22bfbdf-32b5-3bcb-c-26eccc1a3',
      value: true
    },
    {
      id: '8814f56-3adc-a35-6554-cceb6ef7cfc2',
      value: false
    }
  ];

  const config = {styleCode:'alternate'}

  const MultiSelectMC = require('../../../../../src/stories/assets/mc/mc_multiple.json');

it("Should render base component", () => {
  act(() => {
    render(<MultipleChoicePreview />, container);
  });

  // test the empty container
  const previewContainer = document.querySelector("[data-testid=preview-container]");
  expect(previewContainer).not.toBeNull;
  expect(previewContainer.children.length).toBe(2);
});

it("Test stacked vertical alignment component", () => {
  let selectedValue = '';
  let keyToUpdate = '';
  const setSelectedValue = jest.fn().mockImplementation((updateKey, value) => {
    keyToUpdate = updateKey;
    selectedValue = value;
  });


  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 1,
            answerAlignment: 'vertical_stacked',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
      />,
      container
    );
  });
  const stackedZinput = document.querySelectorAll("[data-testid='stackedvertical-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput[0]);
  expect(keyToUpdate).toBe('8814f56-3adc-a35-6554-cceb6ef7cfc2');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
  fireEvent.click(stackedZinput[1]);
  const msgPreviewOkayButton = document.querySelector("[data-testid=mp-okay-button]");
  // Fix this test
  // expect(msgPreviewOkayButton.innerHTML).toBe("Okay");
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test stacked vertical alignment component", () => {
  let selectedValue = '';
  let keyToUpdate = '';
  const setSelectedValue = jest.fn().mockImplementation((updateKey, value) => {
    keyToUpdate = updateKey;
    selectedValue = value;
  });


  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 1,
            answerAlignment: 'vertical_stacked',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
      />,
      container
    );
  });
  const stackedZinput = document.querySelectorAll("[data-testid='stackedvertical-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput[0]);
  expect(keyToUpdate).toBe('8814f56-3adc-a35-6554-cceb6ef7cfc2');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;

  fireEvent.click(stackedZinput[1]);
  const msgPreviewOkayButton = document.querySelector("[data-testid=mp-okay-button]");
  // Fix this test
  // expect(msgPreviewOkayButton.innerHTML).toBe("Okay");
  // fireEvent.click(msgPreviewOkayButton);
  // expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});


it("Test stacked vertical alignment component", () => {
  let selectedValue = '';
  let keyToUpdate = '';
  let clickHistoryObj = {}
  const setSelectedValue = jest.fn().mockImplementation((updateKey, value) => {
    keyToUpdate = updateKey;
    selectedValue = value;
  });
  const updateClickHistory = jest.fn().mockImplementation((clickHistory) => {
     clickHistoryObj = {... clickHistory};
    // selectedValue = value;
  });
  let config = {
    clickHistoryRequired:true,
    selectionType:''
  }


  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 1,
            answerAlignment: 'vertical_stacked',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
        config={config}
        clickHistory={clickHistoryObj}
        onClickHistoryUpdate={updateClickHistory}

      />,
      container
    );
  });
  const stackedZinput = document.querySelectorAll("[data-testid='stackedvertical-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput[0]);
  expect(keyToUpdate).toBe('8814f56-3adc-a35-6554-cceb6ef7cfc2');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
  expect(clickHistoryObj.selectionType).toBe('multiple')
  expect(clickHistoryObj.options[0].optionId).toBe('8814f56-3adc-a35-6554-cceb6ef7cfc2')

  fireEvent.click(stackedZinput[1]);
  const msgPreviewOkayButton = document.querySelector("[data-testid=mp-okay-button]");
  // Fix this test
  // expect(msgPreviewOkayButton.innerHTML).toBe("Okay");
  // expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});



it("Test stacked Z alignment component", () => {

  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'stacked_z',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse,
            responseLabels: "No Response Label",
          }
        }}
        onUpdate={setSelectedValue}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='stackedz-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test stacked Z alignment component- Alternate", () => {
  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'stacked_z',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
        config={config}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='stackedz-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});


it("Test RightSide Z alignment component", () => {

  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'right_z',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse,
            responseLabels: "Letters",
            
          }
        }}
        onUpdate={setSelectedValue}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='rightsidez-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test RightSide Z alignment component - Alternate", () => {
  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'right_z',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
        config={config}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='rightsidez-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test Right Side Vertical alignment component", () => {

  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'right_vertical_stacked',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse,
            responseLabels: "Numbers",
            
          }
        }}
        onUpdate={setSelectedValue}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='rightsidevertical-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test Right Side Vertical alignment component- Alternate", () => {
  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'right_vertical_stacked',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
        config={config}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='rightsidevertical-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test Stacked Horizontal alignment component", () => {

  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'horizontal',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='stackedhorizontal-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});

it("Test Stacked Horizontal alignment component- Alternate", () => {
  act(() => {
    render(
      <MultipleChoicePreview
        item={{
          item_json: {
            maxSelections: 2,
            answerAlignment: 'horizontal',
            selectionType: 'multiple',
            optionList: optionList,
            correctResponse: correctResponse
          }
        }}
        onUpdate={setSelectedValue}
        config={config}
      />,
      container
    );
  });
  const stackedZinput = document.querySelector("[data-testid='stackedhorizontal-input-option']");
  expect(stackedZinput).not.toBeNull;
  fireEvent.click(stackedZinput);
  expect(selectedValue).toBe('');
  expect(setSelectedValue).toHaveBeenCalledTimes(1);
  expect(stackedZinput.checked).toBeTruthy;
});


