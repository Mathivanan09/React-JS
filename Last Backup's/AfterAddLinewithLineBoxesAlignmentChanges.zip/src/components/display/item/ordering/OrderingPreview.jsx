import React, { useState } from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

import OrderingResponse from '../../response/ordering/OrderingResponse';

import '../../../../styles/item/OrderingPreview.css';

/**
 * React functional component to display Ordering click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace OrderingPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Ordering click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - OrderingPreview component for displaying Ordering click item
 */

const OrderingPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  // state object of ordered responses
  const [ordered, setOrdered] = useState(item.item_json.optionList || []);

  const handleResponse = (orderedResponses) => {
    setOrdered(orderedResponses);
    // Updating history
    let clickHistoryObj = { ...clickHistory };
    if (config?.clickHistoryRequired) {
      clickHistoryObj.orderedResponses = orderedResponses;
    }
    onClickHistoryUpdate && onClickHistoryUpdate(clickHistoryObj);
  };

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className={'row m-1'}>
            <StemFormatter stemContent={item.item_json?.stemContent} />
          </div>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <OrderingResponse
              item={item}
              onUpdate={handleResponse}
              config={config}
              showCorrectResponse={showCorrectResponse}
              isPreview={true}
              clickHistory={clickHistory}
              onClickHistoryUpdate={onClickHistoryUpdate}
              ordered={ordered}
            />
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

OrderingPreview.propTypes = itemPreviewProps;

export default OrderingPreview;
