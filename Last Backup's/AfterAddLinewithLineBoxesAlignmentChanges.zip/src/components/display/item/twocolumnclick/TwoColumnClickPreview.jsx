import React, { useState } from 'react';
import contentParser from '../../../../utility/contentParser';
import StemFormatter from '../shared/StemFormatter';
import PropTypes from 'prop-types';
import Tabs from './Tabs';

import '../../../../styles/item/TwoColumnClickPreview.css';

/**
 * React functional component to display two column click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace TwoColumnClickPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying two column click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside, if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - TwoColumnClickPreview component for displaying two column click item
 */

const TwoColumnClickPreview = ({ item, onUpdate, config, clickHistory }) => {
  const itemJson = item?.item_json || {};
  const title = itemJson?.title;
  const optionList = itemJson?.optionList || [];
  const answerAlignment = itemJson?.answerAlignment;
  const [selectedTabIndex, setSelectedTabIndex] = useState(0);
  const [selectedSubTabIndex, setSelectedSubTabIndex] = useState(0);
  const [rightView, setRightView] = useState(
    (optionList && optionList[0]?.items[0]?.right) || ''
  );

  const columnType = itemJson?.columnType;
  const leftColWidth = itemJson?.column1;
  const subTabColWidth = itemJson?.column2;
  const rightColWidth =
    columnType === 'twocolumn' ? itemJson?.column2 : itemJson?.column3;

  // For storing clickhistory

  if (config?.clickHistoryRequired && clickHistory) {
    clickHistory.numberOfColumns = columnType;
  }
  let styles = {};
  if (answerAlignment === 'vertical_stacked') {
    styles = {
      width: `${rightColWidth}%`,
      padding: '10px'
    };
  }
  let titleClassName = 'row';
  if (title !== '<p>&nbsp;</p>' && title !== "") {
    if (answerAlignment === 'horizontal_stacked') {
      titleClassName = 'row tcc-top-bar';
    }
    else {
      titleClassName = 'tcc-top-bar';
    }
  }
  return (
    <div data-testid='preview-container'>
      <StemFormatter stemContent={itemJson?.stemContent} />
      <div className='tcc-preivew m-3' style={answerAlignment === 'horizontal_stacked' ? { border: 'none' } : {}} data-testid='tcc-preivew'>
        <div id='title-text' className={titleClassName} data-testid='tcc-title'>
          {itemJson?.title && contentParser(title)}
        </div>
        <div className={answerAlignment === 'vertical_stacked' && 'tcc-columns-wrapper'} data-testid='tcc-tab-container'>
          {optionList?.length >= 0 && columnType && (
            <>
              {/* Tab */}
              <div
                className={answerAlignment === 'horizontal_stacked' ? 'row tcc-horizontal' : 'tcc-column'}
                style={answerAlignment === 'horizontal_stacked' ? { border: 'none' } : { flexBasis: leftColWidth + '%' }}
                data-testid='tcc-tab-left'
                role='tablist'
              >
                {optionList?.map((tabItem, index) => (
                  <React.Fragment key={tabItem?.id}>
                    <Tabs
                      tabItem={tabItem}
                      index={index}
                      answerAlignment={itemJson?.answerAlignment}
                      leftColWidth={leftColWidth}
                      columnType={columnType}
                      itemsSize={optionList?.length}
                      selectedTabIndex={selectedTabIndex}
                      setSelectedTabIndex={setSelectedTabIndex}
                      selectedSubTabIndex={selectedSubTabIndex}
                      setSelectedSubTabIndex={setSelectedSubTabIndex}
                      setRightView={setRightView}
                      clickHistory={
                        (config?.clickHistoryRequired && clickHistory) || null
                      }
                      tabLength={optionList?.length}
                    />
                  </React.Fragment>
                ))}
              </div>

              {/* Sub-tab */}
              {columnType === 'threecolumn' && (
                <div
                  className={answerAlignment === 'horizontal_stacked' ? 'row tcc-horizontal' : 'tcc-column'}
                  style={answerAlignment === 'horizontal_stacked' ? { border: 'none' } : { flexBasis: `${subTabColWidth}%` }}
                  data-testid='tcc-sub-tab-middle'
                  role='tablist'
                >
                  {optionList[selectedTabIndex]?.items?.map((tabItem, index) => (
                    <React.Fragment key={tabItem?.id}>
                      <Tabs
                        tabItem={tabItem}
                        index={index}
                        answerAlignment={itemJson?.answerAlignment}
                        leftColWidth={subTabColWidth}
                        columnType={columnType}
                        isSubTab={true}
                        itemsSize={optionList?.length}
                        selectedTabIndex={selectedTabIndex}
                        setSelectedTabIndex={setSelectedTabIndex}
                        selectedSubTabIndex={selectedSubTabIndex}
                        setSelectedSubTabIndex={setSelectedSubTabIndex}
                        setRightView={setRightView}
                        mainIndex={optionList[selectedTabIndex]?.index}
                        clickHistory={
                          (config?.clickHistoryRequired && clickHistory) || null
                        }
                        tabLength={optionList[selectedTabIndex]?.items?.length}
                      />
                    </React.Fragment>
                  ))}
                </div>
              )}

              {/* Right View */}
              <div
                id='tcc-sub-tab-right'
                className={answerAlignment === 'horizontal_stacked' ? 'row tcc-horizontal-col' : 'tcc-column tcc-rightview'}
                style={styles}
                data-testid='tcc-sub-tab-right'
                role='tabpanel'
                tabIndex={0}
              >
                {rightView && (
                  <div
                    style={{ position: 'relative', top: 6 }}
                    data-testid='tcc-sub-tab-description'
                  >
                    {contentParser(rightView)}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

TwoColumnClickPreview.propTypes = {
  item: PropTypes.object,
  onUpdate: PropTypes.func,
  config: PropTypes.object,
  clickHistory: PropTypes.object
};

export default TwoColumnClickPreview;
