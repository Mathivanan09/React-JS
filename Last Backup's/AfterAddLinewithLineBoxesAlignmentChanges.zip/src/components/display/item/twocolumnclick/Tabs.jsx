import React from 'react';
import PropTypes from 'prop-types';
import contentParser from '../../../../utility/contentParser';

/**
 * React functional component to build the tab content for Two Column Click Item Preview
 *
 * @inner
 * @memberof TwoColumnClickPreview
 *
 * @component
 * @namespace Tabs
 *
 * @param {JSON} tabItem - JSON data that will contain the item information
 * for displaying Tab/Sub-Tab of the Two Column Click Item
 * @param {Number} index - index of Tab/Sub-Tab.
 * @param {String} columnType - selected column type code
 * @param {Boolean} isSubTab - is this called for Tab or Sub-Tab.
 * If True then meant for Tab else for Sub-Tab, default false.
 * @param {Number} itemsSize - size of the main optionList
 * @param {Number} selectedTabIndex - index of the selected tab
 * @param {function} setSelectedTabIndex - set the new index of the selected tab
 * @param {Number} selectedSubTabIndex - index of the selected sub-tab
 * @param {function} setSelectedSubTabIndex - set the new index of the selected sub-tab
 * @param {function} setRightView - set the right view of the selected tab/sub-tab
 * @param {Number} mainIndex - tab main index for the respective sub-tab
 * @param {object} clickHistory - click history
 * @return {component} - tab/sub-tab to displaying for two column click item
 */
const Tabs = ({
  tabItem,
  index,
  answerAlignment,
  leftColWidth,
  columnType,
  isSubTab = false,
  itemsSize,
  selectedTabIndex,
  setSelectedTabIndex,
  selectedSubTabIndex,
  setSelectedSubTabIndex,
  setRightView,
  mainIndex,
  clickHistory,
  tabLength
}) => {
  const firstItem = tabItem?.items && tabItem?.items[0];
  const itemContent =
    columnType === 'threecolumn' && !isSubTab
      ? tabItem?.header
      : isSubTab
        ? tabItem?.left
        : firstItem?.left;

  const selectTab = (e) => {
    if (e.type === 'click' || e.code === 'Enter') {
      // to support accessbility
      // handles setting the clicked tab as selected for either 2 or 3 column view
      if (isSubTab) {
        setSelectedSubTabIndex(index);
        setRightView(tabItem?.right);
      } else {
        setSelectedTabIndex(index);
        setSelectedSubTabIndex(0);
        setRightView(firstItem?.right);
      }

      // Updating the history on clicking the tab options
      if (clickHistory) {
        const historyOption = {
          optionId: tabItem?.id
        };
        if (!clickHistory.options) {
          clickHistory.options = [];
        }
        clickHistory.options.push(historyOption);
      }
    }
  };

  let controlId = 'tcc-sub-tab-right';
  if (columnType === 'threecolumn') {
    if (!isSubTab) {
      controlId = firstItem?.id;
    }
  }

  // highlight tab when it is selected
  const tabSelected =
    (index === selectedTabIndex && !isSubTab) ||
    (isSubTab && index === selectedSubTabIndex);

  const width = 100 / tabLength;
  const styles = {
    backgroundColor: tabSelected ? '#c8e5f3' : '#FFF',
    width: answerAlignment === 'horizontal_stacked' && itemContent !== '' && `${width}%`,
  };

  const menuType = isSubTab ? 'sub-tab-' : 'tab-';
  const code = menuType + (isSubTab ? itemsSize + index + 1 : index + 1);
  const testId =
    'tcc-' + (isSubTab ? 'sub-tab-menu-' + (mainIndex + 1) + '-' : 'tab-menu-');

  return (
    <div
      id={tabItem?.id}
      onClick={selectTab}
      onKeyDown={selectTab} // for screenreaders
      style={styles}
      className={answerAlignment === 'horizontal_stacked' ? 'two-column-horizontal tcc-bold-text' : 'tcc-tab tcc-bold-text'}
      key={code}
      role='tab'
      tabIndex={0}
      aria-label={code}
      data-testid={testId + (index + 1)}
      aria-selected={tabSelected}
      aria-controls={controlId}
    >
      {itemContent && (
        <div
          className='tcc-tab-content'
          data-testid={testId + 'content-' + (index + 1)}
        >
          {contentParser(itemContent)}
        </div>
      )}
    </div>
  );
};

Tabs.propTypes = {
  tabItem: PropTypes.object,
  index: PropTypes.number,
  columnType: PropTypes.string,
  isSubTab: PropTypes.bool,
  itemsSize: PropTypes.number,
  selectedTabIndex: PropTypes.number,
  setSelectedTabIndex: PropTypes.func,
  selectedSubTabIndex: PropTypes.number,
  setSelectedSubTabIndex: PropTypes.func,
  setRightView: PropTypes.func,
  mainIndex: PropTypes.number,
  clickHistory: PropTypes.object
};

export default Tabs;
