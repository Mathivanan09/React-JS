import React from 'react';
import PropTypes from 'prop-types';
import StemFormatter from './StemFormatter';

/**
 * React functional component that applies response alignment to the respective Item.
 *
 * @component
 * @namespace ResponseAlignment
 * @param {{ stem: string, responses: component, alignment: string, dataTestId: string}} param passed in parameters
 * @param {string} param.stem - stem content to be rendered
 * @param {component} param.responses - response component that needs to be rendered
 * @param {string} param.alignment - selected alignment type, vertical stack as default value
 * @param {string} param.dataTestId - optional, test id to the container for testing purpose, response-alignment as default value
 * @return {component} - Item rendered with respective of the selected alignment type
 *
 */

const ResponseAlignment = ({
    stem,
    responses,
    alignment,
    dataTestId = 'response-alignment'
}) => {

    let stemClasses = 'col';
    let responseClass = 'col';

    // TODO - Currently supports Right Side Vertical and Stacked Vertical only, can be implement the others later when needed.
    if (alignment === 'right_vertical_stacked') {
        stemClasses = 'col-6';
        responseClass = 'col-6';
    } else { // vertical_stacked is default alignment
        stemClasses = 'row mx-1';
        responseClass = 'row mx-1 mt-4';
    }

    return (
        <div className='row' data-testid={dataTestId}>
            <div className={stemClasses}>
                <StemFormatter stemContent={stem} />
            </div>
            <div className={responseClass}>
                <div className='item-content p-4 content_style'>{responses}</div>
            </div>
        </div >
    );
};

ResponseAlignment.propTypes = {
    stem: PropTypes.string,
    responses: PropTypes.element,
    alignment: PropTypes.string
};

export default ResponseAlignment;
