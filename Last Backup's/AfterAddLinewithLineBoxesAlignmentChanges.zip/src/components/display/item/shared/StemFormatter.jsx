import React from 'react';
import PropTypes from 'prop-types';
import contentParser from '../../../../utility/contentParser';
import '../../../../styles/item/StemContent.css';


/**
 * React functional component to display the stem content 
 * 
 * @inner
 * @memberof BasicInputComponents 
 * 
 * @component
 * @namespace StemFormatter
 * 
 * @param {string} stemContent - String containing the stem content that need to be 
 * displayed in stem
 * @return {component} - component which renders and display stem content
 * 
 * example:
 * <StemFormatter stemContent={stemContent} />
 */

const StemFormatter = ({ stemContent, dataTestId = "stem-content" }) => {
  const data = stemContent || '<div></div>';

  // This is to display the stem content
  return (
    <>
      <div className="stem-content p-4" data-testid={dataTestId}>
        {contentParser(data)}
      </div>
    </>
  );
};

StemFormatter.propTypes = {
  stemContent: PropTypes.string,
  dataTestId: PropTypes.string
};

export default StemFormatter;
