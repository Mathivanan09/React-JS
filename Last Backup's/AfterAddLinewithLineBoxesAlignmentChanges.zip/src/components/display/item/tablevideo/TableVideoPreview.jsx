import React from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

import '../../../../styles/item/TableVideoPreview.css';
import TableVideoResponse from '../../response/tablevideo/TableVideoResponse';

/**
 * React functional component to display Table Video click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace TableVideoPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Table Video click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - TableVideoPreview component for displaying Table Video click item
 */

const TableVideoPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className={'row m-1 content_style'}>
            <StemFormatter stemContent={item.item_json?.stemContent} />
          </div>
          <div className='row item-content m-1 mt-4 p-4'>
            <TableVideoResponse
              item={item}
              config={config}
              showCorrectResponse={showCorrectResponse}
              isPreview={true}
            ></TableVideoResponse>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

TableVideoPreview.propTypes = itemPreviewProps;

export default TableVideoPreview;
