import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import { act } from "react-dom/test-utils";
import { fireEvent } from '@testing-library/react';

// import component here
import LineGraphPreview from './LineGraphPreview';

let container = null;
beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});
const config = { styleCode: 'general' }

const defaultJSON = require('../../../../../src/stories/assets/lg/LineGraph.json');

it("Should render base component", () => {
    act(() => {
        render(<LineGraphPreview />, container);
    });

    // test the empty container
    const previewContainer = document.querySelector("[data-testid=preview-container]");
    expect(previewContainer).not.toBeNull;
    //   expect(previewContainer.children.length).toBe(2);
});