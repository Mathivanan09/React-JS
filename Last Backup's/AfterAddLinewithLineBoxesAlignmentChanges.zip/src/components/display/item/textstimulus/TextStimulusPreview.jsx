import React from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

import '../../../../styles/item/TextStimulusPreview.css';

/**
 * React functional component to display Text Stimulus click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace TextStimulusPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Text Stimulus click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - TextStimulusPreview component for displaying Text Stimulus click item
 */

const TextStimulusPreview = ({
  item,
  onUpdate,
  config
}) => {

  const passageContent = item?.item_json?.passageContent;
  const acknowledgeContent = item?.item_json?.source?.acknowledge;
  let stemData;

  if (acknowledgeContent === null) {
    stemData = passageContent;
  }
  else {
    stemData = passageContent.concat(`<hr class='newhr'></hr>`, acknowledgeContent);
  }

  return (
    <>
      {item ? (
        <div data-testid='ts-preview-container'>
          <StemFormatter stemContent={stemData} />
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

TextStimulusPreview.propTypes = itemPreviewProps;

export default TextStimulusPreview;
