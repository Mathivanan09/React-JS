import React from 'react';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

import '../../../../styles/item/ActingForcesPreview.css';

/**
 * React functional component to display Acting Forces click item
 *
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace ActingForcesPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Acting Forces click item
 * @param {function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {object} clickHistory - click history
 * @return {component} - ActingForcesPreview component for displaying Acting Forces click item
 */

const ActingForcesPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {
  const defaultSelections = [
    { name: 'tag', dataTestId: 'af-tag'},
    { name: 'circle', dataTestId: 'af-circle'},
    { name: 'arrow', dataTestId: 'af-arrow'},
    { name: 'triangle', dataTestId: 'af-triangle'},
    { name: 'square', dataTestId: 'af-square'},
    { name: 'plus', dataTestId: 'af-plus'}
  ];

  // For storing clickhistory
  if (config?.clickHistoryRequired && clickHistory) {
    // TODO
  }

  const clearSimulation = (e) => {
    // TODO clear simulation
  };

  return (
    <>
      {item ? (
        <div data-testid='preview-container'>
          <div className={'row m-1'}>
            <StemFormatter stemContent={item.item_json?.stemContent} />
          </div>
          <div className='row item-content m-1 mt-4 p-4 content_style'>
            <div className='col-12 text-end'>
              <button
                variant='primary'
                data-testid='mp-okay-button'
                onClick={clearSimulation}
              >
                Clear Data
              </button>
            </div>
            <div
              className='col mt-4 p-4'
              style={
                item.item_json.backgroundURL
                  ? {
                      backgroundImage: `url(${item.item_json.backgroundURL})`,
                      height: item.item_json.minItemHeight
                        ? `${item.item_json.minItemHeight}px`
                        : '500px',
                      width: item.item_json.minItemWidth
                        ? `${item.item_json.minItemWidth}px`
                        : '500px',
                      backgroundPosition: 'center',
                      backgroundRepeat: 'no-repeat'
                    }
                  : {}
              }
            ></div>
            <div className='row mt-4 p-4'>
              {defaultSelections.map((selection) => {
                if (
                  item.item_json.rowList.defaultSelection.includes(
                    selection.name
                  )
                ) {
                  return (
                    <div
                      sm={12}
                      md={6}
                      lg={4}
                      className='col mt-2 align-items-center w-auto d-flex'
                      key={selection.name}
                    >
                      <div className='p-2 shadow rounded m-2'>
                        <span></span>
                      </div>
                    </div>
                  );
                }
                return null;
              })}
              {item.item_json?.rowList?.customSelection?.map(
                (selection, index) => {
                  return (
                    <div
                      sm={12}
                      md={6}
                      lg={4}
                      className='col mt-2 align-items-center w-auto d-flex'
                      key={index}
                    >
                      <div className='p-2 shadow rounded m-2'>
                        <img
                          src={selection.imageURL}
                          alt={selection.name}
                          style={{ width: '100px', height: '100px' }}
                        />
                      </div>
                    </div>
                  );
                }
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

ActingForcesPreview.propTypes = itemPreviewProps;

export default ActingForcesPreview;
