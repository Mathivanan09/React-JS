import React from 'react';
import PropTypes from 'prop-types';

import DisplayInterface from '../../DisplayInterface';
import contentParser from '../../../../utility/contentParser';

import { itemPreviewProps } from '../../../common/ItemHelper';

import '../../../../styles/item/CompositeItemsPreview.css';

/**
 * React functional component to display Composite click item
 *
 * @memberof CompositeItemsPreview
 * @inner
 *
 * @namespace CompositeItem
 * @param {JSON} item - Item JSON data
 * @param {JSON} header - item header information
 * @param {Function} onUpdate - the function that needs to be called, 
 * if there is any change in the state of the item
 * @param {Object} config - configuration data that comes from outside, 
 * if anything needs to be customized can sent to preview
 * @param {Object} clickHistory - click history for preview
 * @param {Function} onClickHistoryUpdate - update the click history for preview
 * @param {Boolean} showCorrectResponse - show the correct response or not for the item
 * @param {Boolean} responseOnly - display the correct response only or not for the item 
 * @return {Component} - component for displaying Composite Items
 */

const CompositeItem = ({
    item,
    header,
    onUpdate = () => { },
    config = {},
    clickHistory,
    onClickHistoryUpdate,
    showCorrectResponse = false,
    responseOnly = false
}) => {
    const classes = {
        container: responseOnly ? 'display-response-only-container' : 'display-preview-container',
        header: 'item-header-container p-3 pb-0 0 rounded-top',
        body: 'item-body-container rounded'
    };

    classes.body = header ? classes.body : 'p-3 pb-0 rounded';

    return (
        <div
            className='row item-preview-container rounded m-1 mt-3 pb-2 ms-0'
            data-testid='item-preview-container'
        >
            <div className={`container-fluid container ${classes.container}`}>
                {
                    header &&
                    <div className={`row ${classes.header}`}>
                        {
                            contentParser(header)
                        }
                    </div>
                }
                <div className={`row ${classes.body}`}>
                    <form>
                        <DisplayInterface
                            item={item}
                            config={config}
                            onUpdate={onUpdate}
                            showCorrectResponse={showCorrectResponse}
                            clickHistory={clickHistory}
                            onClickHistoryUpdate={onClickHistoryUpdate}
                        />
                    </form>
                </div>
            </div>
        </div>
    );
};

const CompositeItemProps = { ...itemPreviewProps };
CompositeItemProps.responseOnly = PropTypes.bool;
CompositeItem.propTypes = CompositeItemProps;

export default CompositeItem;
