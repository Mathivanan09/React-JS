import React from 'react';

import CompositeItem from './CompositeItem';

import StemFormatter from '../shared/StemFormatter';
import label from '../../../../constants/labelCodes';
import { itemPreviewProps } from '../../../common/ItemHelper';

/**
 * React functional component - to Preview the Composite Items Functionality or to display the Correct Response of the Composite Items
 * 
 * 
 * @memberof PreviewComponents
 * @inner
 *
 * @namespace CompositeItemsPreview
 * @param {JSON} item - JSON data that will contain the item information
 * for displaying Composite
 * @param {Function} onUpdate - the function that needs to be called
 * if there is any change in the state of the item
 * @param {Object} config - configuration data that comes from outside,
 * if anything needs to be customized can sent to preview
 * @param {Object} clickHistory - click history for preview
 * @param {Function} onClickHistoryUpdate - update the click history for preview
 * @param {Boolean} showCorrectResponse - define show correct response or not for preview
 * @return {Component} - component for displaying Composite Items
 */

const CompositeItemsPreview = ({
  item,
  onUpdate,
  config,
  clickHistory,
  onClickHistoryUpdate,
  showCorrectResponse
}) => {

  const itemJson = { ...(item?.item_json || {}) };
  const itemList = (itemJson?.itemList || []);

  const onChangeHistoryUpdate = (history, index, data) => {
    if (config?.clickHistoryRequired) {
      let clickHistoryObj = { ...(clickHistory || {}) };
      if (clickHistoryObj.response === undefined) {
        clickHistoryObj.response = [];
      }
      history.itemId = data.id;
      history.itemTypeCode = data?.item_json?.itemTypeCode;
      history.order = index;
      clickHistoryObj.response.push(history);
      onClickHistoryUpdate(clickHistoryObj);
    }
  };

  const updateItemJson = (data, index, args) => {
    if (onUpdate) {
      const itemId = data.id;
      const itemTypeCode = data?.item_json?.itemTypeCode;
      onUpdate(itemId, itemTypeCode, index, args);
    }
  };

  return (
    <>
      {item?.item_json ? (
        <div className='composite-item-preview-container pb-2' data-testid='composite-item-preview-container'>
          <div className='row m-1 ms-0'>
            <StemFormatter stemContent={itemJson?.stemContent} dataTestId='composite-stem-content' />
          </div>
          {
            itemList?.map((data, index) => {
              let composite = data;
              if (typeof composite?.item_json === 'object') {
                composite.item_json = {
                  ...composite.item_json,
                  minItemWidth: 0,
                  minItemHeight: 0
                };
              };
              return (
                <CompositeItem
                  key={composite?.id+'-'+index}
                  item={composite}
                  header={itemList[index].header}
                  onUpdate={(...args) => updateItemJson(data, index, args)}
                  config={config}
                  clickHistory={clickHistory}
                  onClickHistoryUpdate={(history) => {
                    onChangeHistoryUpdate(history, index, data)
                  }}
                  showCorrectResponse={showCorrectResponse}
                />
              );
            })
          }
        </div>
      ) : (
        <div className='row' data-testid='missing-item'>{label.missing_item_data}</div>
      )}
    </>
  );
};

CompositeItemsPreview.propTypes = itemPreviewProps;

export default CompositeItemsPreview;
