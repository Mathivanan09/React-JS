import React from "react";
import { unmountComponentAtNode } from "react-dom";
import { render, screen } from '@testing-library/react';
import { act } from "react-dom/test-utils";

// import component here
import CompositeItemsPreview from './CompositeItemsPreview';
import CompositeItem from './CompositeItem';

const item = require('../../../../../src/stories/assets/com/CompositeItems.json').item;
import DummyItems from "../../../../../src/stories/assets/com/DummyItems.json";
import MCMS from "../../../../../src/stories/assets/mc/mc_multiple.json";
import TF from "../../../../../src/stories/assets/mc/mc_true_false.json";

let container = null;

const config = { styleCode: 'general' }

const itemList = JSON.parse(JSON.stringify(DummyItems)).filter(item => item.category === "question");
itemList[0] = { ...MCMS?.item, ...itemList[0] };
itemList[1] = { ...TF?.item, ...itemList[1] };
item.item_json.itemList = itemList;

beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

describe('Check the Composite Item Preview Functionality', () => {

    test("Should render base component", () => {
        act(() => {
            render(
                <CompositeItemsPreview />,
                container
            );
        });

        expect(screen.getByTestId("missing-item")).toBeInTheDocument();
    });

    test("Check the Component Item Preview", () => {
        // set up test mock function
        const onUpdate = jest.fn(data => {
            compositeItem = data
        });
        act(() => {
            render(
                <CompositeItemsPreview
                    item={item}
                    onUpdate={onUpdate}
                    config={config}
                    clickHistory={{}}
                    onClickHistoryUpdate={() => { }}
                    showCorrectResponse={true}
                />,
                container
            );
        });

        expect(screen.getByTestId("composite-item-preview-container")).toBeInTheDocument();
        expect(screen.getByTestId("composite-stem-content")).toBeInTheDocument();
        expect(document.querySelectorAll("[data-testid=item-preview-container]")?.length).toBe(2);
        expect(document.querySelectorAll('.composite-item-preview-container .item-body-container .item-display-container')?.length).toBe(2);
    });

    test("Check the Component Item Functionality and Show Correct Response as False", () => {
        // set up test mock function
        const onUpdate = jest.fn(data => {
            compositeItem = data
        });
        act(() => {
            render(
                <CompositeItemsPreview
                    item={item}
                    onUpdate={onUpdate}
                    config={config}
                    clickHistory={{}}
                    onClickHistoryUpdate={() => { }}
                    showCorrectResponse={false}
                />,
                container
            );
        });

        expect(screen.getByTestId("composite-item-preview-container")).toBeInTheDocument();
        expect(screen.getByTestId("composite-stem-content")).toBeInTheDocument();
        expect(document.querySelector('.composite-item-preview-container .item-preview-container')).toBeInTheDocument();
        expect(document.querySelectorAll('.composite-item-preview-container .item-body-container .item-display-container')?.length).toBe(2);
    });

    test("Check the Component Item Functionality with Display Correct Response", () => {
        // set up test mock function
        const onUpdate = jest.fn(data => {
            compositeItem = data
        });
        act(() => {
            render(
                <CompositeItem
                    item={itemList[0]}
                    header={itemList[0].header}
                    onUpdate={onUpdate}
                    config={config}
                    showCorrectResponse={true}
                    responseOnly={true}
                />,
                container
            );
        });

        expect(document.querySelectorAll('.composite-item-preview-container')?.length).toBe(0);
        expect(screen.getByTestId("item-preview-container")).toBeInTheDocument();
        expect(document.querySelectorAll('.item-body-container .item-display-container')?.length).toBe(1);
    });
});