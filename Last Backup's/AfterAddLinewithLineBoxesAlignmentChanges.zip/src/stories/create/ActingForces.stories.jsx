import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/ActingForces',
  component: ItemLoader
};
