import React from 'react';

import MultipleChoice from '../../../components/create/multiplechoice/MultipleChoice';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Create Items/Alternate/MultipleChoice',
  component: MultipleChoice,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const alternateConfig = {
  styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateAlt = (args) => <MultipleChoice {...args} config={alternateConfig}/>;

// multiple choice alternate
export const MCAlternate = TemplateAlt.bind({});
MCAlternate.args = {
  item: { item_json: { itemTypeCode: 'mc' } },
  onUpdate: (content) => {
    console.log(content);
  }
};