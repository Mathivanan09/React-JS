import React from 'react';

import ML from '../../assets/ml/MatchingLines.json';
import MatchingLines from '../../../components/create/matchinglines/MatchingLines';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/Alternate/MatchingLines',
    component: MatchingLines,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const alternateConfig = {
    styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateAlt = (args) => <MatchingLines {...args} config={alternateConfig} />;

// Matching Lines alternate
export const MLAlternate = TemplateAlt.bind({});
MLAlternate.args = {
    item: {
        ...ML
    },
    onUpdate: (content) => {
        console.log(content);
    }
};