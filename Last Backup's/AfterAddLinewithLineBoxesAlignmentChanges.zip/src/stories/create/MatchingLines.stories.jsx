import ItemLoader from '../ItemLoader';
import uuid from 'react-uuid';

export default {
  title: 'Create Items/MatchingLines',
  component: ItemLoader
};

const Template = (args) => (
  <ItemLoader
    {...args}
    newItem={true}
    data={{
      item: {
        id: -1,
        name: '',
        assessment_program_id: 0,
        item_type_id: 0,
        item_type_code: '',
        item_json: {
          itemTypeCode: 'ml',
          dimensions: {
            width: 150,
            height: 35
          },
          leftTitle: "",
          rightTitle: "",
          optionList: [
            {
              id: uuid(),
              optionText: ""
            },
          ],
          matchList: [
            {
              id: uuid(),
              optionText: ""
            },
          ],
          correctResponse: [],
        },
        rationale: {
          id: uuid(),
          optionRationales: []

        },
        user_id: 0
      }
    }}
  ></ItemLoader>
);

export const NewItem = Template.bind({});
