import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/BackgroundGraphic',
  component: ItemLoader
};
