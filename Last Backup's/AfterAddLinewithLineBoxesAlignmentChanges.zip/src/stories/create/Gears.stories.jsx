import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/Gears',
  component: ItemLoader
};
