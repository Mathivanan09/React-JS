import React from 'react';

import ML from '../../assets/ml/MatchingLines.json';
import MatchingLines from '../../../components/create/matchinglines/MatchingLines';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/KELPA_Grade_K-1/MatchingLines',
    component: MatchingLines,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG1Config = {
    styleCode: 'kelpa_grade_k_1'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG1 = (args) => <MatchingLines {...args} config={kelpaG1Config} />;

// Matching Lines kelpaG1
export const MLKelpaG1 = TemplateKelpaG1.bind({});
MLKelpaG1.args = {
    item: {
        ...ML
    },
    onUpdate: (content) => {
        console.log(content);
    }
};