import React from 'react';
import data from '../assets/st/select_text_manual_selection.json';
import ItemLoader from '../ItemLoader';

export default {
  title: 'Create Items/SelectText',
  component: ItemLoader
};

const Template = (args) => (
  <ItemLoader
    {...args}
    newItem={true}
    data={data}
  ></ItemLoader>
);

export const NewItem = Template.bind({});
