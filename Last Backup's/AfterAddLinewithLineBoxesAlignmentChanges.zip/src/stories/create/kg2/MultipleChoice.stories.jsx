import React from 'react';

import MultipleChoice from '../../../components/create/multiplechoice/MultipleChoice';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Create Items/KELPA_Grade_2-3/MultipleChoice',
  component: MultipleChoice,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const kelpaG2Config = {
  styleCode: 'kelpa_grade_2_3'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG2 = (args) => <MultipleChoice {...args} config={kelpaG2Config}/>;

// multiple choice kelpaG2
export const MCKelpaG2 = TemplateKelpaG2.bind({});
MCKelpaG2.args = {
  item: { item_json: { itemTypeCode: 'mc' } },
  onUpdate: (content) => {
    console.log(content);
  }
};