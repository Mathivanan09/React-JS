import React from 'react';

import TextStimulus from '../../../components/create/textstimulus/TextStimulus';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/KELPA_Grade_4-12/TextStimulus',
    component: TextStimulus,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG4Config = {
    styleCode: 'kelpa_grade_4_12'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG4 = (args) => <TextStimulus {...args} config={kelpaG4Config} />;

// Text Stimulus kelpaG4
export const TSKelpaG4 = TemplateKelpaG4.bind({});
TSKelpaG4.args = {
    item: { item_json: { itemTypeCode: 'ts' } },
    onUpdate: (content) => {
        console.log(content);
    }
};