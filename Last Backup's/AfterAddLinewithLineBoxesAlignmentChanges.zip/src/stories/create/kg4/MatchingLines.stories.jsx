import React from 'react';

import ML from '../../assets/ml/MatchingLines.json';
import MatchingLines from '../../../components/create/matchinglines/MatchingLines';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Create Items/KELPA_Grade_4-12/MatchingLines',
    component: MatchingLines,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG4Config = {
    styleCode: 'kelpa_grade_4_12'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG4 = (args) => <MatchingLines {...args} config={kelpaG4Config} />;

// Matching Lines kelpaG4
export const MLKelpaG4 = TemplateKelpaG4.bind({});
MLKelpaG4.args = {
    item: {
        ...ML
    },
    onUpdate: (content) => {
        console.log(content);
    }
};