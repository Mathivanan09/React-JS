import React from 'react';

import MultipleChoice from '../../../components/create/multiplechoice/MultipleChoice';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Create Items/KELPA_Grade_4-12/MultipleChoice',
  component: MultipleChoice,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const kelpaG4Config = {
  styleCode: 'kelpa_grade_4_12'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG4 = (args) => <MultipleChoice {...args} config={kelpaG4Config}/>;

// multiple choice kelpaG4
export const MCKelpaG4 = TemplateKelpaG4.bind({});
MCKelpaG4.args = {
  item: { item_json: { itemTypeCode: 'mc' } },
  onUpdate: (content) => {
    console.log(content);
  }
};