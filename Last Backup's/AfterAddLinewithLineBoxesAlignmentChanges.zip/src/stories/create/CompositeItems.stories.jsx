import React from 'react';
import ItemLoader from '../ItemLoader';

// Existing Dummy Item Types Category (like questions)
import DummyItems from "../assets/com/DummyItems.json";

import MCMS from "../assets/mc/mc_multiple.json";
import TF from "../assets/mc/mc_true_false.json";
import TCC_TWO from "../assets/tcc/tcc_two_column.json";
import TCC_THREE from "../assets/tcc/tcc_three_column.json";

export default {
  title: 'Create Items/CompositeItems',
  component: ItemLoader
};

// external config object for the CompositeItems component
const config = {
  fetchItems: async (categoryCodes, excludeIds, callback) => {
    const savedItemList = DummyItems;
    savedItemList[0] = { ...savedItemList[0], ...TCC_THREE?.item };
    savedItemList[1] = { ...savedItemList[1], ...TCC_TWO?.item };
    savedItemList[2] = { ...savedItemList[2], ...MCMS?.item };
    savedItemList[3] = { ...savedItemList[3], ...TF?.item };
    if (categoryCodes.includes('question')) {
      const questions = savedItemList?.filter((item) =>
        item.id && item?.category &&
        excludeIds?.includes(item.id) === false &&
        categoryCodes.includes(item?.category)
      ) || [];
      callback(questions);
    }
  }
}

const Template = (args) => (
  <ItemLoader
    {...args}
    newItem={true}
    data={{
      item: {
        id: -1,
        name: '',
        assessment_program_id: 0,
        item_type_id: 0,
        item_type_code: '',
        item_json: { itemTypeCode: 'COM' },
        user_id: 0
      }
    }}
    config={config}
  ></ItemLoader>
);

export const NewItem = Template.bind({});
