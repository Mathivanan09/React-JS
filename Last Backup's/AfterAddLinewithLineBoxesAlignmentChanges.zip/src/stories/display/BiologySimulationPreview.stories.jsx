import BiologySimulationPreview from '../../components/display/item/biologysimulation/BiologySimulationPreview';

export default {
  title: 'Display Items/BiologySimulationPreview',
  component: BiologySimulationPreview
};
