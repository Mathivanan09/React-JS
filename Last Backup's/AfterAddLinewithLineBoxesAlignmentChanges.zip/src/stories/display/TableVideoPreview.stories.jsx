import TableVideoPreview from '../../components/display/item/tablevideo/TableVideoPreview';

export default {
  title: 'Display Items/TableVideoPreview',
  component: TableVideoPreview,
};
