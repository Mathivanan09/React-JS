import SpeechInteractionPreview from '../../components/display/item/speechinteraction/SpeechInteractionPreview';

export default {
  title: 'Display Items/SpeechInteractionPreview',
  component: SpeechInteractionPreview,
};
