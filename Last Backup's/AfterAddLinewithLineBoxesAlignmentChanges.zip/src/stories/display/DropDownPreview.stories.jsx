import DropDownPreview from '../../components/display/item/dropdown/DropDownPreview';

export default {
  title: 'Display Items/DropDownPreview',
  component: DropDownPreview
};
