import MatrixInteractionPreview from '../../components/display/item/matrixinteraction/MatrixInteractionPreview';

export default {
  title: 'Display Items/MatrixInteractionPreview',
  component: MatrixInteractionPreview
};
