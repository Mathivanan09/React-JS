import LikertScalePreview from '../../components/display/item/likertscale/LikertScalePreview';

export default {
  title: 'Display Items/LikertScalePreview',
  component: LikertScalePreview
};
