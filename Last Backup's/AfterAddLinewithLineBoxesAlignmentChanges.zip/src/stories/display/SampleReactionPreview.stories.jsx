import SampleReactionPreview from '../../components/display/item/samplereaction/SampleReactionPreview';

export default {
  title: 'Display Items/SampleReactionPreview',
  component: SampleReactionPreview,
};
