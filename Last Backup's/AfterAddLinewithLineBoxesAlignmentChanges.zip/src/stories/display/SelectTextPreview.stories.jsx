import SelectTextPreview from '../../components/display/item/selecttext/SelectTextPreview';

export default {
  title: 'Display Items/SelectTextPreview',
  component: SelectTextPreview,
};
