import PlacingPointsPreview from '../../components/display/item/placingpoints/PlacingPointsPreview';

export default {
  title: 'Display Items/PlacingPointsPreview',
  component: PlacingPointsPreview,
};
