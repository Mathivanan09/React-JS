import React from 'react';

import TextStimulusPreview from '../../../components/display/item/textstimulus/TextStimulusPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/KelpaG4/TextStimulus',
    component: TextStimulusPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG4Config = {
    styleCode: 'kelpaG4'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const KelpaG4Template = (args) => (
    <TextStimulusPreview {...args} config={kelpaG4Config} />
);

// Text Stimulus Preview - KelpaG4
export const TSPKelpaG4 = KelpaG4Template.bind({});
TSPKelpaG4.args = require('../../assets/ts/TextStimulus.json');