import React from 'react';

import MatchingLinesPreview from '../../../components/display/item/matchinglines/MatchingLinesPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/KelpaG4/MatchingLines',
    component: MatchingLinesPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG4Config = {
    styleCode: 'kelpaG4'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const KelpaG4Template = (args) => (
    <MatchingLinesPreview {...args} config={kelpaG4Config} />
);

// Matching Lines Preview - KelpaG4
export const MLPKelpaG4 = KelpaG4Template.bind({});
MLPKelpaG4.args = require('../../assets/ml/MatchingLines.json');