import React from 'react';

import MultipleChoicePreview from '../../../components/display/item/multiplechoice/MultipleChoicePreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Display Items/KelpaG4/MultipleChoice',
  component: MultipleChoicePreview,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const kelpaG4Config = {
  styleCode: 'kelpaG4'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const KelpaG4Template = (args) => (
  <MultipleChoicePreview {...args} config={kelpaG4Config} />
);

// Stacked Z alignement - KelpaG4
export const StackedZKelpaG4 = KelpaG4Template.bind({});
StackedZKelpaG4.args = require('../../assets/mc/mc_stackedZ.json');

// RightSideZ alignement - KelpaG4
export const RightSideZKelpaG4 = KelpaG4Template.bind({});
RightSideZKelpaG4.args = require('../../assets/mc/mc_rightsideZ.json');

// RightSideVertical alignement - KelpaG4
export const RightSideVerticalKelpaG4 = KelpaG4Template.bind({});
RightSideVerticalKelpaG4.args = require('../../assets/mc/mc_rightsideVertical.json');

// StackedVertical alignement - KelpaG4
export const StackedVerticalKelpaG4 = KelpaG4Template.bind({});
StackedVerticalKelpaG4.args = require('../../assets/mc/mc_stackedVertical.json');

// StackedHorizontal alignement - KelpaG4
export const StackedHorizontalKelpaG4 = KelpaG4Template.bind({});
StackedHorizontalKelpaG4.args = require('../../assets/mc/mc_stackedHorizontal.json');
