import React from 'react';

import TextStimulusPreview from '../../../components/display/item/textstimulus/TextStimulusPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/Alternate/TextStimulus',
    component: TextStimulusPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const alternateConfig = {
    styleCode: 'alternate'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const AlternateTemplate = (args) => (
    <TextStimulusPreview {...args} config={alternateConfig} />
);

// Text Stimulus Preview - Alternate
export const TSPAlt = AlternateTemplate.bind({});
TSPAlt.args = require('../../assets/ts/TextStimulus.json');