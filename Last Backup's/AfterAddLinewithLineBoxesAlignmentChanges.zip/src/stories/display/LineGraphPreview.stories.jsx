import LineGraphPreview from '../../components/display/item/linegraph/LineGraphPreview';

export default {
  title: 'Display Items/LineGraphPreview',
  component: LineGraphPreview
};
