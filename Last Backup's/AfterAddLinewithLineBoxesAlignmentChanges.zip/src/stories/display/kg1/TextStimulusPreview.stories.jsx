import React from 'react';

import TextStimulusPreview from '../../../components/display/item/textstimulus/TextStimulusPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/KELPA_Grade_K-1/TextStimulus',
    component: TextStimulusPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG1Config = {
    styleCode: 'kelpa_grade_k_1'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG1 = (args) => (
    <TextStimulusPreview {...args} config={kelpaG1Config} />
);

// Text Stimulus Preview - KelpaG1
export const TSPKelpaG1 = TemplateKelpaG1.bind({});
TSPKelpaG1.args = require('../../assets/ts/TextStimulus.json')