import React from 'react';

import MultipleChoicePreview from '../../../components/display/item/multiplechoice/MultipleChoicePreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Display Items/KELPA_Grade_K-1/MultipleChoice',
  component: MultipleChoicePreview,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const kelpaG1Config = {
  styleCode: 'kelpa_grade_k_1'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG1 = (args) => (
  <MultipleChoicePreview {...args} config={kelpaG1Config} />
);

// Stacked Z alignement - KelpaG1
export const StackedZKelpaG1 = TemplateKelpaG1.bind({});
StackedZKelpaG1.args = require('../../assets/mc/mc_stackedZ.json');

// RightSideZ alignement - KelpaG1
export const RightSideZKelpaG1 = TemplateKelpaG1.bind({});
RightSideZKelpaG1.args = require('../../assets/mc/mc_rightsideZ.json');

// RightSideVertical alignement - KelpaG1
export const RightSideVerticalKelpaG1 = TemplateKelpaG1.bind({});
RightSideVerticalKelpaG1.args = require('../../assets/mc/mc_rightsideVertical.json');

// StackedVertical alignement - KelpaG1
export const StackedVerticalKelpaG1 = TemplateKelpaG1.bind({});
StackedVerticalKelpaG1.args = require('../../assets/mc/mc_stackedVertical.json');

// StackedHorizontal alignement - KelpaG1
export const StackedHorizontalKelpaG1 = TemplateKelpaG1.bind({});
StackedHorizontalKelpaG1.args = require('../../assets/mc/mc_stackedHorizontal.json');
