import React from 'react';

import MatchingLinesPreview from '../../../components/display/item/matchinglines/MatchingLinesPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/KELPA_Grade_K-1/MatchingLines',
    component: MatchingLinesPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG1Config = {
    styleCode: 'kelpa_grade_k_1'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const TemplateKelpaG1 = (args) => (
    <MatchingLinesPreview {...args} config={kelpaG1Config} />
);

// Matching Lines Preview - KelpaG1
export const MLPKelpaG1 = TemplateKelpaG1.bind({});
MLPKelpaG1.args = require('../../assets/ml/MatchingLines.json')