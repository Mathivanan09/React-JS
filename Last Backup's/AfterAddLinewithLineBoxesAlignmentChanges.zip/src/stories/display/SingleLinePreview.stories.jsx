import SingleLinePreview from '../../components/display/item/singleline/SingleLinePreview';

export default {
  title: 'Display Items/SingleLinePreview',
  component: SingleLinePreview,
};
