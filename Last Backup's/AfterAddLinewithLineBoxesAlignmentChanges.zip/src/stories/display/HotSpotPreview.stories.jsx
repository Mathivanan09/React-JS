import HotSpotPreview from '../../components/display/item/hotspot/HotSpotPreview';

export default {
  title: 'Display Items/HotSpotPreview',
  component: HotSpotPreview
};
