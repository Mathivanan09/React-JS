import ScatterPlotPreview from '../../components/display/item/scatterplot/ScatterPlotPreview';

export default {
  title: 'Display Items/ScatterPlotPreview',
  component: ScatterPlotPreview,
};
