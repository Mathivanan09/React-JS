import MazeRunnerPreview from '../../components/display/item/mazerunner/MazeRunnerPreview';

export default {
  title: 'Display Items/MazeRunnerPreview',
  component: MazeRunnerPreview
};
