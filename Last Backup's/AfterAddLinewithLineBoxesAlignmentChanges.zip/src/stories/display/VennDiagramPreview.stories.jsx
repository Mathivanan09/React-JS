import VennDiagramPreview from '../../components/display/item/venndiagram/VennDiagramPreview';

export default {
  title: 'Display Items/VennDiagramPreview',
  component: VennDiagramPreview,
};