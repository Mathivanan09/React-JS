import GearsPreview from '../../components/display/item/gears/GearsPreview';

export default {
  title: 'Display Items/GearsPreview',
  component: GearsPreview
};
