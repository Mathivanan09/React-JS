import FirewallPreview from '../../components/display/item/firewall/FirewallPreview';

export default {
  title: 'Display Items/FirewallPreview',
  component: FirewallPreview
};
