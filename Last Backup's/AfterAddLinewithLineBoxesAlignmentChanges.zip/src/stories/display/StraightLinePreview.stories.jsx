import StraightLinePreview from '../../components/display/item/straightline/StraightLinePreview';

export default {
  title: 'Display Items/StraightLinePreview',
  component: StraightLinePreview,
};
