import CompositeItemsPreview from '../../components/display/item/composite/CompositeItemsPreview';

export default {
  title: 'Display Items/CompositeItemsPreview',
  component: CompositeItemsPreview
};
