import ObjectCanvasPreview from '../../components/display/item/objectcanvas/ObjectCanvasPreview';

export default {
  title: 'Display Items/ObjectCanvasPreview',
  component: ObjectCanvasPreview,
};
