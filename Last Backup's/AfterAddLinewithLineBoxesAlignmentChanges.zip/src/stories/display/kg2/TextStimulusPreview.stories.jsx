import React from 'react';

import TextStimulusPreview from '../../../components/display/item/textstimulus/TextStimulusPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/KelpaG2/TextStimulus',
    component: TextStimulusPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG2Config = {
    styleCode: 'kelpaG2'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const KelpaG2Template = (args) => (
    <TextStimulusPreview {...args} config={kelpaG2Config} />
);

// Text Stimulus Preview - KelpaG2
export const TSPKelpaG2 = KelpaG2Template.bind({});
TSPKelpaG2.args = require('../../assets/ts/TextStimulus.json');