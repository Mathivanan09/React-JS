import React from 'react';

import MultipleChoicePreview from '../../../components/display/item/multiplechoice/MultipleChoicePreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Display Items/KelpaG2/MultipleChoice',
  component: MultipleChoicePreview,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

const kelpaG2Config = {
  styleCode: 'kelpaG2'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const KelpaG2Template = (args) => (
  <MultipleChoicePreview {...args} config={kelpaG2Config} />
);

// Stacked Z alignement - KelpaG2
export const StackedZKelpaG2 = KelpaG2Template.bind({});
StackedZKelpaG2.args = require('../../assets/mc/mc_stackedZ.json');

// RightSideZ alignement - KelpaG2
export const RightSideZKelpaG2 = KelpaG2Template.bind({});
RightSideZKelpaG2.args = require('../../assets/mc/mc_rightsideZ.json');

// RightSideVertical alignement - KelpaG2
export const RightSideVerticalKelpaG2 = KelpaG2Template.bind({});
RightSideVerticalKelpaG2.args = require('../../assets/mc/mc_rightsideVertical.json');

// StackedVertical alignement - KelpaG2
export const StackedVerticalKelpaG2 = KelpaG2Template.bind({});
StackedVerticalKelpaG2.args = require('../../assets/mc/mc_stackedVertical.json');

// StackedHorizontal alignement - KelpaG2
export const StackedHorizontalKelpaG2 = KelpaG2Template.bind({});
StackedHorizontalKelpaG2.args = require('../../assets/mc/mc_stackedHorizontal.json');
