import React from 'react';

import MatchingLinesPreview from '../../../components/display/item/matchinglines/MatchingLinesPreview';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: 'Display Items/KelpaG2/MatchingLines',
    component: MatchingLinesPreview,
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
    argTypes: {}
};

const kelpaG2Config = {
    styleCode: 'kelpaG2'
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const KelpaG2Template = (args) => (
    <MatchingLinesPreview {...args} config={kelpaG2Config} />
);

// Matching Lines Preview - KelpaG2
export const MLPKelpaG2 = KelpaG2Template.bind({});
MLPKelpaG2.args = require('../../assets/ml/MatchingLines.json');