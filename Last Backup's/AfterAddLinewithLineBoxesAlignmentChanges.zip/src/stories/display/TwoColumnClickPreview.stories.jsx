import TwoColumnClickPreview from '../../components/display/item/twocolumnclick/TwoColumnClickPreview';

export default {
  title: 'Display Items/TwoColumnClick',
  component: TwoColumnClickPreview
};
