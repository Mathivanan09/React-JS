import { default as React, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import CreateInterface from '../components/create/CreateInterface';
import DisplayInterface from '../components/display/DisplayInterface';

const options = Object.freeze({
  SET_ITEM: 'SET_ITEM',
  HYDRATE_ITEM: 'HYDRATE_ITEM',
  UPDATE_ITEM: 'UPDATE_ITEM'
});

const ItemLoader = ({ newItem, data, config }) => {
  // for new item
  let isNewItem = newItem;

  const item = useSelector((store) => store.item); // item comes from Redux item reducer
  const dispatch = useDispatch();

  const hydrateItem = () =>
    dispatch({ type: options.HYDRATE_ITEM, payload: data.item });
  // hydrate item with new data if necessary using saga

  const setItem = () =>
    dispatch({ type: options.SET_ITEM, payload: data.item });
  // hydrate item with new data if necessary using saga

  useEffect(() => {
    if (isNewItem) {
      hydrateItem();
    } else {
      setItem();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNewItem]);

  // This will be the main dispatch to pass to external components
  // This updates the item.item_json attributes
  const updateItem = (payload) => {
    // Payload object updates Redux item with payload properties
    dispatch({ type: options.UPDATE_ITEM, payload });
  };

  return (
    <>
      <div className=''>
        {isNewItem && (
          <CreateInterface item={item} onUpdate={updateItem} config={config} />
        )}

        {!isNewItem && (
          <DisplayInterface
            item={item}
            onUpdate={updateItem}
            config={config}
            clickHistory={{}}
          />
        )}
      </div>
    </>
  );
};

ItemLoader.propTypes = {
  newItem: PropTypes.bool,
  data: PropTypes.object,
  config: PropTypes.object
};

export default ItemLoader;
