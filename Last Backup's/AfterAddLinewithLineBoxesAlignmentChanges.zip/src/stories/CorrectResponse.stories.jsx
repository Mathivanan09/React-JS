/* eslint-disable */
import React from 'react';
import DisplayResponse from '../components/display/response/constructedresponse/DisplayResponse';
import editItem from '../stories/assets/cr/ConstructedResponse.json';

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: 'Shared/DisplayResponse',
  component: DisplayResponse,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {}
};

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template = (args) => <DisplayResponse {...args} />;

export const CRCorrectResponse = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
CRCorrectResponse.args = {
  item: editItem.item,
  showCorrectResponse: true,
  isPreview: true
};
