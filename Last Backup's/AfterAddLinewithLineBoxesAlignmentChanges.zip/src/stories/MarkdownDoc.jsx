import React from 'react';
import PropTypes from 'prop-types';
import ReactMarkdown from 'react-markdown';
import {
  Title,
  Subtitle,
  Description,
  Primary,
  ArgsTable,
  Stories,
  PRIMARY_STORY
} from '@storybook/addon-docs';

const MarkdownDoc = ({ markdown }) => {
  return (
    <>
      <Title />
      <Subtitle />
      <Description />
      <Primary />
      <ArgsTable story={PRIMARY_STORY} />
      <Stories />
      <ReactMarkdown>{markdown}</ReactMarkdown>
    </>
  );
};

MarkdownDoc.propTypes = {
  markdown: PropTypes.string.isRequired
};

export default MarkdownDoc;
