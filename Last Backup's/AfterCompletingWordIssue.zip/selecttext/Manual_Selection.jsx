/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react';
import parse from "html-react-parser";
import PropTypes from 'prop-types';
import { CLASS } from "./constants";

/**
 * React functional component which renders Paragraph selection based on selection type.
 * @inner
 * @memberof SharedComponents
 *
 * @component
 * @namespace Manual_Selection
 *
 * @function Manual_Selection - React functional container component for Manual Selection selectionType
 * @param {object} item - JSON data that will contain the item information
 * for displaying select text item
 * @param {object} divUUID - Id for the div to be rendered
 * @param {boolean} showCorrectResponse -  display Correct Response checkbox value
 * @param {object} buildCorrectResponse - Build correct response for the passage content written based on selection type choosed
 * @param {function} getClassName - return the class names based on id
 * @return {component} - container for Manual selection of passage content
 *
 */
const Manual_Selection = ({
  item,
  divUUID,
  showCorrectResponse,
  buildCorrectResponse,
  getClassName,
}) => {

  const content = item?.item_json || {};
  const [parsedPassageContent, setParsedPassageContent] = useState(item?.item_json.passageContent);

  useEffect(() => {
    correctResponseHighlight();
    // eslint-disable-next-line
  }, [content, showCorrectResponse]);

  useEffect(() => {
    const container = document.getElementById(divUUID);
    if (container !== undefined) {
      container.querySelectorAll("span.cked-highlight").forEach(span => {
        if (span?.id) {
          span.className = getClassName(span.id) + ' cked-highlight';
          span.removeAttribute('style');
          span.onclick = buildCorrectResponse;
        }
      });
    }
  });

  const correctResponseHighlight = () => {
    let updatedPassageContent = item.item_json.passageContent;
    if (updatedPassageContent && content.optionList.length > 0) {
      const parser = new DOMParser();
      const doc = parser.parseFromString(item?.item_json?.passageContent, "text/html");
      for (let i = 0; i < content.optionList.length; i++) {
        /* Get all the span tag which are all created for manually selected content
        and adding the classes for highlight in the same span */
        if (doc.querySelectorAll("span.cked-highlight")[i] !== undefined) {
          doc.querySelectorAll("span.cked-highlight")[i].setAttribute(CLASS, getClassName(content.optionList[i].id) + ' cked-highlight');
          updatedPassageContent = doc?.documentElement?.querySelector('body')?.innerHTML || '';
        }
      }


  /* Removing all span styles for avoiding the new line which is created during the selection of new Word using SelectResponse */
      let paraTag = doc.querySelectorAll('p');
      let finalContent = "";
      let paraStyle = "";
      for (let j = 0; j < paraTag.length; j++) {
        let tagName = paraTag[j].firstChild.nodeName;
        let spanTag = paraTag[j].querySelector(`${tagName}`);
        let firstSpanStyle = spanTag.getAttribute('style');
        paraStyle = paraTag[j].getAttribute('style');
        paraStyle+="text-align:center;"
        paraStyle = JSON.stringify(paraStyle + firstSpanStyle);
        let anoTest = paraTag[j].innerHTML.trim();
        const parser = new DOMParser();
        const testing = parser.parseFromString(anoTest, "text/html");

        finalContent += `<p style=${paraStyle}>` + testing.querySelector('span').innerHTML + "</p>";
      }

      let removeTry=parser.parseFromString(finalContent, "text/html");
      if(removeTry.querySelectorAll('span.cked-highlight').length > 0){
        for(let j=0;j<removeTry.querySelectorAll('span').length;j++){
         removeTry.querySelectorAll('span')[j].removeAttribute('style');
         finalContent=removeTry.querySelector('body').innerHTML;
        }
      }
      updatedPassageContent = `<div>` + finalContent + "</div>";
    }


    if (updatedPassageContent !== parsedPassageContent) {
      setParsedPassageContent(updatedPassageContent);
    }
  };

  return (
    <div id={divUUID} >
      {console.log(parsedPassageContent)}
      <div className='row item-content m-1 mt-4 p-4 content_style'>{parse(parsedPassageContent || '<div></div>')}</div>
    </div>
  );
};

Manual_Selection.propTypes = {
  item: PropTypes.object,
  divUUID: PropTypes.string,
  showCorrectResponse: PropTypes.bool,
  buildCorrectResponse: PropTypes.func,
  getClassName: PropTypes.func
};

export default Manual_Selection;
